import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
export function RevisionList({ revisions, compareLoadedRevisions = false, sortLoadedRevisions = false, onCompareRevisions }) {
    const [selectedIds, setSelectedIds] = useState([]);
    const [selectedOrder, setSelectedOrder] = useState("");
    const orderId = useId().replaceAll(":", "");
    const enabled = compareLoadedRevisions && typeof onCompareRevisions === "function";
    const loadedIds = new Set(revisions.map((revision) => revision.id));
    const currentSelection = enabled ? selectedIds.filter((id) => loadedIds.has(id)) : [];
    useEffect(() => {
        setSelectedIds((prior) => {
            const next = enabled ? prior.filter((id) => loadedIds.has(id)).slice(0, 2) : [];
            return next.length === prior.length && next.every((id, i) => id === prior[i]) ? prior : next;
        });
    }, [revisions, enabled]);
    if (!revisions.length) {
        return _jsx(EmptyState, { title: "No revisions", description: "No revision history is available from the product adapter." });
    }
    // Order only the already-authorized product page by actual timestamp instants.
    // Invalid/missing timestamps are last in either direction; equal instants
    // keep adapter ordering, never implying backend chronology or version authority.
    const ordered = sortLoadedRevisions && selectedOrder
        ? [...revisions].sort((a, b) => {
            const left = Date.parse(a.timestamp);
            const right = Date.parse(b.timestamp);
            const leftValid = Number.isFinite(left);
            const rightValid = Number.isFinite(right);
            if (!leftValid || !rightValid) {
                return leftValid === rightValid ? 0 : leftValid ? -1 : 1;
            }
            return selectedOrder === "newest" ? right - left : left - right;
        })
        : revisions;
    const sortControl = sortLoadedRevisions ? (_jsxs("div", { className: "dr-admin__revision-order", children: [_jsx("label", { htmlFor: orderId + "-order", children: "Order loaded revisions" }), _jsxs("select", { id: orderId + "-order", value: selectedOrder, onChange: (event) => setSelectedOrder(event.target.value), children: [_jsx("option", { value: "", children: "Adapter order" }), _jsx("option", { value: "newest", children: "Newest loaded first" }), _jsx("option", { value: "oldest", children: "Oldest loaded first" })] })] })) : null;
    const list = (_jsx("ol", { className: "dr-admin__revision-list", "aria-label": "Revision history", children: ordered.map((revision) => (_jsxs("li", { className: "dr-admin__revision", children: [_jsxs("div", { className: "dr-admin__revision-title", children: [_jsx("strong", { children: revision.label ?? revision.id }), revision.current ? _jsx(StatusBadge, { tone: "success", children: "Current" }) : null] }), _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Time" }), _jsx("dd", { children: revision.timestamp })] }), revision.actor ? _jsxs("div", { children: [_jsx("dt", { children: "Actor" }), _jsx("dd", { children: revision.actor })] }) : null, revision.audit ? _jsxs("div", { children: [_jsx("dt", { children: "Audit" }), _jsx("dd", { children: revision.audit.label ?? revision.audit.id })] }) : null] }), revision.summary ? _jsx("p", { children: revision.summary }) : null, enabled ? (_jsxs("label", { className: "dr-admin__revision-checkbox", children: [_jsx("input", { type: "checkbox", "aria-label": "Select revision " + (revision.label ?? revision.id) + " for comparison", checked: currentSelection.includes(revision.id), disabled: !currentSelection.includes(revision.id) && currentSelection.length >= 2, onChange: (event) => {
                                const id = revision.id;
                                setSelectedIds((prior) => {
                                    const valid = prior.filter((candidate) => loadedIds.has(candidate));
                                    if (!event.target.checked)
                                        return valid.filter((candidate) => candidate !== id);
                                    if (!loadedIds.has(id) || valid.includes(id) || valid.length >= 2)
                                        return valid;
                                    return [...valid, id];
                                });
                            } }), _jsx("span", { children: "Include in comparison" })] })) : null] }, revision.id))) }));
    if (!enabled && !sortLoadedRevisions)
        return list;
    if (!enabled)
        return _jsxs("div", { className: "dr-admin__revision-order-layout", children: [sortControl, list] });
    return (_jsxs("div", { className: "dr-admin__revision-compare", children: [sortControl, list, _jsxs("p", { role: "status", "aria-live": "polite", children: ["Selected ", currentSelection.length, " of 2 loaded revisions for comparison"] }), _jsx(Button, { type: "button", variant: "secondary", disabled: currentSelection.length !== 2, onClick: () => {
                    if (currentSelection.length !== 2 || !onCompareRevisions)
                        return;
                    const [first, second] = currentSelection;
                    if (!first || !second || first === second || !loadedIds.has(first) || !loadedIds.has(second))
                        return;
                    onCompareRevisions(first, second);
                }, children: "Compare selected revisions" })] }));
}
