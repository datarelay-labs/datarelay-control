"""Common portable JSON export/import lifecycle, not database disaster recovery.

Configuration entities keep their existing product-defined format. Foundation
owns bounds, authority, intent binding, idempotency, atomic audit and read-back.
The native interpreter maps its existing additive/clone semantics and redaction;
no replacement import mode, production database or file/network effect is added.
The native HTTP layer also bounds raw request bytes before JSON decoding; parsed
values cannot reveal how much discarded whitespace arrived over the transport.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from hashlib import sha256
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import json
import math
import time
import unicodedata

from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict

MAX_WORKSPACE_BYTES = 5 * 1024 * 1024


class WorkspaceTransferUnverified(RuntimeError):
    """Reconcile the same native operation; never assume another import is safe."""


def _ref(value: object) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 256 or any(c.isspace() or unicodedata.category(c).startswith('C') for c in value):
        raise SettingsValidationError('A current native reference is required.')
    return value


def _time(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402300000:
        raise SettingsValidationError('Invalid native clock evidence.')
    return float(value)


def _json_bytes(value: object, *, envelope: bool = False) -> bytes:
    if not isinstance(value, dict) or not value:
        raise SettingsValidationError('Workspace JSON must be a nonempty object.')
    stack = [(value, 0)]; count = 0
    while stack:
        item, depth = stack.pop(); count += 1
        if count > 100000 + (8 if envelope else 0) or depth > 64 + (1 if envelope else 0):
            raise SettingsValidationError('Workspace JSON is too complex.')
        if isinstance(item, dict):
            if count + len(stack) + len(item) > 100000 + (8 if envelope else 0):
                raise SettingsValidationError('Workspace JSON is too complex.')
            if any(not isinstance(key, str) or len(key) > MAX_WORKSPACE_BYTES for key in item):
                raise SettingsValidationError('Workspace JSON keys must be strings.')
            stack.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            if count + len(stack) + len(item) > 100000 + (8 if envelope else 0):
                raise SettingsValidationError('Workspace JSON is too complex.')
            stack.extend((child, depth + 1) for child in item)
        elif type(item) is str:
            if len(item) > MAX_WORKSPACE_BYTES:
                raise SettingsValidationError('Workspace JSON exceeds the 5 MiB limit.')
        elif item is None or type(item) is bool:
            pass
        elif type(item) is int:
            if not -(2**53 - 1) <= item <= 2**53 - 1:
                raise SettingsValidationError('Workspace integers must preserve JSON wire precision.')
        elif type(item) is float:
            if not math.isfinite(item):
                raise SettingsValidationError('Workspace numbers must be finite.')
        else:
            raise SettingsValidationError('Workspace payload must contain JSON values only.')
    try:
        result = json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise SettingsValidationError('Workspace payload is not portable JSON.') from None
    if len(result) > MAX_WORKSPACE_BYTES + (1024 if envelope else 0):
        raise SettingsValidationError('Workspace JSON exceeds the 5 MiB limit.')
    return result


def _digest(value: dict[str, Any], *, envelope: bool = False) -> str:
    return sha256(_json_bytes(value, envelope=envelope)).hexdigest()


def _intent(request: object) -> dict[str, Any]:
    if not isinstance(request, Mapping) or request.get('mode') not in ('additive', 'clone'):
        raise SettingsValidationError('Only additive and clone import are supported.')
    keys = {'bundle', 'mode'} | ({'cloneSuffix'} if request['mode'] == 'clone' else set())
    if set(request) != keys:
        raise SettingsValidationError('Submit only bundle, mode and the required clone suffix.')
    _json_bytes(request['bundle'])
    if request['mode'] == 'clone':
        suffix = request['cloneSuffix']
        if (not isinstance(suffix, str) or not suffix.strip() or len(suffix) > 80
                or any(unicodedata.category(c).startswith('C') for c in suffix)):
            raise SettingsValidationError('Enter a clone suffix of 1–80 characters without controls.')
    return deepcopy(dict(request))


@dataclass(frozen=True)
class WorkspaceSnapshot:
    revision: str
    value: dict[str, Any]


@dataclass(frozen=True)
class WorkspaceReadiness:
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    rollback_ready: bool = False

    def __post_init__(self) -> None:
        if any(type(v) is not bool for v in vars(self).values()):
            raise SettingsValidationError('Readiness requires actual native Boolean evidence.')

    @property
    def safe(self) -> bool:
        return all(vars(self).values())


@dataclass(frozen=True)
class WorkspaceImportAnalysis:
    value: dict[str, Any]
    counts: list[dict[str, Any]]
    conflicts: list[str]
    warnings: list[str]
    non_destructive: bool = False


@dataclass(frozen=True)
class WorkspaceExportProjection:
    bundle: dict[str, Any]
    redaction_verified: bool = False


@dataclass(frozen=True)
class WorkspaceExportArtifact:
    content: bytes
    filename: str
    audit_reference: str
    redacted: bool = True


@dataclass(frozen=True)
class WorkspaceImportPlan:
    reference: str
    actor: str
    revision: str
    intent_digest: str
    source_digest: str
    analysis: WorkspaceImportAnalysis
    mode: str
    created_at: float
    expires_at: float
    safe: bool


@dataclass(frozen=True)
class WorkspaceImportOperation:
    actor: str
    key: str
    preview_ref: str
    expected_revision: str
    intent_digest: str
    mode: str
    audit_ref: str
    after_revision: str = ''


@dataclass(frozen=True)
class WorkspaceDecision:
    value: dict[str, Any] | None
    event: dict[str, Any] | None
    operation: WorkspaceImportOperation | None = None
    preview_ref: str | None = None
    replay: bool = False


@dataclass(frozen=True)
class WorkspaceCommitResult:
    snapshot: WorkspaceSnapshot
    operation: WorkspaceImportOperation | None = None


class WorkspaceInterpreter(Protocol):
    """Bind existing product-specific entity format, not another transfer lifecycle.

    Both methods are pure projections over detached native snapshots. They must
    enforce the actor's resource scope and product schema; never send requests,
    run scripts, import entities or modify storage. inspect_import maps existing
    additive/clone semantics into the proposed configuration and reports public,
    secret-free counts/conflicts/warnings. It may assert non_destructive only
    after proving the proposed operation preserves existing protected entities.
    export_workspace masks secrets using the product's actual secret inventory;
    redaction_verified is true only after native policy scans the final bundle.
    Never infer safety from client flags, field-name guessing or sample fixtures.
    """
    def inspect_import(self, actor: SettingsActor, current: Mapping[str, Any], bundle: Mapping[str, Any],
                       mode: str, clone_suffix: str | None) -> WorkspaceImportAnalysis: ...
    def export_workspace(self, actor: SettingsActor, current: Mapping[str, Any],
                         options: Mapping[str, bool]) -> WorkspaceExportProjection: ...


class WorkspaceStore(Protocol):
    """Existing native transactional storage; no new common production database.

    Every configuration/format/policy change must advance the workspace revision.
    Plans contain restricted internal proposed configuration and must never be
    exposed via a public read endpoint. transact locks the current configuration,
    plans and idempotency records before calling build exactly once. Native
    current authorization participates in the same transaction. Commit content,
    durable rollback snapshot, audit and completed operation atomically or write
    nothing. Fill after_revision from the actual committed revision and consume
    the preview. Replay must compare exact stored actor/intent and add no audit
    or configuration write. Return detached data. Lost responses are reconciled
    by read_operation; do not auto-retry the transaction callback.
    """
    def read(self) -> WorkspaceSnapshot: ...
    def register_plan(self, plan: WorkspaceImportPlan) -> None: ...
    def read_operation(self, key: str) -> WorkspaceImportOperation | None: ...
    def read_audit(self, audit_reference: str) -> Mapping[str, Any] | None: ...
    def transact(self, build: Callable[[WorkspaceSnapshot, Mapping[str, WorkspaceImportPlan],
                 Mapping[str, WorkspaceImportOperation]], WorkspaceDecision]) -> WorkspaceCommitResult: ...


class MemoryWorkspaceStore:
    """Synthetic reference with reversible snapshots, never native import/restore."""
    def __init__(self, value: dict[str, Any]) -> None:
        _json_bytes(value)
        self._value = deepcopy(value); self._version = 1; self._lock = RLock()
        self._plans: dict[str, WorkspaceImportPlan] = {}; self._operations: dict[str, WorkspaceImportOperation] = {}
        self._audit: list[dict[str, Any]] = []; self._rollback: dict[str, dict[str, Any]] = {}

    def read(self) -> WorkspaceSnapshot:
        with self._lock:
            return WorkspaceSnapshot('workspace-' + str(self._version), deepcopy(self._value))

    def register_plan(self, plan: WorkspaceImportPlan) -> None:
        with self._lock:
            if plan.revision != self.read().revision:
                raise SettingsRevisionConflict('Workspace changed while preparing the preview.')
            self._plans = {k: v for k, v in self._plans.items() if v.expires_at > plan.created_at}
            size = len(_json_bytes(plan.analysis.value)) + sum(len(_json_bytes(p.analysis.value)) for p in self._plans.values())
            if len(self._plans) >= 256 or size > 32 * 1024 * 1024:
                raise SettingsValidationError('Workspace preview capacity exceeded.')
            self._plans[plan.reference] = deepcopy(plan)

    def read_operation(self, key: str) -> WorkspaceImportOperation | None:
        with self._lock:
            return deepcopy(self._operations.get(key))

    def read_audit(self, audit_reference: str) -> Mapping[str, Any] | None:
        with self._lock:
            return deepcopy(next((e for e in self._audit if e['id'] == audit_reference), None))

    def transact(self, build: Callable[[WorkspaceSnapshot, Mapping[str, WorkspaceImportPlan],
                 Mapping[str, WorkspaceImportOperation]], WorkspaceDecision]) -> WorkspaceCommitResult:
        with self._lock:
            before = self.read(); decision = build(before, deepcopy(self._plans), deepcopy(self._operations))
            if not isinstance(decision, WorkspaceDecision):
                raise SettingsValidationError('Invalid workspace transaction decision.')
            if decision.replay:
                operation = decision.operation
                if (operation is None or self._operations.get(operation.key) != operation
                        or decision.value is not None or decision.event is not None):
                    raise SettingsRevisionConflict('Workspace replay does not match its stored operation.')
                return WorkspaceCommitResult(before, deepcopy(operation))
            event = deepcopy(decision.event)
            if not isinstance(event, dict):
                raise SettingsValidationError('Atomic workspace audit is required.')
            _ref(event.get('id'))
            operation = deepcopy(decision.operation)
            if decision.value is None:
                if operation is not None:
                    raise SettingsValidationError('Import requires an actual configuration commit.')
                self._audit.append(event)
                return WorkspaceCommitResult(before)
            _json_bytes(decision.value); next_value = deepcopy(decision.value)
            plan = self._plans.get(decision.preview_ref)
            if (not isinstance(operation, WorkspaceImportOperation) or plan is None
                    or operation.key in self._operations or operation.actor != plan.actor
                    or operation.preview_ref != plan.reference or operation.expected_revision != before.revision
                    or operation.audit_ref != event['id'] or plan.revision != before.revision
                    or next_value != plan.analysis.value):
                raise SettingsRevisionConflict('Import transaction no longer matches the native plan.')
            if len(self._operations) >= 10000:
                raise SettingsValidationError('Native import operation capacity exceeded.')
            committed = replace(operation, after_revision='workspace-' + str(self._version + 1))
            # Validate all data before the first effect, then commit as one locked unit.
            self._rollback[operation.key] = deepcopy(before.value)
            self._value = next_value; self._version += 1; self._audit.append(event)
            self._operations[operation.key] = committed; self._plans.clear()
            return WorkspaceCommitResult(self.read(), deepcopy(committed))

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class WorkspaceTransferService:
    def __init__(self, store: WorkspaceStore, interpreter: WorkspaceInterpreter, *,
                 authorize: Callable[[SettingsActor, str], bool],
                 readiness: Callable[[SettingsActor], WorkspaceReadiness],
                 clock: Callable[[], float] = time.time) -> None:
        if not callable(authorize) or not callable(readiness):
            raise SettingsValidationError('Current native authority and readiness are required.')
        self.store = store; self.interpreter = interpreter; self.authorize = authorize
        self.readiness = readiness; self.clock = clock

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            permitted = isinstance(actor, SettingsActor) and permission in actor.capabilities and self.authorize(actor, permission) is True
        except Exception:
            permitted = False
        if not permitted:
            raise SettingsPermissionError('Native actor does not currently authorize this workspace operation.')

    def _snapshot(self) -> WorkspaceSnapshot:
        snapshot = self.store.read()
        if not isinstance(snapshot, WorkspaceSnapshot):
            raise SettingsValidationError('Invalid native workspace snapshot.')
        _ref(snapshot.revision); _json_bytes(snapshot.value)
        return WorkspaceSnapshot(snapshot.revision, deepcopy(snapshot.value))

    def _ready(self, actor: SettingsActor, *, require_safe: bool = True) -> WorkspaceReadiness:
        try:
            ready = self.readiness(actor)
        except Exception:
            raise SettingsPermissionError('Native workspace readiness is unavailable.') from None
        if not isinstance(ready, WorkspaceReadiness):
            raise SettingsValidationError('Invalid native workspace readiness.')
        if require_safe and not ready.safe:
            raise SettingsPermissionError('Current MFA, audit and rollback readiness are required.')
        return ready

    @staticmethod
    def _analysis(value: object) -> WorkspaceImportAnalysis:
        if not isinstance(value, WorkspaceImportAnalysis) or type(value.non_destructive) is not bool:
            raise SettingsValidationError('Invalid native import analysis.')
        _json_bytes(value.value)
        if (not isinstance(value.counts, list) or len(value.counts) > 128
                or any(not isinstance(c, dict) or set(c) != {'label', 'count'}
                       or not isinstance(c['label'], str) or not 0 < len(c['label']) <= 120
                       or type(c['count']) is not int or not 0 <= c['count'] <= 2**53 - 1 for c in value.counts)):
            raise SettingsValidationError('Invalid native import counts.')
        for strings in (value.conflicts, value.warnings):
            if not isinstance(strings, list) or len(strings) > 200 or any(not isinstance(s, str) or not 0 < len(s) <= 2048 for s in strings):
                raise SettingsValidationError('Invalid native public import explanation.')
        return deepcopy(value)

    def preview_import(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'workspace.import.preview'); intent = _intent(request); before = self._snapshot()
        try:
            analysis = self._analysis(self.interpreter.inspect_import(actor, deepcopy(before.value),
                deepcopy(intent['bundle']), intent['mode'], intent.get('cloneSuffix')))
        except Exception:
            raise SettingsValidationError('Native workspace schema or scope rejected the import preview.') from None
        ready = self._ready(actor, require_safe=False); self._require(actor, 'workspace.import.preview')
        now = _time(self.clock()); changes_pending = analysis.value != before.value
        allowed = ready.safe and analysis.non_destructive and not analysis.conflicts and changes_pending
        plan = WorkspaceImportPlan('workspace-preview-' + uuid4().hex, actor.subject, before.revision,
            _digest(intent, envelope=True), _digest(before.value), analysis, intent['mode'], now, now + 300, bool(allowed))
        self.store.register_plan(plan)
        warnings = analysis.warnings if analysis.non_destructive else ['Native preservation of existing configuration is not verified.']
        if not changes_pending and not analysis.conflicts:
            warnings = [*warnings, 'No configuration changes are pending.']
        return {'previewRef': plan.reference, 'expectedRevision': plan.revision, 'mode': plan.mode,
                'expiresAt': datetime.fromtimestamp(plan.expires_at, timezone.utc).isoformat(), 'ok': plan.safe,
                'counts': analysis.counts, 'conflicts': analysis.conflicts, 'warnings': warnings,
                'actorAuthorized': True, 'recentMfaVerified': ready.recent_mfa_verified,
                'auditReady': ready.audit_ready, 'rollbackReady': ready.rollback_ready}

    @staticmethod
    def _receipt(operation: WorkspaceImportOperation, actor: SettingsActor, key: str) -> dict[str, Any]:
        if not isinstance(operation, WorkspaceImportOperation):
            raise WorkspaceTransferUnverified('Native import operation is not verified.')
        if operation.actor != actor.subject:
            raise SettingsPermissionError('This native import operation is not authorized.')
        if operation.key != key:
            raise WorkspaceTransferUnverified('Native operation identity does not match.')
        for reference in (operation.key, operation.preview_ref, operation.expected_revision,
                          operation.after_revision, operation.audit_ref):
            _ref(reference)
        if operation.mode not in ('additive', 'clone') or operation.after_revision == operation.expected_revision:
            raise WorkspaceTransferUnverified('Native import completion is not verified.')
        return {'idempotencyKey': operation.key, 'previewRef': operation.preview_ref, 'mode': operation.mode,
                'status': 'completed', 'afterRevision': operation.after_revision, 'auditReference': operation.audit_ref}

    def _audit_proof(self, operation: WorkspaceImportOperation) -> None:
        event = self.store.read_audit(operation.audit_ref)
        expected = {'id': operation.audit_ref, 'actor': operation.actor,
                    'action': 'workspace.import.completed', 'operation': operation.key,
                    'expectedRevision': operation.expected_revision, 'intentDigest': operation.intent_digest}
        if not isinstance(event, Mapping) or any(event.get(k) != v for k, v in expected.items()):
            raise WorkspaceTransferUnverified('Native import audit was not independently persisted.')

    def read_import(self, actor: SettingsActor, key: str) -> dict[str, Any] | None:
        self._require(actor, 'workspace.import.read'); _ref(key)
        result = self.store.read_operation(key); self._require(actor, 'workspace.import.read')
        if result is None:
            return None
        receipt = self._receipt(result, actor, key); self._audit_proof(result)
        return receipt

    @staticmethod
    def _event(actor: SettingsActor, action: str, timestamp: float, **metadata: Any) -> dict[str, Any]:
        return {'id': 'workspace-audit-' + uuid4().hex, 'actor': actor.subject, 'action': action,
                'timestamp': timestamp, **metadata}

    def apply_import(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'workspace.import.apply'); self._require(actor, 'workspace.import.read')
        if not isinstance(request, Mapping):
            raise SettingsValidationError('Invalid workspace import request.')
        intent_keys = {'bundle', 'mode'} | ({'cloneSuffix'} if request.get('mode') == 'clone' else set())
        if set(request) != intent_keys | {'previewRef', 'expectedRevision', 'idempotencyKey', 'confirm'} or request['confirm'] is not True:
            raise SettingsValidationError('A complete reviewed import and explicit confirmation are required.')
        intent = _intent({k: request[k] for k in intent_keys}); digest = _digest(intent, envelope=True)
        key, preview_ref, expected = (_ref(request[k]) for k in ('idempotencyKey', 'previewRef', 'expectedRevision'))
        proposed: dict[str, Any] | None = None

        def build(current: WorkspaceSnapshot, plans: Mapping[str, WorkspaceImportPlan],
                  operations: Mapping[str, WorkspaceImportOperation]) -> WorkspaceDecision:
            nonlocal proposed
            self._require(actor, 'workspace.import.apply'); self._require(actor, 'workspace.import.read')
            existing = operations.get(key)
            if existing is not None:
                self._receipt(existing, actor, key)
                if (existing.intent_digest != digest or existing.preview_ref != preview_ref
                        or existing.expected_revision != expected or existing.mode != intent['mode']):
                    raise SettingsRevisionConflict('Idempotency key is already bound to another import intent.')
                return WorkspaceDecision(None, None, existing, replay=True)
            if current.revision != expected:
                raise SettingsRevisionConflict('Workspace changed after the reviewed preview.')
            plan = plans.get(preview_ref)
            if not isinstance(plan, WorkspaceImportPlan):
                raise SettingsValidationError('A stored native import preview is required.')
            if plan.actor != actor.subject:
                raise SettingsPermissionError('This native import preview is not authorized.')
            now = _time(self.clock())
            if (plan.revision != expected or plan.reference != preview_ref or plan.intent_digest != digest
                    or plan.mode != intent['mode'] or plan.safe is not True or not plan.created_at <= now < plan.expires_at):
                raise SettingsValidationError('Import preview is mismatched, blocked or expired.')
            if _digest(current.value) != plan.source_digest:
                raise SettingsRevisionConflict('Native configuration changed without a matching workspace revision.')
            analysis = self._analysis(plan.analysis)
            if not analysis.non_destructive or analysis.conflicts:
                raise SettingsValidationError('The native import does not preserve existing configuration safely.')
            self._ready(actor); self._require(actor, 'workspace.import.apply')
            # Readiness may be slow. Expiry is checked once more before committing.
            if not plan.created_at <= _time(self.clock()) < plan.expires_at:
                raise SettingsValidationError('Import preview expired during native readiness verification.')
            event = self._event(actor, 'workspace.import.completed', now,
                operation=key, expectedRevision=expected, intentDigest=digest)
            proposed = deepcopy(analysis.value)
            operation = WorkspaceImportOperation(actor.subject, key, preview_ref, expected, digest,
                intent['mode'], event['id'])
            return WorkspaceDecision(proposed, event, operation, preview_ref)

        try:
            result = self.store.transact(build)
        except (SettingsValidationError, SettingsPermissionError, SettingsRevisionConflict):
            raise
        except Exception:
            raise WorkspaceTransferUnverified('Import status is unknown. Read the same operation identifier before another action.') from None
        if not isinstance(result, WorkspaceCommitResult) or result.operation is None:
            raise WorkspaceTransferUnverified('Native import commit did not provide an operation receipt.')
        receipt = self._receipt(result.operation, actor, key)
        self._require(actor, 'workspace.import.read')
        persisted = self.store.read_operation(key)
        if persisted != result.operation:
            raise WorkspaceTransferUnverified('Native import receipt was not independently persisted.')
        self._audit_proof(persisted)
        if proposed is not None:
            observed = self._snapshot()
            if (result.snapshot.revision != receipt['afterRevision'] or result.snapshot.value != proposed
                    or observed.revision != receipt['afterRevision'] or observed.value != proposed):
                raise WorkspaceTransferUnverified('Imported configuration read-back is unverified. Reconcile the same operation.')
        return receipt

    def export_workspace(self, actor: SettingsActor, options: Mapping[str, Any]) -> WorkspaceExportArtifact:
        self._require(actor, 'workspace.export')
        if (not isinstance(options, Mapping) or set(options) != {'includeCheckpoints', 'includeDestinations'}
                or any(type(v) is not bool for v in options.values())):
            raise SettingsValidationError('Workspace export requires explicit Boolean include options.')
        before = self._snapshot(); original_digest = _digest(before.value)
        try:
            projection = self.interpreter.export_workspace(actor, deepcopy(before.value), dict(options))
        except Exception:
            raise SettingsValidationError('Native workspace export or redaction failed.') from None
        if not isinstance(projection, WorkspaceExportProjection) or projection.redaction_verified is not True:
            raise SettingsValidationError('Native export redaction must be verified before downloading.')
        content = _json_bytes(projection.bundle); event = self._event(actor, 'workspace.exported', _time(self.clock()),
            expectedRevision=before.revision, contentDigest=sha256(content).hexdigest())

        def build(current: WorkspaceSnapshot, plans: Mapping[str, WorkspaceImportPlan],
                  operations: Mapping[str, WorkspaceImportOperation]) -> WorkspaceDecision:
            self._require(actor, 'workspace.export')
            ready = self._ready(actor, require_safe=False)
            if not ready.audit_ready:
                raise SettingsPermissionError('Native export audit is not ready.')
            if current.revision != before.revision or _digest(current.value) != original_digest:
                raise SettingsRevisionConflict('Workspace changed during export redaction.')
            self._require(actor, 'workspace.export')
            return WorkspaceDecision(None, event)

        try:
            result = self.store.transact(build)
        except (SettingsValidationError, SettingsPermissionError, SettingsRevisionConflict):
            raise
        except Exception:
            raise WorkspaceTransferUnverified('Workspace export audit was not verified; no artifact is released.') from None
        self._require(actor, 'workspace.export')
        if (not isinstance(result, WorkspaceCommitResult) or result.snapshot != before
                or self.store.read_audit(event['id']) != event):
            raise WorkspaceTransferUnverified('Workspace export snapshot or audit was not independently verified.')
        return WorkspaceExportArtifact(content, 'foundation-workspace.json', event['id'])
