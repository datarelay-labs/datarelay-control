import type { RevisionProjection } from "@datarelay-labs/system-contracts";
export type RevisionListProps = {
    revisions: readonly RevisionProjection[];
    /** Opt-in to selecting two already-loaded revisions. No diff/restore is performed here. */
    compareLoadedRevisions?: boolean;
    /** Independent default-off chronological ordering of product-provided revisions only. */
    sortLoadedRevisions?: boolean;
    /** Consumer-owned authorization and comparison; receives IDs in selection order. */
    onCompareRevisions?: (firstRevisionId: string, secondRevisionId: string) => void;
};
export declare function RevisionList({ revisions, compareLoadedRevisions, sortLoadedRevisions, onCompareRevisions }: RevisionListProps): import("react").JSX.Element;
