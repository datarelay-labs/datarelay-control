"""Common account and password workflows over native identity/storage ports.

No database, HTTP route, password algorithm or live account is installed here.
Products bind their existing hasher, current authorization and atomic transaction.
MemoryUserStore is a development-only reference, never an authentication backend.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import time
import unicodedata

from .session_policy import PasswordPolicy, evaluate_new_password
from .timezone_service import (
    SettingsActor, SettingsPermissionError, SettingsRevisionConflict, SettingsValidationError,
)


class UserChangeUnverified(RuntimeError):
    """The native result cannot be proven; reconcile before another write."""


def _text(value: object, maximum: int = 256, *, whitespace: bool = False) -> str:
    if (not isinstance(value, str) or not 0 < len(value) <= maximum
            or any(unicodedata.category(c).startswith('C') for c in value)
            or (not whitespace and any(c.isspace() for c in value))):
        raise SettingsValidationError('Invalid account metadata.')
    return value


def _time(value: object) -> float:
    if type(value) not in (float, int) or not math.isfinite(value) or not 0 <= value <= 253402300000:
        raise SettingsValidationError('Invalid native clock.')
    return float(value)


def _policy(value: object) -> PasswordPolicy:
    if not isinstance(value, Mapping) or set(value) != {'minimumLength', 'maximumLength'}:
        raise SettingsValidationError('Invalid native password policy.')
    try:
        return PasswordPolicy(value['minimumLength'], value['maximumLength'])
    except (ValueError, TypeError):
        raise SettingsValidationError('Invalid native password policy.') from None


def _state(value: object) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != {'accounts', 'roles', 'passwordPolicy'}:
        raise SettingsValidationError('A complete native user directory is required.')
    _policy(value['passwordPolicy'])
    roles, accounts = value['roles'], value['accounts']
    if not isinstance(roles, list) or not 0 < len(roles) <= 256:
        raise SettingsValidationError('Invalid native role registry.')
    refs: set[str] = set()
    for role in roles:
        if not isinstance(role, dict) or set(role) != {'ref', 'label', 'administrator'}:
            raise SettingsValidationError('Invalid native role registry.')
        ref = _text(role['ref'], 128); _text(role['label'], whitespace=True)
        if ref in refs or type(role['administrator']) is not bool:
            raise SettingsValidationError('Invalid native role registry.')
        refs.add(ref)
    if not isinstance(accounts, list) or not 0 < len(accounts) <= 10000:
        raise SettingsValidationError('Invalid native user directory.')
    ids: set[str] = set(); names: set[str] = set()
    for account in accounts:
        keys = {'id', 'username', 'roleRef', 'status', 'mfaRequired', 'credentialRevision', 'sessionEpoch', 'passwordHash'}
        if not isinstance(account, dict) or set(account) != keys:
            raise SettingsValidationError('Invalid native account state.')
        identity = _text(account['id']); name = _text(account['username'], 128)
        _text(account['credentialRevision']); _text(account['roleRef'], 128)
        _text(account['passwordHash'], 65536, whitespace=True)
        if (identity in ids or name.casefold() in names or account['roleRef'] not in refs
                or account['status'] not in ('active', 'disabled') or type(account['mfaRequired']) is not bool
                or type(account['sessionEpoch']) is not int or not 0 <= account['sessionEpoch'] < 2**53 - 1):
            raise SettingsValidationError('Invalid native account state.')
        ids.add(identity); names.add(name.casefold())
    if not any(a['status'] == 'active' and next(r for r in roles if r['ref'] == a['roleRef'])['administrator'] for a in accounts):
        raise SettingsValidationError('At least one active administrator is required.')
    return deepcopy(dict(value))


@dataclass(frozen=True)
class UserSnapshot:
    revision: str
    value: dict[str, Any]


@dataclass(frozen=True)
class UserPreview:
    token: str
    actor: str
    draft: dict[str, Any]
    created_at: float
    expires_at: float


@dataclass(frozen=True)
class UserMutation:
    value: dict[str, Any]
    event: dict[str, Any]
    account_id: str


class UserPasswordHasher(Protocol):
    """Bind existing native password algorithm and stronger native policy.

    No default or fallback algorithm is provided. hash_password MUST enforce
    additional product policy before returning an encoded hash, never plaintext.
    verify_password MUST use the native constant-time implementation. Neither
    function may log values. Endpoints must impose native rate limits/CSRF/TLS.
    """
    def hash_password(self, password: str) -> str: ...
    def verify_password(self, password: str, encoded: str) -> bool: ...


class UserStore(Protocol):
    """Native transaction port, not a requirement for a new Foundation DB.

    All account/role/policy/credential changes advance the directory revision.
    transact locks the complete authoritative directory/preview and invokes
    build under that lock. Current authorization MUST participate in the same
    native transaction. Persist mutation + audit + epoch and consume previews
    atomically, or write nothing. Never invoke build more than once or retry it
    transparently. read returns detached internal data, never an HTTP response.
    Native session admission rejects absent/disabled users and stale epochs.
    """
    def read(self) -> UserSnapshot: ...
    def register_preview(self, preview: UserPreview) -> None: ...
    def preview(self, token: str) -> UserPreview | None: ...
    def transact(self, expected_revision: str,
                 build: Callable[[UserSnapshot, Mapping[str, UserPreview]], UserMutation]) -> UserSnapshot: ...


class MemoryUserStore:
    """Isolated thread-safe reference; no real users, sessions, files or APIs."""
    def __init__(self, value: Mapping[str, Any]) -> None:
        self._value = _state(value); self._version = 1; self._lock = RLock()
        self._previews: dict[str, UserPreview] = {}; self._audit: list[dict[str, Any]] = []

    def read(self) -> UserSnapshot:
        with self._lock:
            return UserSnapshot('users-' + str(self._version), deepcopy(self._value))

    def register_preview(self, preview: UserPreview) -> None:
        with self._lock:
            if preview.draft['expectedRevision'] != self.read().revision:
                raise SettingsRevisionConflict('User directory changed.')
            self._previews = {k: v for k, v in self._previews.items() if v.expires_at > preview.created_at}
            if len(self._previews) >= 1024:
                raise SettingsValidationError('Preview capacity exceeded.')
            self._previews[preview.token] = deepcopy(preview)

    def preview(self, token: str) -> UserPreview | None:
        with self._lock:
            return deepcopy(self._previews.get(token))

    def transact(self, expected_revision: str,
                 build: Callable[[UserSnapshot, Mapping[str, UserPreview]], UserMutation]) -> UserSnapshot:
        with self._lock:
            before = self.read()
            if before.revision != expected_revision:
                raise SettingsRevisionConflict('User directory changed.')
            mutation = build(before, deepcopy(self._previews))
            if not isinstance(mutation, UserMutation):
                raise SettingsValidationError('Invalid atomic user mutation.')
            value = _state(mutation.value); event = deepcopy(mutation.event)
            _text(event.get('id')); _text(mutation.account_id)
            # Validate both before any state change. Native ports provide durable equivalent.
            self._value = value; self._version += 1; self._audit.append(event); self._previews.clear()
            return self.read()

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class UserManagementService:
    """Own account validation, lifecycle, previews, epochs, audit and read-back.

    authorize is a server-owned CURRENT authority lookup, never a browser flag.
    It must fail closed and honor current MFA/session/role policy. Capability
    snapshots constrain it further. Role assignment additionally requires the
    native `users.assign.<roleRef>` capability, so manage never implies all roles.
    """
    def __init__(self, store: UserStore, hasher: UserPasswordHasher, *,
                 authorize: Callable[[SettingsActor, str], bool],
                 clock: Callable[[], float] = time.time) -> None:
        if not callable(authorize):
            raise SettingsValidationError('Current native authorization is required.')
        self.store = store; self.hasher = hasher; self.authorize = authorize; self.clock = clock

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = isinstance(actor, SettingsActor) and permission in actor.capabilities and self.authorize(actor, permission) is True
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError('Native actor does not currently authorize this account operation.')

    def _snapshot(self, expected: str | None = None) -> UserSnapshot:
        snapshot = self.store.read()
        if not isinstance(snapshot, UserSnapshot):
            raise SettingsValidationError('Invalid native account snapshot.')
        _text(snapshot.revision)
        if expected is not None and snapshot.revision != _text(expected):
            raise SettingsRevisionConflict('User directory changed. Refresh before retrying.')
        return UserSnapshot(snapshot.revision, _state(snapshot.value))

    @staticmethod
    def _subject(snapshot: UserSnapshot, actor: SettingsActor) -> dict[str, Any]:
        subject = next((a for a in snapshot.value['accounts'] if a['id'] == actor.subject), None)
        if subject is None or subject['status'] != 'active':
            raise SettingsPermissionError('Current authenticated account is not active.')
        return subject

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, 'users.read'); snapshot = self._snapshot(); self._subject(snapshot, actor)
        self._require(actor, 'users.read')
        allowed_keys = {'id', 'username', 'roleRef', 'status', 'mfaRequired', 'credentialRevision'}
        return {'revision': snapshot.revision, 'currentUserId': actor.subject, 'complete': True,
                'accounts': [{k: a[k] for k in allowed_keys} for a in snapshot.value['accounts']],
                'roles': snapshot.value['roles'], 'passwordPolicy': snapshot.value['passwordPolicy']}

    @staticmethod
    def _draft(request: object) -> dict[str, Any]:
        keys = {'operation', 'accountId', 'username', 'roleRef', 'status', 'expectedRevision', 'passwordChange'}
        if not isinstance(request, Mapping) or set(request) != keys:
            raise SettingsValidationError('Submit only the password-free account intent.')
        draft = deepcopy(dict(request))
        if (draft['operation'] not in ('create', 'update', 'delete') or draft['status'] not in ('active', 'disabled')
                or type(draft['passwordChange']) is not bool):
            raise SettingsValidationError('Invalid account intent.')
        for key, maximum in [('username', 128), ('roleRef', 128), ('expectedRevision', 256)]:
            _text(draft[key], maximum)
        if draft['operation'] == 'create':
            if draft['accountId'] is not None or not draft['passwordChange'] or draft['status'] != 'active':
                raise SettingsValidationError('New accounts require an initial password and active status.')
        else:
            _text(draft['accountId'])
            if draft['operation'] == 'delete' and draft['passwordChange']:
                raise SettingsValidationError('Delete cannot change credentials.')
        return draft

    def _validate(self, actor: SettingsActor, draft: dict[str, Any], snapshot: UserSnapshot) -> None:
        self._require(actor, 'users.read'); self._require(actor, 'users.manage'); self._subject(snapshot, actor)
        if snapshot.revision != draft['expectedRevision']:
            raise SettingsRevisionConflict('User directory changed.')
        roles = snapshot.value['roles']; accounts = snapshot.value['accounts']
        role = next((r for r in roles if r['ref'] == draft['roleRef']), None)
        if role is None:
            raise SettingsValidationError('Choose a current native role.')
        if draft['operation'] == 'create':
            if any(a['username'].casefold() == draft['username'].casefold() for a in accounts):
                raise SettingsValidationError('That username already exists.')
            self._require(actor, 'users.assign.' + draft['roleRef'])
            return
        subject = next((a for a in accounts if a['id'] == draft['accountId']), None)
        if subject is None or subject['username'] != draft['username']:
            raise SettingsValidationError('Selected account is no longer current.')
        if subject['id'] == actor.subject and (draft['operation'] == 'delete' or draft['status'] != 'active' or draft['roleRef'] != subject['roleRef']):
            raise SettingsValidationError('Use another authorized administrator to change your own access.')
        was_admin = subject['status'] == 'active' and next(r for r in roles if r['ref'] == subject['roleRef'])['administrator']
        reducing = draft['operation'] == 'delete' or draft['status'] != 'active' or not role['administrator']
        admin_count = sum(a['status'] == 'active' and next(r for r in roles if r['ref'] == a['roleRef'])['administrator'] for a in accounts)
        if was_admin and reducing and admin_count <= 1:
            raise SettingsValidationError('The last active administrator must be preserved.')
        if draft['operation'] == 'update' and draft['roleRef'] != subject['roleRef']:
            self._require(actor, 'users.assign.' + draft['roleRef'])
        if draft['operation'] == 'delete' and (draft['roleRef'] != subject['roleRef'] or draft['status'] != subject['status']):
            raise SettingsValidationError('Delete intent must match the current account.')

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'users.manage'); draft = self._draft(request)
        snapshot = self._snapshot(draft['expectedRevision']); self._validate(actor, draft, snapshot)
        now = _time(self.clock()); token = 'user-preview-' + uuid4().hex
        plan = UserPreview(token, actor.subject, draft, now, now + 300)
        self.store.register_preview(plan)
        return {'allowed': True, 'blockers': [], 'expectedRevision': snapshot.revision,
                'draft': deepcopy(draft), 'token': token, 'expiresAt': plan.expires_at * 1000}

    def _plan(self, plan: UserPreview | None, actor: SettingsActor, draft: dict[str, Any], token: str) -> None:
        now = _time(self.clock())
        if (not isinstance(plan, UserPreview) or plan.token != token or plan.actor != actor.subject
                or plan.draft != draft or not _time(plan.created_at) <= now < _time(plan.expires_at)):
            raise SettingsValidationError('A current matching native account preview is required.')

    def _hash(self, password: object, snapshot: UserSnapshot) -> str:
        if not evaluate_new_password(password, _policy(snapshot.value['passwordPolicy'])).accepted:
            raise SettingsValidationError('The new password does not satisfy current policy.')
        try:
            encoded = self.hasher.hash_password(password)
            _text(encoded, 65536, whitespace=True)
            if encoded == password:
                raise ValueError('invalid encoding')
            return encoded
        except Exception:
            raise SettingsValidationError('Native password policy or hashing rejected the request.') from None

    def _event(self, actor: SettingsActor, action: str, subject: str, revision: str) -> dict[str, Any]:
        return {'id': 'user-audit-' + uuid4().hex, 'actor': actor.subject, 'subject': subject,
                'action': action, 'expectedRevision': revision, 'timestamp': _time(self.clock())}

    def _verified(self, returned: UserSnapshot, expected_value: dict[str, Any], before_revision: str) -> UserSnapshot:
        observed = self._snapshot()
        if (not isinstance(returned, UserSnapshot) or returned.revision == before_revision
                or observed.revision != returned.revision or observed.value != expected_value
                or returned.value != expected_value):
            raise UserChangeUnverified('Native account state was not independently verified. Reconcile the audit before retrying.')
        return observed

    def apply(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'users.manage')
        if not isinstance(request, Mapping) or set(request) not in ({'draft', 'previewToken'}, {'draft', 'previewToken', 'password'}):
            raise SettingsValidationError('Invalid account apply request.')
        draft = self._draft(request['draft']); token = _text(request['previewToken'])
        if ('password' in request) != draft['passwordChange']:
            raise SettingsValidationError('Password presence must match the reviewed intent.')
        before = self._snapshot(draft['expectedRevision']); self._validate(actor, draft, before)
        self._plan(self.store.preview(token), actor, draft, token)
        encoded = self._hash(request['password'], before) if draft['passwordChange'] else None
        account_id = draft['accountId'] or 'user-' + uuid4().hex
        credential_revision = 'credential-' + uuid4().hex
        event = self._event(actor, 'users.' + draft['operation'], account_id, before.revision)
        next_value: dict[str, Any] = {}

        def build(current: UserSnapshot, plans: Mapping[str, UserPreview]) -> UserMutation:
            nonlocal next_value
            current = UserSnapshot(current.revision, _state(current.value))
            self._validate(actor, draft, current); self._plan(plans.get(token), actor, draft, token)
            # Hashing is an external/slow boundary: reject even a broken same-revision native store.
            if current.value != before.value:
                raise SettingsRevisionConflict('Native account state changed without a matching revision.')
            next_value = deepcopy(current.value)
            if draft['operation'] == 'create':
                next_value['accounts'].append({'id': account_id, 'username': draft['username'], 'roleRef': draft['roleRef'],
                    'status': 'active', 'mfaRequired': False, 'passwordHash': encoded,
                    'credentialRevision': credential_revision, 'sessionEpoch': 0})
            elif draft['operation'] == 'delete':
                next_value['accounts'] = [a for a in next_value['accounts'] if a['id'] != account_id]
            else:
                subject = next(a for a in next_value['accounts'] if a['id'] == account_id)
                invalidates = encoded is not None or subject['status'] != draft['status'] or subject['roleRef'] != draft['roleRef']
                subject['roleRef'] = draft['roleRef']; subject['status'] = draft['status']
                if encoded is not None:
                    subject['passwordHash'] = encoded; subject['credentialRevision'] = credential_revision
                if invalidates:
                    subject['sessionEpoch'] += 1
            return UserMutation(next_value, event, account_id)

        returned = self.store.transact(before.revision, build)
        after = self._verified(returned, next_value, before.revision)
        result = {'applied': True, 'revision': after.revision, 'auditRef': event['id'], 'accountId': account_id}
        if draft['passwordChange']:
            result['credentialRevision'] = credential_revision
        return result

    def read_password(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, 'password.read'); snapshot = self._snapshot(); account = self._subject(snapshot, actor)
        self._require(actor, 'password.read')
        return {'username': account['username'], 'revision': snapshot.revision,
                'credentialRevision': account['credentialRevision'], 'sessionEpoch': account['sessionEpoch'],
                'passwordPolicy': snapshot.value['passwordPolicy']}

    def change_password(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'password.read'); self._require(actor, 'password.change')
        keys = {'currentPassword', 'newPassword', 'confirmPassword', 'expectedRevision'}
        if not isinstance(request, Mapping) or set(request) != keys:
            raise SettingsValidationError('Submit only passwords and the current revision; subject comes from the native session.')
        before = self._snapshot(_text(request['expectedRevision'])); account = self._subject(before, actor)
        old, new, confirm = (request[k] for k in ('currentPassword', 'newPassword', 'confirmPassword'))
        if (not isinstance(old, str) or not 0 < len(old) <= 1024 or not isinstance(new, str)
                or new != confirm or old == new):
            raise SettingsValidationError('Password verification or confirmation failed.')
        try:
            verified = self.hasher.verify_password(old, account['passwordHash']) is True
        except Exception:
            verified = False
        if not verified:
            raise SettingsValidationError('Password verification or confirmation failed.')
        self._require(actor, 'password.change')
        encoded = self._hash(new, before)
        event = self._event(actor, 'password.changed', actor.subject, before.revision)
        credential_revision = 'credential-' + uuid4().hex
        next_value: dict[str, Any] = {}

        def build(current: UserSnapshot, plans: Mapping[str, UserPreview]) -> UserMutation:
            nonlocal next_value
            self._require(actor, 'password.read'); self._require(actor, 'password.change')
            self._subject(current, actor)
            if current.revision != before.revision or current.value != before.value:
                raise SettingsRevisionConflict('Credential state changed during native hashing.')
            next_value = deepcopy(current.value)
            subject = next(a for a in next_value['accounts'] if a['id'] == actor.subject)
            subject['passwordHash'] = encoded; subject['credentialRevision'] = credential_revision
            subject['sessionEpoch'] += 1
            return UserMutation(next_value, event, actor.subject)

        returned = self.store.transact(before.revision, build)
        after = self._verified(returned, next_value, before.revision); subject = self._subject(after, actor)
        return {'changed': True, 'revision': after.revision, 'credentialRevision': subject['credentialRevision'],
                'sessionEpoch': subject['sessionEpoch'], 'auditRef': event['id']}
