export declare const COMMON_ERROR_CATEGORIES: readonly ["validation", "unauthenticated", "forbidden", "conflict", "stale_state", "unavailable", "interrupted", "failed"];
export type CommonErrorCategory = (typeof COMMON_ERROR_CATEGORIES)[number];
export type AdapterError = {
    category: CommonErrorCategory;
    message: string;
    code?: string;
    detail?: unknown;
};
export declare const OPERATION_EFFECTS: readonly ["long_running", "reconnect_required", "restart_required", "destructive", "security_sensitive"];
export type OperationEffect = (typeof OPERATION_EFFECTS)[number];
export type CapabilityAvailability = "supported" | "read_only" | "unavailable";
export type CapabilityProjection = {
    id: string;
    label: string;
    availability: CapabilityAvailability;
    effects?: readonly OperationEffect[];
    permission?: string;
    notes?: string;
};
export declare const JOB_STATES: readonly ["QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"];
export type JobState = (typeof JOB_STATES)[number];
export type JobProjection<Result = unknown> = {
    id: string;
    state: JobState;
    label?: string;
    progressPercent?: number;
    statusMessage?: string;
    result?: Result;
    error?: AdapterError;
    cancellable?: boolean;
    auditReference?: string;
};
export type AuditReference = {
    id: string;
    label?: string;
};
export type ReadBack<State> = {
    effective: State;
    revision?: string;
    readAt?: string;
    audit?: AuditReference;
};
export type PreviewChange = {
    field: string;
    before?: string;
    after?: string;
    note?: string;
};
export type OperationPreview<Detail = unknown> = {
    supported: boolean;
    summary?: string;
    effects?: readonly OperationEffect[];
    changes?: readonly PreviewChange[];
    detail?: Detail;
};
export type MutationOutcome<State = unknown, Result = unknown> = {
    effective?: ReadBack<State>;
    job?: JobProjection<Result>;
    audit?: AuditReference;
    reconnectTargets?: readonly string[];
};
export type OpaqueChoice<Value = string> = {
    value: Value;
    label: string;
    description?: string;
};
export type AccountRelationshipProjection = {
    id: string;
    kind: string;
    label: string;
    detail?: string;
};
export type AccountProjection<RoleValue = string> = {
    id: string;
    displayName: string;
    status?: string;
    role?: OpaqueChoice<RoleValue>;
    relationships?: readonly AccountRelationshipProjection[];
    capabilities?: readonly string[];
    detail?: string;
};
/** PF-11: only product-validated, code-only connectivity diagnostic projections.
 * Mirrors the shared Python diagnostic enum vocabulary; never transport raw
 * probe exceptions, target URLs/hosts, credentials or certificate bodies. */
/** PF-10: code-only product-authoritative audit-forwarding evidence.
 * A Python ForwardReceipt.accepted means product transport accepted one
 * attempt; it does not prove downstream SIEM/collector ingestion. */
export type AuditForwardingProjection = {
    state: "configured" | "degraded" | "disabled" | "unknown";
    pendingCount?: number;
    lastReceipt?: {
        eventId: string;
        status: "accepted" | "retry_pending";
    };
};
/** PF-11A product-owned SMTP/Webhook snapshot. No URLs, headers, secrets,
 * recipients, free-form errors, raw message data or network operations. */
export declare const NOTIFICATION_TEST_BLOCKERS: readonly ["destination_disabled", "stale_destination", "permission_denied", "mfa_required", "sender_unavailable", "destination_unverified", "credential_unavailable", "tls_unverified", "audit_unavailable"];
export type NotificationTestBlocker = (typeof NOTIFICATION_TEST_BLOCKERS)[number];
export type NotificationDestinationProjection = {
    /** Opaque product references from validated NotificationDestination. */
    reference: string;
    revision: string;
    kind: "smtp" | "webhook";
    enabled: boolean;
    /** Aggregated product queue snapshot, not full history/server completeness. */
    queue?: {
        queued: number;
        retryPending: number;
        deadLetter: number;
    };
    /** Acceptance is transport-level, NOT inbox/SIEM/webhook ingestion. */
    lastOutcome?: "accepted" | "retry_pending" | "dead_letter";
    /** Product-computed TestSendPreview; client still never grants authority. */
    testPreview?: {
        expectedRevision: string;
        blockers: readonly NotificationTestBlocker[];
        maySubmitToProductSender: boolean;
        productSendRequired: true;
    };
};
/** PF-12 immutable code-only recovery proof enums mirror the existing
 * Python backup_recovery module; no customer archive content or restore. */
/** PF-10C product-authoritative, code-only public secret lifecycle.
 * Exclude Python masked_value, actual key bytes, KMS endpoints, and credentials. */
/** PF-10D roles/capability authority is owned by each product.
 * This is a bounded, code-only advisory comparison, not a role grant. */
/** PF-9 management ingress is a separate host SSH and Web/API policy.
 * Browser projections are read-only; authoritative Python ACL evaluates IPs. */
/** PF-10B product-authoritative effective and proposed password/login/session
 * policy. Never contains raw credentials, user identities or session tokens. */
/** PF-11 reusable TLS certificate status and candidate preflight. Product
 * supplies code-only validated evidence; no PEM, SAN, hostnames or key data. */
/** PF-11 on-prem network configuration intent, distinct from SystemDoctor
 * measurements. Only code-only modes, never hostnames/URLs, keys or PEM. */
/** PF-11 first-run product readiness stage identities are shared UX, not
 * an auth/identity service, installer or product config authority. */
/** PF-12 read-only effective/desired operational backup policy. No archive
 * paths, credentials, actual backup scheduler, storage or user action. */
/** PF-12 product-owned installer has verified offline bytes/signature/trust.
 * No file paths, payload digests, key values or arbitrary shell commands
 * are displayed or accepted in this UI projection. */
/** PF-12 pure code-only historical configuration rollback preflight.
 * Source values, user identity, secrets and actual writes are excluded. */
/** PF-11 additive product-owned SMTP/Webhook routing and retry policy
 * change review. It never exposes endpoint, auth, recipient or message data.
 * Timings match NotificationRetryPolicy, NOT Grafana alert-group timers. */
/** PF-11 product-owned FAILED one-shot operation retry review only.
 * Not a task re-run API, job scheduler or permission grant. */
/** PF-11 privacy-sensitive support evidence bundle review only.
 * Real product server performs redaction/byte scanning and download. */
/** PF-10 product-verified audit forwarding sink *settings*, separate
 * from ForwardReceipt transport attempts. Never include endpoint URL, IP,
 * path, TLS material, event data, message bodies, headers or credentials. */
/** PF-12 product-native *data* retention, distinct from backup retention.
 * This first-party boundary only reviews product-generated code-only facts. */
export declare const DATA_RETENTION_CATEGORIES: readonly ["audit_events", "operation_history", "notification_jobs", "configuration_revisions", "support_artifacts"];
export type DataRetentionCategory = (typeof DATA_RETENTION_CATEGORIES)[number];
export declare const DATA_RETENTION_BLOCKERS: readonly ["permission_denied", "mfa_required", "audit_unavailable", "legal_hold", "protected_record", "dry_run_missing", "backup_unverified", "rollback_unavailable", "scheduler_unavailable", "storage_unverified", "stale_revision", "retention_minimum"];
export type DataRetentionBlocker = (typeof DATA_RETENTION_BLOCKERS)[number];
export type DataRetentionPolicySnapshot = {
    /** Product-authenticated per-category retention period, in whole days. */
    retentionDays: number;
    cleanupIntervalHours: number;
    cleanupEnabled: boolean;
};
export type DataRetentionPolicyReviewProjection = {
    category: DataRetentionCategory;
    revision: string;
    effective: DataRetentionPolicySnapshot;
    proposed?: DataRetentionPolicySnapshot;
    /** Product-computed legal/governance minimum, not a Foundation default. */
    requirements: {
        minimumDays: number;
        legalHoldActive: boolean;
    };
    /** Product-created dry-run, authorization and reversible-delete readiness.
     * A browser-provided Boolean cannot establish actual deletion authority. */
    preflight?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly DataRetentionBlocker[];
        productApplyRequired: true;
        estimatedRecordsToDelete: number;
        dryRunVerified: boolean;
        retentionWindowVerified: boolean;
        legalHoldExcluded: boolean;
        protectedRecordsExcluded: boolean;
        backupVerified: boolean;
        storageBoundaryVerified: boolean;
        schedulerReady: boolean;
        rollbackReady: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const AUDIT_FORWARDING_CONFIG_BLOCKERS: readonly ["permission_denied", "mfa_required", "audit_unavailable", "redaction_unverified", "destination_unverified", "tls_unverified", "queue_unverified", "capture_unavailable", "retention_unverified", "rollback_unavailable", "stale_revision"];
export type AuditForwardingConfigBlocker = (typeof AUDIT_FORWARDING_CONFIG_BLOCKERS)[number];
export type AuditForwardingConfigSnapshot = {
    enabled: boolean;
    /** Exact first-party supported sink types; file is product-owned. */
    sinkKind: "syslog_tls" | "product_owned_file";
    /** Corresponds to bounded Python encode_rfc5424(max_bytes=...). */
    frameLimitBytes: number;
    /** Native product must provide persistently retryable event delivery. */
    durableRetryRequired: boolean;
};
export type AuditForwardingConfigReviewProjection = {
    destination: {
        reference: string;
        revision: string;
    };
    effective: AuditForwardingConfigSnapshot;
    proposed?: AuditForwardingConfigSnapshot;
    /** Product-owned sink settings change preflight. Python forward_event
     * is an attempt, NOT this policy mutation authorization. */
    preflight?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly AuditForwardingConfigBlocker[];
        productApplyRequired: true;
        sourceRedactionVerified: boolean;
        destinationAuthorized: boolean;
        secureSinkVerified: boolean;
        durableQueueVerified: boolean;
        pendingQueueTransitionVerified: boolean;
        auditSourceContinuous: boolean;
        retentionVerified: boolean;
        rollbackReady: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const SUPPORT_BUNDLE_CATEGORIES: readonly ["system_diagnostics", "operation_status", "configuration_summary", "audit_metadata"];
export type SupportBundleCategory = (typeof SUPPORT_BUNDLE_CATEGORIES)[number];
export declare const SUPPORT_BUNDLE_BLOCKERS: readonly ["redaction_unverified", "credentials_unverified", "personal_data_unverified", "customer_payload_present", "archive_integrity_missing", "expired_bundle", "permission_denied", "mfa_required", "audit_unavailable", "stale_revision"];
export type SupportBundleBlocker = (typeof SUPPORT_BUNDLE_BLOCKERS)[number];
export type SupportBundleReviewProjection = {
    /** Opaque product reference and CAS revision, never a download URL or path. */
    reference: string;
    revision: string;
    state: "ready" | "generating" | "failed" | "unavailable" | "unknown";
    /** Product-authoritative Unix seconds, not the browser's wall clock. */
    checkedAt: number;
    expiresAt: number;
    sizeBytes: number;
    categories: readonly SupportBundleCategory[];
    /** Only the product can inspect/redact actual archive bytes. These
     * flags are non-authenticating UI evidence, not independent proof. */
    proof?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly SupportBundleBlocker[];
        productTransferRequired: true;
        archiveBytesVerified: boolean;
        redactionVerified: boolean;
        credentialScanPassed: boolean;
        personalDataScanPassed: boolean;
        customerPayloadExcluded: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const JOB_RETRY_BLOCKERS: readonly ["permission_denied", "mfa_required", "audit_unavailable", "idempotency_unverified", "previous_attempt_active", "retry_budget_exhausted", "backoff_pending", "stale_revision", "scheduled_task", "runner_unavailable"];
export type JobRetryBlocker = (typeof JOB_RETRY_BLOCKERS)[number];
export type JobRetryReviewProjection = {
    /** Current product-authorized opaque failed operation ID. */
    jobId: string;
    /** Product CAS revision; not part of the generic JobProjection. */
    expectedJobRevision: string;
    retryClass: "one_shot" | "scheduled";
    allowed: boolean;
    blockers: readonly JobRetryBlocker[];
    productApplyRequired: true;
    originalExecutionTerminal: boolean;
    idempotencyVerified: boolean;
    retryBudgetAvailable: boolean;
    backoffElapsed: boolean;
    actorAuthorized: boolean;
    recentMfaVerified: boolean;
    auditReady: boolean;
};
export declare const NOTIFICATION_ROUTING_BLOCKERS: readonly ["permission_denied", "mfa_required", "sender_unavailable", "destination_unverified", "credential_unavailable", "tls_unverified", "drain_unverified", "rollback_unavailable", "audit_unavailable", "stale_revision"];
export type NotificationRoutingBlocker = (typeof NOTIFICATION_ROUTING_BLOCKERS)[number];
export type NotificationRetryPolicySnapshot = {
    maxAttempts: number;
    initialDelaySeconds: number;
    maxDelaySeconds: number;
};
export type NotificationRoutingReviewProjection = {
    destination: {
        reference: string;
        revision: string;
        kind: "smtp" | "webhook";
        enabled: boolean;
    };
    effective: NotificationRetryPolicySnapshot;
    proposed?: {
        enabled: boolean;
        retryPolicy: NotificationRetryPolicySnapshot;
    };
    /** Separate product-created policy-change preflight. Python's
     * TestSendPreview only gates a single test-send, NOT a settings write. */
    preflight?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly NotificationRoutingBlocker[];
        productApplyRequired: true;
        senderReady: boolean;
        destinationValidated: boolean;
        credentialReady: boolean;
        tlsVerified: boolean;
        queueDrainVerified: boolean;
        rollbackReady: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const CONFIG_ROLLBACK_BLOCKERS: readonly ["nonhistorical_target", "wrong_revision", "no_target", "same_revision", "unsupported", "unauthorized", "mfa_required", "backup_missing", "recovery_unavailable", "out_of_band_required", "audit_unavailable", "nonreversible_field"];
export type ConfigurationRollbackBlocker = (typeof CONFIG_ROLLBACK_BLOCKERS)[number];
export type ConfigurationRollbackReviewProjection = {
    current: {
        productRef: string;
        revision: string;
        createdAt: number;
    };
    target: {
        productRef: string;
        revision: string;
        createdAt: number;
    };
    /** Sanitized from Python RollbackPreview; values are never sent here. */
    preview?: {
        productRef: string;
        fromRevision: string;
        targetRevision: string;
        expectedCurrentRevision: string;
        changedPaths: readonly string[];
        blockers: readonly ConfigurationRollbackBlocker[];
        maySubmitToProductAuthority: boolean;
        productApplyRequired: true;
        currentBackupVerified: boolean;
        rollbackPathVerified: boolean;
        offlineConsoleRecoveryReady: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const OFFLINE_UPGRADE_BLOCKERS: readonly ["wrong_product", "wrong_kind", "not_newer", "major_upgrade_untested", "artifact_hash_mismatch", "manifest_hash_mismatch", "publisher_mismatch", "artifact_integrity_missing", "manifest_integrity_missing", "signature_unverified", "publisher_untrusted", "provenance_unverified", "stale_installation", "installer_unavailable", "permission_denied", "mfa_required", "schema_unverified", "migration_untested", "backup_unverified", "rollback_unverified", "offline_recovery_required", "maintenance_not_authorized", "audit_unavailable"];
export type OfflineUpgradeBlocker = (typeof OFFLINE_UPGRADE_BLOCKERS)[number];
export type OfflineUpgradeReviewProjection = {
    installed: {
        productRef: string;
        revision: string;
        version: string;
    };
    artifact: {
        productRef: string;
        releaseRef: string;
        version: string;
        kind: "product_release" | "platform_os_upgrade";
    };
    /** This is a trusted installer assertion; JS never validates actual
     * archive bytes or signed publisher provenance. */
    proof?: {
        artifactBytesHashed: boolean;
        manifestBytesHashed: boolean;
        manifestSignatureVerified: boolean;
        publisherTrustVerified: boolean;
        provenanceVerified: boolean;
    };
    /** Bound Python UpgradePreview and independently collected product facts. */
    preview?: {
        productRef: string;
        releaseRef: string;
        expectedInstalledRevision: string;
        installedVersion: string;
        targetVersion: string;
        blockers: readonly OfflineUpgradeBlocker[];
        maySubmitToProductInstaller: boolean;
        productApplyRequired: true;
        schemaCompatible: boolean;
        schemaMigrationTested: boolean;
        backupRestoreDrillVerified: boolean;
        rollbackArtifactVerified: boolean;
        offlineConsoleRecoveryReady: boolean;
        maintenanceWindowAuthorized: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const BACKUP_POLICY_BLOCKERS: readonly ["scheduler_unavailable", "encrypted_storage_unverified", "restore_drill_unverified", "permission_denied", "mfa_required", "rollback_unavailable", "audit_unavailable", "stale_revision", "weakening_prohibited"];
export type BackupPolicyBlocker = (typeof BACKUP_POLICY_BLOCKERS)[number];
export type BackupPolicySnapshot = {
    scheduleSeconds: number;
    maxAcceptableAgeSeconds: number;
    keepLast: number;
    maxRestoreProofAgeSeconds: number;
    requireEncryption: boolean;
    requireRestoreDrill: boolean;
};
export type BackupPolicyReviewProjection = {
    revision: string;
    effective: BackupPolicySnapshot;
    proposed?: BackupPolicySnapshot;
    /** Authenticated product policy-change approval preview; the Python pure
     * BackupPolicy model is not a native scheduler or mutating backend. */
    preflight?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly BackupPolicyBlocker[];
        productApplyRequired: true;
        schedulerVerified: boolean;
        encryptedStorageVerified: boolean;
        isolatedRestoreDrillVerified: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        rollbackReady: boolean;
        auditReady: boolean;
    };
};
export declare const ONPREM_SETUP_STAGE_IDS: readonly ["administrator", "management_access", "network_time", "tls", "notifications", "backup_recovery"];
export type OnPremSetupStageId = (typeof ONPREM_SETUP_STAGE_IDS)[number];
export declare const ONPREM_SETUP_REVIEW_BLOCKERS: readonly ["administrator_missing", "mfa_unverified", "acl_unverified", "network_unverified", "tls_unverified", "notifications_unverified", "backup_unverified", "rollback_unavailable", "audit_unavailable", "permission_denied", "stale_revision"];
export type OnPremSetupReviewBlocker = (typeof ONPREM_SETUP_REVIEW_BLOCKERS)[number];
export type OnPremSetupReadinessProjection = {
    revision: string;
    /** Exactly one current status for each of six known stages, from product. */
    steps: readonly {
        id: OnPremSetupStageId;
        status: "ready" | "attention" | "unknown" | "unavailable";
        required: boolean;
    }[];
    /** Separate product-authenticated preflight and permission proof. */
    review?: {
        expectedRevision: string;
        allowed: boolean;
        blockers: readonly OnPremSetupReviewBlocker[];
        productReviewRequired: true;
    };
};
export declare const NETWORK_TRUST_BLOCKERS: readonly ["dns_unverified", "ntp_unverified", "proxy_unverified", "ca_unverified", "management_lockout", "rollback_unavailable", "permission_denied", "mfa_required", "audit_unavailable", "stale_revision"];
export type NetworkTrustBlocker = (typeof NETWORK_TRUST_BLOCKERS)[number];
export type NetworkTrustPolicy = {
    dns: {
        mode: "system" | "custom";
    };
    ntp: {
        mode: "system" | "external" | "disabled";
    };
    proxy: {
        enabled: boolean;
    };
    trustedCa: {
        mode: "system" | "enterprise";
    };
};
export type NetworkTrustReviewProjection = {
    revision: string;
    effective: NetworkTrustPolicy;
    proposed?: NetworkTrustPolicy;
    /** Independent product readiness preflight. This is not from Python
     * diagnose_network alone; that API evaluates measurements, not writes. */
    preflight?: {
        expectedRevision: string;
        maySubmitToProductAuthority: boolean;
        blockers: readonly NetworkTrustBlocker[];
        productApplyRequired: true;
        dnsVerified: boolean;
        ntpVerified: boolean;
        proxyVerified: boolean;
        caVerified: boolean;
        managementPathVerified: boolean;
        rollbackReady: boolean;
        actorAuthorized: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const TLS_REPLACEMENT_BLOCKERS: readonly ["chain_unverified", "hostname_unverified", "key_pair_unverified", "tls_policy_unverified", "candidate_expired", "listener_unverified", "rollback_unavailable", "recovery_unavailable", "permission_denied", "mfa_required", "audit_unavailable", "stale_revision"];
export type TlsReplacementBlocker = (typeof TLS_REPLACEMENT_BLOCKERS)[number];
export type TlsCertificateReviewProjection = {
    /** Product-collected, bounded Unix second clock. */
    observedAt: number;
    current: {
        revision: string;
        status: "valid" | "expiring" | "expired" | "unknown";
        notAfter?: number | null;
    };
    /** Opaque candidate reference, not a certificate or secret body. */
    candidate?: {
        reference: string;
        notAfter: number;
        chainVerified: boolean;
        hostnameVerified: boolean;
        keyPairVerified: boolean;
        tlsPolicyVerified: boolean;
    };
    /** Separate product-authenticated RBAC/MFA, connectivity and rollback proof. */
    preview?: {
        expectedRevision: string;
        candidateReference: string;
        safe: boolean;
        blockers: readonly TlsReplacementBlocker[];
        productApplyRequired: true;
        rollbackReady: boolean;
        outOfBandRecoveryReady: boolean;
        authorizedActor: boolean;
        recentMfaVerified: boolean;
        auditReady: boolean;
    };
};
export declare const SECURITY_POLICY_BLOCKERS: readonly ["AUTHORITY_UNAVAILABLE", "MFA_REQUIRED", "LAST_ADMIN_RECOVERY_UNAVAILABLE", "ROLLBACK_UNAVAILABLE", "AUDIT_UNAVAILABLE", "POLICY_WEAKENING"];
export type SecurityPolicyBlocker = (typeof SECURITY_POLICY_BLOCKERS)[number];
export type SecurityPolicySnapshot = {
    password: {
        minimumLength: number;
        maximumLength: number;
    };
    login: {
        maxFailures: number;
        windowSeconds: number;
        lockoutSeconds: number;
    };
    sessions: {
        idleTimeoutSeconds: number;
        absoluteLifetimeSeconds: number;
        maxConcurrentSessions: number;
    };
};
export type SecurityPolicyReviewProjection = {
    revision: string;
    effective: SecurityPolicySnapshot;
    /** Proposed source policy, never auto-applied. */
    proposed?: SecurityPolicySnapshot;
    /** Product-owned change authorization preflight, not part of pure Python
     * password/session validators and not a frontend role grant. */
    preview?: {
        expectedRevision: string;
        safe: boolean;
        blockers: readonly SecurityPolicyBlocker[];
        productApplyRequired: true;
    };
};
export declare const MANAGEMENT_ACCESS_BLOCKERS: readonly ["INVALID_ROLLBACK_WINDOW", "OFFLINE_RECOVERY_REQUIRED", "SSH_ENFORCEMENT_UNAVAILABLE", "WEB_SELF_LOCKOUT", "SSH_SELF_LOCKOUT"];
export type ManagementAccessBlocker = (typeof MANAGEMENT_ACCESS_BLOCKERS)[number];
export type ManagementAccessSurfaceProjection = {
    target: "ssh" | "web";
    revision: string;
    enabled: boolean;
    /** Product-authorized, Python-canonical CIDRs only, never a server query. */
    sources: readonly {
        cidr: string;
        expiresAt?: number | null;
    }[];
};
export type ManagementAccessPolicyProjection = {
    ssh: ManagementAccessSurfaceProjection;
    /** Web UI AND management API, not merely the login page. */
    web: ManagementAccessSurfaceProjection;
    preview?: {
        sshRevision: string;
        webRevision: string;
        safe: boolean;
        blockers: readonly ManagementAccessBlocker[];
        sshDecision: {
            allowed: boolean;
            reason: "ALLOW_DISABLED" | "ALLOW_CIDR" | "DENY_POLICY_UNAVAILABLE" | "DENY_UNKNOWN_SOURCE" | "DENY_NO_MATCH" | "DENY_EXPIRED";
        };
        webDecision: {
            allowed: boolean;
            reason: "ALLOW_DISABLED" | "ALLOW_CIDR" | "DENY_POLICY_UNAVAILABLE" | "DENY_UNKNOWN_SOURCE" | "DENY_NO_MATCH" | "DENY_EXPIRED";
        };
        rollbackSeconds: number;
    };
};
export declare const ROLE_CHANGE_BLOCKERS: readonly ["no_product_backend", "permission_denied", "mfa_required", "stale_role", "unknown_capability", "last_admin_lockout", "self_escalation", "escalation_approval_required", "audit_unavailable", "rollback_unavailable"];
export type RoleChangeBlocker = (typeof ROLE_CHANGE_BLOCKERS)[number];
export type RoleChangeReviewProjection = {
    currentRoleRef: string;
    proposedRoleRef: string;
    currentRevision: string;
    preview?: {
        fromRoleRef: string;
        toRoleRef: string;
        /** Product must bind this to RoleChangeEvidence's current revision. */
        expectedCurrentRevision: string;
        gained: readonly string[];
        lost: readonly string[];
        blockers: readonly RoleChangeBlocker[];
        maySubmitToProductAuthority: boolean;
        productWriteRequired: true;
    };
};
export declare const SECRET_ROTATION_BLOCKERS: readonly ["unsupported_backend", "unauthorized", "mfa_required", "stale_revision", "not_active", "rotation_disabled", "recovery_not_verified", "rollback_not_ready", "bindings_unprepared", "active_consumers", "audit_unavailable"];
export type SecretRotationBlocker = (typeof SECRET_ROTATION_BLOCKERS)[number];
export type SecretLifecycleProjection = {
    reference: string;
    revision: string;
    kind: "application_credential" | "encryption_key" | "tls_private_key" | "transport_credential";
    health: "invalid_evidence" | "healthy" | "rotation_due" | "expiring" | "expired" | "disabled" | "compromised" | "revoked";
    /** Product-provided Unix seconds, not an API status timestamp or raw key. */
    expiresAt?: number | null;
    rotatedAt?: number | null;
    dependencyCount: number;
    rotationPreview?: {
        reference: string;
        /** Must be bound to the product's currently validated exact revision. */
        expectedRevision: string;
        canProceedToProductAuthority: boolean;
        blockers: readonly SecretRotationBlocker[];
        requiresProductApply: true;
    };
};
export declare const RECOVERY_BACKUP_PROBLEMS: readonly ["wrong_backup_kind", "not_complete", "zero_length", "unencrypted", "future_evidence", "overdue", "restore_not_verified", "restore_evidence_stale"];
export type RecoveryBackupProblem = (typeof RECOVERY_BACKUP_PROBLEMS)[number];
export declare const RECOVERY_RESTORE_BLOCKERS: readonly ["wrong_product", "stale_backup_revision", "not_operational_backup", "incomplete_backup", "unencrypted_backup", "restore_proof_missing", "future_evidence", "restore_proof_stale", "unsupported", "permission_denied", "mfa_required", "integrity_unverified", "schema_unverified", "restore_drill_missing", "current_backup_missing", "rollback_not_ready", "offline_recovery_required", "audit_unavailable"];
export type RecoveryRestoreBlocker = (typeof RECOVERY_RESTORE_BLOCKERS)[number];
export type RecoveryBackupProjection = {
    /** Opaque validated product backup and revision references. */
    reference: string;
    revision: string;
    kind: "configuration_export" | "disaster_recovery";
    state: "succeeded" | "failed" | "incomplete";
    /** Pure product-supplied result of Python assess_backup. */
    assessment?: {
        healthy: boolean;
        problems: readonly RecoveryBackupProblem[];
    };
    /** Advisory Python preview_restore, tied to the same exact revision. */
    restorePreview?: {
        backupRef: string;
        expectedRevision: string;
        blockers: readonly RecoveryRestoreBlocker[];
        maySubmitToProductAuthority: boolean;
        productApplyRequired: true;
        freshnessChecked: boolean;
    };
};
export declare const DIAGNOSTIC_AREAS: readonly ["dns", "ntp", "proxy", "trusted_ca", "certificate"];
export type DiagnosticArea = (typeof DIAGNOSTIC_AREAS)[number];
export type DiagnosticSeverity = "pass" | "warn" | "fail" | "unknown" | "skipped";
export type DiagnosticReason = "healthy" | "evidence_stale" | "evidence_unavailable" | "dns_failure" | "time_not_synchronized" | "time_offset_high" | "time_offset_warning" | "proxy_disabled" | "proxy_failure" | "trusted_ca_not_configured" | "trusted_ca_failure" | "certificate_missing" | "certificate_expired" | "certificate_expiring";
export type DiagnosticRemediation = "none" | "collect_diagnostics" | "check_dns" | "restore_ntp" | "verify_proxy" | "check_enterprise_ca" | "renew_certificate";
export type DiagnosticReportProjection = {
    /** Unix epoch seconds, from the product's authenticated report. */
    collectedAt: number;
    /** Only a complete, self-consistent report can display a passing summary. */
    status: Exclude<DiagnosticSeverity, "skipped">;
    findings: readonly {
        area: DiagnosticArea;
        severity: DiagnosticSeverity;
        code: DiagnosticReason;
        remediation: DiagnosticRemediation;
        /** Unix epoch seconds. Must agree with the report's collection time. */
        checkedAt: number;
    }[];
};
export type HealthStatus = "healthy" | "degraded" | "unhealthy" | "unknown";
export type HealthProjection = {
    status: HealthStatus;
    checks?: readonly {
        id: string;
        label: string;
        status: HealthStatus;
        detail?: string;
    }[];
};
export type SystemInfoProjection = {
    facts: readonly {
        id: string;
        label: string;
        value: string;
    }[];
};
export type AuditEventProjection = {
    id: string;
    timestamp: string;
    action: string;
    actor?: string;
    outcome?: string;
    summary?: string;
    reference?: string;
};
export type RevisionProjection = {
    id: string;
    timestamp: string;
    label?: string;
    actor?: string;
    summary?: string;
    current?: boolean;
    audit?: AuditReference;
};
export type ArtifactReference = {
    id: string;
    label: string;
    sizeBytes?: number;
};
export type UpgradeCandidate = {
    currentVersion: string;
    targetVersion?: string;
    available: boolean;
    notes?: readonly string[];
};
