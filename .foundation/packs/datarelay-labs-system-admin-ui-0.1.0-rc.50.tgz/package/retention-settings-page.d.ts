import type { ReadBack } from "@datarelay-labs/system-contracts";
export declare const CONTROL_RETENTION_CATEGORIES: {
    readonly logs: "Logs";
    readonly runtime_metrics: "Runtime metrics";
    readonly preview_cache: "Preview cache";
    readonly backup_temp: "Backup temp";
};
export type RetentionCategoryId = keyof typeof CONTROL_RETENTION_CATEGORIES;
export type RetentionCategorySetting = {
    id: RetentionCategoryId;
    enabled: boolean;
    retentionDays: number;
    minimumDays: number;
    legalHold: boolean;
};
export type RetentionOutcome = {
    category: string;
    status: "ok" | "skipped" | "not_applicable" | "error";
    matchedCount: number;
    affectedCount: number;
};
export type RetentionCleanupResult = {
    previewRef: string;
    dryRun: false;
    auditReference: string;
    outcomes: readonly RetentionOutcome[];
};
export type RetentionSettingsState = {
    schedulerEnabled: boolean;
    schedulerActive: boolean;
    intervalMinutes: number;
    batchSize: number;
    lastSweepAt: string | null;
    categories: readonly RetentionCategorySetting[];
    lastResult?: RetentionCleanupResult;
};
export type RetentionPolicyDraft = {
    schedulerEnabled: boolean;
    intervalMinutes: number;
    batchSize: number;
    expectedRevision: string;
    categories: readonly Pick<RetentionCategorySetting, "id" | "enabled" | "retentionDays">[];
};
export type RetentionSafetyProof = {
    purpose: "policy" | "cleanup";
    expectedRevision: string;
    previewRef: string;
    allowed: boolean;
    blockers: readonly string[];
    actorAuthorized: boolean;
    recentMfaVerified: boolean;
    auditReady: boolean;
    protectedRecordsExcluded: boolean;
    backupReady: boolean;
    rollbackReady: boolean;
};
export type RetentionPolicyPreview = RetentionSafetyProof & {
    draft: RetentionPolicyDraft;
};
export type RetentionCleanupPreview = RetentionSafetyProof & {
    categories: readonly string[];
    dryRun: true;
    outcomes: readonly RetentionOutcome[];
};
/** Native adapters enforce authorization and consume revision/scope-bound preview references atomically. */
export type RetentionSettingsAdapter = {
    read: () => Promise<ReadBack<RetentionSettingsState>>;
    previewPolicy: (draft: RetentionPolicyDraft) => Promise<RetentionPolicyPreview>;
    configure: (draft: RetentionPolicyDraft, previewRef: string) => Promise<unknown>;
    dryRun: (request: {
        categories: readonly RetentionCategoryId[];
        expectedRevision: string;
    }) => Promise<RetentionCleanupPreview>;
    run: (request: {
        previewRef: string;
        expectedRevision: string;
        categories: readonly RetentionCategoryId[];
    }) => Promise<RetentionCleanupResult>;
};
export type RetentionSettingsPageProps = {
    adapter: RetentionSettingsAdapter;
    canManage?: boolean;
};
export declare function validateRetentionPolicy(state: RetentionSettingsState, draft: RetentionPolicyDraft): string | null;
/** Common Control Retention workflow. No storage or scheduler is changed without the native adapter. */
export declare function RetentionSettingsPage({ adapter, canManage }: RetentionSettingsPageProps): import("react").JSX.Element;
