import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Card, StatusBadge } from "@datarelay-labs/ui";
import { JOB_RETRY_BLOCKERS } from "@datarelay-labs/system-contracts";
const JOB_REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const RETRY_WARNING = {
    permission_denied: "Product actor permission denied",
    mfa_required: "Recent product MFA verification required",
    audit_unavailable: "Product retry audit unavailable",
    idempotency_unverified: "Product idempotency not proven",
    previous_attempt_active: "Previous attempt still running",
    retry_budget_exhausted: "Retry budget has been exhausted",
    backoff_pending: "Product retry backoff is pending",
    stale_revision: "Job execution revision has changed",
    scheduled_task: "Scheduled task must be retriggered through its schedule",
    runner_unavailable: "Product maintenance runner unavailable"
};
function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exact(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validRetryReview(value) {
    if (!record(value) || !exact(value, [
        "jobId", "expectedJobRevision", "retryClass", "allowed", "blockers",
        "productApplyRequired", "originalExecutionTerminal", "idempotencyVerified",
        "retryBudgetAvailable", "backoffElapsed", "actorAuthorized",
        "recentMfaVerified", "auditReady"
    ]) || typeof value.jobId !== "string" || !JOB_REFERENCE.test(value.jobId) ||
        typeof value.expectedJobRevision !== "string" ||
        !JOB_REFERENCE.test(value.expectedJobRevision) ||
        (value.retryClass !== "one_shot" && value.retryClass !== "scheduled") ||
        typeof value.allowed !== "boolean" || value.productApplyRequired !== true ||
        !Array.isArray(value.blockers) || value.blockers.length > JOB_RETRY_BLOCKERS.length)
        return false;
    for (const key of ["originalExecutionTerminal", "idempotencyVerified",
        "retryBudgetAvailable", "backoffElapsed", "actorAuthorized",
        "recentMfaVerified", "auditReady"])
        if (typeof value[key] !== "boolean")
            return false;
    const seen = new Set();
    for (const blocker of value.blockers) {
        if (typeof blocker !== "string" ||
            !JOB_RETRY_BLOCKERS.includes(blocker) ||
            seen.has(blocker))
            return false;
        seen.add(blocker);
    }
    return !value.allowed || value.blockers.length === 0;
}
function tone(state) {
    if (state === "SUCCEEDED")
        return "success";
    if (state === "FAILED")
        return "critical";
    if (state === "CANCELLED")
        return "neutral";
    return "info";
}
export function JobStatusPanel({ job, onCancel, cancelAccessibleLabel, renderResult, retryReview, retryJobRevision, retryAvailability = "unknown", onReviewRetry, retryPending = false }) {
    const progress = typeof job.progressPercent === "number"
        ? Math.min(100, Math.max(0, job.progressPercent))
        : undefined;
    const retryValid = retryReview !== undefined && validRetryReview(retryReview);
    const activeRetry = retryValid ? retryReview : undefined;
    const revisionValid = typeof retryJobRevision === "string" &&
        JOB_REFERENCE.test(retryJobRevision);
    const retryReady = Boolean(job.state === "FAILED" && activeRetry &&
        retryJobRevision && revisionValid &&
        activeRetry.jobId === job.id &&
        activeRetry.expectedJobRevision === retryJobRevision &&
        activeRetry.retryClass === "one_shot" &&
        activeRetry.allowed && activeRetry.blockers.length === 0 &&
        activeRetry.originalExecutionTerminal && activeRetry.idempotencyVerified &&
        activeRetry.retryBudgetAvailable && activeRetry.backoffElapsed &&
        activeRetry.actorAuthorized && activeRetry.recentMfaVerified &&
        activeRetry.auditReady);
    const canReviewRetry = retryReady && retryAvailability === "supported" &&
        typeof onReviewRetry === "function";
    return (_jsx(Card, { title: job.label ?? "Operation", actions: _jsx(StatusBadge, { tone: tone(job.state), children: job.state }), children: _jsxs("div", { className: "dr-admin__job", children: [progress !== undefined ? (_jsxs("div", { children: [_jsxs("div", { className: "dr-admin__progress-label", children: [_jsx("span", { children: "Progress" }), _jsxs("span", { children: [progress, "%"] })] }), _jsxs("progress", { max: 100, value: progress, children: [progress, "%"] })] })) : null, job.statusMessage ? _jsx("p", { children: job.statusMessage }) : null, job.error ? _jsx("p", { className: "dr-admin__job-error", role: "alert", children: job.error.message }) : null, job.state === "SUCCEEDED" && job.result !== undefined && renderResult ? (_jsx("div", { className: "dr-admin__job-result", "aria-label": "Operation result", children: renderResult(job.result) })) : null, job.auditReference ? _jsxs("p", { className: "dr-admin__muted", children: ["Reference: ", job.auditReference] }) : null, onCancel && job.cancellable ? (_jsx(Button, { variant: "secondary", "aria-label": cancelAccessibleLabel, onClick: () => void onCancel(job.id), children: "Cancel operation" })) : null, job.state === "FAILED" && retryReview !== undefined ? (_jsx("section", { className: "dr-admin__job-retry", "aria-label": "Product maintenance retry review", children: !retryValid ? (_jsx("p", { children: "Invalid product retry evidence" })) : activeRetry ? (_jsxs(_Fragment, { children: [!retryJobRevision ? _jsx("p", { children: "Current product job revision is unavailable" }) : null, retryJobRevision && !revisionValid ?
                                _jsx("p", { children: "Invalid product job revision" }) : null, revisionValid && activeRetry.expectedJobRevision !== retryJobRevision ?
                                _jsx("p", { children: "Job retry preview is stale" }) : null, activeRetry.jobId !== job.id ?
                                _jsx("p", { children: "Job retry preview refers to a different run" }) : null, activeRetry.retryClass === "scheduled" ?
                                _jsx("p", { children: "Scheduled jobs must be retriggered through the product schedule" }) : null, !activeRetry.originalExecutionTerminal ?
                                _jsx("p", { children: "Previous execution termination is not proven" }) : null, !activeRetry.idempotencyVerified ?
                                _jsx("p", { children: "Operation idempotence is not verified" }) : null, !activeRetry.retryBudgetAvailable ?
                                _jsx("p", { children: "Retry budget exhausted or unknown" }) : null, !activeRetry.backoffElapsed ?
                                _jsx("p", { children: "Product retry backoff is not complete" }) : null, !activeRetry.actorAuthorized ?
                                _jsx("p", { children: "Actor authorization not verified" }) : null, !activeRetry.recentMfaVerified ?
                                _jsx("p", { children: "Recent privileged MFA not verified" }) : null, !activeRetry.auditReady ?
                                _jsx("p", { children: "Product audit readiness not verified" }) : null, activeRetry.blockers.map((blocker) => _jsx("p", { children: RETRY_WARNING[blocker] }, blocker)), retryReady ? _jsx("p", { children: "Retry review eligible \u2014 product evidence only" }) :
                                _jsx("p", { children: "Retry requires a fresh, authorized and safe product preflight." }), canReviewRetry ? (_jsx(Button, { type: "button", variant: "secondary", disabled: retryPending, onClick: () => void onReviewRetry?.(job.id, retryJobRevision), children: "Review failed job retry" })) : null] })) : null })) : null] }) }));
}
