import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button, Card, StatusBadge } from "@datarelay-labs/ui";
import { SupportBundleWorkflow } from "./support-bundle-workflow.js";
import { RevisionList } from "./revision-list.js";
import { OperationalAlerts } from "./operational-alerts.js";
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v, n) => typeof v === "string" && v.length > 0 && v.length <= n;
const status = (v) => ["good", "medium", "bad", "unknown"].includes(String(v));
function summaryValid(v) {
    return record(v) && Number.isSafeInteger(v.windowSeconds) && Number(v.windowSeconds) > 0 &&
        Array.isArray(v.metrics) && v.metrics.length <= 256 && new Set(v.metrics.map(m => m?.id)).size === v.metrics.length && v.metrics.every(m => record(m) && text(m.id, 128) && text(m.label, 256) &&
        typeof m.available === "boolean" && (m.value === null || typeof m.value === "string" && m.value.length <= 2048) && status(m.status) &&
        (m.notes === undefined || typeof m.notes === "string" && m.notes.length <= 2048) && (m.relatedPath === undefined || typeof m.relatedPath === "string" && m.relatedPath.length <= 512));
}
function infoValid(v) {
    return record(v) && Array.isArray(v.facts) && v.facts.length <= 100 &&
        new Set(v.facts.map(f => f?.id)).size === v.facts.length && v.facts.every(f => record(f) && text(f.id, 128) && text(f.label, 256) && typeof f.value === "string" && f.value.length <= 2048);
}
function revisionsValid(v) {
    return Array.isArray(v) && v.length <= 100 && new Set(v.map(r => r?.id)).size === v.length && v.every(r => record(r) && text(r.id, 128) && typeof r.timestamp === "string" && Number.isFinite(Date.parse(r.timestamp)) &&
        ["label", "actor", "summary"].every(k => r[k] === undefined || typeof r[k] === "string" && r[k].length <= 2048));
}
function maintenanceValid(v) {
    return Array.isArray(v) && v.length <= 100 && new Set(v.map(p => p?.id)).size === v.length && v.every(p => record(p) && text(p.id, 128) && text(p.label, 256) && status(p.status) &&
        Array.isArray(p.facts) && p.facts.length <= 100 && p.facts.every(f => record(f) && text(f.label, 256) && typeof f.value === "string" && f.value.length <= 2048));
}
const tone = (s) => s === "good" ? "success" : s === "medium" ? "warning" : s === "bad" ? "critical" : "neutral";
const label = (s) => s === "good" ? "Good" : s === "medium" ? "Medium" : s === "bad" ? "Poor" : "Unknown";
const localPath = (v) => v.startsWith("/") && !v.startsWith("//") && !/[\\\s\x00-\x1f]/.test(v);
/** Authoritative health/maintenance observations; unavailable is never counted as healthy. */
export function SystemHealthPage({ adapter, canRead = false, alerts, support, onOpenRelated }) {
    const id = useId();
    const seq = useRef(0);
    const live = useRef({ adapter, canRead });
    live.current = { adapter, canRead };
    const [loaded, setLoaded] = useState(null);
    const [busy, setBusy] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const current = canRead && loaded?.adapter === adapter ? loaded : null;
    const metrics = current?.summary?.metrics ?? [];
    async function load() {
        if (!canRead)
            return;
        const n = ++seq.current;
        setBusy(true);
        setLoaded(null);
        const entries = [
            { name: "summary", label: "Health summary", read: adapter.readSummary, valid: summaryValid },
            { name: "info", label: "System information", read: adapter.readInfo, valid: infoValid },
            { name: "revisions", label: "Configuration history", read: adapter.readRevisions, valid: revisionsValid },
            { name: "maintenance", label: "Maintenance evidence", read: adapter.readMaintenance, valid: maintenanceValid }
        ];
        const settled = await Promise.all(entries.map(async (entry) => {
            if (!entry.read)
                return { name: entry.name, error: entry.label + " is unavailable." };
            try {
                const value = await entry.read();
                return entry.valid(value) ? { name: entry.name, value } : { name: entry.name, error: entry.label + " is unavailable." };
            }
            catch {
                return { name: entry.name, error: entry.label + " is unavailable." };
            }
        }));
        if (seq.current !== n || live.current.adapter !== adapter || !live.current.canRead)
            return;
        const result = { adapter, errors: settled.flatMap(r => r.error ? [r.error] : []) };
        for (const item of settled) {
            if (item.value !== undefined)
                Object.assign(result, { [item.name]: item.value });
        }
        setLoaded(result);
        setBusy(false);
    }
    useEffect(() => { setLoaded(null); setExpanded(false); setBusy(false); if (canRead)
        void load(); return () => { seq.current++; }; }, [adapter, canRead]);
    function metric(m) {
        const s = m.available ? m.status : "unknown";
        return _jsxs(Card, { title: m.label, actions: _jsx(StatusBadge, { tone: tone(s), children: label(s) }), children: [_jsx("p", { className: "dr-admin__health-value", children: m.available && m.value !== null ? m.value : "Not available" }), m.notes ? _jsx("p", { children: m.notes }) : null, m.relatedPath && localPath(m.relatedPath) && onOpenRelated ? _jsx(Button, { variant: "secondary", onClick: () => onOpenRelated(m.relatedPath), children: "Open related view" }) : null] }, m.id);
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "System health", children: _jsx("p", { children: "System health access is unavailable for this session." }) });
    return _jsxs("section", { className: "dr-admin__health-page", "aria-label": "System health", children: [_jsxs("header", { children: [_jsxs("div", { children: [_jsx("h3", { children: "System Health" }), _jsx("p", { children: "Current health, actionable signals and maintenance evidence from the product." })] }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh system health" })] }), busy ? _jsx("p", { role: "status", children: "Loading system health\u2026" }) : null, current?.errors.map(e => _jsx("p", { role: "status", children: e }, e)), current?.summary ? _jsxs(_Fragment, { children: [_jsxs("p", { children: ["Observation window: ", current.summary.windowSeconds, " seconds"] }), _jsx("dl", { className: "dr-admin__timezone-facts", children: [["Good", metrics.filter(m => m.available && m.status === "good").length], ["Medium", metrics.filter(m => m.available && m.status === "medium").length],
                            ["Poor", metrics.filter(m => m.available && m.status === "bad").length], ["Unknown / unavailable", metrics.filter(m => !m.available || m.status === "unknown").length]].map(([name, value]) => _jsxs("div", { children: [_jsx("dt", { children: name }), _jsx("dd", { children: value })] }, name)) }), _jsxs("section", { "aria-label": "Actionable health signals", children: [_jsx("h4", { children: "Actionable signals" }), _jsx("div", { className: "dr-admin__health-grid", children: metrics.filter(m => m.available && (m.status === "medium" || m.status === "bad")).map(metric) }), !metrics.some(m => m.available && (m.status === "medium" || m.status === "bad")) ? _jsx("p", { children: "No medium or poor signals reported. Unknown metrics may still need investigation." }) : null] }), _jsx(Button, { variant: "secondary", "aria-expanded": expanded, "aria-controls": id + "-metrics", onClick: () => setExpanded(v => !v), children: expanded ? "Hide all metrics" : "Show all metrics" }), expanded ? _jsx("div", { id: id + "-metrics", className: "dr-admin__health-grid", children: metrics.map(metric) }) : null] }) : null, current?.info ? _jsxs("section", { "aria-label": "System information", children: [_jsx("h4", { children: "System information" }), _jsx("dl", { className: "dr-admin__timezone-facts", children: current.info.facts.map(f => _jsxs("div", { children: [_jsx("dt", { children: f.label }), _jsx("dd", { children: f.value })] }, f.id)) })] }) : null, current?.maintenance ? _jsxs("section", { "aria-label": "Maintenance readiness", children: [_jsx("h4", { children: "Maintenance readiness" }), _jsx("div", { className: "dr-admin__health-grid", children: current.maintenance.map(p => _jsx(Card, { title: p.label, actions: _jsx(StatusBadge, { tone: tone(p.status), children: label(p.status) }), children: _jsxs("details", { children: [_jsx("summary", { children: "View evidence" }), _jsx("dl", { children: p.facts.map((f, i) => _jsxs("div", { children: [_jsx("dt", { children: f.label }), _jsx("dd", { children: f.value })] }, i)) })] }) }, p.id)) })] }) : null, current?.revisions ? _jsxs("section", { "aria-label": "Recent configuration history", children: [_jsx("h4", { children: "Recent configuration history" }), _jsx(RevisionList, { revisions: current.revisions })] }) : null, support ? _jsx(SupportBundleWorkflow, { ...support }) : null, alerts ? _jsx(OperationalAlerts, { ...alerts, canRead: canRead && Boolean(alerts.canRead) }) : _jsx("p", { children: "Operational alerting is not connected for this product." })] });
}
