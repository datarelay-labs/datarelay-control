import { type ManagementAccessPolicyProjection } from "@datarelay-labs/system-contracts";
export type ManagementAccessSourceDraft = {
    cidr: string;
    expiresAt?: number | null;
};
export type ManagementAccessSurfaceDraft = {
    enabled: boolean;
    sources: ManagementAccessSourceDraft[];
};
export type ManagementAccessDraft = {
    expectedRevision: string;
    rollbackSeconds: number;
    ssh: ManagementAccessSurfaceDraft;
    web: ManagementAccessSurfaceDraft;
};
export type ManagementAccessReadState = {
    revision: string;
    policy: Omit<ManagementAccessPolicyProjection, "preview">;
};
export type ManagementAccessPreviewResult = {
    previewRef: string;
    expectedRevision: string;
    expiresAt: number;
    allowed: boolean;
    blockers: string[];
    policy: ManagementAccessPolicyProjection;
    draft: ManagementAccessDraft;
};
export type ManagementAccessApplyReceipt = {
    applied: true;
    revision: string;
    auditReference: string;
    policy: Omit<ManagementAccessPolicyProjection, "preview">;
};
export type ManagementAccessAdapter = {
    read: () => Promise<ManagementAccessReadState>;
    preview: (draft: ManagementAccessDraft) => Promise<ManagementAccessPreviewResult>;
    apply: (request: {
        draft: ManagementAccessDraft;
        previewRef: string;
        confirm: true;
    }) => Promise<ManagementAccessApplyReceipt>;
};
export type ManagementAccessPageProps = {
    adapter: ManagementAccessAdapter;
    canRead?: boolean;
    canManage?: boolean;
};
export declare function ManagementAccessPage({ adapter, canRead, canManage }: ManagementAccessPageProps): import("react").JSX.Element;
