import type { RevisionProjection, SystemInfoProjection } from "@datarelay-labs/system-contracts";
import { type SupportBundleWorkflowProps } from "./support-bundle-workflow";
import { type OperationalAlertsProps } from "./operational-alerts";
export type SystemMetricStatus = "good" | "medium" | "bad" | "unknown";
export type SystemHealthMetric = {
    id: string;
    label: string;
    available: boolean;
    value: string | null;
    status: SystemMetricStatus;
    notes?: string;
    relatedPath?: string;
};
export type SystemHealthSummary = {
    windowSeconds: number;
    metrics: readonly SystemHealthMetric[];
};
export type MaintenanceEvidencePanel = {
    id: string;
    label: string;
    status: SystemMetricStatus;
    facts: readonly {
        label: string;
        value: string;
    }[];
};
export type SystemHealthAdapter = {
    readSummary: () => Promise<SystemHealthSummary>;
    readInfo?: () => Promise<SystemInfoProjection>;
    readRevisions?: () => Promise<readonly RevisionProjection[]>;
    readMaintenance?: () => Promise<readonly MaintenanceEvidencePanel[]>;
};
export type SystemHealthPageProps = {
    adapter: SystemHealthAdapter;
    canRead?: boolean;
    alerts?: OperationalAlertsProps;
    support?: SupportBundleWorkflowProps;
    onOpenRelated?: (path: string) => void;
};
/** Authoritative health/maintenance observations; unavailable is never counted as healthy. */
export declare function SystemHealthPage({ adapter, canRead, alerts, support, onOpenRelated }: SystemHealthPageProps): import("react").JSX.Element;
