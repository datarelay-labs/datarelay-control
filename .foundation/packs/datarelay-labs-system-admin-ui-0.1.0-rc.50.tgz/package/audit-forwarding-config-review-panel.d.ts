import { type AuditForwardingConfigReviewProjection, type CapabilityAvailability } from "@datarelay-labs/system-contracts";
export type AuditForwardingConfigReviewPanelProps = {
    /** Current backend-approved *settings*, not an audit event or raw endpoint. */
    projection?: AuditForwardingConfigReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Product-only review/confirmation; no sink write, file or network send. */
    onReviewConfig?: (sinkReference: string, expectedRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Product-owned sink settings review, kept separate from AuditForwardingPanel
 * transport-attempt status. Neither UI authenticates downstream SIEM ingestion. */
export declare function AuditForwardingConfigReviewPanel({ projection, reviewAvailability, onReviewConfig, pending }: AuditForwardingConfigReviewPanelProps): import("react").JSX.Element;
