import { type CapabilityAvailability, type DiagnosticReportProjection } from "@datarelay-labs/system-contracts";
export type SystemDoctorProps = {
    /** Read-only, already-authorized report from the owning product's PF-11 adapter.
     * The matching Python DiagnosticReport is not invoked or trusted automatically. */
    report?: DiagnosticReportProjection;
    /** The product asserts a *current* server-authorized diagnostic action. No default grant. */
    runAvailability?: CapabilityAvailability | "unknown";
    onRunDiagnostics?: () => void | Promise<void>;
    /** Product-owned pending state, never inferred from click. */
    running?: boolean;
};
/** Presentation only. It never runs a probe, fetches privileged data, authorizes a
 * user or treats a missing/contradictory product report as evidence of health. */
export declare function SystemDoctor({ report, runAvailability, onRunDiagnostics, running }: SystemDoctorProps): import("react").JSX.Element;
