import { type ChangeEventHandler } from "react";
export type PasswordRevealFieldProps = {
    label: string;
    autoComplete: "current-password" | "new-password";
    value: string;
    onChange: ChangeEventHandler<HTMLInputElement>;
    disabled?: boolean;
    allowReveal?: boolean;
    placeholder?: string;
};
/** Pure UI state. Authentication and password policy remain consumer-owned. */
export declare function PasswordRevealField({ label, autoComplete, value, onChange, disabled, allowReveal, placeholder }: PasswordRevealFieldProps): import("react").JSX.Element;
