import { type ReactNode, type SVGProps } from "react";
import type { LoginFormProps } from "./login-form";
import type { AuthAdapter, AuthErrorCategory, AuthResourceLink } from "./types";
export declare const DEFAULT_DATARELAY_LOGIN_RESOURCES: readonly AuthResourceLink[];
export type DataRelayLogoMarkProps = SVGProps<SVGSVGElement> & {
    label?: string;
};
export declare function DataRelayLogoMark({ label, className, ...props }: DataRelayLogoMarkProps): import("react").JSX.Element;
export type DataRelayLoginPageProps = Omit<LoginFormProps, "submitLabel" | "allowPasswordReveal"> & {
    productName?: string;
    productSubtitle?: string;
    description?: string;
    title?: string;
    subtitle?: string;
    resources?: readonly AuthResourceLink[];
    brandMark?: ReactNode;
    submitLabel?: string;
    allowPasswordReveal?: boolean;
    accountNotice?: string;
};
export declare function DataRelayLoginPage({ productName, productSubtitle, description, title, subtitle, resources, brandMark, submitLabel, allowPasswordReveal, accountNotice, ...formProps }: DataRelayLoginPageProps): import("react").JSX.Element;
export type DataRelayLoginFlowProps<Principal = unknown> = Omit<DataRelayLoginPageProps, "onSubmit" | "busy" | "errorCategory" | "errorMessage"> & {
    adapter: Pick<AuthAdapter<Principal>, "signIn"> & Partial<Pick<AuthAdapter<Principal>, "verifyMfa">>;
    onAuthenticated?: (principal: Principal) => void | Promise<void>;
    onPasswordChangeRequired?: (principal?: Principal) => void | Promise<void>;
    mapError?: (error: unknown) => {
        category: AuthErrorCategory;
        message: string;
    };
};
export declare function DataRelayLoginFlow<Principal = unknown>({ adapter, onAuthenticated, onPasswordChangeRequired, mapError, productName, productSubtitle, description, title, subtitle, resources, brandMark, submitLabel, allowPasswordReveal, accountNotice, initialUsername, infoMessage }: DataRelayLoginFlowProps<Principal>): import("react").JSX.Element;
