import type { AuthErrorCategory, PasswordChangeSubmission } from "./types";
export type PasswordChangeFormProps = {
    onSubmit: (submission: PasswordChangeSubmission) => void | Promise<void>;
    busy?: boolean;
    requireCurrentPassword?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
    guidance?: string;
    /** Optional independent reveal toggles for each product-owned password field. */
    allowPasswordReveal?: boolean;
};
export declare function PasswordChangeForm({ onSubmit, busy, requireCurrentPassword, errorCategory, errorMessage, guidance, allowPasswordReveal }: PasswordChangeFormProps): import("react").JSX.Element;
