import { type CapabilityAvailability, type NotificationDestinationProjection } from "@datarelay-labs/system-contracts";
export type NotificationDeliveryPanelProps = {
    /** Only current authorized destination snapshots from the owning product. */
    destinations: readonly NotificationDestinationProjection[];
    /** Default OFF local-only attention triage. No server paging/filter authority. */
    triageLoadedNotificationDestinations?: boolean;
    /** Explicit current product capability; unknown/no callback cannot start a send. */
    testAvailability?: CapabilityAvailability | "unknown";
    onRequestTest?: (destinationRef: string, expectedRevision: string) => void | Promise<void>;
    /** Pending flag controlled by the owning product's actual send lifecycle. */
    pendingTestReference?: string;
};
/** PF-11: loaded-only code-safe destination status and test admission.
 * It never stores/configures credentials, sends mail, invokes a Webhook,
 * advances a durable queue or claims that a downstream recipient received data. */
export declare function NotificationDeliveryPanel({ destinations, triageLoadedNotificationDestinations, testAvailability, onRequestTest, pendingTestReference }: NotificationDeliveryPanelProps): import("react").JSX.Element;
