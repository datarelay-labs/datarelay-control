import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button, EmptyState, TextField } from "@datarelay-labs/ui";
import { JOB_STATES } from "@datarelay-labs/system-contracts";
import { JobStatusPanel } from "./job-status-panel.js";
export function JobList({ jobs, filterLoadedJobs = false, resetLoadedJobFilters = false, sortLoadedJobs = false, hideLoadedSuccessfulJobs = false, discloseLoadedJobDetails = false, onCancel, renderResult }) {
    const [query, setQuery] = useState("");
    const [selectedState, setSelectedState] = useState("");
    const [selectedOrder, setSelectedOrder] = useState("");
    const [hideSuccessful, setHideSuccessful] = useState(false);
    const activeHideSuccessful = hideLoadedSuccessfulJobs && hideSuccessful;
    const selectId = useId().replaceAll(":", "");
    const stateOptions = JOB_STATES.filter((state) => !(activeHideSuccessful && state === "SUCCEEDED") && jobs.some((job) => job.state === state));
    const activeState = filterLoadedJobs && stateOptions.includes(selectedState)
        ? selectedState : "";
    const hasActiveLoadedFilters = Boolean(query.trim() || activeState);
    useEffect(() => {
        if (selectedState && (!filterLoadedJobs || !stateOptions.includes(selectedState))) {
            setSelectedState("");
        }
    }, [jobs, filterLoadedJobs, selectedState, activeHideSuccessful]);
    useEffect(() => {
        if (!hideLoadedSuccessfulJobs)
            setHideSuccessful(false);
    }, [hideLoadedSuccessfulJobs]);
    if (jobs.length === 0) {
        return _jsx(EmptyState, { title: "No operations", description: "No operations are currently supplied by the product adapter." });
    }
    const phrase = filterLoadedJobs ? query.trim().toLowerCase() : "";
    const visible = jobs.filter((job) => (!activeHideSuccessful || job.state !== "SUCCEEDED") &&
        (!activeState || job.state === activeState) &&
        (!phrase || (job.label ?? "").toLowerCase().includes(phrase)));
    // Sort only the currently supplied (and optionally filtered) page. Missing
    // product labels remain last in either direction, equal labels remain stable.
    const comparator = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
    const ordered = sortLoadedJobs && selectedOrder
        ? [...visible].sort((a, b) => {
            const left = a.label?.trim() ?? "";
            const right = b.label?.trim() ?? "";
            if (!left || !right)
                return !left && !right ? 0 : !left ? 1 : -1;
            const difference = comparator.compare(left, right);
            return selectedOrder === "label-asc" ? difference : -difference;
        })
        : visible;
    const renderPanel = (job, index) => (_jsx(JobStatusPanel, { job: job, ...(onCancel ? { onCancel } : {}), ...(renderResult ? { renderResult } : {}), cancelAccessibleLabel: `Cancel operation: ${job.label ?? `Operation ${index + 1}`}` }));
    const list = (_jsx("ol", { className: "dr-admin__job-list", "aria-label": "Loaded operations", children: ordered.map((job, index) => (_jsx("li", { className: "dr-admin__job-list-item", children: discloseLoadedJobDetails ? (_jsxs("details", { className: "dr-admin__job-disclosure", children: [_jsxs("summary", { className: "dr-admin__job-summary", children: [_jsx("strong", { children: job.label ?? `Operation ${index + 1}` }), _jsx("span", { className: "dr-admin__job-summary-state", children: job.state }), _jsx("span", { className: "dr-admin__job-summary-hint", children: "Details" })] }), renderPanel(job, index)] })) : renderPanel(job, index) }, job.id))) }));
    if (!filterLoadedJobs && !sortLoadedJobs &&
        !hideLoadedSuccessfulJobs && !discloseLoadedJobDetails)
        return list;
    return (_jsxs("div", { className: "dr-admin__job-discovery", children: [hideLoadedSuccessfulJobs ? (_jsxs("label", { className: "dr-admin__job-hide-success", children: [_jsx("input", { type: "checkbox", checked: activeHideSuccessful, onChange: (event) => {
                            const checked = event.target.checked;
                            setHideSuccessful(checked);
                            if (checked)
                                setSelectedState((current) => current === "SUCCEEDED" ? "" : current);
                        } }), "Hide successful loaded operations"] })) : null, filterLoadedJobs ? _jsxs("div", { className: "dr-admin__job-filters", children: [_jsx(TextField, { id: selectId + "-job-search", type: "search", label: "Find loaded operations", value: query, maxLength: 120, autoComplete: "off", onChange: (event) => setQuery(event.target.value) }), _jsxs("div", { className: "dr-admin__job-state-filter", children: [_jsx("label", { htmlFor: selectId + "-job-state", children: "Filter loaded operation status" }), _jsxs("select", { id: selectId + "-job-state", value: activeState, onChange: (event) => setSelectedState(event.target.value), children: [_jsxs("option", { value: "", children: ["All loaded states (", jobs.length, ")"] }), stateOptions.map((state) => (_jsxs("option", { value: state, children: [state, " (", jobs.filter((job) => job.state === state).length, " loaded)"] }, state)))] })] })] }) : null, sortLoadedJobs ? (_jsxs("div", { className: "dr-admin__job-order", children: [_jsx("label", { htmlFor: selectId + "-job-order", children: "Order loaded operations" }), _jsxs("select", { id: selectId + "-job-order", value: selectedOrder, onChange: (event) => setSelectedOrder(event.target.value), children: [_jsx("option", { value: "", children: "Adapter order" }), _jsx("option", { value: "label-asc", children: "Operation label A-Z" }), _jsx("option", { value: "label-desc", children: "Operation label Z-A" })] })] })) : null, filterLoadedJobs && resetLoadedJobFilters && hasActiveLoadedFilters ? (_jsx(Button, { type: "button", variant: "secondary", className: "dr-admin__job-reset", onClick: () => {
                    setQuery("");
                    setSelectedState("");
                    document.getElementById(selectId + "-job-search")?.focus();
                }, children: "Clear loaded operation filters" })) : null, _jsxs("p", { className: "dr-admin__muted", role: "status", "aria-live": "polite", children: ["Showing ", visible.length, " of ", jobs.length, " loaded operations. Only jobs supplied by the product adapter are displayed."] }), visible.length ? list : _jsx(EmptyState, { title: "No matching loaded operations", description: "No currently loaded job matches these local filters; no server-wide job query was performed." })] }));
}
