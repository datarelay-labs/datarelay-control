"""Common health interpretation over read-only native telemetry and metadata.

No host probing, monitoring daemon, secret collection or configuration mutation
is installed. Native sources expose scoped, bounded observations and verified
public metadata. Thresholds are native product policy, not universal defaults.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Protocol
import math
import time
import unicodedata

from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError


class HealthReadUnavailable(RuntimeError):
    """Native telemetry unavailable; this is not evidence of a healthy system."""


def _text(value: object, maximum: int, *, empty: bool = False) -> str:
    if (not isinstance(value, str) or len(value) > maximum or (not empty and not value)
            or any(unicodedata.category(c).startswith('C') for c in value)):
        raise SettingsValidationError('Invalid public health metadata.')
    return value


def _number(value: object) -> float:
    if type(value) not in (float, int) or not math.isfinite(value) or abs(value) > 2**53 - 1:
        raise SettingsValidationError('Health observations must contain bounded finite numbers.')
    return float(value)


def _clock(value: object) -> float:
    result = _number(value)
    if not 0 <= result <= 253402300000:
        raise SettingsValidationError('Invalid native observation time.')
    return result


def _timestamp(value: object) -> str:
    _text(value, 64)
    try:
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            raise ValueError('timezone required')
        return stamp.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')
    except (ValueError, TypeError, OverflowError):
        raise SettingsValidationError('Configuration evidence requires an explicit valid timestamp.') from None


@dataclass(frozen=True)
class HealthMetricSample:
    id: str
    label: str
    value: float | int | None
    unit: str
    observed_at: float
    warning: float | int | None
    critical: float | int | None
    direction: str = 'high'
    max_age_seconds: int = 300
    notes: str | None = None
    related_path: str | None = None

    def __post_init__(self) -> None:
        _text(self.id, 128); _text(self.label, 256); _text(self.unit, 32, empty=True); _clock(self.observed_at)
        if self.value is not None:
            _number(self.value)
        if (self.direction not in ('high', 'low') or type(self.max_age_seconds) is not int
                or not 1 <= self.max_age_seconds <= 86400 or (self.warning is None) != (self.critical is None)):
            raise SettingsValidationError('Invalid native health threshold or freshness policy.')
        if self.warning is not None:
            warning, critical = _number(self.warning), _number(self.critical)
            if (self.direction == 'high' and warning > critical) or (self.direction == 'low' and warning < critical):
                raise SettingsValidationError('Warning and critical thresholds are out of order.')
        if self.notes is not None:
            _text(self.notes, 2048, empty=True)
        if self.related_path is not None:
            path = _text(self.related_path, 512)
            if (not path.startswith('/') or path.startswith('//') or any(c.isspace() for c in path)
                    or any(c in path for c in ('\\', '?', '#', '%'))):
                raise SettingsValidationError('Related health links must be local static paths without tokens.')


@dataclass(frozen=True)
class HealthSummarySnapshot:
    window_seconds: int
    metrics: tuple[HealthMetricSample, ...]


@dataclass(frozen=True)
class HealthMetadata:
    value: Any
    redaction_verified: bool = False


class SystemHealthSource(Protocol):
    """Bind existing product telemetry and public native evidence endpoints.

    Each read authorizes the actual native actor/scope; metadata contains no raw
    configuration, payload, address credentials or secret values. Metric values,
    timestamps and thresholds come from native evidence/policy, never a posted
    browser status. Observations must remain detached from concurrent mutation.
    Each optional metadata read returns independently redaction-verified data;
    unsupported native endpoints raise rather than synthesizing healthy output.
    """
    def read_summary(self, actor: SettingsActor) -> HealthSummarySnapshot: ...
    def read_info(self, actor: SettingsActor) -> HealthMetadata: ...
    def read_revisions(self, actor: SettingsActor) -> HealthMetadata: ...
    def read_maintenance(self, actor: SettingsActor) -> HealthMetadata: ...


class SystemHealthService:
    def __init__(self, source: SystemHealthSource, *, authorize: Callable[[SettingsActor, str], bool],
                 clock: Callable[[], float] = time.time) -> None:
        if not callable(authorize):
            raise SettingsValidationError('Current native health authority is required.')
        self.source = source; self.authorize = authorize; self.clock = clock

    def _require(self, actor: SettingsActor) -> None:
        try:
            allowed = isinstance(actor, SettingsActor) and 'health.read' in actor.capabilities and self.authorize(actor, 'health.read') is True
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError('Native actor does not currently authorize reading system health.')

    def _read(self, actor: SettingsActor, method: str) -> Any:
        self._require(actor)
        try:
            result = getattr(self.source, method)(actor)
        except Exception:
            raise HealthReadUnavailable('Native health evidence is unavailable. It must not be treated as healthy.') from None
        self._require(actor)
        return result

    @staticmethod
    def _metric(sample: HealthMetricSample, now: float) -> dict[str, Any]:
        available = sample.value is not None and 0 <= now - sample.observed_at <= sample.max_age_seconds
        result: dict[str, Any] = {'id': sample.id, 'label': sample.label, 'available': available, 'value': None, 'status': 'unknown'}
        if sample.notes is not None:
            result['notes'] = sample.notes
        if sample.related_path is not None:
            result['relatedPath'] = sample.related_path
        if not available:
            result['notes'] = ('Metric value is unavailable.' if sample.value is None else
                'Observation is ahead of the server clock.' if now < sample.observed_at else 'Metric observation is stale.')
            return result
        number = format(sample.value, '.12g')
        result['value'] = number + (sample.unit if sample.unit in ('', '%') else ' ' + sample.unit)
        if sample.warning is None:
            result['notes'] = 'No native health thresholds are configured.'
            return result
        def reached(threshold: float) -> bool:
            return sample.value >= threshold if sample.direction == 'high' else sample.value <= threshold
        result['status'] = 'bad' if reached(sample.critical) else 'medium' if reached(sample.warning) else 'good'
        return result

    def read_summary(self, actor: SettingsActor) -> dict[str, Any]:
        snapshot = self._read(actor, 'read_summary')
        if (not isinstance(snapshot, HealthSummarySnapshot) or type(snapshot.window_seconds) is not int
                or not 1 <= snapshot.window_seconds <= 86400 or not isinstance(snapshot.metrics, tuple)
                or len(snapshot.metrics) > 256 or any(not isinstance(m, HealthMetricSample) for m in snapshot.metrics)
                or len({m.id for m in snapshot.metrics}) != len(snapshot.metrics)):
            raise SettingsValidationError('Invalid native health summary snapshot.')
        now = _clock(self.clock())
        return {'windowSeconds': snapshot.window_seconds, 'metrics': [self._metric(m, now) for m in snapshot.metrics]}

    def _metadata(self, actor: SettingsActor, method: str) -> Any:
        raw = self._read(actor, method)
        if not isinstance(raw, HealthMetadata) or raw.redaction_verified is not True:
            raise SettingsValidationError('Native public health metadata requires verified redaction.')
        return deepcopy(raw.value)

    @staticmethod
    def _rows(value: Any, limit: int = 100) -> list[dict[str, Any]]:
        if not isinstance(value, list) or len(value) > limit or any(not isinstance(v, dict) for v in value):
            raise SettingsValidationError('Invalid bounded native health metadata list.')
        return value

    @staticmethod
    def _facts(value: Any, *, identifiers: bool) -> list[dict[str, Any]]:
        rows = SystemHealthService._rows(value)
        ids: set[str] = set()
        for row in rows:
            if set(row) != ({'id', 'label', 'value'} if identifiers else {'label', 'value'}):
                raise SettingsValidationError('Only public health facts may be exposed.')
            _text(row['label'], 256); _text(row['value'], 2048, empty=True)
            if identifiers:
                key = _text(row['id'], 128)
                if key in ids:
                    raise SettingsValidationError('Native health fact identifiers must be unique.')
                ids.add(key)
        return rows

    def read_info(self, actor: SettingsActor) -> dict[str, Any]:
        value = self._metadata(actor, 'read_info')
        if not isinstance(value, dict) or set(value) != {'facts'}:
            raise SettingsValidationError('Only public system information facts may be exposed.')
        return {'facts': self._facts(value['facts'], identifiers=True)}

    def read_revisions(self, actor: SettingsActor) -> list[dict[str, Any]]:
        rows = self._rows(self._metadata(actor, 'read_revisions')); ids: set[str] = set(); current_count = 0
        for row in rows:
            if not {'id', 'timestamp'} <= set(row) or not set(row) <= {'id', 'timestamp', 'label', 'actor', 'summary', 'current', 'audit'}:
                raise SettingsValidationError('Invalid public revision metadata.')
            key = _text(row['id'], 128); row['timestamp'] = _timestamp(row['timestamp'])
            if key in ids:
                raise SettingsValidationError('Revision identities must be unique.')
            ids.add(key)
            for field in ('label', 'actor', 'summary'):
                if field in row:
                    _text(row[field], 2048, empty=True)
            if 'current' in row:
                if type(row['current']) is not bool:
                    raise SettingsValidationError('Current revision must be a Boolean fact.')
                current_count += int(row['current'])
            if 'audit' in row:
                if not isinstance(row['audit'], dict) or set(row['audit']) != {'id'}:
                    raise SettingsValidationError('Only the audit reference may be attached to a revision.')
                _text(row['audit']['id'], 256)
        if current_count > 1:
            raise SettingsValidationError('Only one native configuration revision may be current.')
        return rows

    def read_maintenance(self, actor: SettingsActor) -> list[dict[str, Any]]:
        rows = self._rows(self._metadata(actor, 'read_maintenance')); ids: set[str] = set()
        for row in rows:
            if set(row) != {'id', 'label', 'status', 'facts'} or row['status'] not in ('good', 'medium', 'bad', 'unknown'):
                raise SettingsValidationError('Invalid maintenance evidence projection.')
            key = _text(row['id'], 128); _text(row['label'], 256)
            if key in ids:
                raise SettingsValidationError('Maintenance evidence identifiers must be unique.')
            ids.add(key); self._facts(row['facts'], identifiers=False)
        return rows
