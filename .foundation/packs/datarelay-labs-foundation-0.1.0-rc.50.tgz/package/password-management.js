import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { PasswordChangeForm } from "@datarelay-labs/auth-ui";
import { Button } from "@datarelay-labs/ui";
import { validateManagedPassword } from "@datarelay-labs/system-admin-ui";
function validState(value) {
    if (!value || typeof value !== "object")
        return false;
    const v = value, p = v.passwordPolicy;
    return [v.username, v.revision, v.credentialRevision].every(s => typeof s === "string" && s.length > 0 && s.length <= 256 && !/[\u0000-\u001f\u007f]/.test(s)) &&
        Number.isSafeInteger(v.sessionEpoch) && v.sessionEpoch >= 0 && Boolean(p) &&
        Number.isInteger(p.minimumLength) && Number.isInteger(p.maximumLength) && p.minimumLength >= 8 && p.maximumLength >= p.minimumLength && p.maximumLength <= 1024;
}
/** Full native-adapter workflow built around the existing common password form. */
export function PasswordManagementPage({ adapter, canRead = false, canChange = false }) {
    const live = useRef({ adapter, canRead, canChange, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead || live.current.canChange !== canChange)
        live.current = { adapter, canRead, canChange, epoch: live.current.epoch + 1 };
    const [loaded, setLoaded] = useState(null);
    const state = loaded?.source === adapter && canRead ? loaded.value : null;
    const [busy, setBusy] = useState(false), [error, setError] = useState("");
    const [notice, setNotice] = useState(""), [generation, setGeneration] = useState(0);
    const [unknown, setUnknown] = useState(false);
    const serial = useRef(0), submitting = useRef(false);
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead && (!write || live.current.canChange);
    useEffect(() => { void load(); return () => { serial.current++; live.current.epoch++; }; }, [adapter, canRead]);
    useEffect(() => { setGeneration(n => n + 1); submitting.current = false; setBusy(false); }, [adapter, canRead, canChange]);
    async function load() {
        if (!canRead) {
            setLoaded(null);
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        try {
            const result = await adapter.read();
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validState(result))
                throw new Error("invalid");
            setLoaded({ source: adapter, value: result });
            setUnknown(false);
            setGeneration(n => n + 1);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setLoaded(null);
                setError("Unable to read current credential policy. Refresh to retry.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    async function change(submission) {
        if (!canRead || !canChange || !state || busy || submitting.current || unknown)
            return;
        const problem = validateManagedPassword(submission.newPassword, state.passwordPolicy);
        if (problem) {
            setError(problem);
            return;
        }
        if (!submission.currentPassword || submission.newPassword !== submission.confirmPassword) {
            setError("Enter the current password and matching new-password confirmation.");
            return;
        }
        const epoch = live.current.epoch;
        submitting.current = true;
        setBusy(true);
        setError("");
        setNotice("");
        let started = false;
        try {
            const before = await adapter.read();
            if (!fresh(epoch, true))
                return;
            if (!validState(before) || before.revision !== state.revision || before.credentialRevision !== state.credentialRevision || before.username !== state.username ||
                before.sessionEpoch !== state.sessionEpoch ||
                before.passwordPolicy.minimumLength !== state.passwordPolicy.minimumLength ||
                before.passwordPolicy.maximumLength !== state.passwordPolicy.maximumLength)
                throw new Error("stale");
            const policyProblem = validateManagedPassword(submission.newPassword, before.passwordPolicy);
            if (policyProblem)
                throw new Error("policy");
            started = true;
            const receipt = await adapter.change({ ...submission, expectedRevision: before.revision });
            if (!fresh(epoch, true))
                return;
            const after = await adapter.read();
            if (!fresh(epoch, true))
                return;
            if (!validState(after))
                throw new Error("unverified");
            setLoaded({ source: adapter, value: after });
            if (!receipt || receipt.changed !== true || typeof receipt.auditRef !== "string" || !receipt.auditRef ||
                after.username !== before.username || after.revision !== receipt.revision || after.revision === before.revision ||
                after.credentialRevision !== receipt.credentialRevision || after.credentialRevision === before.credentialRevision ||
                after.sessionEpoch !== receipt.sessionEpoch || after.sessionEpoch <= before.sessionEpoch)
                throw new Error("unverified");
            setNotice("Password changed and credential state verified.");
        }
        catch {
            if (fresh(epoch)) {
                setUnknown(started);
                setError(started ? "Password change was not verified. Check your account or contact an administrator before retrying." : "Credential state changed. Refresh before retrying.");
            }
        }
        finally {
            if (fresh(epoch)) {
                setBusy(false);
                setGeneration(n => n + 1);
            }
            submitting.current = false;
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "Password management", children: _jsx("p", { role: "status", children: "Password management is not authorized." }) });
    return _jsxs("section", { className: "dr-management__password", "aria-label": "Password management", children: [_jsxs("header", { children: [_jsx("h3", { children: "Password Management" }), _jsx("p", { children: "Change your platform password. The native service verifies your current password and updates credential and session state." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, state ? _jsxs(_Fragment, { children: [_jsxs("dl", { children: [_jsx("dt", { children: "Account" }), _jsx("dd", { children: state.username }), _jsx("dt", { children: "Password policy" }), _jsxs("dd", { children: [state.passwordPolicy.minimumLength, "\u2013", state.passwordPolicy.maximumLength, " characters"] })] }), canChange && !unknown ? _jsx(PasswordChangeForm, { busy: busy, allowPasswordReveal: true, onSubmit: change, guidance: "The current password is required. Existing sessions must honor the new credential epoch. No password appears in read-back or audit evidence." }, generation)
                        : _jsx("p", { children: unknown ? "Outcome reconciliation is required before another password change." : "This session has read-only credential access." })] }) : busy ? _jsx("p", { role: "status", children: "Loading credential policy\u2026" }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh credential state" })] });
}
