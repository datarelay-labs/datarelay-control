import { type CapabilityAvailability, type RoleChangeReviewProjection } from "@datarelay-labs/system-contracts";
export type RoleChangeReviewPanelProps = {
    /** Already-authorized, current, product-provided immutable role preview. */
    change?: RoleChangeReviewProjection;
    /** Current product permission, not inferred from the displayed preview. */
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Opens only a product-owned confirmation; Foundation never writes roles. */
    onReviewRoleChange?: (currentRoleRef: string, proposedRoleRef: string, currentRevision: string) => void | Promise<void>;
    /** Server/product-owned pending indicator. */
    pending?: boolean;
};
/** Product-neutral role/capability impact preflight. No role store, session
 * mutation, self-escalation, impersonation or permission issuing. */
export declare function RoleChangeReviewPanel({ change, reviewAvailability, onReviewRoleChange, pending }: RoleChangeReviewPanelProps): import("react").JSX.Element;
