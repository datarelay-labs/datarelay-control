import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button, StatusBadge } from "@datarelay-labs/ui";
const PAGE_SIZE = 100;
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v, cap) => typeof v === "string" && v.length <= cap;
function validResult(value, q) {
    if (!record(value) || !Number.isSafeInteger(value.total) || Number(value.total) < 0 || value.offset !== q.offset || value.limit !== q.limit ||
        !Array.isArray(value.items) || value.items.length > q.limit || Number(value.total) < value.items.length + q.offset)
        return false;
    const ids = new Set();
    for (const row of value.items) {
        if (!record(row) || !text(row.id, 256) || !row.id || ids.has(row.id) || !text(row.action, 256) || !text(row.result, 100) ||
            !text(row.timestamp, 64) || !Number.isFinite(Date.parse(row.timestamp)) ||
            !["actor", "entityType", "entityId", "summary"].every(k => row[k] === undefined || row[k] === null || text(row[k], k === "summary" ? 2048 : 256)))
            return false;
        ids.add(row.id);
    }
    return true;
}
function buildQuery(action, entityType, result, offset) {
    return { limit: PAGE_SIZE, offset, ...(action.trim() ? { action: action.trim() } : {}), ...(entityType.trim() ? { entityType: entityType.trim() } : {}),
        ...(result === "success" || result === "failure" ? { result } : {}) };
}
/** Complete read-only Control query surface: adapter owns server filtering and total count. */
export function AuditExplorerPage({ adapter, canRead = false, formatTimestamp }) {
    const id = useId();
    const sequence = useRef(0);
    const live = useRef({ adapter, canRead });
    live.current = { adapter, canRead };
    const [action, setAction] = useState("");
    const [entity, setEntity] = useState("");
    const [result, setResult] = useState("");
    const [query, setQuery] = useState({ offset: 0, limit: PAGE_SIZE });
    const [data, setData] = useState(null);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const active = canRead && data?.adapter === adapter ? data.result : null;
    const alive = (n) => n === sequence.current && live.current.adapter === adapter && live.current.canRead;
    async function load(q) {
        if (!canRead)
            return;
        const n = ++sequence.current;
        setBusy(true);
        setError("");
        setData(null);
        setQuery(q);
        try {
            const response = await adapter.query(q);
            if (!alive(n))
                return;
            if (!validResult(response, q))
                throw new Error("Invalid audit result or inconsistent pagination returned by the product.");
            setData({ adapter, result: response });
        }
        catch (e) {
            if (alive(n))
                setError(e instanceof Error ? e.message.slice(0, 512) : "Audit query failed.");
        }
        finally {
            if (alive(n))
                setBusy(false);
        }
    }
    useEffect(() => {
        setData(null);
        setAction("");
        setEntity("");
        setResult("");
        setError("");
        setBusy(false);
        if (canRead)
            void load({ offset: 0, limit: PAGE_SIZE });
        return () => { sequence.current++; };
    }, [adapter, canRead]);
    function timeLabel(value) {
        if (formatTimestamp) {
            try {
                return formatTimestamp(value);
            }
            catch {
                return value;
            }
        }
        return new Date(value).toISOString().replace("T", " ").replace(".000Z", " UTC");
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "Audit explorer", children: _jsx("p", { children: "Audit access is unavailable for this session." }) });
    return _jsxs("section", { className: "dr-admin__audit-explorer", "aria-label": "Audit explorer", children: [_jsxs("header", { children: [_jsxs("div", { children: [_jsx("h3", { children: "Audit Logs" }), _jsx("p", { children: "Operator and administrator actions, separate from runtime delivery logs." })] }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(query), children: "Refresh audit" })] }), _jsxs("form", { className: "dr-admin__audit-explorer-filters", onSubmit: e => { e.preventDefault(); if (!busy)
                    void load(buildQuery(action, entity, result, 0)); }, children: [_jsxs("label", { htmlFor: id + "-action", children: ["Action", _jsx("input", { id: id + "-action", value: action, maxLength: 120, disabled: busy, placeholder: "USER_LOGIN", onChange: e => setAction(e.target.value) })] }), _jsxs("label", { htmlFor: id + "-entity", children: ["Entity type", _jsx("input", { id: id + "-entity", value: entity, maxLength: 120, disabled: busy, placeholder: "SYSTEM", onChange: e => setEntity(e.target.value) })] }), _jsxs("label", { htmlFor: id + "-result", children: ["Result", _jsxs("select", { id: id + "-result", value: result, disabled: busy, onChange: e => setResult(e.target.value), children: [_jsx("option", { value: "", children: "All" }), _jsx("option", { value: "success", children: "success" }), _jsx("option", { value: "failure", children: "failure" })] })] }), _jsx(Button, { type: "submit", disabled: busy, children: "Apply filters" }), _jsx(Button, { variant: "secondary", type: "button", disabled: busy, onClick: () => { setAction(""); setEntity(""); setResult(""); void load({ offset: 0, limit: PAGE_SIZE }); }, children: "Reset filters" })] }), error ? _jsx("p", { role: "alert", children: error }) : null, busy ? _jsx("p", { role: "status", children: "Loading audit entries\u2026" }) : null, _jsx("div", { className: "dr-admin__audit-explorer-table", role: "region", "aria-label": "Scrollable audit events", tabIndex: 0, children: _jsxs("table", { "aria-label": "Audit events", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Time" }), _jsx("th", { children: "Actor" }), _jsx("th", { children: "Action" }), _jsx("th", { children: "Entity" }), _jsx("th", { children: "Result" }), _jsx("th", { children: "Summary" })] }) }), _jsx("tbody", { children: active?.items.length ? active.items.map(row => _jsxs("tr", { children: [_jsx("td", { children: _jsx("time", { dateTime: row.timestamp, children: timeLabel(row.timestamp) }) }), _jsx("td", { children: row.actor || "—" }), _jsx("td", { children: _jsx("code", { children: row.action }) }), _jsx("td", { children: row.entityType ? row.entityType + (row.entityId ? " #" + row.entityId : "") : "—" }), _jsx("td", { children: _jsx(StatusBadge, { tone: row.result === "success" ? "success" : row.result === "failure" ? "critical" : "neutral", children: row.result }) }), _jsx("td", { children: row.summary || "—" })] }, row.id)) : _jsx("tr", { children: _jsx("td", { colSpan: 6, children: busy ? "Loading…" : error ? "Audit entries are unavailable." : "No audit entries match the current filters." }) }) })] }) }), active ? _jsxs("footer", { children: [_jsxs("p", { role: "status", children: ["Showing ", active.total === 0 ? 0 : active.offset + 1, "\u2013", active.offset + active.items.length, " of ", active.total, " entries"] }), _jsxs("nav", { "aria-label": "Audit pagination", children: [_jsx(Button, { variant: "secondary", disabled: busy || active.offset === 0, onClick: () => void load({ ...query, offset: Math.max(0, query.offset - PAGE_SIZE) }), children: "Previous" }), _jsx(Button, { variant: "secondary", disabled: busy || active.offset + active.items.length >= active.total || active.items.length === 0, onClick: () => void load({ ...query, offset: query.offset + PAGE_SIZE }), children: "Next" })] })] }) : null] });
}
