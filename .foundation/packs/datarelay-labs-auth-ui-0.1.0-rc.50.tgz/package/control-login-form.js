import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
function Glyph({ children }) {
    return (_jsx("svg", { className: "dr-control-login__glyph", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: children }));
}
function UserGlyph() {
    return (_jsxs(Glyph, { children: [_jsx("path", { d: "M20 21a8 8 0 0 0-16 0" }), _jsx("circle", { cx: "12", cy: "7", r: "4" })] }));
}
function LockGlyph() {
    return (_jsxs(Glyph, { children: [_jsx("rect", { width: "18", height: "11", x: "3", y: "11", rx: "2" }), _jsx("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" })] }));
}
function EyeGlyph({ hidden }) {
    return hidden ? (_jsxs(Glyph, { children: [_jsx("path", { d: "m2 2 20 20" }), _jsx("path", { d: "M6.7 6.7C4.6 8.1 3.1 10 2 12c2 3.7 5.7 6 10 6 1.7 0 3.3-.4 4.7-1" }), _jsx("path", { d: "M10.6 10.6A2 2 0 0 0 13.4 13.4" }), _jsx("path", { d: "M9.9 4.2A11.6 11.6 0 0 1 12 4c4.3 0 8 2.3 10 6a11.8 11.8 0 0 1-2.1 2.9" })] })) : (_jsxs(Glyph, { children: [_jsx("path", { d: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" }), _jsx("circle", { cx: "12", cy: "12", r: "2.5" })] }));
}
/**
 * Exact Control credential form presentation. Authentication remains delegated
 * to the consumer through onSubmit; no credential or session storage lives here.
 */
export function ControlLoginForm({ onSubmit, busy = false, errorCategory, errorMessage, infoMessage, initialUsername = "", submitLabel = "Sign In", allowPasswordReveal = true, usernamePlaceholder = "Enter your username", passwordPlaceholder = "Enter your password", accountNotice }) {
    const [username, setUsername] = useState(initialUsername);
    const [password, setPassword] = useState("");
    const [revealed, setRevealed] = useState(false);
    const [localError, setLocalError] = useState("");
    function submit(event) {
        event.preventDefault();
        const normalized = username.trim();
        if (!normalized || !password) {
            setLocalError("Enter your username and password.");
            return;
        }
        setLocalError("");
        void onSubmit({ username: normalized, password });
    }
    const error = localError || errorMessage;
    return (_jsxs("form", { className: "dr-control-login", onSubmit: submit, children: [_jsxs("div", { className: "dr-control-login__field", children: [_jsx("label", { htmlFor: "dr-control-login-username", children: "Username" }), _jsxs("div", { className: "dr-control-login__input-wrap", children: [_jsx(UserGlyph, {}), _jsx("input", { id: "dr-control-login-username", name: "username", autoComplete: "username", value: username, onChange: (event) => setUsername(event.target.value), placeholder: usernamePlaceholder, disabled: busy })] })] }), _jsxs("div", { className: "dr-control-login__field", children: [_jsx("label", { htmlFor: "dr-control-login-password", children: "Password" }), _jsxs("div", { className: "dr-control-login__input-wrap", children: [_jsx(LockGlyph, {}), _jsx("input", { id: "dr-control-login-password", name: "password", type: revealed ? "text" : "password", autoComplete: "current-password", value: password, onChange: (event) => setPassword(event.target.value), placeholder: passwordPlaceholder, disabled: busy }), allowPasswordReveal ? (_jsx("button", { type: "button", className: "dr-control-login__reveal", "aria-label": revealed ? "Hide password" : "Show password", "aria-controls": "dr-control-login-password", "aria-pressed": revealed, disabled: busy, onClick: () => setRevealed((value) => !value), children: _jsx(EyeGlyph, { hidden: revealed }) })) : null] })] }), infoMessage ? (_jsx("p", { className: "dr-control-login__message dr-control-login__message--info", role: "status", children: infoMessage })) : null, error ? (_jsx("p", { className: "dr-control-login__message dr-control-login__message--error", role: "alert", "data-error-category": errorCategory ?? (localError ? "validation" : "failed"), children: error })) : null, _jsx("button", { className: "dr-control-login__submit", type: "submit", disabled: busy, children: busy ? "Signing in…" : submitLabel }), accountNotice ? (_jsx("p", { className: "dr-control-login__notice", children: accountNotice })) : null] }));
}
