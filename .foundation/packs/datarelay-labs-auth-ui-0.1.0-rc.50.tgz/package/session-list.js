import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button, EmptyState, StatusBadge, TextField } from "@datarelay-labs/ui";
export function SessionList({ sessions, onRevoke, revokingSessionId, filterLoadedSessions = false, filterLoadedSessionStates = false, selectLoadedSessions = false, onReviewSelectedSessions }) {
    const [query, setQuery] = useState("");
    const [selectedState, setSelectedState] = useState("");
    const [selectedReviewIds, setSelectedReviewIds] = useState([]);
    const reviewEnabled = selectLoadedSessions && Boolean(onReviewSelectedSessions);
    const selectId = useId().replaceAll(":", "");
    const localControls = filterLoadedSessions || filterLoadedSessionStates;
    // These are *display classifications* of already loaded flags, not backend session states.
    // Explicit revoked wins if a product supplies contradictory flags.
    const stateOf = (session) => session.revoked === true ? "revoked" : session.current === true ? "current" : "other";
    const available = new Set(filterLoadedSessionStates ? sessions.map(stateOf) : []);
    const activeState = filterLoadedSessionStates && available.has(selectedState)
        ? selectedState : "";
    useEffect(() => {
        if (selectedState && (!filterLoadedSessionStates || !available.has(selectedState))) {
            setSelectedState("");
        }
    }, [selectedState, filterLoadedSessionStates, sessions]);
    // Search only fields already visible in the product-provided session list.
    // The opaque session ID is an action target, not a discoverable credential.
    const normalized = localControls ? query.trim().toLowerCase() : "";
    const visible = sessions.filter((session) => (!normalized || [
        session.deviceLabel ?? "Browser session", session.source,
        session.createdAt, session.lastSeenAt, session.expiresAt,
        session.current === true ? "Current" : undefined,
        session.revoked === true ? "Revoked" : undefined
    ].some((value) => value?.toLowerCase().includes(normalized)))
        && (!filterLoadedSessionStates || !activeState || stateOf(session) === activeState));
    // Selection is a product-owned REVIEW request, not a revoke operation. The
    // current session is deliberately excluded even when separately revocable.
    const reviewable = reviewEnabled ? visible.filter((session) => session.revocable === true && session.revoked !== true &&
        session.current !== true && revokingSessionId !== session.id) : [];
    const reviewableIds = new Set(reviewable.map((session) => session.id));
    const selectedValidIds = reviewable.filter((session) => selectedReviewIds.includes(session.id))
        .map((session) => session.id);
    useEffect(() => {
        setSelectedReviewIds((previous) => {
            const next = previous.filter((id) => reviewableIds.has(id));
            return next.length === previous.length ? previous : next;
        });
    }, [sessions, query, selectedState, filterLoadedSessions, filterLoadedSessionStates,
        selectLoadedSessions, onReviewSelectedSessions, revokingSessionId]);
    if (!sessions.length) {
        return _jsx(EmptyState, { title: "No active sessions", description: "No sessions are available from the product adapter." });
    }
    const list = (_jsx("ul", { className: "dr-auth-sessions", "aria-label": "Active sessions", children: visible.map((session) => {
            const canRevoke = session.revocable === true && !session.revoked && Boolean(onRevoke);
            return (_jsxs("li", { className: "dr-auth-session", children: [reviewableIds.has(session.id) ? (_jsxs("label", { className: "dr-auth-session__review-choice", children: [_jsx("input", { type: "checkbox", "aria-label": "Select session " + (session.deviceLabel ?? "Browser session") + " for review", checked: selectedValidIds.includes(session.id), onChange: (event) => {
                                    setSelectedReviewIds((previous) => event.target.checked
                                        ? [...previous.filter((id) => id !== session.id), session.id]
                                        : previous.filter((id) => id !== session.id));
                                } }), _jsx("span", { children: "Select for review" })] })) : null, _jsxs("div", { className: "dr-auth-session__summary", children: [_jsxs("div", { className: "dr-auth-session__title", children: [_jsx("strong", { children: session.deviceLabel ?? "Browser session" }), session.current ? _jsx(StatusBadge, { tone: "info", children: "Current" }) : null, session.revoked ? _jsx(StatusBadge, { tone: "neutral", children: "Revoked" }) : null] }), session.source ? _jsx("p", { children: session.source }) : null, _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Created" }), _jsx("dd", { children: session.createdAt })] }), session.lastSeenAt ? _jsxs("div", { children: [_jsx("dt", { children: "Last seen" }), _jsx("dd", { children: session.lastSeenAt })] }) : null, session.expiresAt ? _jsxs("div", { children: [_jsx("dt", { children: "Expires" }), _jsx("dd", { children: session.expiresAt })] }) : null] })] }), canRevoke ? (_jsx(Button, { variant: "danger", size: "sm", disabled: revokingSessionId === session.id, onClick: () => void onRevoke?.(session.id), "aria-label": "Revoke session " + (session.deviceLabel ?? session.id), children: revokingSessionId === session.id ? "Revoking…" : "Revoke" })) : null] }, session.id));
        }) }));
    if (!localControls && !reviewEnabled)
        return list;
    return (_jsxs("div", { className: "dr-auth-session-search-layout", children: [localControls ? (_jsx("div", { role: "search", children: _jsx(TextField, { type: "search", label: "Find loaded sessions", autoComplete: "off", maxLength: 120, value: query, onChange: (event) => setQuery(event.target.value) }) })) : null, filterLoadedSessionStates ? (_jsxs("div", { className: "dr-auth-session-state", children: [_jsx("label", { htmlFor: selectId + "-state", children: "Filter loaded session state" }), _jsxs("select", { id: selectId + "-state", value: activeState, onChange: (event) => setSelectedState(event.target.value), children: [_jsx("option", { value: "", children: "All loaded sessions" }), available.has("current") ? _jsx("option", { value: "current", children: "Current session" }) : null, available.has("other") ? _jsx("option", { value: "other", children: "Other loaded sessions" }) : null, available.has("revoked") ? _jsx("option", { value: "revoked", children: "Revoked sessions" }) : null] })] })) : null, localControls ? (_jsxs("p", { className: "dr-auth-form__guidance", role: "status", "aria-live": "polite", children: ["Showing ", visible.length, " of ", sessions.length, " loaded sessions. Only sessions supplied by the product adapter are searched."] })) : null, reviewEnabled ? (_jsxs("div", { className: "dr-auth-session__selection", children: [_jsxs("p", { "aria-live": "polite", children: ["Selected ", selectedValidIds.length, " loaded sessions for review"] }), _jsx(Button, { type: "button", variant: "secondary", disabled: selectedValidIds.length === 0, onClick: () => {
                            if (selectedValidIds.length)
                                void onReviewSelectedSessions?.([...selectedValidIds]);
                        }, children: "Review selected sessions" })] })) : null, visible.length ? list : (_jsx(EmptyState, { title: "No matching loaded sessions", description: "Only sessions supplied by the product adapter are searched; no server-wide session query was made." }))] }));
}
