import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useMemo, useState } from "react";
import { Button } from "@datarelay-labs/ui";
const SAMPLE_UTC = "2026-06-29T07:10:00Z";
function isIanaTimezone(zone) {
    if (!zone || zone.length > 128 || !/^[a-zA-Z0-9_+./-]+$/.test(zone))
        return false;
    try {
        new Intl.DateTimeFormat("en-US", { timeZone: zone });
        return true;
    }
    catch {
        return false;
    }
}
function validReadBack(value) {
    if (!value || typeof value !== "object")
        return false;
    const row = value;
    const effective = row.effective;
    return Boolean(effective && isIanaTimezone(effective.resolvedTimezone) &&
        isIanaTimezone(effective.platformDefaultTimezone) &&
        (effective.userTimezone === null || isIanaTimezone(effective.userTimezone)));
}
function supportedZones() {
    try {
        return [...new Set(["UTC", ...Intl.supportedValuesOf("timeZone")])].sort();
    }
    catch {
        return ["UTC", "Asia/Seoul", "Asia/Tokyo", "America/New_York", "Europe/London"];
    }
}
const IANA_ZONES = supportedZones();
function sampleInZone(zone) {
    return new Intl.DateTimeFormat("en-US", {
        timeZone: zone, year: "numeric", month: "short", day: "numeric",
        hour: "2-digit", minute: "2-digit", timeZoneName: "short"
    }).format(new Date(SAMPLE_UTC));
}
/**
 * Shared Control-equivalent timezone form: full IANA selection, two distinct
 * authorization scopes, optimistic-concurrency protection and server read-back.
 * A UI callback never grants privilege; Core must enforce exact revision and RBAC.
 */
export function DisplayTimezoneSettings({ adapter, canEditPersonal = false, canEditPlatform = false }) {
    const instanceId = useId().replaceAll(":", "");
    const [loaded, setLoaded] = useState(null);
    const [personalDraft, setPersonalDraft] = useState("");
    const [platformDraft, setPlatformDraft] = useState("UTC");
    const [personalFilter, setPersonalFilter] = useState("");
    const [platformFilter, setPlatformFilter] = useState("");
    const [busy, setBusy] = useState("refresh");
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const state = loaded?.effective;
    const editor = typeof adapter.configure === "function" && typeof loaded?.revision === "string"
        && loaded.revision.length > 0;
    const canChangePersonal = editor && canEditPersonal;
    const canChangePlatform = editor && canEditPlatform;
    const personalValid = !personalDraft || isIanaTimezone(personalDraft);
    const platformValid = isIanaTimezone(platformDraft);
    const personalOptions = useMemo(() => [...new Set([...IANA_ZONES, ...(personalDraft && isIanaTimezone(personalDraft) ? [personalDraft] : [])])].sort().filter((zone) => zone === personalDraft || zone.toLowerCase().includes(personalFilter.toLowerCase().trim())), [personalDraft, personalFilter]);
    const platformOptions = useMemo(() => [...new Set([...IANA_ZONES, ...(isIanaTimezone(platformDraft) ? [platformDraft] : [])])].sort().filter((zone) => zone === platformDraft || zone.toLowerCase().includes(platformFilter.toLowerCase().trim())), [platformDraft, platformFilter]);
    useEffect(() => {
        let mounted = true;
        setBusy("refresh");
        void adapter.read().then((readBack) => {
            if (!mounted)
                return;
            if (!validReadBack(readBack))
                throw new Error("Invalid timezone state returned by the product.");
            setLoaded(readBack);
            setPersonalDraft(readBack.effective.userTimezone ?? "");
            setPlatformDraft(readBack.effective.platformDefaultTimezone);
            setError("");
        }).catch((reason) => {
            if (mounted)
                setError(reason instanceof Error ? reason.message : "Cannot read timezone settings.");
        }).finally(() => {
            if (mounted)
                setBusy(null);
        });
        return () => { mounted = false; };
    }, [adapter]);
    async function reload() {
        if (busy)
            return;
        setBusy("refresh");
        setError("");
        setNotice("");
        try {
            const fresh = await adapter.read();
            if (!validReadBack(fresh))
                throw new Error("Invalid timezone state returned by the product.");
            setLoaded(fresh);
            setPersonalDraft(fresh.effective.userTimezone ?? "");
            setPlatformDraft(fresh.effective.platformDefaultTimezone);
        }
        catch (reason) {
            setError(reason instanceof Error ? reason.message : "Cannot reload timezone settings.");
        }
        finally {
            setBusy(null);
        }
    }
    async function save(scope) {
        if (busy || !loaded || !loaded.revision || !adapter.configure ||
            (scope === "personal" && !canChangePersonal) ||
            (scope === "platform" && !canChangePlatform))
            return;
        const proposed = scope === "personal" ? personalDraft || null : platformDraft;
        if (proposed !== null && !isIanaTimezone(proposed)) {
            setError("Select a valid IANA timezone.");
            return;
        }
        const expectedRevision = loaded.revision;
        setBusy(scope);
        setError("");
        setNotice("");
        try {
            const before = await adapter.read();
            if (!validReadBack(before) || before.revision !== expectedRevision) {
                throw new Error("Timezone settings changed since you loaded this page. Refresh before saving.");
            }
            await adapter.configure({ scope, timezone: proposed, expectedRevision });
            // Only server-provided read-back can establish success. No optimistic UX.
            const after = await adapter.read();
            if (!validReadBack(after))
                throw new Error("Invalid timezone state returned by the product.");
            setLoaded(after);
            const match = scope === "personal"
                ? after.effective.userTimezone === proposed
                : after.effective.platformDefaultTimezone === proposed;
            if (!match || !after.revision || after.revision === expectedRevision) {
                throw new Error("Timezone change not confirmed by authoritative read-back.");
            }
            setPersonalDraft(after.effective.userTimezone ?? "");
            setPlatformDraft(after.effective.platformDefaultTimezone);
            setNotice(scope === "personal"
                ? "Your display timezone was updated and verified."
                : "Platform default was updated and verified.");
        }
        catch (reason) {
            setError(reason instanceof Error ? reason.message : "Timezone update failed.");
        }
        finally {
            setBusy(null);
        }
    }
    return (_jsxs("section", { className: "dr-admin__timezone", "aria-label": "Display timezone settings", children: [_jsxs("header", { children: [_jsx("h3", { children: "Display timezone" }), _jsx("p", { children: "Runtime events and API timestamps remain in UTC. Timezone preferences only affect display." })] }), busy === "refresh" && !state ? _jsx("p", { role: "status", children: "Loading timezone settings\u2026" }) : null, error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, state ? (_jsxs(_Fragment, { children: [_jsxs("dl", { className: "dr-admin__timezone-facts", children: [_jsxs("div", { children: [_jsx("dt", { children: "Effective display timezone" }), _jsx("dd", { children: state.resolvedTimezone })] }), _jsxs("div", { children: [_jsx("dt", { children: "Resolved from" }), _jsx("dd", { children: state.userTimezone ? "Your account override" : "Platform default" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Your override" }), _jsx("dd", { children: state.userTimezone ?? "None" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Platform default" }), _jsx("dd", { children: state.platformDefaultTimezone })] })] }), _jsxs("p", { className: "dr-admin__muted", children: ["Example conversion: ", sampleInZone(state.resolvedTimezone), " (from ", SAMPLE_UTC, ")"] }), _jsxs("div", { className: "dr-admin__timezone-editors", children: [_jsxs("div", { className: "dr-admin__timezone-editor", children: [_jsx("h4", { children: "Your timezone" }), _jsx("p", { children: "Use the platform default or choose a personal timezone override." }), _jsx("label", { htmlFor: instanceId + "-personal-filter", children: "Filter personal timezones" }), _jsx("input", { id: instanceId + "-personal-filter", type: "search", value: personalFilter, placeholder: "Filter city / region", disabled: !canChangePersonal || Boolean(busy), onChange: (event) => setPersonalFilter(event.target.value) }), _jsx("label", { htmlFor: instanceId + "-personal", children: "Your timezone" }), _jsxs("select", { id: instanceId + "-personal", value: personalDraft, disabled: !canChangePersonal || Boolean(busy), onChange: (event) => setPersonalDraft(event.target.value), children: [_jsx("option", { value: "", children: "Use platform default" }), personalOptions.map((zone) => _jsx("option", { value: zone, children: zone }, zone))] }), canChangePersonal ? _jsx(Button, { type: "button", disabled: Boolean(busy) || !personalValid ||
                                            personalDraft === (state.userTimezone ?? ""), onClick: () => void save("personal"), children: "Save personal timezone" })
                                        : _jsx("p", { className: "dr-admin__muted", children: "Your timezone is read-only for this session." })] }), _jsxs("div", { className: "dr-admin__timezone-editor", children: [_jsx("h4", { children: "Platform default timezone" }), _jsx("p", { children: "Only product-authorized administrators can change the platform default." }), _jsx("label", { htmlFor: instanceId + "-platform-filter", children: "Filter platform timezones" }), _jsx("input", { id: instanceId + "-platform-filter", type: "search", value: platformFilter, placeholder: "Filter city / region", disabled: !canChangePlatform || Boolean(busy), onChange: (event) => setPlatformFilter(event.target.value) }), _jsx("label", { htmlFor: instanceId + "-platform", children: "Platform timezone" }), _jsx("select", { id: instanceId + "-platform", value: platformDraft, disabled: !canChangePlatform || Boolean(busy), onChange: (event) => setPlatformDraft(event.target.value), children: platformOptions.map((zone) => _jsx("option", { value: zone, children: zone }, zone)) }), canChangePlatform ? _jsx(Button, { type: "button", disabled: Boolean(busy) || !platformValid ||
                                            platformDraft === state.platformDefaultTimezone, onClick: () => void save("platform"), children: "Save platform default" })
                                        : _jsx("p", { className: "dr-admin__muted", children: "Platform default is administrator-only." })] })] }), _jsx(Button, { variant: "secondary", type: "button", disabled: Boolean(busy), onClick: () => void reload(), children: "Refresh settings" })] })) : !busy ? _jsx(Button, { type: "button", onClick: () => void reload(), children: "Retry loading" }) : null] }));
}
