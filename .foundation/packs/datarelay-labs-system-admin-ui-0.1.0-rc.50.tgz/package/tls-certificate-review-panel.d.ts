import { type CapabilityAvailability, type TlsCertificateReviewProjection } from "@datarelay-labs/system-contracts";
export type TlsCertificateReviewPanelProps = {
    /** Product-authenticated, code-only TLS listener certificate evidence. */
    projection?: TlsCertificateReviewProjection;
    /** Independently server-authoritative capability; unknown is default. */
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Product review/confirmation only; no PEM, private key or file transfer. */
    onReviewTlsChange?: (currentRevision: string, candidateReference: string) => void | Promise<void>;
    pending?: boolean;
};
/** Source-only TLS status and replacement preflight. Products retain full
 * chain/SAN/hostname/key/TLS policy validators, credentials, listener restart
 * and all reversible host apply operations. */
export declare function TlsCertificateReviewPanel({ projection, reviewAvailability, onReviewTlsChange, pending }: TlsCertificateReviewPanelProps): import("react").JSX.Element;
