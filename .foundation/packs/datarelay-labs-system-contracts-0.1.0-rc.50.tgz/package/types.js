export const COMMON_ERROR_CATEGORIES = [
    "validation",
    "unauthenticated",
    "forbidden",
    "conflict",
    "stale_state",
    "unavailable",
    "interrupted",
    "failed"
];
export const OPERATION_EFFECTS = [
    "long_running",
    "reconnect_required",
    "restart_required",
    "destructive",
    "security_sensitive"
];
export const JOB_STATES = [
    "QUEUED",
    "RUNNING",
    "SUCCEEDED",
    "FAILED",
    "CANCELLED"
];
/** PF-11A product-owned SMTP/Webhook snapshot. No URLs, headers, secrets,
 * recipients, free-form errors, raw message data or network operations. */
export const NOTIFICATION_TEST_BLOCKERS = [
    "destination_disabled", "stale_destination", "permission_denied",
    "mfa_required", "sender_unavailable", "destination_unverified",
    "credential_unavailable", "tls_unverified", "audit_unavailable"
];
/** PF-12 immutable code-only recovery proof enums mirror the existing
 * Python backup_recovery module; no customer archive content or restore. */
/** PF-10C product-authoritative, code-only public secret lifecycle.
 * Exclude Python masked_value, actual key bytes, KMS endpoints, and credentials. */
/** PF-10D roles/capability authority is owned by each product.
 * This is a bounded, code-only advisory comparison, not a role grant. */
/** PF-9 management ingress is a separate host SSH and Web/API policy.
 * Browser projections are read-only; authoritative Python ACL evaluates IPs. */
/** PF-10B product-authoritative effective and proposed password/login/session
 * policy. Never contains raw credentials, user identities or session tokens. */
/** PF-11 reusable TLS certificate status and candidate preflight. Product
 * supplies code-only validated evidence; no PEM, SAN, hostnames or key data. */
/** PF-11 on-prem network configuration intent, distinct from SystemDoctor
 * measurements. Only code-only modes, never hostnames/URLs, keys or PEM. */
/** PF-11 first-run product readiness stage identities are shared UX, not
 * an auth/identity service, installer or product config authority. */
/** PF-12 read-only effective/desired operational backup policy. No archive
 * paths, credentials, actual backup scheduler, storage or user action. */
/** PF-12 product-owned installer has verified offline bytes/signature/trust.
 * No file paths, payload digests, key values or arbitrary shell commands
 * are displayed or accepted in this UI projection. */
/** PF-12 pure code-only historical configuration rollback preflight.
 * Source values, user identity, secrets and actual writes are excluded. */
/** PF-11 additive product-owned SMTP/Webhook routing and retry policy
 * change review. It never exposes endpoint, auth, recipient or message data.
 * Timings match NotificationRetryPolicy, NOT Grafana alert-group timers. */
/** PF-11 product-owned FAILED one-shot operation retry review only.
 * Not a task re-run API, job scheduler or permission grant. */
/** PF-11 privacy-sensitive support evidence bundle review only.
 * Real product server performs redaction/byte scanning and download. */
/** PF-10 product-verified audit forwarding sink *settings*, separate
 * from ForwardReceipt transport attempts. Never include endpoint URL, IP,
 * path, TLS material, event data, message bodies, headers or credentials. */
/** PF-12 product-native *data* retention, distinct from backup retention.
 * This first-party boundary only reviews product-generated code-only facts. */
export const DATA_RETENTION_CATEGORIES = [
    "audit_events", "operation_history", "notification_jobs",
    "configuration_revisions", "support_artifacts"
];
export const DATA_RETENTION_BLOCKERS = [
    "permission_denied", "mfa_required", "audit_unavailable", "legal_hold",
    "protected_record", "dry_run_missing", "backup_unverified",
    "rollback_unavailable", "scheduler_unavailable", "storage_unverified",
    "stale_revision", "retention_minimum"
];
export const AUDIT_FORWARDING_CONFIG_BLOCKERS = [
    "permission_denied", "mfa_required", "audit_unavailable",
    "redaction_unverified", "destination_unverified", "tls_unverified",
    "queue_unverified", "capture_unavailable", "retention_unverified",
    "rollback_unavailable", "stale_revision"
];
export const SUPPORT_BUNDLE_CATEGORIES = [
    "system_diagnostics", "operation_status",
    "configuration_summary", "audit_metadata"
];
export const SUPPORT_BUNDLE_BLOCKERS = [
    "redaction_unverified", "credentials_unverified",
    "personal_data_unverified", "customer_payload_present",
    "archive_integrity_missing", "expired_bundle", "permission_denied",
    "mfa_required", "audit_unavailable", "stale_revision"
];
export const JOB_RETRY_BLOCKERS = [
    "permission_denied", "mfa_required", "audit_unavailable",
    "idempotency_unverified", "previous_attempt_active",
    "retry_budget_exhausted", "backoff_pending", "stale_revision",
    "scheduled_task", "runner_unavailable"
];
export const NOTIFICATION_ROUTING_BLOCKERS = [
    "permission_denied", "mfa_required", "sender_unavailable",
    "destination_unverified", "credential_unavailable", "tls_unverified",
    "drain_unverified", "rollback_unavailable", "audit_unavailable",
    "stale_revision"
];
export const CONFIG_ROLLBACK_BLOCKERS = [
    "nonhistorical_target", "wrong_revision", "no_target", "same_revision",
    "unsupported", "unauthorized", "mfa_required", "backup_missing",
    "recovery_unavailable", "out_of_band_required", "audit_unavailable",
    "nonreversible_field"
];
export const OFFLINE_UPGRADE_BLOCKERS = [
    "wrong_product", "wrong_kind", "not_newer", "major_upgrade_untested",
    "artifact_hash_mismatch", "manifest_hash_mismatch", "publisher_mismatch",
    "artifact_integrity_missing", "manifest_integrity_missing",
    "signature_unverified", "publisher_untrusted", "provenance_unverified",
    "stale_installation", "installer_unavailable", "permission_denied",
    "mfa_required", "schema_unverified", "migration_untested",
    "backup_unverified", "rollback_unverified", "offline_recovery_required",
    "maintenance_not_authorized", "audit_unavailable"
];
export const BACKUP_POLICY_BLOCKERS = [
    "scheduler_unavailable", "encrypted_storage_unverified",
    "restore_drill_unverified", "permission_denied", "mfa_required",
    "rollback_unavailable", "audit_unavailable", "stale_revision",
    "weakening_prohibited"
];
export const ONPREM_SETUP_STAGE_IDS = [
    "administrator", "management_access", "network_time", "tls",
    "notifications", "backup_recovery"
];
export const ONPREM_SETUP_REVIEW_BLOCKERS = [
    "administrator_missing", "mfa_unverified", "acl_unverified",
    "network_unverified", "tls_unverified", "notifications_unverified",
    "backup_unverified", "rollback_unavailable", "audit_unavailable",
    "permission_denied", "stale_revision"
];
export const NETWORK_TRUST_BLOCKERS = [
    "dns_unverified", "ntp_unverified", "proxy_unverified",
    "ca_unverified", "management_lockout", "rollback_unavailable",
    "permission_denied", "mfa_required", "audit_unavailable",
    "stale_revision"
];
export const TLS_REPLACEMENT_BLOCKERS = [
    "chain_unverified", "hostname_unverified", "key_pair_unverified",
    "tls_policy_unverified", "candidate_expired", "listener_unverified",
    "rollback_unavailable", "recovery_unavailable", "permission_denied",
    "mfa_required", "audit_unavailable", "stale_revision"
];
export const SECURITY_POLICY_BLOCKERS = [
    "AUTHORITY_UNAVAILABLE", "MFA_REQUIRED",
    "LAST_ADMIN_RECOVERY_UNAVAILABLE", "ROLLBACK_UNAVAILABLE",
    "AUDIT_UNAVAILABLE", "POLICY_WEAKENING"
];
export const MANAGEMENT_ACCESS_BLOCKERS = [
    "INVALID_ROLLBACK_WINDOW", "OFFLINE_RECOVERY_REQUIRED",
    "SSH_ENFORCEMENT_UNAVAILABLE", "WEB_SELF_LOCKOUT", "SSH_SELF_LOCKOUT"
];
export const ROLE_CHANGE_BLOCKERS = [
    "no_product_backend", "permission_denied", "mfa_required",
    "stale_role", "unknown_capability", "last_admin_lockout",
    "self_escalation", "escalation_approval_required",
    "audit_unavailable", "rollback_unavailable"
];
export const SECRET_ROTATION_BLOCKERS = [
    "unsupported_backend", "unauthorized", "mfa_required",
    "stale_revision", "not_active", "rotation_disabled",
    "recovery_not_verified", "rollback_not_ready", "bindings_unprepared",
    "active_consumers", "audit_unavailable"
];
export const RECOVERY_BACKUP_PROBLEMS = [
    "wrong_backup_kind", "not_complete", "zero_length", "unencrypted",
    "future_evidence", "overdue", "restore_not_verified", "restore_evidence_stale"
];
export const RECOVERY_RESTORE_BLOCKERS = [
    "wrong_product", "stale_backup_revision", "not_operational_backup",
    "incomplete_backup", "unencrypted_backup", "restore_proof_missing",
    "future_evidence", "restore_proof_stale", "unsupported",
    "permission_denied", "mfa_required", "integrity_unverified",
    "schema_unverified", "restore_drill_missing", "current_backup_missing",
    "rollback_not_ready", "offline_recovery_required", "audit_unavailable"
];
export const DIAGNOSTIC_AREAS = ["dns", "ntp", "proxy", "trusted_ca", "certificate"];
