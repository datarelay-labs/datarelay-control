import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { AUDIT_FORWARDING_CONFIG_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const KINDS = {
    syslog_tls: "Syslog over TLS",
    product_owned_file: "Product-owned protected file"
};
const BLOCKER_LABELS = {
    permission_denied: "Product role permission denied",
    mfa_required: "Recent privileged MFA is required",
    audit_unavailable: "Product audit persistence is unavailable",
    redaction_unverified: "Product audit source redaction is unverified",
    destination_unverified: "Product destination is not authorized",
    tls_unverified: "Product TLS transport is unverified",
    queue_unverified: "Product queue transition is not verified",
    capture_unavailable: "Audit source capture is not continuous",
    retention_unverified: "Product retention policy is unverified",
    rollback_unavailable: "Product rollback is unavailable",
    stale_revision: "Audit sink revision is stale"
};
function obj(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function only(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validSnapshot(value) {
    return obj(value) && only(value, [
        "enabled", "sinkKind", "frameLimitBytes", "durableRetryRequired"
    ]) && typeof value.enabled === "boolean" &&
        typeof value.sinkKind === "string" && Object.hasOwn(KINDS, value.sinkKind) &&
        typeof value.frameLimitBytes === "number" &&
        Number.isSafeInteger(value.frameLimitBytes) &&
        value.frameLimitBytes >= 512 && value.frameLimitBytes <= 65536 &&
        typeof value.durableRetryRequired === "boolean";
}
function valid(value) {
    if (!obj(value) ||
        !only(value, ["destination", "effective", "proposed", "preflight"]) ||
        !obj(value.destination) ||
        !only(value.destination, ["reference", "revision"]) ||
        typeof value.destination.reference !== "string" ||
        !REF.test(value.destination.reference) ||
        typeof value.destination.revision !== "string" ||
        !REF.test(value.destination.revision) ||
        !validSnapshot(value.effective) ||
        (value.proposed !== undefined && !validSnapshot(value.proposed)))
        return false;
    if (value.preflight !== undefined) {
        const p = value.preflight;
        if (!obj(p) ||
            !only(p, [
                "expectedRevision", "allowed", "blockers", "productApplyRequired",
                "sourceRedactionVerified", "destinationAuthorized", "secureSinkVerified",
                "durableQueueVerified", "pendingQueueTransitionVerified",
                "auditSourceContinuous", "retentionVerified", "rollbackReady",
                "actorAuthorized", "recentMfaVerified", "auditReady"
            ]) ||
            typeof p.expectedRevision !== "string" || !REF.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" || p.productApplyRequired !== true ||
            !Array.isArray(p.blockers) ||
            p.blockers.length > AUDIT_FORWARDING_CONFIG_BLOCKERS.length)
            return false;
        const flags = [
            "sourceRedactionVerified", "destinationAuthorized", "secureSinkVerified",
            "durableQueueVerified", "pendingQueueTransitionVerified",
            "auditSourceContinuous", "retentionVerified", "rollbackReady",
            "actorAuthorized", "recentMfaVerified", "auditReady"
        ];
        if (flags.some((f) => typeof p[f] !== "boolean"))
            return false;
        const seen = new Set();
        for (const item of p.blockers) {
            if (typeof item !== "string" ||
                !AUDIT_FORWARDING_CONFIG_BLOCKERS.includes(item) ||
                seen.has(item))
                return false;
            seen.add(item);
        }
        if (p.allowed && p.blockers.length > 0)
            return false;
    }
    return true;
}
function different(a, b) {
    return a.enabled !== b.enabled ||
        a.sinkKind !== b.sinkKind ||
        a.frameLimitBytes !== b.frameLimitBytes ||
        a.durableRetryRequired !== b.durableRetryRequired;
}
function weakening(a, b) {
    return (a.enabled && !b.enabled) ||
        (a.durableRetryRequired && !b.durableRetryRequired);
}
function printable(value) {
    if (typeof value === "boolean")
        return value ? "Enabled" : "Disabled";
    if (typeof value === "number")
        return String(value);
    return KINDS[value];
}
const ROWS = [
    ["Audit forwarding enabled", "enabled"],
    ["Forwarding destination type", "sinkKind"],
    ["Maximum RFC5424 frame bytes", "frameLimitBytes"],
    ["Durable retry required", "durableRetryRequired"]
];
/** Product-owned sink settings review, kept separate from AuditForwardingPanel
 * transport-attempt status. Neither UI authenticates downstream SIEM ingestion. */
export function AuditForwardingConfigReviewPanel({ projection, reviewAvailability = "unknown", onReviewConfig, pending = false }) {
    const inputValid = valid(projection);
    const current = inputValid ? projection : undefined;
    const proposed = current?.proposed;
    const proof = current?.preflight;
    const changed = Boolean(current && proposed && different(current.effective, proposed));
    const weakened = Boolean(current && proposed && weakening(current.effective, proposed));
    const stale = Boolean(proof && proof.expectedRevision !== current?.destination.revision);
    const positive = Boolean(proof && proof.sourceRedactionVerified &&
        proof.destinationAuthorized && proof.secureSinkVerified &&
        proof.durableQueueVerified && proof.pendingQueueTransitionVerified &&
        proof.auditSourceContinuous && proof.retentionVerified &&
        proof.rollbackReady && proof.actorAuthorized &&
        proof.recentMfaVerified && proof.auditReady);
    const eligible = Boolean(changed && proposed?.enabled &&
        proposed?.durableRetryRequired && !weakened && !stale &&
        positive && proof?.allowed && proof.blockers.length === 0);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewConfig === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Audit forwarding settings unavailable", description: "No current product-authenticated audit forwarding configuration was supplied." });
    return (_jsxs("section", { className: "dr-admin__audit-config", "aria-label": "Audit forwarding settings review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Audit forwarding settings review" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Audit forwarding: ", eligible ? "review eligible" : inputValid ? "review unavailable" : "unknown"] })] }), !inputValid ? _jsx("p", { children: "Invalid audit forwarding settings evidence" }) : null, current ? (_jsxs(_Fragment, { children: [_jsx("h3", { children: "Effective product audit forwarding policy" }), _jsx("p", { className: "dr-admin__muted", children: "Product transport accepted does not mean downstream SIEM ingestion" }), _jsx("div", { className: "dr-admin__audit-config-table", children: _jsxs("table", { "aria-label": "Audit forwarding configuration comparison", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsx("tbody", { children: ROWS.map(([title, field]) => (_jsxs("tr", { children: [_jsx("th", { scope: "row", children: title }), _jsx("td", { children: printable(current.effective[field]) }), _jsx("td", { children: proposed ? printable(proposed[field]) : "Not supplied" })] }, field))) })] }) }), _jsx("p", { children: "Only product-owned transport and storage may apply settings." }), !changed ? _jsx("p", { children: "No audit forwarding configuration change proposed" }) : null, current.effective.enabled && proposed && !proposed.enabled ?
                        _jsx("p", { children: "Disabling required audit forwarding weakens accountability" }) : null, proposed && current.effective.durableRetryRequired &&
                        !proposed.durableRetryRequired ?
                        _jsx("p", { children: "Removing product durable retry weakens audit delivery" }) : null, !proof ? _jsx("p", { children: "Product audit forwarding change preflight unavailable" }) : null, stale ? _jsx("p", { children: "Audit sink configuration review is stale" }) : null, proof ? (_jsxs("div", { className: "dr-admin__audit-config-checks", children: [!proof.sourceRedactionVerified ?
                                _jsx("p", { children: "Product audit event redaction is unverified" }) : null, !proof.destinationAuthorized ? _jsx("p", { children: "Audit output destination is not approved" }) : null, !proof.secureSinkVerified ? _jsx("p", { children: "Secure TLS/file transport is unverified" }) : null, !proof.durableQueueVerified ? _jsx("p", { children: "Durable queue is not verified" }) : null, !proof.pendingQueueTransitionVerified ?
                                _jsx("p", { children: "Existing audit queue transition is unverified" }) : null, !proof.auditSourceContinuous ?
                                _jsx("p", { children: "Audit event capture continuity is not verified" }) : null, !proof.retentionVerified ? _jsx("p", { children: "Product audit retention is unverified" }) : null, !proof.rollbackReady ?
                                _jsx("p", { children: "Protected audit configuration rollback is not ready" }) : null, !proof.actorAuthorized ?
                                _jsx("p", { children: "Current actor authorization is unverified" }) : null, !proof.recentMfaVerified ?
                                _jsx("p", { children: "Recent privileged MFA verification is required" }) : null, !proof.auditReady ? _jsx("p", { children: "Change audit persistence is not ready" }) : null, proof.blockers.map((code) => _jsx("p", { children: BLOCKER_LABELS[code] }, code))] })) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewConfig?.(current.destination.reference, current.destination.revision), children: "Review audit forwarding settings" })) : (_jsx("p", { className: "dr-admin__muted", children: "A current product-authorized configuration, protected sink and safe queue transition are required." }))] })) : null] }));
}
