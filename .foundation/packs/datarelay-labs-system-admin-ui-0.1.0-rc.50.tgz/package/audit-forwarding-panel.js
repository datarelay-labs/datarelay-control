import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, StatusBadge } from "@datarelay-labs/ui";
const STATES = {
    configured: "configured",
    degraded: "degraded",
    disabled: "disabled",
    unknown: "unknown"
};
const RECEIPTS = {
    accepted: "Product transport accepted last attempt",
    retry_pending: "Product reports retry pending"
};
const TOKEN = /^[A-Za-z0-9_.:@-]{1,128}$/;
/** The Python ForwardReceipt reports local transport acceptance only, never
 * downstream SIEM/file ingestion. Do not render arbitrary product error strings. */
function safeProjection(projection) {
    if (!projection || typeof projection !== "object" || Array.isArray(projection))
        return false;
    const record = projection;
    if (Object.keys(record).some((key) => !["state", "pendingCount", "lastReceipt"].includes(key)))
        return false;
    if (typeof projection.state !== "string" ||
        !Object.hasOwn(STATES, projection.state))
        return false;
    if (projection.pendingCount !== undefined &&
        (!Number.isSafeInteger(projection.pendingCount) || projection.pendingCount < 0))
        return false;
    const receipt = projection.lastReceipt;
    if (receipt !== undefined) {
        if (!receipt || typeof receipt !== "object" || Array.isArray(receipt))
            return false;
        if (Object.keys(receipt).some((key) => !["eventId", "status"].includes(key)))
            return false;
        if (typeof receipt.eventId !== "string" || !TOKEN.test(receipt.eventId) ||
            typeof receipt.status !== "string" || !Object.hasOwn(RECEIPTS, receipt.status))
            return false;
    }
    return true;
}
/** Safe, common, read-only forwarding operations UI. No event payload, IP, TLS
 * secret, destination address, transport send, queue mutation or permission grant. */
export function AuditForwardingPanel({ projection, testAvailability = "unknown", onTestForwarding, testing = false }) {
    const valid = safeProjection(projection);
    const state = valid ? projection.state : "unknown";
    const receipt = valid ? projection.lastReceipt : undefined;
    const canTest = valid && testAvailability === "supported" &&
        typeof onTestForwarding === "function";
    return (_jsxs("section", { className: "dr-admin__forwarding", "aria-label": "Audit forwarding", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Audit forwarding" }), _jsxs(StatusBadge, { tone: state === "configured" ? "info" : state === "degraded" ? "warning" : "neutral", children: ["Forwarding: ", STATES[state]] })] }), _jsx("p", { className: "dr-admin__muted", children: "Product-supplied audit transport status only. No network or file forwarding is performed here." }), !projection ? _jsx("p", { children: "No audit-forwarding status was supplied by the product." }) : null, projection && !valid ? _jsx("p", { children: "Invalid product forwarding status. No details displayed." }) : null, valid ? (_jsxs(_Fragment, { children: [_jsx("p", { role: "status", "aria-live": "polite", className: "dr-admin__muted", children: projection.pendingCount === undefined ? "Product queue count unavailable." :
                            `${projection.pendingCount} product-queued audit events` }), _jsxs("div", { className: "dr-admin__forwarding-receipt", children: [receipt ? _jsx("p", { children: RECEIPTS[receipt.status] }) :
                                _jsx("p", { children: "No product transport receipt was supplied." }), _jsx("small", { children: "Downstream delivery must be verified by the product before claiming SIEM ingestion." })] })] })) : null, canTest ? (_jsx(Button, { type: "button", variant: "secondary", disabled: testing, onClick: () => onTestForwarding(), children: "Test audit forwarding" })) : (_jsx("p", { className: "dr-admin__muted", children: "Forwarding tests require explicit product permission and a product-provided action." }))] }));
}
