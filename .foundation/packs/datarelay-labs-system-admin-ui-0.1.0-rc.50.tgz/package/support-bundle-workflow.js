import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { SupportBundleReviewPanel } from "./support-bundle-review-panel.js";
function valid(value) {
    if (!value || typeof value !== "object")
        return false;
    const b = value;
    const p = b.projection;
    return Boolean(p && typeof p.reference === "string" && /^[a-z][a-z0-9_.-]{0,95}$/.test(p.reference) && typeof p.revision === "string" && /^[a-z][a-z0-9_.-]{0,95}$/.test(p.revision) &&
        ["ready", "generating", "failed", "unavailable", "unknown"].includes(p.state) && Array.isArray(p.categories) && Number.isSafeInteger(p.checkedAt) && Number.isSafeInteger(p.expiresAt) &&
        Number.isSafeInteger(p.sizeBytes) && p.sizeBytes >= 0 && p.sizeBytes <= 50 * 1024 * 1024 && typeof b.filename === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,110}\.(json|zip|tgz|tar\.gz)$/.test(b.filename) &&
        (p.state !== "ready" && b.sha256 === undefined || typeof b.sha256 === "string" && /^[a-f0-9]{64}$/.test(b.sha256)));
}
function safe(b) {
    const p = b.projection;
    const proof = p.proof;
    return p.state === "ready" && p.expiresAt > Math.floor(Date.now() / 1000) && p.expiresAt > p.checkedAt &&
        proof?.expectedRevision === p.revision && proof.allowed === true && Array.isArray(proof.blockers) && proof.blockers.length === 0 && proof.productTransferRequired === true &&
        proof.archiveBytesVerified === true && proof.redactionVerified === true && proof.credentialScanPassed === true && proof.personalDataScanPassed === true && proof.customerPayloadExcluded === true &&
        proof.actorAuthorized === true && proof.recentMfaVerified === true && proof.auditReady === true;
}
/** Native archive generation plus shared privacy review, exact-byte hash verification and download. */
export function SupportBundleWorkflow({ adapter, canGenerate = false, canDownload = false }) {
    const seq = useRef(0);
    const live = useRef({ adapter, canGenerate, canDownload });
    live.current = { adapter, canGenerate, canDownload };
    const [bundle, setBundle] = useState(null);
    const [review, setReview] = useState(false);
    const [ack, setAck] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    useEffect(() => { seq.current++; setBundle(null); setReview(false); setAck(false); setBusy(false); setError(""); setNotice(""); return () => { seq.current++; }; }, [adapter, canGenerate, canDownload]);
    const alive = (n, right) => seq.current === n && live.current.adapter === adapter && live.current[right];
    async function prepare() {
        if (!canGenerate || busy)
            return;
        const n = ++seq.current;
        setBusy(true);
        setBundle(null);
        setReview(false);
        setAck(false);
        setError("");
        setNotice("");
        try {
            const b = await adapter.prepare();
            if (!alive(n, "canGenerate"))
                return;
            if (!valid(b))
                throw Error();
            setBundle(b);
        }
        catch {
            if (alive(n, "canGenerate"))
                setError("Support bundle generation could not be verified.");
        }
        finally {
            if (seq.current === n)
                setBusy(false);
        }
    }
    async function refresh() {
        if (!bundle || busy || !canGenerate)
            return;
        const n = ++seq.current;
        setBusy(true);
        setReview(false);
        setAck(false);
        setError("");
        try {
            const b = await adapter.read(bundle.projection.reference);
            if (!alive(n, "canGenerate"))
                return;
            if (!valid(b) || b.projection.reference !== bundle.projection.reference)
                throw Error();
            setBundle(b);
        }
        catch {
            if (alive(n, "canGenerate"))
                setError("Support bundle metadata is unavailable.");
        }
        finally {
            if (seq.current === n)
                setBusy(false);
        }
    }
    async function download() {
        if (!bundle || !valid(bundle) || !safe(bundle) || !canDownload || !review || !ack || busy)
            return;
        const n = ++seq.current;
        setBusy(true);
        setError("");
        setNotice("");
        setAck(false);
        setReview(false);
        try {
            const fresh = await adapter.read(bundle.projection.reference);
            if (!alive(n, "canDownload"))
                return;
            if (!valid(fresh) || !safe(fresh) || fresh.projection.reference !== bundle.projection.reference || fresh.projection.revision !== bundle.projection.revision || fresh.sha256 !== bundle.sha256 || fresh.filename !== bundle.filename)
                throw Error("changed");
            const result = await adapter.download(fresh.projection.reference, fresh.projection.revision);
            if (!alive(n, "canDownload"))
                return;
            if (!(result?.blob instanceof Blob) || result.blob.size !== fresh.projection.sizeBytes || typeof result.auditReference !== "string" || !result.auditReference || !crypto.subtle)
                throw Error("integrity");
            const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", await result.blob.arrayBuffer()))).map(b => b.toString(16).padStart(2, "0")).join("");
            if (!alive(n, "canDownload"))
                return;
            if (digest !== fresh.sha256)
                throw Error("integrity");
            const href = URL.createObjectURL(result.blob);
            const link = document.createElement("a");
            link.href = href;
            link.download = fresh.filename;
            link.rel = "noopener";
            document.body.append(link);
            try {
                link.click();
            }
            finally {
                link.remove();
                setTimeout(() => URL.revokeObjectURL(href), 1000);
            }
            setNotice("Support bundle hash verified; download started.");
        }
        catch (e) {
            if (alive(n, "canDownload"))
                setError(e instanceof Error && e.message === "changed" ? "Support bundle changed or expired. Generate or review a fresh bundle." : "Support bundle integrity or transfer could not be verified. No download was authorized.");
        }
        finally {
            if (seq.current === n)
                setBusy(false);
        }
    }
    return _jsxs("section", { className: "dr-admin__support-workflow", "aria-label": "Support bundle workflow", children: [_jsx("h4", { children: "Support bundle" }), _jsx("p", { children: "Generate diagnostic evidence, review privacy checks, then verify bytes before download." }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, canGenerate ? _jsx(Button, { disabled: busy, onClick: () => void prepare(), children: "Generate support bundle" }) : _jsx("p", { children: "Support bundle generation is not authorized." }), bundle ? _jsxs(_Fragment, { children: [_jsx(SupportBundleReviewPanel, { projection: bundle.projection, reviewAvailability: canDownload ? "supported" : "read_only", pending: busy, onReviewDownload: (reference, revision) => { if (canDownload && reference === bundle.projection.reference && revision === bundle.projection.revision && safe(bundle)) {
                            setReview(true);
                            setAck(false);
                        } } }), canGenerate ? _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void refresh(), children: "Refresh support bundle" }) : null] }) : null, bundle && review && canDownload && safe(bundle) ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Confirm support bundle download", children: [_jsx("h4", { children: "Confirm download" }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: ack, disabled: busy, onChange: e => setAck(e.target.checked) }), "I reviewed the bundle privacy and transfer impact"] }), _jsx(Button, { disabled: !ack || busy, onClick: () => void download(), children: "Download verified support bundle" })] }) : null] });
}
