import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { TLS_REPLACEMENT_BLOCKERS } from "@datarelay-labs/system-contracts";
const REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const MAX_UNIX_SECONDS = 253402300799;
const CERT_STATUS = ["valid", "expiring", "expired", "unknown"];
const BLOCKERS = {
    chain_unverified: "Full certificate chain was not verified",
    hostname_unverified: "Certificate hostname/SAN match was not verified",
    key_pair_unverified: "Certificate/private-key pairing was not verified",
    tls_policy_unverified: "Minimum TLS policy was not verified",
    candidate_expired: "Replacement certificate has expired",
    listener_unverified: "HTTPS listener and reconnect path were not verified",
    rollback_unavailable: "Rollback plan is not ready",
    recovery_unavailable: "Out-of-band management recovery not confirmed",
    permission_denied: "Actor permission not confirmed",
    mfa_required: "Recent MFA verification not confirmed",
    audit_unavailable: "Audit persistence not ready",
    stale_revision: "Certificate revision is stale"
};
const VERIFIED_LABELS = [
    ["chainVerified", "Product-verified full chain", "Full certificate chain unverified"],
    ["hostnameVerified", "Product-verified hostname/SAN match", "Certificate hostname/SAN match unverified"],
    ["keyPairVerified", "Product-verified key pair", "Certificate and key pairing unverified"],
    ["tlsPolicyVerified", "Product-verified minimum TLS policy", "Minimum TLS policy not verified"]
];
function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exact(value, names) {
    return Object.keys(value).every((key) => names.includes(key));
}
function seconds(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 &&
        value <= MAX_UNIX_SECONDS;
}
function validProjection(value) {
    if (!record(value) || !exact(value, ["observedAt", "current", "candidate", "preview"]) ||
        !seconds(value.observedAt) || !record(value.current) ||
        !exact(value.current, ["revision", "status", "notAfter"]) ||
        typeof value.current.revision !== "string" || !REFERENCE.test(value.current.revision) ||
        typeof value.current.status !== "string" || !CERT_STATUS.includes(value.current.status) ||
        (value.current.notAfter !== undefined && value.current.notAfter !== null &&
            !seconds(value.current.notAfter)))
        return false;
    const status = value.current.status;
    if (value.current.notAfter !== null && value.current.notAfter !== undefined) {
        if (status === "valid" && value.current.notAfter <= value.observedAt)
            return false;
        if (status === "expiring" && value.current.notAfter <= value.observedAt)
            return false;
        if (status === "expired" && value.current.notAfter > value.observedAt)
            return false;
    }
    else if (status !== "unknown")
        return false;
    if (value.candidate !== undefined) {
        const c = value.candidate;
        if (!record(c) || !exact(c, [
            "reference", "notAfter", "chainVerified", "hostnameVerified",
            "keyPairVerified", "tlsPolicyVerified"
        ]) || typeof c.reference !== "string" || !REFERENCE.test(c.reference) ||
            !seconds(c.notAfter) || typeof c.chainVerified !== "boolean" ||
            typeof c.hostnameVerified !== "boolean" ||
            typeof c.keyPairVerified !== "boolean" ||
            typeof c.tlsPolicyVerified !== "boolean")
            return false;
    }
    if (value.preview !== undefined) {
        const p = value.preview;
        if (!record(p) || !record(value.candidate) ||
            !exact(p, ["expectedRevision", "candidateReference", "safe", "blockers",
                "productApplyRequired", "rollbackReady", "outOfBandRecoveryReady",
                "authorizedActor", "recentMfaVerified", "auditReady"]) ||
            typeof p.expectedRevision !== "string" || !REFERENCE.test(p.expectedRevision) ||
            typeof p.candidateReference !== "string" || !REFERENCE.test(p.candidateReference) ||
            typeof p.safe !== "boolean" || p.productApplyRequired !== true ||
            typeof p.rollbackReady !== "boolean" ||
            typeof p.outOfBandRecoveryReady !== "boolean" ||
            typeof p.authorizedActor !== "boolean" ||
            typeof p.recentMfaVerified !== "boolean" ||
            typeof p.auditReady !== "boolean" ||
            !Array.isArray(p.blockers) || p.blockers.length > TLS_REPLACEMENT_BLOCKERS.length)
            return false;
        const seen = new Set();
        for (const code of p.blockers) {
            if (typeof code !== "string" ||
                !TLS_REPLACEMENT_BLOCKERS.includes(code) ||
                seen.has(code))
                return false;
            seen.add(code);
        }
        if (p.safe && p.blockers.length > 0)
            return false;
    }
    return true;
}
function canReview(value) {
    const c = value.candidate, p = value.preview;
    return Boolean(c && p && p.safe && p.blockers.length === 0 &&
        p.expectedRevision === value.current.revision &&
        p.candidateReference === c.reference &&
        c.notAfter > value.observedAt && c.chainVerified &&
        c.hostnameVerified && c.keyPairVerified && c.tlsPolicyVerified &&
        p.rollbackReady && p.outOfBandRecoveryReady &&
        p.authorizedActor && p.recentMfaVerified && p.auditReady);
}
/** Source-only TLS status and replacement preflight. Products retain full
 * chain/SAN/hostname/key/TLS policy validators, credentials, listener restart
 * and all reversible host apply operations. */
export function TlsCertificateReviewPanel({ projection, reviewAvailability = "unknown", onReviewTlsChange, pending = false }) {
    const valid = validProjection(projection);
    const accepted = valid ? projection : undefined;
    const candidate = accepted?.candidate;
    const preview = accepted?.preview;
    const ready = accepted ? canReview(accepted) : false;
    const canDelegate = ready && reviewAvailability === "supported" &&
        typeof onReviewTlsChange === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Certificate evidence unavailable", description: "Certificate evidence unavailable; no TLS replacement action is available." });
    return (_jsxs("section", { className: "dr-admin__tls-review", "aria-label": "TLS certificate review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "TLS certificate lifecycle" }), _jsxs(StatusBadge, { tone: !valid ? "neutral" : accepted?.current.status === "valid" ? "success" :
                            accepted?.current.status === "expired" ? "critical" :
                                accepted?.current.status === "expiring" ? "warning" : "neutral", children: ["TLS certificate: ", accepted?.current.status ?? "unknown"] })] }), !valid ? _jsx("p", { children: "Invalid TLS certificate evidence. No certificate details displayed." }) : null, accepted ? _jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "Certificate status is supplied by the product and is advisory only, not an actual certificate install." }), _jsxs("p", { children: ["Certificate expiration: ", accepted.current.notAfter == null ?
                                "Unknown" : new Date(accepted.current.notAfter * 1000).toISOString().slice(0, 10) + " UTC"] }), !candidate ? _jsx("p", { children: "Product replacement candidate unavailable" }) : (_jsxs("div", { className: "dr-admin__tls-review-checks", children: [_jsx("h3", { children: "Replacement preflight" }), _jsx("ul", { children: VERIFIED_LABELS.map(([key, good, bad]) => _jsx("li", { children: candidate[key] ? good : bad }, key)) }), candidate.notAfter <= accepted.observedAt ?
                                _jsx("p", { children: "Replacement certificate is already expired" }) :
                                _jsxs("p", { children: ["Product candidate expiry: ", new Date(candidate.notAfter * 1000).toISOString().slice(0, 10), " UTC"] })] })), !preview ? _jsx("p", { children: "Product TLS replacement preview unavailable" }) : (_jsxs("div", { className: "dr-admin__tls-review-blockers", children: [preview.expectedRevision !== accepted.current.revision ?
                                _jsx("p", { children: "TLS replacement preview is stale" }) : null, candidate && preview.candidateReference !== candidate.reference ?
                                _jsx("p", { children: "Candidate identity does not match" }) : null, !preview.rollbackReady ? _jsx("p", { children: "Rollback plan is not ready" }) : null, !preview.outOfBandRecoveryReady ?
                                _jsx("p", { children: "Out-of-band management recovery not confirmed" }) : null, !preview.authorizedActor ? _jsx("p", { children: "Actor permission not confirmed" }) : null, !preview.recentMfaVerified ? _jsx("p", { children: "Recent MFA verification not confirmed" }) : null, !preview.auditReady ? _jsx("p", { children: "Audit persistence not ready" }) : null, preview.blockers.map((code) => _jsx("p", { children: BLOCKERS[code] }, code))] })), _jsx("p", { role: "status", "aria-live": "polite", children: ready ? "TLS replacement review eligible — product evidence only" :
                            "TLS replacement not qualified for review" }), canDelegate ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewTlsChange?.(accepted.current.revision, candidate.reference), children: "Review TLS replacement" })) : (_jsx("p", { className: "dr-admin__muted", children: "Product permission, chain/SAN/key proof, recovery and rollback are required before any review." }))] }) : null] }));
}
