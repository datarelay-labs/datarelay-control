import { type BackupPolicyReviewProjection, type CapabilityAvailability } from "@datarelay-labs/system-contracts";
export type BackupPolicyReviewPanelProps = {
    /** Authenticated current/desired pure BackupPolicy fields from product. */
    projection?: BackupPolicyReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Optional review/confirmation navigation only, never scheduler mutation. */
    onReviewBackupPolicy?: (expectedRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Product-neutral schedule, retention and proof-policy review only.
 * No real archive/file/S3/DB/restore access, no task scheduling or mutation. */
export declare function BackupPolicyReviewPanel({ projection, reviewAvailability, onReviewBackupPolicy, pending }: BackupPolicyReviewPanelProps): import("react").JSX.Element;
