import { type CapabilityAvailability, type ManagementAccessPolicyProjection } from "@datarelay-labs/system-contracts";
export type ManagementAccessPolicyPanelProps = {
    /** Sanitized, already-authorized product policy and Python AccessChangePreview. */
    policy?: ManagementAccessPolicyProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    onReviewPolicy?: (sshRevision: string, webRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Strictly presentation-only; it neither edits firewall/sshd/proxy rules
 * nor trusts this browser as the current management source or actor. */
export declare function ManagementAccessPolicyPanel({ policy, reviewAvailability, onReviewPolicy, pending }: ManagementAccessPolicyPanelProps): import("react").JSX.Element;
