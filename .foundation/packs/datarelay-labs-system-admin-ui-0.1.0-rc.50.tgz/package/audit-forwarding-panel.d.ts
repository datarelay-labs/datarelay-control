import type { AuditForwardingProjection, CapabilityAvailability } from "@datarelay-labs/system-contracts";
export type AuditForwardingPanelProps = {
    /** Product-authorized read-only status, never a direct audit transport sink. */
    projection?: AuditForwardingProjection;
    /** Current server-validated role capability, not a UI role guess. */
    testAvailability?: CapabilityAvailability | "unknown";
    /** Product performs its own test/sink safety/authorization; Foundation never sends. */
    onTestForwarding?: () => void | Promise<void>;
    testing?: boolean;
};
/** Safe, common, read-only forwarding operations UI. No event payload, IP, TLS
 * secret, destination address, transport send, queue mutation or permission grant. */
export declare function AuditForwardingPanel({ projection, testAvailability, onTestForwarding, testing }: AuditForwardingPanelProps): import("react").JSX.Element;
