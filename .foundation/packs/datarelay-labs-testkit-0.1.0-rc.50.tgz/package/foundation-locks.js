import { report } from "./types.js";
const PRODUCTS = ["control", "link", "grant"];
const PACKAGE_NAMES = [
    "@datarelay-labs/tokens",
    "@datarelay-labs/icons",
    "@datarelay-labs/ui",
    "@datarelay-labs/product-shell",
    "@datarelay-labs/auth-ui",
    "@datarelay-labs/system-contracts",
    "@datarelay-labs/system-admin-ui",
    "@datarelay-labs/testkit",
    "@datarelay-labs/foundation",
    "@datarelay-labs/foundation-cli"
];
const REQUIRED_PACKAGES = new Set(PACKAGE_NAMES);
const SHA40 = /^[a-f0-9]{40}$/;
const SHA256 = /^[a-f0-9]{64}$/;
const SEMVER = /^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isLock(value) {
    if (!isRecord(value))
        return false;
    if (typeof value.source_head !== "string" || !SHA40.test(value.source_head))
        return false;
    if (typeof value.version !== "string" || !SEMVER.test(value.version))
        return false;
    if (!Array.isArray(value.packages) || value.packages.length !== PACKAGE_NAMES.length)
        return false;
    const seen = new Set();
    for (const entry of value.packages) {
        if (!isRecord(entry))
            return false;
        if (typeof entry.name !== "string" || !REQUIRED_PACKAGES.has(entry.name))
            return false;
        if (typeof entry.sha256 !== "string" || !SHA256.test(entry.sha256))
            return false;
        if (seen.has(entry.name))
            return false;
        seen.add(entry.name);
    }
    return seen.size === PACKAGE_NAMES.length;
}
/**
 * Checks Foundation pin convergence across the THREE product-owned checked-in
 * locks at three exact product commits. It does not read source/archives itself,
 * verify a package was installed, inspect runtime RBAC or grant user/release PASS.
 *
 * The expected lock MUST come from a separately authenticated Foundation source
 * candidate. A consumer-supplied expected lock is not an authority boundary.
 */
export function verifyFoundationConsumerLocks(expected, consumers, options) {
    if (options !== undefined && (!isRecord(options) ||
        Object.keys(options).some((key) => key !== "requireArchiveDigests") ||
        (options.requireArchiveDigests !== undefined &&
            typeof options.requireArchiveDigests !== "boolean"))) {
        return report([{
                id: "FOUNDATION_ARCHIVE_OPTIONS_INVALID",
                message: "Archive verification options must be explicit boolean declarations."
            }]);
    }
    if (!isLock(expected)) {
        return report([{
                id: "FOUNDATION_EXPECTED_LOCK_INVALID",
                message: "A valid, authoritative ten-package Foundation expected lock is required."
            }]);
    }
    if (!Array.isArray(consumers)) {
        return report([{
                id: "FOUNDATION_CONSUMER_SET_INVALID",
                message: "Control, Link and Grant consumer snapshots must be an array."
            }]);
    }
    // An independently authenticated Foundation expected archive manifest is
    // a caller prerequisite. Product-supplied reference pins are diagnostic only.
    const strictArchives = options?.requireArchiveDigests === true;
    if (strictArchives && expected.packages.some((entry) => typeof entry.archive_sha256 !== "string" ||
        !SHA256.test(entry.archive_sha256))) {
        return report([{
                id: "FOUNDATION_EXPECTED_ARCHIVE_INVALID",
                message: "Expected Foundation lock is missing valid ten-package archive SHA256 declarations."
            }]);
    }
    const expectedArchiveHashes = strictArchives
        ? new Map(expected.packages.map(({ name, archive_sha256 }) => [name, archive_sha256]))
        : null;
    const findings = [];
    const byProduct = new Map();
    const usedHeads = new Set();
    for (const candidate of consumers) {
        if (!isRecord(candidate) || !PRODUCTS.includes(candidate.productId)) {
            findings.push({
                id: "FOUNDATION_CONSUMER_UNKNOWN",
                message: "Only control, link and grant product snapshots are allowed."
            });
            continue;
        }
        const productId = candidate.productId;
        if (byProduct.has(productId)) {
            findings.push({
                id: "FOUNDATION_CONSUMER_DUPLICATE",
                message: `Duplicate snapshot for ${productId}.`
            });
            continue;
        }
        byProduct.set(productId, candidate);
        if (typeof candidate.consumerHead !== "string" || !SHA40.test(candidate.consumerHead)) {
            findings.push({
                id: "FOUNDATION_CONSUMER_HEAD_INVALID",
                message: `Exact consumer Git HEAD is required for ${productId}.`
            });
        }
        else if (usedHeads.has(candidate.consumerHead)) {
            findings.push({
                id: "FOUNDATION_CONSUMER_HEAD_DUPLICATED",
                message: `Repeated consumer Git HEAD for ${productId}.`
            });
        }
        else {
            usedHeads.add(candidate.consumerHead);
        }
    }
    const expectedPackages = new Map(expected.packages.map(({ name, sha256 }) => [name, sha256]));
    // Fixed order keeps findings stable independent of caller input order.
    for (const productId of PRODUCTS) {
        const candidate = byProduct.get(productId);
        if (!candidate) {
            findings.push({
                id: "FOUNDATION_CONSUMER_MISSING",
                message: `Missing ${productId} Foundation consumer snapshot.`
            });
            continue;
        }
        if (!isLock(candidate.lock)) {
            findings.push({
                id: "FOUNDATION_CONSUMER_LOCK_INVALID",
                message: `Invalid or incomplete ten-package Foundation lock for ${productId}.`
            });
            continue;
        }
        if (candidate.lock.source_head !== expected.source_head) {
            findings.push({
                id: "FOUNDATION_SOURCE_DRIFT",
                message: `${productId} Foundation source HEAD differs from expected source.`
            });
        }
        if (candidate.lock.version !== expected.version) {
            findings.push({
                id: "FOUNDATION_VERSION_DRIFT",
                message: `${productId} Foundation package version differs from expected version.`
            });
        }
        const actualPackages = new Map(candidate.lock.packages.map(({ name, sha256 }) => [name, sha256]));
        const actualArchives = strictArchives
            ? new Map(candidate.lock.packages.map(({ name, archive_sha256 }) => [name, archive_sha256]))
            : null;
        for (const name of PACKAGE_NAMES) {
            if (actualPackages.get(name) !== expectedPackages.get(name)) {
                findings.push({
                    id: "FOUNDATION_PACKAGE_DRIFT",
                    message: `${productId} pinned digest differs for ${name}.`
                });
            }
            if (!strictArchives)
                continue;
            const archiveDigest = actualArchives?.get(name);
            if (archiveDigest === undefined) {
                findings.push({
                    id: "FOUNDATION_ARCHIVE_DIGEST_MISSING",
                    message: `${productId} declares no archive SHA256 for ${name}.`
                });
            }
            else if (typeof archiveDigest !== "string" || !SHA256.test(archiveDigest)) {
                findings.push({
                    id: "FOUNDATION_ARCHIVE_DIGEST_INVALID",
                    message: `${productId} has invalid archive SHA256 for ${name}.`
                });
            }
            else if (archiveDigest !== expectedArchiveHashes?.get(name)) {
                findings.push({
                    id: "FOUNDATION_ARCHIVE_DIGEST_DRIFT",
                    message: `${productId} archive SHA256 differs for ${name}.`
                });
            }
        }
    }
    return report(findings);
}
