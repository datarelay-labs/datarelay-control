import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { AccountList } from "./account-list.js";
const text = (v, max = 256) => typeof v === "string" && v.length > 0 && v.length <= max && !/[\u0000-\u001f\u007f]/.test(v);
export function validUserDirectory(value) {
    if (!value || typeof value !== "object")
        return false;
    const d = value;
    if (!text(d.revision) || !text(d.currentUserId) || typeof d.complete !== "boolean" ||
        !Array.isArray(d.roles) || !d.roles.length || d.roles.length > 256 ||
        !Array.isArray(d.accounts) || d.accounts.length > 10000 || !d.passwordPolicy)
        return false;
    const p = d.passwordPolicy;
    if (!Number.isInteger(p.minimumLength) || !Number.isInteger(p.maximumLength) ||
        p.minimumLength < 8 || p.maximumLength < p.minimumLength || p.maximumLength > 1024)
        return false;
    const roles = new Set();
    for (const r of d.roles) {
        if (!r || !text(r.ref, 128) || !text(r.label) || typeof r.administrator !== "boolean" || roles.has(r.ref))
            return false;
        roles.add(r.ref);
    }
    const ids = new Set(), names = new Set();
    for (const a of d.accounts) {
        if (!a || !text(a.id) || !text(a.username, 128) || !roles.has(a.roleRef) ||
            !["active", "disabled"].includes(a.status) || typeof a.mfaRequired !== "boolean" ||
            (a.credentialRevision !== undefined && !text(a.credentialRevision)) || ids.has(a.id) || names.has(a.username.toLowerCase()))
            return false;
        ids.add(a.id);
        names.add(a.username.toLowerCase());
    }
    return !d.complete || ids.has(d.currentUserId);
}
export function validateManagedPassword(value, policy) {
    if (!value.trim() || value.length < policy.minimumLength || value.length > policy.maximumLength || /[\p{C}]/u.test(value)) {
        return `Password must contain ${policy.minimumLength}–${policy.maximumLength} characters without control characters.`;
    }
    return null;
}
function validateDraft(draft, directory) {
    if (!directory.complete)
        return "A complete current directory is required for account changes.";
    if (!text(draft.username, 128) || draft.username !== draft.username.trim() || /\s/.test(draft.username))
        return "Enter a valid username without whitespace.";
    const role = directory.roles.find(r => r.ref === draft.roleRef);
    if (!role)
        return "Choose a current product role.";
    if (draft.operation === "create") {
        if (directory.accounts.some(a => a.username.toLowerCase() === draft.username.toLowerCase()))
            return "That username already exists.";
        return null;
    }
    const subject = directory.accounts.find(a => a.id === draft.accountId);
    if (!subject || subject.username !== draft.username)
        return "The selected account is no longer current.";
    const reducing = draft.operation === "delete" || draft.status !== "active" || !role.administrator;
    const wasAdmin = directory.roles.find(r => r.ref === subject.roleRef)?.administrator === true && subject.status === "active";
    if (subject.id === directory.currentUserId && (draft.operation === "delete" || draft.status !== "active" || draft.roleRef !== subject.roleRef))
        return "Use a different authorized administrator to change your own access.";
    const activeAdmins = directory.accounts.filter(a => a.status === "active" && directory.roles.find(r => r.ref === a.roleRef)?.administrator).length;
    if (wasAdmin && reducing && activeAdmins <= 1)
        return "The last active administrator must be preserved.";
    return null;
}
function sameDraft(a, b) {
    return a && b && Object.keys(a).length === Object.keys(b).length &&
        Object.keys(b).every(k => a[k] === b[k]);
}
function previewMatches(p, draft) {
    return p?.allowed === true && Array.isArray(p.blockers) && p.blockers.length === 0 &&
        p.expectedRevision === draft.expectedRevision && sameDraft(p.draft, draft) && text(p.token, 4096) &&
        Number.isFinite(p.expiresAt) && p.expiresAt > Date.now();
}
export function UserManagementPage({ adapter, canRead = false, canManage = false }) {
    const prefix = useId();
    const live = useRef({ adapter, canRead, canManage, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead || live.current.canManage !== canManage) {
        live.current = { adapter, canRead, canManage, epoch: live.current.epoch + 1 };
    }
    const [data, setData] = useState(null);
    const directory = data?.source === adapter && canRead ? data.value : null;
    const [edit, setEdit] = useState(null);
    const [password, setPassword] = useState("");
    const [preview, setPreview] = useState(null);
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const [uncertain, setUncertain] = useState(false);
    const serial = useRef(0);
    const writable = canRead && canManage && directory?.complete === true;
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead && (!write || live.current.canManage);
    function clearEditor() { setEdit(null); setPassword(""); setPreview(null); setConfirmed(false); }
    useEffect(() => { setBusy(false); if (!canManage || !canRead)
        clearEditor(); }, [canManage, canRead, adapter]);
    useEffect(() => { void load(); return () => { serial.current++; live.current.epoch++; }; }, [adapter, canRead]);
    async function load() {
        if (!canRead) {
            setData(null);
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        try {
            const result = await adapter.read();
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validUserDirectory(result))
                throw new Error("invalid");
            setData({ source: adapter, value: result });
            clearEditor();
            setUncertain(false);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setData(null);
                setError("Cannot read a valid current user directory. Refresh to retry.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    function open(operation, id = null) {
        if (!writable || busy || uncertain || !directory)
            return;
        const account = directory.accounts.find(a => a.id === id);
        const roleRef = account?.roleRef ?? directory.roles.find(r => !r.administrator)?.ref;
        if (!roleRef) {
            setError("No safe non-administrator default role is available.");
            return;
        }
        const draft = { operation, accountId: id, username: account?.username ?? "", roleRef,
            status: account?.status ?? "active", expectedRevision: directory.revision, passwordChange: operation === "create" };
        const problem = operation === "delete" ? validateDraft(draft, directory) : null;
        if (problem) {
            setError(problem);
            return;
        }
        clearEditor();
        setEdit(draft);
        setError("");
        setNotice("");
    }
    function change(patch) { if (busy)
        return; setEdit(e => e ? { ...e, ...patch } : null); setPreview(null); setConfirmed(false); setError(""); }
    async function prepare() {
        if (!writable || busy || !edit || !directory)
            return;
        const problem = validateDraft(edit, directory) ?? (edit.passwordChange ? validateManagedPassword(password, directory.passwordPolicy) : null);
        setPreview(null);
        setConfirmed(false);
        setError(problem ?? "");
        if (problem)
            return;
        const epoch = live.current.epoch, draft = { ...edit };
        setBusy(true);
        try {
            const result = await adapter.preview(draft);
            if (!fresh(epoch, true))
                return;
            if (!result || !Array.isArray(result.blockers) || !result.blockers.every(b => text(b, 512)) || !sameDraft(result.draft, draft) || result.expectedRevision !== directory.revision)
                throw new Error("invalid");
            setPreview(result);
            if (!previewMatches(result, draft))
                setError("The product did not authorize a current account change preview.");
        }
        catch {
            if (fresh(epoch, true))
                setError("Cannot obtain a current authorized account preview.");
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    async function apply() {
        if (!writable || busy || uncertain || !edit || !preview || !confirmed || !directory || !previewMatches(preview, edit))
            return;
        const problem = validateDraft(edit, directory);
        if (problem) {
            setError(problem);
            return;
        }
        const epoch = live.current.epoch, draft = { ...edit }, secret = password;
        setBusy(true);
        setError("");
        setNotice("");
        let submitted = false;
        try {
            const before = await adapter.read();
            if (!fresh(epoch, true))
                return;
            if (!validUserDirectory(before) || before.revision !== draft.expectedRevision || validateDraft(draft, before))
                throw new Error("stale");
            if (!previewMatches(preview, draft))
                throw new Error("expired");
            submitted = true;
            setUncertain(true);
            const receipt = await adapter.apply({ draft, previewToken: preview.token, ...(draft.passwordChange ? { password: secret } : {}) });
            setPassword("");
            if (!fresh(epoch, true))
                return;
            const after = await adapter.read();
            if (!fresh(epoch, true))
                return;
            if (!validUserDirectory(after))
                throw new Error("invalid");
            setData({ source: adapter, value: after });
            if (receipt?.applied !== true || !text(receipt.auditRef) || !text(receipt.accountId) ||
                (draft.accountId !== null && receipt.accountId !== draft.accountId) || after.revision !== receipt.revision || after.revision === before.revision)
                throw new Error("unverified");
            const subject = after.accounts.find(a => a.id === receipt.accountId);
            if (draft.operation === "delete" ? after.accounts.some(a => a.id === draft.accountId) :
                !subject || subject.username !== draft.username || subject.roleRef !== draft.roleRef || subject.status !== draft.status ||
                    (draft.operation === "create" && subject.mfaRequired !== false))
                throw new Error("unverified");
            if (draft.operation === "update" && draft.passwordChange && (!text(receipt.credentialRevision) || subject?.credentialRevision !== receipt.credentialRevision ||
                before.accounts.find(a => a.id === draft.accountId)?.credentialRevision === receipt.credentialRevision))
                throw new Error("unverified");
            clearEditor();
            setUncertain(false);
            setNotice("User change applied and verified.");
        }
        catch {
            if (fresh(epoch)) {
                setPassword("");
                setPreview(null);
                setConfirmed(false);
                setUncertain(submitted);
                setError(submitted ? "Account change status unknown. Inspect the refreshed directory and audit before starting another change." : "Account settings changed or preview expired. Refresh and review again.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "User management", children: _jsx("p", { role: "status", children: "User management is not authorized." }) });
    return _jsxs("section", { className: "dr-admin__users-page", "aria-label": "User management", children: [_jsxs("header", { children: [_jsx("h3", { children: "User Management" }), _jsx("p", { children: "Manage platform users, roles and access. Native authorization and audit are required for every account change." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, !directory && busy ? _jsx("p", { role: "status", children: "Loading users\u2026" }) : null, _jsxs("div", { className: "dr-admin__users-actions", children: [_jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh users" }), writable ? _jsx(Button, { disabled: busy || uncertain, onClick: () => open("create"), children: "Create user" }) : null] }), directory ? _jsxs(_Fragment, { children: [_jsxs("p", { children: [directory.accounts.length, " ", directory.complete ? "users in the authorized directory" : "loaded users; directory is incomplete", "."] }), _jsx(AccountList, { filterLoadedAccounts: true, filterLoadedAccountFacets: true, sortLoadedAccounts: true, resetLoadedAccountFilters: true, accounts: directory.accounts.map(a => ({ id: a.id, displayName: a.username, status: a.status, role: { value: a.roleRef, label: directory.roles.find(r => r.ref === a.roleRef).label } })), ...(writable ? { actions: (row) => {
                                const a = directory.accounts.find(u => u.id === row.id);
                                const blocked = validateDraft({ operation: "delete", accountId: a.id, username: a.username, roleRef: a.roleRef, status: a.status, expectedRevision: directory.revision, passwordChange: false }, directory);
                                return _jsxs("div", { className: "dr-admin__users-actions", children: [_jsx(Button, { variant: "secondary", disabled: busy || uncertain, onClick: () => open("update", row.id), "aria-label": `Edit ${row.displayName}`, children: "Edit" }), _jsx(Button, { variant: "danger", disabled: busy || uncertain || Boolean(blocked), title: blocked ?? "Delete account", onClick: () => open("delete", row.id), "aria-label": `Delete ${row.displayName}`, children: "Delete" })] });
                            } } : {}) }), writable && edit ? _jsxs("section", { className: "dr-admin__users-editor", "aria-label": "Account editor", children: [_jsx("h4", { children: edit.operation === "create" ? "New user" : edit.operation === "delete" ? "Delete user" : "Edit user" }), _jsx("label", { htmlFor: prefix + "username", children: "Username" }), _jsx("input", { id: prefix + "username", value: edit.username, maxLength: 128, disabled: busy || edit.operation !== "create", onChange: e => change({ username: e.target.value }) }), edit.operation !== "delete" ? _jsxs(_Fragment, { children: [_jsx("label", { htmlFor: prefix + "role", children: "Role" }), _jsx("select", { id: prefix + "role", value: edit.roleRef, disabled: busy, onChange: e => change({ roleRef: e.target.value }), children: directory.roles.map(r => _jsx("option", { value: r.ref, children: r.label }, r.ref)) }), edit.operation === "update" ? _jsxs(_Fragment, { children: [_jsx("label", { htmlFor: prefix + "status", children: "Account status" }), _jsxs("select", { id: prefix + "status", value: edit.status, disabled: busy, onChange: e => change({ status: e.target.value }), children: [_jsx("option", { value: "active", children: "Active" }), _jsx("option", { value: "disabled", children: "Disabled" })] })] }) : _jsx("p", { children: "New accounts start with MFA off. MFA policy is configured separately." }), _jsx("label", { htmlFor: prefix + "password", children: edit.operation === "create" ? "Initial password" : "New password (optional)" }), _jsx("input", { id: prefix + "password", type: "password", autoComplete: "new-password", value: password, maxLength: directory.passwordPolicy.maximumLength, disabled: busy, onChange: e => { setPassword(e.target.value); change({ passwordChange: edit.operation === "create" || e.target.value.length > 0 }); } })] }) : _jsx("p", { children: "This removes the selected account and invalidates its sessions. Review carefully." }), _jsxs("div", { className: "dr-admin__users-actions", children: [_jsx(Button, { disabled: busy || uncertain, onClick: () => void prepare(), children: "Preview user change" }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: clearEditor, children: "Cancel" })] }), preview ? _jsxs("section", { className: "dr-admin__users-review", "aria-label": "Account change review", children: [_jsx("h4", { children: "Review user change" }), _jsxs("p", { children: [edit.operation, ": ", edit.username, " \u00B7 ", edit.roleRef, " \u00B7 ", edit.status] }), preview.blockers.length ? _jsx("ul", { children: preview.blockers.map((b, i) => _jsx("li", { children: b }, i)) }) : null, previewMatches(preview, edit) ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: e => setConfirmed(e.target.checked) }), "I confirm this account change"] }), _jsx(Button, { disabled: busy || !confirmed || uncertain, onClick: () => void apply(), children: "Apply user change" })] }) : null] }) : null] }) : null] }) : null] });
}
