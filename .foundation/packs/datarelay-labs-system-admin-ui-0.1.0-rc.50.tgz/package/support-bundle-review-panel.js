import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { SUPPORT_BUNDLE_CATEGORIES, SUPPORT_BUNDLE_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const STATES = ["ready", "generating", "failed", "unavailable", "unknown"];
const CATEGORIES = {
    system_diagnostics: "System diagnostics",
    operation_status: "Operation status",
    configuration_summary: "Configuration summary",
    audit_metadata: "Audit metadata"
};
const BLOCKER_LABELS = {
    redaction_unverified: "Redaction review is incomplete",
    credentials_unverified: "Credential scan verification missing",
    personal_data_unverified: "Personal data exclusion unverified",
    customer_payload_present: "Customer payload exclusion is unverified",
    archive_integrity_missing: "Artifact byte integrity is unverified",
    expired_bundle: "Bundle evidence expired",
    permission_denied: "Product permission denied",
    mfa_required: "Recent privileged MFA required",
    audit_unavailable: "Product audit unavailable",
    stale_revision: "Support bundle revision no longer matches"
};
const MAX_SECONDS = 253402300799;
function obj(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exact(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validTimestamp(value) {
    return typeof value === "number" && Number.isSafeInteger(value) &&
        value >= 0 && value <= MAX_SECONDS;
}
function validProjection(value) {
    if (!obj(value) ||
        !exact(value, [
            "reference", "revision", "state", "checkedAt",
            "expiresAt", "sizeBytes", "categories", "proof"
        ]) ||
        typeof value.reference !== "string" || !REF.test(value.reference) ||
        typeof value.revision !== "string" || !REF.test(value.revision) ||
        typeof value.state !== "string" ||
        !STATES.includes(value.state) ||
        !validTimestamp(value.checkedAt) || !validTimestamp(value.expiresAt) ||
        typeof value.sizeBytes !== "number" ||
        !Number.isSafeInteger(value.sizeBytes) || value.sizeBytes < 1 ||
        value.sizeBytes > 2 ** 40 ||
        !Array.isArray(value.categories) || value.categories.length > SUPPORT_BUNDLE_CATEGORIES.length)
        return false;
    const seen = new Set();
    for (const category of value.categories) {
        if (typeof category !== "string" ||
            !SUPPORT_BUNDLE_CATEGORIES.includes(category) ||
            seen.has(category))
            return false;
        seen.add(category);
    }
    if (value.proof !== undefined) {
        const p = value.proof;
        if (!obj(p) ||
            !exact(p, [
                "expectedRevision", "allowed", "blockers", "productTransferRequired",
                "archiveBytesVerified", "redactionVerified", "credentialScanPassed",
                "personalDataScanPassed", "customerPayloadExcluded",
                "actorAuthorized", "recentMfaVerified", "auditReady"
            ]) ||
            typeof p.expectedRevision !== "string" || !REF.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" ||
            p.productTransferRequired !== true ||
            !Array.isArray(p.blockers) || p.blockers.length > SUPPORT_BUNDLE_BLOCKERS.length)
            return false;
        for (const flag of [
            "archiveBytesVerified", "redactionVerified", "credentialScanPassed",
            "personalDataScanPassed", "customerPayloadExcluded",
            "actorAuthorized", "recentMfaVerified", "auditReady"
        ])
            if (typeof p[flag] !== "boolean")
                return false;
        const blockerSet = new Set();
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !SUPPORT_BUNDLE_BLOCKERS.includes(blocker) ||
                blockerSet.has(blocker))
                return false;
            blockerSet.add(blocker);
        }
        if (p.allowed && p.blockers.length)
            return false;
    }
    return true;
}
/** No artifact bytes, network fetch, browser URL, or user-supplied path.
 * Only a current product server may prove redaction/safety of actual bytes. */
export function SupportBundleReviewPanel({ projection, reviewAvailability = "unknown", onReviewDownload, pending = false }) {
    const valid = validProjection(projection);
    const current = valid ? projection : undefined;
    const proof = current?.proof;
    const stale = Boolean(proof && proof.expectedRevision !== current?.revision);
    const expired = Boolean(current && current.expiresAt <= current.checkedAt);
    const proofVerified = Boolean(proof &&
        proof.archiveBytesVerified && proof.redactionVerified &&
        proof.credentialScanPassed && proof.personalDataScanPassed &&
        proof.customerPayloadExcluded && proof.actorAuthorized &&
        proof.recentMfaVerified && proof.auditReady);
    const ready = Boolean(current?.state === "ready" &&
        current.categories.length > 0 && !expired && !stale &&
        proof?.allowed && proof.blockers.length === 0 && proofVerified);
    const canReview = ready && reviewAvailability === "supported" &&
        typeof onReviewDownload === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Support bundle unavailable", description: "No product-authenticated support evidence is available for review." });
    return (_jsxs("section", { className: "dr-admin__support-bundle", "aria-label": "Support bundle download review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Support evidence bundle" }), _jsxs(StatusBadge, { tone: ready ? "info" : "neutral", children: ["Support bundle: ", current?.state ?? "unknown"] })] }), !valid ? _jsx("p", { children: "Invalid support bundle evidence" }) : null, current ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "Evidence is product-reported; Foundation has not inspected the archive bytes." }), _jsxs("p", { children: [current.sizeBytes.toLocaleString("en-US"), " bytes (product-reported)"] }), current.categories.length ? (_jsx("ul", { "aria-label": "Product-reviewed support evidence categories", className: "dr-admin__support-bundle-categories", children: current.categories.map((category) => _jsx("li", { children: CATEGORIES[category] }, category)) })) : _jsx("p", { children: "No reviewed diagnostic categories were supplied" }), expired ? _jsx("p", { children: "Bundle already expired at the product verification time" }) : null, !proof ? _jsx("p", { children: "Product bundle redaction and integrity proof unavailable" }) : (_jsxs("div", { className: "dr-admin__support-bundle-checks", children: [stale ? _jsx("p", { children: "Product support bundle review is stale" }) : null, !proof.archiveBytesVerified ?
                                _jsx("p", { children: "Actual bundle bytes were not independently verified by the product" }) : null, !proof.redactionVerified ?
                                _jsx("p", { children: "Sensitive content redaction is not proven" }) : null, !proof.credentialScanPassed ?
                                _jsx("p", { children: "Credential exposure scan is not proven" }) : null, !proof.personalDataScanPassed ?
                                _jsx("p", { children: "Personal data exposure scan is not proven" }) : null, !proof.customerPayloadExcluded ?
                                _jsx("p", { children: "Customer payload exclusion is not proven" }) : null, !proof.actorAuthorized ? _jsx("p", { children: "Actor permission not verified" }) : null, !proof.recentMfaVerified ? _jsx("p", { children: "Recent privileged MFA not verified" }) : null, !proof.auditReady ? _jsx("p", { children: "Product audit not ready" }) : null, proof.blockers.map((blocker) => _jsx("p", { children: BLOCKER_LABELS[blocker] }, blocker))] })), canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => void onReviewDownload?.(current.reference, current.revision), children: "Review support bundle download" })) : _jsx("p", { className: "dr-admin__muted", children: "Product redaction, scans, integrity, actor/MFA and audit approval are required." })] })) : null] }));
}
