import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { EmptyState, StatusBadge } from "@datarelay-labs/ui";
function outcomeTone(outcome) {
    switch (outcome?.trim().toLowerCase()) {
        case "applied":
        case "success":
        case "succeeded":
            return "success";
        case "blocked":
        case "denied":
            return "warning";
        case "failed":
        case "error":
            return "critical";
        default:
            return outcome ? "info" : "neutral";
    }
}
function displayedValue(value, masked) {
    return masked ? "Redacted" : value ?? "—";
}
export function ConfigurationChangeHistory({ entries }) {
    if (!entries.length) {
        return (_jsx(EmptyState, { title: "No configuration changes", description: "No product-supplied configuration history is available." }));
    }
    return (_jsx("ol", { className: "dr-admin__change-history", "aria-label": "Configuration change history", children: entries.map((entry) => (_jsxs("li", { className: "dr-admin__change-history-card", children: [_jsxs("div", { className: "dr-admin__change-history-title", children: [_jsx("strong", { children: entry.target }), entry.outcome ? _jsx(StatusBadge, { tone: outcomeTone(entry.outcome), children: entry.outcome }) : null] }), _jsxs("dl", { className: "dr-admin__change-history-meta", children: [_jsxs("div", { children: [_jsx("dt", { children: "Time" }), _jsx("dd", { children: entry.timestamp })] }), entry.actor ? _jsxs("div", { children: [_jsx("dt", { children: "Actor" }), _jsx("dd", { children: entry.actor })] }) : null, entry.auditReference ? _jsxs("div", { children: [_jsx("dt", { children: "Audit" }), _jsx("dd", { children: entry.auditReference })] }) : null] }), entry.summary ? _jsx("p", { className: "dr-admin__change-history-summary", children: entry.summary }) : null, entry.changes.length ? (_jsxs("details", { className: "dr-admin__change-history-details", children: [_jsxs("summary", { children: ["Review ", entry.changes.length, " ", entry.changes.length === 1 ? "change" : "changes"] }), _jsx("ul", { className: "dr-admin__change-history-diff", "aria-label": `${entry.target} changed settings`, children: entry.changes.map((change, index) => (_jsxs("li", { className: "dr-admin__change-history-change", children: [_jsx("strong", { children: change.field }), _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Before" }), _jsx("dd", { children: displayedValue(change.before, change.masked) })] }), _jsxs("div", { children: [_jsx("dt", { children: "After" }), _jsx("dd", { children: displayedValue(change.after, change.masked) })] })] }), change.note ? _jsx("small", { children: change.note }) : null] }, `${change.field}-${index}`))) })] })) : null] }, entry.id))) }));
}
