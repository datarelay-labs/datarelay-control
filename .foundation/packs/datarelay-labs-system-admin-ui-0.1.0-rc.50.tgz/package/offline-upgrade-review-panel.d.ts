import { type CapabilityAvailability, type OfflineUpgradeReviewProjection } from "@datarelay-labs/system-contracts";
export type OfflineUpgradeReviewPanelProps = {
    /** Already-authenticated product installer facts, no artifact/file body. */
    projection?: OfflineUpgradeReviewProjection;
    /** Real actor's current product server permission, not the preview's Boolean. */
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Only opens a product-owned review; never invokes installer/rollback. */
    onReviewUpgrade?: (currentRevision: string, releaseRef: string) => void | Promise<void>;
    pending?: boolean;
};
/** PF-12 product-neutral offline upgrade review: zero I/O, no signing or
 * cryptographic publisher authentication by the UI, no host/DB update. */
export declare function OfflineUpgradeReviewPanel({ projection, reviewAvailability, onReviewUpgrade, pending }: OfflineUpgradeReviewPanelProps): import("react").JSX.Element;
