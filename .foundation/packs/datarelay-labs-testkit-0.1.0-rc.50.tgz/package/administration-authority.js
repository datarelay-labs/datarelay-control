import { report } from "./types.js";
const SAFE_ID = /^[a-z0-9][a-z0-9._-]{0,63}$/;
const TIERS = { none: 0, view: 1, manage: 2 };
const admissionValid = (value) => value === "allowed" || value === "denied" || value === "unknown";
const isSafeId = (value) => typeof value === "string" && SAFE_ID.test(value);
const finding = (id, message) => ({ id, message });
/**
 * Compare an actor's UI-displayed administrative tasks against independent
 * product route/API authority and *all mandatory* initial page-load reads.
 *
 * No backend requests are made, and a passing result says only that the
 * provided product fixture is internally consistent, NOT that it is true.
 */
export function verifyAdministrationTaskAuthority(cases) {
    if (!Array.isArray(cases)) {
        return report([finding("ADMIN_INVALID_EVIDENCE_ID", "Expected bounded product task evidence.")]);
    }
    if (cases.length === 0) {
        return report([finding("ADMIN_EVIDENCE_EMPTY", "No product/role Administration task evidence was provided.")]);
    }
    const findings = [];
    const seen = new Set();
    // Use deterministic ordering while preserving the caller's input array.
    const ordered = [...cases].sort((a, b) => {
        const key = (x) => [x?.productId ?? "", x?.roleId ?? "", x?.taskId ?? ""].join("\u0000");
        return key(a).localeCompare(key(b));
    });
    for (const entry of ordered) {
        if (!entry ||
            !isSafeId(entry.productId) ||
            !isSafeId(entry.roleId) ||
            !isSafeId(entry.taskId) ||
            !Array.isArray(entry.requiredReads) ||
            entry.requiredReads.some((read) => !read || !isSafeId(read.id)) ||
            !["none", "view", "manage"].includes(entry.presentedAccess) ||
            !["none", "view", "manage", "unknown"].includes(entry.backendAccess) ||
            !admissionValid(entry.targetAdmission) ||
            typeof entry.pageLoadCovered !== "boolean") {
            findings.push(finding("ADMIN_INVALID_EVIDENCE_ID", "Product administrative authority evidence must have stable IDs and defined states."));
            continue;
        }
        const identity = [entry.productId, entry.roleId, entry.taskId].join("\u0000");
        if (seen.has(identity)) {
            findings.push(finding("ADMIN_DUPLICATE_TASK_ROLE", "Administrative task authority evidence duplicates a product/role/task identity."));
            continue;
        }
        seen.add(identity);
        const scope = [entry.productId, entry.roleId, entry.taskId].join("/");
        // An unexposed task has no actionable UI route; missing product authority
        // does not falsely become permission to show it.
        if (entry.presentedAccess === "none")
            continue;
        if (entry.backendAccess === "unknown") {
            findings.push(finding("ADMIN_BACKEND_AUTHORITY_UNKNOWN", `Backend authority UNKNOWN for ${scope}`));
        }
        else if (TIERS[entry.backendAccess] < TIERS[entry.presentedAccess]) {
            findings.push(finding("ADMIN_BACKEND_ACCESS_MISMATCH", `UI access exceeds backend authority for ${scope}`));
        }
        if (entry.targetAdmission === "unknown") {
            findings.push(finding("ADMIN_TARGET_ADMISSION_UNKNOWN", `Target admission UNKNOWN for ${scope}`));
        }
        else if (entry.targetAdmission === "denied") {
            findings.push(finding("ADMIN_TARGET_DENIED", `Target denied for ${scope}`));
        }
        if (!entry.pageLoadCovered) {
            findings.push(finding("ADMIN_PAGE_LOAD_UNVERIFIED", `Initial reads not fully verified for ${scope}`));
        }
        for (const read of entry.requiredReads) {
            if (!admissionValid(read.admission)) {
                findings.push(finding("ADMIN_PAGE_LOAD_UNKNOWN", `Malformed initial read admission for ${scope}`));
            }
            else if (read.admission === "unknown") {
                findings.push(finding("ADMIN_PAGE_LOAD_UNKNOWN", `Initial read authority UNKNOWN for ${scope}`));
            }
            else if (read.admission === "denied") {
                findings.push(finding("ADMIN_PAGE_LOAD_DENIED", `Initial read denied for ${scope}`));
            }
        }
    }
    return report(findings);
}
