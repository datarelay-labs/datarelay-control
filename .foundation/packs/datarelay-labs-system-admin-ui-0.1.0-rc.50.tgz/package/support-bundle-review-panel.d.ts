import { type CapabilityAvailability, type SupportBundleReviewProjection } from "@datarelay-labs/system-contracts";
export type SupportBundleReviewPanelProps = {
    /** Product-authenticated bounded metadata, never actual file content. */
    projection?: SupportBundleReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Delegates a product-owned confirmation. It does NOT directly download. */
    onReviewDownload?: (bundleReference: string, expectedRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** No artifact bytes, network fetch, browser URL, or user-supplied path.
 * Only a current product server may prove redaction/safety of actual bytes. */
export declare function SupportBundleReviewPanel({ projection, reviewAvailability, onReviewDownload, pending }: SupportBundleReviewPanelProps): import("react").JSX.Element;
