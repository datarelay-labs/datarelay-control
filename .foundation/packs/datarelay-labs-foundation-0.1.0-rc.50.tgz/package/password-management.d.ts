import { type PasswordChangeSubmission } from "@datarelay-labs/auth-ui";
export type PasswordManagementState = {
    username: string;
    revision: string;
    credentialRevision: string;
    sessionEpoch: number;
    passwordPolicy: {
        minimumLength: number;
        maximumLength: number;
    };
};
export type PasswordChangeReceipt = {
    changed: boolean;
    revision: string;
    credentialRevision: string;
    sessionEpoch: number;
    auditRef: string;
};
export type PasswordManagementAdapter = {
    /** Metadata only. Never return a password, hash, salt, session token or MFA seed. */
    read: () => Promise<PasswordManagementState>;
    /** Subject is always the native authenticated actor, never a posted username. */
    change: (request: PasswordChangeSubmission & {
        expectedRevision: string;
    }) => Promise<PasswordChangeReceipt>;
};
export type PasswordManagementPageProps = {
    adapter: PasswordManagementAdapter;
    canRead?: boolean;
    canChange?: boolean;
};
/** Full native-adapter workflow built around the existing common password form. */
export declare function PasswordManagementPage({ adapter, canRead, canChange }: PasswordManagementPageProps): import("react").JSX.Element;
