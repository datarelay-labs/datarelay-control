import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { SECURITY_POLICY_BLOCKERS } from "@datarelay-labs/system-contracts";
const CODE = /^[a-z][a-z0-9_.-]{0,95}$/;
const BLOCKER_LABELS = {
    AUTHORITY_UNAVAILABLE: "Product policy backend is unavailable",
    MFA_REQUIRED: "Recent privileged MFA verification is required",
    LAST_ADMIN_RECOVERY_UNAVAILABLE: "Last administrator recovery path is unavailable",
    ROLLBACK_UNAVAILABLE: "Product rollback path is unavailable",
    AUDIT_UNAVAILABLE: "Product change audit is unavailable",
    POLICY_WEAKENING: "The proposed security policy weakens existing safeguards"
};
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function fields(value, allowed) {
    return Object.keys(value).every((key) => allowed.includes(key));
}
function range(value, min, max) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max;
}
function validSnapshot(value) {
    if (!object(value) || !fields(value, ["password", "login", "sessions"]))
        return false;
    const password = value.password, login = value.login, sessions = value.sessions;
    if (!object(password) || !fields(password, ["minimumLength", "maximumLength"]) ||
        !range(password.minimumLength, 8, 256) ||
        !range(password.maximumLength, password.minimumLength, 1024))
        return false;
    if (!object(login) || !fields(login, ["maxFailures", "windowSeconds", "lockoutSeconds"]) ||
        !range(login.maxFailures, 1, 100) ||
        !range(login.windowSeconds, 30, 86400) ||
        !range(login.lockoutSeconds, 30, 86400))
        return false;
    if (!object(sessions) ||
        !fields(sessions, ["idleTimeoutSeconds", "absoluteLifetimeSeconds", "maxConcurrentSessions"]) ||
        !range(sessions.idleTimeoutSeconds, 60, 86400) ||
        !range(sessions.absoluteLifetimeSeconds, sessions.idleTimeoutSeconds, 365 * 86400) ||
        !range(sessions.maxConcurrentSessions, 1, 100))
        return false;
    return true;
}
function validPolicy(value) {
    if (!object(value) || !fields(value, ["revision", "effective", "proposed", "preview"]) ||
        typeof value.revision !== "string" || !CODE.test(value.revision) ||
        !validSnapshot(value.effective) ||
        (value.proposed !== undefined && !validSnapshot(value.proposed)))
        return false;
    if (value.preview !== undefined) {
        const preview = value.preview;
        if (!object(preview) ||
            !fields(preview, ["expectedRevision", "safe", "blockers", "productApplyRequired"]) ||
            typeof preview.expectedRevision !== "string" || !CODE.test(preview.expectedRevision) ||
            typeof preview.safe !== "boolean" ||
            preview.productApplyRequired !== true ||
            !Array.isArray(preview.blockers) ||
            preview.blockers.length > SECURITY_POLICY_BLOCKERS.length)
            return false;
        const seen = new Set();
        for (const b of preview.blockers) {
            if (typeof b !== "string" || !SECURITY_POLICY_BLOCKERS.includes(b) ||
                seen.has(b))
                return false;
            seen.add(b);
        }
        if (preview.safe !== (preview.blockers.length === 0))
            return false;
    }
    return true;
}
const FIELDS = [
    ["Password minimum length", "password", "minimumLength"],
    ["Password maximum length", "password", "maximumLength"],
    ["Login failure threshold", "login", "maxFailures"],
    ["Login failure window", "login", "windowSeconds"],
    ["Login lockout duration", "login", "lockoutSeconds"],
    ["Session idle timeout", "sessions", "idleTimeoutSeconds"],
    ["Session absolute lifetime", "sessions", "absoluteLifetimeSeconds"],
    ["Concurrent session limit", "sessions", "maxConcurrentSessions"]
];
function values(p) {
    return [
        p.password.minimumLength, p.password.maximumLength,
        p.login.maxFailures, p.login.windowSeconds, p.login.lockoutSeconds,
        p.sessions.idleTimeoutSeconds, p.sessions.absoluteLifetimeSeconds,
        p.sessions.maxConcurrentSessions
    ];
}
function weakens(current, next) {
    return next.password.minimumLength < current.password.minimumLength ||
        next.password.maximumLength > current.password.maximumLength ||
        next.login.maxFailures > current.login.maxFailures ||
        next.login.windowSeconds < current.login.windowSeconds ||
        next.login.lockoutSeconds < current.login.lockoutSeconds ||
        next.sessions.idleTimeoutSeconds > current.sessions.idleTimeoutSeconds ||
        next.sessions.absoluteLifetimeSeconds > current.sessions.absoluteLifetimeSeconds ||
        next.sessions.maxConcurrentSessions > current.sessions.maxConcurrentSessions;
}
/** Pure shared policy review UX. Its preview is product-generated, NOT a
 * native Python "change policy" API or real server-side permission check. */
export function SecurityPolicyReviewPanel({ policy, reviewAvailability = "unknown", onReviewPolicy, pending = false }) {
    const valid = validPolicy(policy);
    const accepted = valid ? policy : undefined;
    const preview = accepted?.preview;
    const proposed = accepted?.proposed;
    const changed = Boolean(accepted && proposed &&
        values(accepted.effective).some((v, i) => v !== values(proposed)[i]));
    const weakening = Boolean(accepted && proposed && weakens(accepted.effective, proposed));
    const stale = Boolean(preview && preview.expectedRevision !== accepted?.revision);
    const eligible = Boolean(changed && !weakening && !stale && preview?.safe);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewPolicy === "function";
    if (!policy)
        return _jsx(EmptyState, { title: "Security policy unavailable", description: "No product-authenticated password, login, or session settings supplied." });
    return (_jsxs("section", { className: "dr-admin__security-policy", "aria-label": "Security policy review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Security policy review" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Security policy: ", eligible ? "review eligible" : valid ? "review not established" : "unknown"] })] }), !valid ? _jsx("p", { children: "Invalid security policy projection. No product policy values displayed." }) : null, accepted ? (_jsxs(_Fragment, { children: [_jsx("h3", { children: "Product effective policy" }), _jsx("p", { className: "dr-admin__muted", children: "Values are product-provided; duration values are seconds. No actual login, password or session is changed here." }), _jsx("div", { className: "dr-admin__security-policy-table", children: _jsxs("table", { "aria-label": "Product security policy comparison", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsx("tbody", { children: FIELDS.map(([label], i) => (_jsxs("tr", { children: [_jsx("th", { scope: "row", children: label }), _jsx("td", { children: values(accepted.effective)[i] }), _jsx("td", { children: proposed ? values(proposed)[i] : "Not provided" })] }, label))) })] }) }), _jsx("p", { children: "Product-supplied preview; not a change or session invalidation" }), !changed ? _jsx("p", { children: "No policy change proposed" }) : null, weakening ? _jsx("p", { children: "Proposed policy weakens at least one effective security limit" }) : null, !preview ? _jsx("p", { children: "Product security policy change preview unavailable" }) : null, stale ? _jsx("p", { children: "Security policy preview revision is stale" }) : null, preview?.blockers.length ? (_jsx("ul", { className: "dr-admin__security-policy-blockers", "aria-label": "Policy change blockers", children: preview.blockers.map((b) => _jsx("li", { children: BLOCKER_LABELS[b] }, b)) })) : null, canReview ? _jsx(Button, { variant: "secondary", type: "button", disabled: pending, onClick: () => onReviewPolicy?.(accepted.revision), children: "Review security policy" }) : _jsx("p", { className: "dr-admin__muted", children: "Only a product-authorized, non-weakening and revision-bound policy may proceed to review." })] })) : null] }));
}
