import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { ONPREM_SETUP_STAGE_IDS, ONPREM_SETUP_REVIEW_BLOCKERS } from "@datarelay-labs/system-contracts";
const REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const REQUIRED = new Set([
    "administrator", "management_access", "network_time", "tls"
]);
const STAGE_LABELS = {
    administrator: "Administrator identity",
    management_access: "Management access",
    network_time: "Network and time",
    tls: "HTTPS and trusted TLS",
    notifications: "Notifications",
    backup_recovery: "Backup and recovery"
};
const STATES = {
    ready: "Ready — verified by product",
    attention: "Needs product attention",
    unknown: "Unknown — evidence not provided",
    unavailable: "Unavailable in product"
};
const BLOCKER_LABELS = {
    administrator_missing: "Initial administrator identity is not ready",
    mfa_unverified: "MFA enrollment is not verified",
    acl_unverified: "Management access readiness is unverified",
    network_unverified: "DNS and NTP readiness is unverified",
    tls_unverified: "HTTPS/TLS readiness is unverified",
    notifications_unverified: "Notification readiness is unverified",
    backup_unverified: "Backup/recovery readiness is unverified",
    rollback_unavailable: "Product rollback is not ready",
    audit_unavailable: "Product audit persistence is unavailable",
    permission_denied: "Actor permission has not been verified",
    stale_revision: "Product setup revision is stale"
};
function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function allowed(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validProjection(v) {
    if (!record(v) || !allowed(v, ["revision", "steps", "review"]) ||
        typeof v.revision !== "string" || !REFERENCE.test(v.revision) ||
        !Array.isArray(v.steps) || v.steps.length !== ONPREM_SETUP_STAGE_IDS.length)
        return false;
    const seen = new Set();
    for (const step of v.steps) {
        if (!record(step) || !allowed(step, ["id", "status", "required"]) ||
            typeof step.id !== "string" ||
            !ONPREM_SETUP_STAGE_IDS.includes(step.id) ||
            typeof step.status !== "string" || !Object.hasOwn(STATES, step.status) ||
            typeof step.required !== "boolean" ||
            (REQUIRED.has(step.id) && !step.required) ||
            seen.has(step.id))
            return false;
        seen.add(step.id);
    }
    if (seen.size !== ONPREM_SETUP_STAGE_IDS.length)
        return false;
    if (v.review !== undefined) {
        const p = v.review;
        if (!record(p) ||
            !allowed(p, ["expectedRevision", "allowed", "blockers", "productReviewRequired"]) ||
            typeof p.expectedRevision !== "string" || !REFERENCE.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" || p.productReviewRequired !== true ||
            !Array.isArray(p.blockers) || p.blockers.length > ONPREM_SETUP_REVIEW_BLOCKERS.length)
            return false;
        const already = new Set();
        for (const b of p.blockers) {
            if (typeof b !== "string" ||
                !ONPREM_SETUP_REVIEW_BLOCKERS.includes(b) ||
                already.has(b))
                return false;
            already.add(b);
        }
        if (p.allowed && p.blockers.length > 0)
            return false;
    }
    return true;
}
/** Six fixed first-run areas, stepper is local/navigation-only.
 * Product owns first administrator, source ACL, NTP/DNS/TLS, notifications,
 * backup/drill, audit, session and all real setup/migration effects. */
export function OnPremSetupReadinessWizard({ projection, reviewAvailability = "unknown", onReviewLaunch, pending = false }) {
    const [localIndex, setLocalIndex] = useState(0);
    const valid = validProjection(projection);
    const current = valid ? projection : undefined;
    const steps = current?.steps;
    const index = Math.min(localIndex, Math.max(0, (steps?.length ?? 1) - 1));
    const step = steps?.[index];
    const required = steps?.filter((s) => REQUIRED.has(s.id)) ?? [];
    const readyCount = required.filter((s) => s.status === "ready").length;
    const mandatoryReady = readyCount === REQUIRED.size;
    const review = current?.review;
    const stale = Boolean(review && review.expectedRevision !== current?.revision);
    const ready = Boolean(mandatoryReady && review?.allowed && review.blockers.length === 0 && !stale);
    const canReview = ready && reviewAvailability === "supported" &&
        typeof onReviewLaunch === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Setup readiness unavailable", description: "Setup readiness unavailable. No product startup or administrator operation is inferred." });
    return (_jsxs("section", { className: "dr-admin__setup", "aria-label": "Initial on-prem setup readiness", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Initial on-prem setup readiness" }), _jsx(StatusBadge, { tone: ready ? "info" : "neutral", children: ready ? "Product review eligible" : "Evidence incomplete or unavailable" })] }), !valid ? _jsx("p", { children: "Invalid setup readiness projection. No setup steps displayed." }) : null, current && steps && step ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "Reviewing readiness never creates users, changes networking or starts services." }), _jsxs("p", { children: ["Required readiness: ", readyCount, " of ", REQUIRED.size] }), _jsx("p", { className: "dr-admin__muted", children: "Optional stages are informational and do not silently block required checks." }), _jsx("nav", { "aria-label": "Setup stages", className: "dr-admin__setup-stages", children: steps.map((s, i) => (_jsxs("button", { type: "button", "aria-current": i === index ? "step" : undefined, onClick: () => setLocalIndex(i), children: [STAGE_LABELS[s.id], " \u2014 ", s.status] }, s.id))) }), _jsxs("div", { className: "dr-admin__setup-focus", role: "group", "aria-label": "Selected setup stage", children: [_jsxs("h3", { children: ["Stage ", index + 1, " of ", steps.length, ": ", STAGE_LABELS[step.id]] }), _jsx("p", { children: STATES[step.status] }), _jsx("p", { children: step.required || REQUIRED.has(step.id) ? "Required" : "Optional" }), _jsxs("div", { className: "dr-admin__setup-navigation", children: [_jsx(Button, { type: "button", variant: "secondary", disabled: index === 0, onClick: () => setLocalIndex(Math.max(0, index - 1)), children: "Previous stage" }), _jsx(Button, { type: "button", variant: "secondary", disabled: index === steps.length - 1, onClick: () => setLocalIndex(Math.min(steps.length - 1, index + 1)), children: "Next stage" })] })] }), !mandatoryReady ? _jsx("p", { children: "Required stage evidence is incomplete" }) : null, !review ? _jsx("p", { children: "Product launch readiness preview unavailable" }) : null, stale ? _jsx("p", { children: "Product setup review is stale" }) : null, review && review.blockers.length > 0 ? (_jsx("ul", { className: "dr-admin__setup-blockers", "aria-label": "Product readiness blockers", children: review.blockers.map((b) => _jsx("li", { children: BLOCKER_LABELS[b] }, b)) })) : null, ready ? _jsx("p", { children: "Review eligible \u2014 product-supplied evidence only" }) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewLaunch?.(current.revision), children: "Review launch readiness" })) : (_jsx("p", { className: "dr-admin__muted", children: "Launch review requires all essential areas, a current verified product preview and actor authorization." }))] })) : null] }));
}
