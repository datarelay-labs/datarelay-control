"""Recovery-safe common HTTPS orchestration using native storage and host ports.

This module generates no key/certificate and changes no host listener itself.
Native adapters provide current authority, durable exclusive ownership, observed
certificate/listener facts and a recovery mechanism that outlives this process.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from ipaddress import ip_address
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlsplit
from uuid import uuid4
import math
import re
import time

from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict

_CONFIG_KEYS = {'enabled', 'certificateIpAddresses', 'certificateDnsNames', 'redirectHttpToHttps', 'certificateValidDays'}
_LABEL = re.compile(r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\Z', re.ASCII)


class HttpsApplyUnverified(RuntimeError):
    """Host outcome is not proven; reconcile the exact native operation first."""


def _ref(value: object) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 256 or any(ord(c) < 33 or ord(c) == 127 for c in value):
        raise SettingsValidationError('A current native reference is required.')
    return value


def _time(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402000000:
        raise SettingsValidationError('Invalid native time evidence.')
    return float(value)


def _url(value: object, scheme: str | None = None) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 2048 or any(c.isspace() or ord(c) < 32 for c in value):
        raise SettingsValidationError('Invalid native public connection URL.')
    try:
        parts = urlsplit(value)
        if (parts.scheme not in ('http', 'https') or (scheme and parts.scheme != scheme)
                or not parts.hostname or parts.username is not None or parts.password is not None
                or parts.query or parts.fragment or parts.port == 0 or '\\' in value):
            raise ValueError('invalid URL')
    except (ValueError, TypeError):
        raise SettingsValidationError('Native connection URLs cannot expose credentials or query tokens.') from None
    return value


def _configuration(value: object) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _CONFIG_KEYS:
        raise SettingsValidationError('Submit only HTTPS configuration fields.')
    if type(value['enabled']) is not bool or type(value['redirectHttpToHttps']) is not bool:
        raise SettingsValidationError('HTTPS flags must be Boolean values.')
    days = value['certificateValidDays']
    if type(days) is not int or not 1 <= days <= 3650:
        raise SettingsValidationError('Certificate validity must be 1–3650 days.')
    ips, names = value['certificateIpAddresses'], value['certificateDnsNames']
    if not isinstance(ips, list) or not isinstance(names, list) or len(ips) + len(names) > 128:
        raise SettingsValidationError('At most 128 certificate SANs may be supplied.')
    seen_ips: set[str] = set(); seen_names: set[str] = set()
    for value_ip in ips:
        if not isinstance(value_ip, str) or not 0 < len(value_ip) <= 45 or '%' in value_ip:
            raise SettingsValidationError('Invalid IP SAN.')
        try:
            canonical = str(ip_address(value_ip))
        except ValueError:
            raise SettingsValidationError('Invalid IP SAN.') from None
        if canonical in seen_ips:
            raise SettingsValidationError('Duplicate IP SAN.')
        seen_ips.add(canonical)
    for name in names:
        if not isinstance(name, str) or not 0 < len(name) <= 253:
            raise SettingsValidationError('Invalid DNS SAN.')
        host = name[2:] if name.startswith('*.') else name
        if not host or any(not _LABEL.fullmatch(label) for label in host.split('.')):
            raise SettingsValidationError('Invalid DNS SAN.')
        if name.lower() in seen_names:
            raise SettingsValidationError('Duplicate DNS SAN.')
        seen_names.add(name.lower())
    if value['enabled'] and not (ips or names):
        raise SettingsValidationError('HTTPS requires at least one IP or DNS SAN.')
    if not value['enabled'] and value['redirectHttpToHttps']:
        raise SettingsValidationError('HTTP redirect requires HTTPS.')
    return deepcopy(dict(value))


def _config_of(state: Mapping[str, Any]) -> dict[str, Any]:
    try:
        return _configuration({k: state[k] for k in _CONFIG_KEYS})
    except KeyError:
        raise SettingsValidationError('Incomplete HTTPS configuration.') from None


def _draft(value: object) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != _CONFIG_KEYS | {'expectedRevision', 'regenerateCertificate'}:
        raise SettingsValidationError('Submit only HTTPS configuration, regeneration and revision.')
    result = _config_of(value); _ref(value['expectedRevision'])
    if type(value['regenerateCertificate']) is not bool:
        raise SettingsValidationError('Regeneration must be Boolean.')
    if value['regenerateCertificate'] and not (result['certificateIpAddresses'] or result['certificateDnsNames']):
        raise SettingsValidationError('Certificate generation requires SANs.')
    return {**result, 'expectedRevision': value['expectedRevision'], 'regenerateCertificate': value['regenerateCertificate']}


@dataclass(frozen=True)
class HttpsObservation:
    state: dict[str, Any]
    certificate_ref: str | None = None


def _observation(value: object) -> HttpsObservation:
    if not isinstance(value, HttpsObservation) or not isinstance(value.state, dict):
        raise SettingsValidationError('Independent native HTTPS observation is required.')
    s = value.state; _config_of(s)
    booleans = {'httpListenerActive', 'httpsListenerActive', 'redirectEffective', 'restartRequired', 'proxyFallbackToHttp'}
    keys = _CONFIG_KEYS | booleans | {'proxyStatus', 'proxyHealthOk', 'currentAccessUrl', 'browserHttpUrl', 'browserHttpsUrl', 'certificateNotAfter'}
    if set(s) != keys or any(type(s[k]) is not bool for k in booleans):
        raise SettingsValidationError('Invalid native HTTPS observation.')
    if s['proxyStatus'] not in ('ok', 'degraded', 'unknown', 'not_configured') or (s['proxyHealthOk'] is not None and type(s['proxyHealthOk']) is not bool):
        raise SettingsValidationError('Invalid native proxy evidence.')
    _url(s['currentAccessUrl']); _url(s['browserHttpUrl'], 'http')
    if s['browserHttpsUrl'] is not None:
        _url(s['browserHttpsUrl'], 'https')
    if value.certificate_ref is not None:
        _ref(value.certificate_ref)
    expiry = s['certificateNotAfter']
    if expiry is not None:
        _expiry(expiry)
    if (value.certificate_ref is None) != (expiry is None):
        raise SettingsValidationError('Certificate identity and validity evidence must be paired.')
    return deepcopy(value)


def _expiry(value: object) -> float:
    try:
        if not isinstance(value, str) or len(value) > 64:
            raise ValueError('invalid time')
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            raise ValueError('timezone required')
        return _time(parsed.timestamp())
    except (ValueError, TypeError, OverflowError):
        raise SettingsValidationError('Invalid native certificate expiry.') from None


@dataclass(frozen=True)
class HttpsReadiness:
    certificate_policy_ok: bool = False
    recovery_ready: bool = False
    rollback_ready: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    recovery_url: str = ''

    def __post_init__(self) -> None:
        if any(type(v) is not bool for k, v in vars(self).items() if k != 'recovery_url'):
            raise SettingsValidationError('Readiness requires actual native Boolean evidence.')
        if not isinstance(self.recovery_url, str):
            raise SettingsValidationError('Invalid native recovery URL.')
        if self.recovery_url:
            _url(self.recovery_url)

    @property
    def safe(self) -> bool:
        return bool(self.recovery_url) and all(v for k, v in vars(self).items() if k != 'recovery_url')


@dataclass(frozen=True)
class HttpsSnapshot:
    revision: str
    configuration: dict[str, Any]
    applying: bool = False


@dataclass(frozen=True)
class HttpsPreview:
    reference: str
    actor: str
    draft: dict[str, Any]
    created_at: float
    expires_at: float
    safe: bool


@dataclass(frozen=True)
class HttpsApplyClaim:
    reference: str
    preview: HttpsPreview
    previous: HttpsObservation


class HttpsHostDriver(Protocol):
    """Native, bounded operations with current authority and ownership checks.

    observe MUST independently inspect actual SANs, certificate identity/expiry,
    listeners, redirect and health, not echo the submitted desired configuration.
    readiness checks native issuer/key/chain/SAN/lifetime policy and usable
    recovery, current MFA and durable audit. No PEM/private keys reach this API.
    arm_rollback persists a recovery timer and snapshot before returning True.
    rollback returns True ONLY after previous state and timer cancellation are
    independently verified for the exact operation (including a lost arm reply).
    confirm returns True ONLY after cancelling this operation's recovery timer.
    Every effect is bound to the exclusive native claim and current permission.
    """
    def observe(self) -> HttpsObservation: ...
    def readiness(self, actor: SettingsActor, draft: Mapping[str, Any]) -> HttpsReadiness: ...
    def arm_rollback(self, operation_id: str, previous: HttpsObservation) -> bool: ...
    def apply(self, operation_id: str, configuration: Mapping[str, Any], regenerate: bool) -> None: ...
    def rollback(self, operation_id: str) -> bool: ...
    def confirm(self, operation_id: str) -> bool: ...


class HttpsStore(Protocol):
    """Bind existing native storage and current authorization transaction.

    All configuration changes invalidate revision. claim consumes the exact
    actor/revision/intent/expiry-bound preview under an exclusive durable lease.
    mark_applied writes verified configuration and audit atomically, retaining
    ownership. release follows verified timer cancellation; failures keep the
    claim unless BOTH state restoration and recovery-timer cleanup are proven.
    Unknown/crashed operations never silently expire into reusable authority.
    """
    def read(self) -> HttpsSnapshot: ...
    def register_preview(self, preview: HttpsPreview) -> None: ...
    def preview_for(self, actor: str, draft: Mapping[str, Any], now: float) -> HttpsPreview: ...
    def claim(self, preview: HttpsPreview, previous: HttpsObservation, now: float) -> HttpsApplyClaim: ...
    def mark_applied(self, claim: HttpsApplyClaim, observation: HttpsObservation, event: Mapping[str, Any]) -> HttpsSnapshot: ...
    def release(self, claim: HttpsApplyClaim) -> None: ...
    def fail(self, claim: HttpsApplyClaim, event: Mapping[str, Any], recovered: bool) -> None: ...


class MemoryHttpsStore:
    """Thread-safe synthetic store; no host or certificate material is stored."""
    def __init__(self, configuration: Mapping[str, Any]) -> None:
        self._configuration = _configuration(configuration); self._version = 1; self._lock = RLock()
        self._previews: dict[str, HttpsPreview] = {}; self._claim: HttpsApplyClaim | None = None
        self._audit: list[dict[str, Any]] = []

    def read(self) -> HttpsSnapshot:
        with self._lock:
            return HttpsSnapshot('https-' + str(self._version), deepcopy(self._configuration), self._claim is not None)

    def _available(self, revision: str) -> None:
        if self.read().revision != revision or self._claim is not None:
            raise SettingsRevisionConflict('HTTPS changed or another operation owns its native lease.')

    def register_preview(self, preview: HttpsPreview) -> None:
        with self._lock:
            self._available(preview.draft['expectedRevision'])
            self._previews = {k: v for k, v in self._previews.items() if v.expires_at > preview.created_at}
            if len(self._previews) >= 1024:
                raise SettingsValidationError('HTTPS preview capacity exceeded.')
            self._previews[preview.reference] = deepcopy(preview)

    def preview_for(self, actor: str, draft: Mapping[str, Any], now: float) -> HttpsPreview:
        with self._lock:
            self._available(draft['expectedRevision'])
            for p in reversed(tuple(self._previews.values())):
                if p.actor == actor and p.draft == draft and p.safe and p.created_at <= now < p.expires_at:
                    return deepcopy(p)
            raise SettingsValidationError('A current matching native HTTPS preview is required.')

    def claim(self, preview: HttpsPreview, previous: HttpsObservation, now: float) -> HttpsApplyClaim:
        previous = _observation(previous)
        with self._lock:
            p = self.preview_for(preview.actor, preview.draft, now)
            if p != preview or _config_of(previous.state) != self._configuration:
                raise SettingsRevisionConflict('HTTPS preview or independently observed state changed.')
            self._claim = HttpsApplyClaim('https-apply-' + uuid4().hex, deepcopy(p), previous)
            self._previews.clear()
            return deepcopy(self._claim)

    def _owned(self, claim: HttpsApplyClaim) -> None:
        if self._claim != claim:
            raise SettingsRevisionConflict('Native HTTPS operation is no longer owned.')

    def mark_applied(self, claim: HttpsApplyClaim, observation: HttpsObservation, event: Mapping[str, Any]) -> HttpsSnapshot:
        observed = _observation(observation); next_configuration = _config_of(observed.state)
        copied = deepcopy(dict(event)); _ref(copied.get('id'))
        with self._lock:
            self._owned(claim)
            if next_configuration != _config_of(claim.preview.draft):
                raise HttpsApplyUnverified('Native HTTPS observation differs from the reviewed configuration.')
            self._configuration = next_configuration; self._version += 1; self._audit.append(copied)
            return self.read()

    def release(self, claim: HttpsApplyClaim) -> None:
        with self._lock:
            self._owned(claim); self._claim = None

    def fail(self, claim: HttpsApplyClaim, event: Mapping[str, Any], recovered: bool) -> None:
        copied = deepcopy(dict(event)); _ref(copied.get('id'))
        if type(recovered) is not bool:
            raise SettingsValidationError('Recovery proof must be Boolean.')
        with self._lock:
            self._owned(claim)
            if recovered:
                self._configuration = _config_of(claim.previous.state); self._claim = None
            self._audit.append(copied); self._version += 1

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class HttpsSettingsService:
    def __init__(self, store: HttpsStore, driver: HttpsHostDriver, *,
                 authorize: Callable[[SettingsActor, str], bool], clock: Callable[[], float] = time.time) -> None:
        if not callable(authorize):
            raise SettingsValidationError('Current native HTTPS authority is required.')
        self.store = store; self.driver = driver; self.authorize = authorize; self.clock = clock

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = isinstance(actor, SettingsActor) and permission in actor.capabilities and self.authorize(actor, permission) is True
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError('Native actor does not currently authorize this HTTPS operation.')

    def _snapshot(self, actor: SettingsActor, expected: str | None = None, *, allow_claim: bool = False) -> HttpsSnapshot:
        self._require(actor, 'tls.read'); s = self.store.read()
        if not isinstance(s, HttpsSnapshot) or type(s.applying) is not bool:
            raise SettingsValidationError('Invalid native HTTPS snapshot.')
        _ref(s.revision); _configuration(s.configuration)
        if (expected is not None and s.revision != _ref(expected)) or (s.applying and not allow_claim):
            raise SettingsRevisionConflict('HTTPS changed or an operation requires reconciliation.')
        return HttpsSnapshot(s.revision, _configuration(s.configuration), s.applying)

    def _baseline(self, snapshot: HttpsSnapshot) -> HttpsObservation:
        o = _observation(self.driver.observe())
        if _config_of(o.state) != snapshot.configuration:
            raise SettingsRevisionConflict('Stored HTTPS and observed native state differ. Reconcile first.')
        return o

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        snapshot = self._snapshot(actor); observed = self._baseline(snapshot); self._require(actor, 'tls.read')
        return {'effective': observed.state, 'revision': snapshot.revision}

    def _readiness(self, actor: SettingsActor, draft: Mapping[str, Any], *, require_safe: bool = True) -> HttpsReadiness:
        self._require(actor, 'tls.configure')
        r = self.driver.readiness(actor, draft)
        if not isinstance(r, HttpsReadiness):
            raise SettingsValidationError('Invalid native HTTPS readiness.')
        if require_safe and not r.safe:
            raise SettingsPermissionError('Native certificate, recovery, MFA and audit must all be ready.')
        return r

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'tls.configure'); d = _draft(request); s = self._snapshot(actor, d['expectedRevision'])
        self._baseline(s)
        if _config_of(d) == s.configuration and not d['regenerateCertificate']:
            raise SettingsValidationError('No pending HTTPS change remains.')
        r = self._readiness(actor, d, require_safe=False); now = _time(self.clock())
        p = HttpsPreview('https-preview-' + uuid4().hex, actor.subject, d, now, now + 300, r.safe)
        self.store.register_preview(p)
        detail = {'expectedRevision': s.revision, 'safe': r.safe,
                  'blockers': [k for k, v in vars(r).items() if not v],
                  'rollbackAvailable': r.rollback_ready, 'recentMfaVerified': r.recent_mfa_verified}
        if r.recovery_url:
            detail['recoveryUrl'] = r.recovery_url
        return {'supported': True, 'summary': 'Review certificate and listener changes with the verified native recovery route.',
                'effects': ['reconnect_required'], 'detail': detail}

    def _plan(self, p: HttpsPreview, actor: SettingsActor, draft: dict[str, Any]) -> None:
        now = _time(self.clock())
        if (not isinstance(p, HttpsPreview) or p.actor != actor.subject or p.draft != draft or p.safe is not True
                or not _time(p.created_at) <= now < _time(p.expires_at)):
            raise SettingsValidationError('HTTPS preview is no longer current for this actor and exact intent.')

    def _healthy(self, observation: HttpsObservation, draft: dict[str, Any], previous: HttpsObservation) -> None:
        s = observation.state; desired = _config_of(draft)
        if (_config_of(s) != desired or s['httpsListenerActive'] != desired['enabled']
                or not s['httpListenerActive'] or s['redirectEffective'] != desired['redirectHttpToHttps']
                or s['restartRequired'] or s['proxyFallbackToHttp'] or s['proxyStatus'] != 'ok' or s['proxyHealthOk'] is not True):
            raise HttpsApplyUnverified('Independent listener and HTTPS configuration read-back did not match.')
        requires_certificate = desired['enabled'] or draft['regenerateCertificate']
        certificate_changed = any(desired[k] != previous.state[k] for k in ('certificateIpAddresses', 'certificateDnsNames', 'certificateValidDays'))
        if requires_certificate:
            now = _time(self.clock()); expires = _expiry(s['certificateNotAfter'])
            if observation.certificate_ref is None or not now < expires <= now + desired['certificateValidDays'] * 86400 + 300:
                raise HttpsApplyUnverified('Certificate identity or validity was not proven.')
            if (draft['regenerateCertificate'] or certificate_changed) and observation.certificate_ref == previous.certificate_ref:
                raise HttpsApplyUnverified('Certificate regeneration was not independently observed.')
        if desired['enabled'] and s['browserHttpsUrl'] is None:
            raise HttpsApplyUnverified('Native HTTPS connection address is unavailable.')

    @staticmethod
    def _event(actor: SettingsActor, action: str, operation: str, timestamp: float) -> dict[str, Any]:
        return {'id': 'https-audit-' + uuid4().hex, 'actor': actor.subject, 'action': action,
                'operation': operation, 'timestamp': timestamp}

    def apply(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'tls.configure'); d = _draft(request); s = self._snapshot(actor, d['expectedRevision'])
        previous = self._baseline(s); p = self.store.preview_for(actor.subject, d, _time(self.clock()))
        self._plan(p, actor, d); self._readiness(actor, d)
        started = _time(self.clock()); claim = self.store.claim(p, previous, started)
        if not isinstance(claim, HttpsApplyClaim) or claim.preview != p or claim.previous != previous:
            raise HttpsApplyUnverified('Native exclusive HTTPS claim was not proven.')
        _ref(claim.reference)
        arm_attempted = False; confirmation_attempted = False
        try:
            arm_attempted = True
            if self.driver.arm_rollback(claim.reference, previous) is not True:
                raise HttpsApplyUnverified('Native recovery timer was not proven armed.')
            self._readiness(actor, d); self._require(actor, 'tls.configure'); self._plan(p, actor, d)
            current = self._snapshot(actor, s.revision, allow_claim=True)
            if not current.applying or current.configuration != s.configuration:
                raise HttpsApplyUnverified('HTTPS ownership or configuration changed before apply.')
            self.driver.apply(claim.reference, _config_of(d), d['regenerateCertificate'])
            observed = _observation(self.driver.observe()); self._healthy(observed, d, previous)
            self._require(actor, 'tls.configure')
            event = self._event(actor, 'tls.apply.verified', claim.reference, started)
            audited = self.store.mark_applied(claim, observed, event)
            if (not isinstance(audited, HttpsSnapshot) or not audited.applying or audited.revision == s.revision
                    or audited.configuration != _config_of(d)):
                raise HttpsApplyUnverified('Verified HTTPS state/audit was not persisted under its native lease.')
            # Treat even a lost confirmation response conservatively; no late rollback.
            confirmation_attempted = True
            if self.driver.confirm(claim.reference) is not True:
                raise HttpsApplyUnverified('Native recovery timer cancellation was not proven.')
            final = self._snapshot(actor, audited.revision, allow_claim=True)
            final_observation = _observation(self.driver.observe()); self._healthy(final_observation, d, previous)
            if not final.applying or final.configuration != _config_of(d) or final_observation.certificate_ref != observed.certificate_ref:
                raise HttpsApplyUnverified('Native HTTPS state changed before ownership release.')
            self.store.release(claim)
            return {'effective': {'effective': final_observation.state, 'revision': final.revision}, 'audit': {'id': event['id']}}
        except Exception:
            recovered = False
            if not confirmation_attempted and arm_attempted:
                try:
                    timer_and_state_restored = self.driver.rollback(claim.reference) is True
                    restored = _observation(self.driver.observe())
                    recovered = timer_and_state_restored and restored == previous
                except Exception:
                    recovered = False
            failure = self._event(actor, 'tls.apply.rolled_back' if recovered else 'tls.apply.unknown', claim.reference, started)
            try:
                self.store.fail(claim, failure, recovered)
            except Exception:
                recovered = False
            raise HttpsApplyUnverified('HTTPS apply was not verified; ' + ('previous state and recovery timer restored.' if recovered else 'native recovery and operation reconciliation are required.')) from None
