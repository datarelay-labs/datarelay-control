import { type ReactNode } from "react";
export type AdministrationHelpSection = {
    title: string;
    body?: string;
    bullets?: readonly string[];
};
export type AdministrationHelpContent = {
    title: string;
    intro: string;
    sections: readonly AdministrationHelpSection[];
};
export type AdministrationPurposeHeaderProps = {
    purpose: string;
    actions?: ReactNode;
    help: AdministrationHelpContent;
};
export declare function AdministrationPurposeHeader({ purpose, actions, help }: AdministrationPurposeHeaderProps): import("react").JSX.Element;
