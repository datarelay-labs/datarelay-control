import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { MANAGEMENT_ACCESS_BLOCKERS } from "@datarelay-labs/system-contracts";
import { ManagementAccessPolicyPanel } from "./management-access-policy-panel.js";
const REV = /^[a-z][a-z0-9_.-]{0,95}$/;
function validCidr(value) {
    if (typeof value !== "string" || value.length < 3 || value.length > 64)
        return false;
    const parts = value.split("/");
    if (parts.length !== 2 || !/^(0|[1-9][0-9]{0,2})$/.test(parts[1]))
        return false;
    const prefix = Number(parts[1]);
    const address = parts[0];
    if (address.includes(":")) {
        if (prefix < 1 || prefix > 128 || !/^[0-9a-fA-F:]+$/.test(address))
            return false;
        const groups = address.split(":");
        if (groups.length > 9 || !groups.every(group => group.length <= 4))
            return false;
        return address.includes("::") || groups.length === 8;
    }
    const octets = address.split(".");
    return prefix >= 1 && prefix <= 32 && octets.length === 4 &&
        octets.every(part => /^(0|[1-9][0-9]{0,2})$/.test(part) && Number(part) <= 255);
}
const cloneSources = (items) => items.map(item => ({ cidr: item.cidr, ...(item.expiresAt == null ? {} : { expiresAt: item.expiresAt }) }));
function objectRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exactKeys(value, permitted) {
    const keys = Object.keys(value);
    return keys.length === permitted.length && keys.every(key => permitted.includes(key));
}
function validRead(value) {
    if (!objectRecord(value) || !exactKeys(value, ["revision", "policy"]))
        return false;
    const state = value;
    if (!REV.test(state.revision ?? "") || !objectRecord(state.policy) ||
        !exactKeys(state.policy, ["ssh", "web"]))
        return false;
    for (const [target, surface] of [["ssh", state.policy.ssh], ["web", state.policy.web]]) {
        if (!objectRecord(surface) || !exactKeys(surface, ["target", "revision", "enabled", "sources"]) ||
            surface.target !== target || surface.revision !== state.revision ||
            typeof surface.enabled !== "boolean" || !Array.isArray(surface.sources) || surface.sources.length > 64)
            return false;
        const seen = new Set();
        for (const source of surface.sources) {
            if (!objectRecord(source) || ![1, 2].includes(Object.keys(source).length) ||
                !Object.keys(source).every(key => ["cidr", "expiresAt"].includes(key)) ||
                typeof source.cidr !== "string" || !validCidr(source.cidr) || seen.has(source.cidr) ||
                (source.expiresAt != null && (typeof source.expiresAt !== "number" ||
                    !Number.isSafeInteger(source.expiresAt) || source.expiresAt <= 0)))
                return false;
            seen.add(source.cidr);
        }
    }
    return true;
}
function sameDraft(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}
const DECISION_REASONS = new Set([
    "ALLOW_DISABLED", "ALLOW_CIDR", "DENY_POLICY_UNAVAILABLE",
    "DENY_UNKNOWN_SOURCE", "DENY_NO_MATCH", "DENY_EXPIRED"
]);
const LIFECYCLE_BLOCKERS = new Set([
    ...MANAGEMENT_ACCESS_BLOCKERS,
    "WEB_ENFORCEMENT_UNAVAILABLE", "ROLLBACK_UNAVAILABLE",
    "RECENT_MFA_REQUIRED", "AUDIT_UNAVAILABLE", "SOURCE_EXPIRES_DURING_RECOVERY"
]);
function validDecision(value, enabled) {
    if (!objectRecord(value) || !exactKeys(value, ["allowed", "reason"]))
        return false;
    const decision = value;
    if (typeof decision.allowed !== "boolean" || typeof decision.reason !== "string" ||
        !DECISION_REASONS.has(decision.reason))
        return false;
    if (decision.allowed)
        return decision.reason === (enabled ? "ALLOW_CIDR" : "ALLOW_DISABLED");
    return enabled && decision.reason.startsWith("DENY_");
}
function validPreviewPolicy(value, revision) {
    if (!objectRecord(value) || !exactKeys(value, ["ssh", "web", "preview"]))
        return false;
    const policy = value;
    if (!validRead({ revision, policy: { ssh: policy.ssh, web: policy.web } }))
        return false;
    const preview = policy.preview;
    if (!objectRecord(preview) || !exactKeys(preview, ["sshRevision", "webRevision", "safe", "blockers",
        "sshDecision", "webDecision", "rollbackSeconds"]))
        return false;
    if (!preview || preview.sshRevision !== revision || preview.webRevision !== revision ||
        typeof preview.safe !== "boolean" || !Array.isArray(preview.blockers) ||
        !Number.isSafeInteger(preview.rollbackSeconds) || preview.rollbackSeconds < 60 ||
        preview.rollbackSeconds > 3600 || !validDecision(preview.sshDecision, policy.ssh.enabled) ||
        !validDecision(preview.webDecision, policy.web.enabled))
        return false;
    const seen = new Set();
    for (const blocker of preview.blockers) {
        if (typeof blocker !== "string" ||
            !MANAGEMENT_ACCESS_BLOCKERS.includes(blocker) || seen.has(blocker))
            return false;
        seen.add(blocker);
    }
    return preview.safe === (preview.blockers.length === 0) &&
        (!preview.safe || (preview.sshDecision.allowed && preview.webDecision.allowed));
}
function sameSurfaceIntent(actual, reviewed) {
    return actual.enabled === reviewed.enabled && JSON.stringify(actual.sources) === JSON.stringify(reviewed.sources);
}
function sameAppliedPolicy(actual, reviewed) {
    return sameSurfaceIntent(actual.ssh, reviewed.ssh) && sameSurfaceIntent(actual.web, reviewed.web);
}
export function ManagementAccessPage({ adapter, canRead = false, canManage = false }) {
    const live = useRef({ adapter, canRead, canManage, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead ||
        live.current.canManage !== canManage) {
        live.current = { adapter, canRead, canManage, epoch: live.current.epoch + 1 };
    }
    const [state, setState] = useState(null);
    const [draft, setDraft] = useState(null);
    const [preview, setPreview] = useState(null);
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false);
    const [uncertain, setUncertain] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const serial = useRef(0);
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead && (!write || live.current.canManage);
    const writable = canRead && canManage && Boolean(state && draft) && !uncertain;
    useEffect(() => {
        void load();
        return () => { serial.current++; live.current.epoch++; };
    }, [adapter, canRead]);
    useEffect(() => {
        if (!canManage) {
            setPreview(null);
            setConfirmed(false);
        }
    }, [adapter, canManage]);
    async function load() {
        if (!canRead) {
            setState(null);
            setDraft(null);
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        setNotice("");
        try {
            const value = await adapter.read();
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validRead(value))
                throw new Error("invalid");
            setState(value);
            setDraft({
                expectedRevision: value.revision,
                rollbackSeconds: 180,
                ssh: { enabled: value.policy.ssh.enabled, sources: cloneSources(value.policy.ssh.sources) },
                web: { enabled: value.policy.web.enabled, sources: cloneSources(value.policy.web.sources) }
            });
            setPreview(null);
            setConfirmed(false);
            setUncertain(false);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setState(null);
                setDraft(null);
                setError("Cannot read a valid current management access policy.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    function changeSurface(target, next) {
        if (!draft)
            return;
        setDraft({ ...draft, [target]: next });
        setPreview(null);
        setConfirmed(false);
        setError("");
        setNotice("");
    }
    function addSource(target) {
        if (!draft || draft[target].sources.length >= 64)
            return;
        changeSurface(target, { ...draft[target], sources: [...draft[target].sources, { cidr: "" }] });
    }
    function updateSource(target, index, value) {
        if (!draft)
            return;
        const sources = draft[target].sources.map((item, i) => i === index ? value : item);
        changeSurface(target, { ...draft[target], sources });
    }
    function removeSource(target, index) {
        if (!draft)
            return;
        changeSurface(target, { ...draft[target],
            sources: draft[target].sources.filter((_, i) => i !== index) });
    }
    function validDraft(value) {
        if (!REV.test(value.expectedRevision) || !Number.isInteger(value.rollbackSeconds) ||
            value.rollbackSeconds < 60 || value.rollbackSeconds > 3600)
            return false;
        for (const target of ["ssh", "web"]) {
            const surface = value[target];
            if (surface.sources.length > 64 || (surface.enabled && surface.sources.length === 0))
                return false;
            const seen = new Set();
            for (const source of surface.sources) {
                if (!validCidr(source.cidr) || seen.has(source.cidr) ||
                    (source.expiresAt != null && (!Number.isSafeInteger(source.expiresAt) ||
                        source.expiresAt <= Math.floor(Date.now() / 1000))))
                    return false;
                seen.add(source.cidr);
            }
        }
        return true;
    }
    async function prepare() {
        if (!writable || !draft || busy || !validDraft(draft)) {
            setError("Enter valid, unique CIDRs and a rollback interval of 60–3600 seconds.");
            return;
        }
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        setPreview(null);
        setConfirmed(false);
        try {
            const result = await adapter.preview(draft);
            if (!fresh(epoch, true))
                return;
            if (!result || result.expectedRevision !== draft.expectedRevision ||
                !sameDraft(result.draft, draft) || typeof result.previewRef !== "string" ||
                !REV.test(result.previewRef) || !Number.isFinite(result.expiresAt) ||
                result.expiresAt <= Date.now() || typeof result.allowed !== "boolean" ||
                !Array.isArray(result.blockers) || new Set(result.blockers).size !== result.blockers.length ||
                result.blockers.some(blocker => typeof blocker !== "string" || !LIFECYCLE_BLOCKERS.has(blocker)) ||
                result.allowed !== (result.blockers.length === 0) ||
                !validPreviewPolicy(result.policy, draft.expectedRevision))
                throw new Error("invalid");
            setPreview(result);
            if (!result.allowed || result.blockers.length) {
                setError("Current product safety checks block this management access change.");
            }
        }
        catch {
            if (fresh(epoch, true))
                setError("Cannot obtain a current authorized management access preview.");
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    async function apply() {
        if (!writable || !draft || !preview || !preview.allowed || preview.blockers.length ||
            !confirmed || preview.expiresAt <= Date.now() || !sameDraft(preview.draft, draft))
            return;
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        setUncertain(true);
        try {
            const before = await adapter.read();
            if (!fresh(epoch, true) || !validRead(before) || before.revision !== draft.expectedRevision)
                throw new Error("stale");
            const receipt = await adapter.apply({ draft, previewRef: preview.previewRef, confirm: true });
            if (!fresh(epoch, true))
                return;
            const after = await adapter.read();
            const validReceipt = Boolean(receipt && receipt.applied === true && REV.test(receipt.auditReference) &&
                validRead({ revision: receipt.revision, policy: receipt.policy }));
            if (!validRead(after) || !validReceipt || after.revision === before.revision ||
                after.revision !== receipt.revision || JSON.stringify(after.policy) !== JSON.stringify(receipt.policy) ||
                !sameAppliedPolicy(after.policy, preview.policy))
                throw new Error("unverified");
            setState(after);
            setDraft({
                expectedRevision: after.revision,
                rollbackSeconds: draft.rollbackSeconds,
                ssh: { enabled: after.policy.ssh.enabled, sources: cloneSources(after.policy.ssh.sources) },
                web: { enabled: after.policy.web.enabled, sources: cloneSources(after.policy.web.sources) }
            });
            setPreview(null);
            setConfirmed(false);
            setUncertain(false);
            setNotice("Management access policy applied and verified.");
        }
        catch {
            if (fresh(epoch)) {
                setPreview(null);
                setConfirmed(false);
                setError("Management access outcome is unknown or stale. Refresh and inspect audit/recovery before retrying.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "Management access", children: _jsx("p", { role: "status", children: "Management access is not authorized." }) });
    return _jsxs("section", { className: "dr-admin__acl-management", "aria-label": "Management access", children: [_jsxs("header", { children: [_jsx("h3", { children: "Management Access (ACL)" }), _jsx("p", { children: "Configure Web/API and host SSH source allowlists through the product recovery-safe backend." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh access policy" }), state && draft ? _jsxs(_Fragment, { children: [["web", "ssh"].map(target => _jsxs("fieldset", { disabled: !writable || busy, children: [_jsx("legend", { children: target === "web" ? "Web UI and management API" : "SSH host access" }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: draft[target].enabled, onChange: event => changeSurface(target, { ...draft[target], enabled: event.target.checked }) }), "Enforce source allowlist"] }), draft[target].sources.map((source, index) => _jsxs("div", { children: [_jsxs("label", { children: ["CIDR", _jsx("input", { value: source.cidr, onChange: event => updateSource(target, index, { ...source, cidr: event.target.value }) })] }), _jsxs("label", { children: ["Expiry epoch seconds (optional)", _jsx("input", { inputMode: "numeric", value: source.expiresAt ?? "", onChange: event => {
                                                    const text = event.target.value;
                                                    updateSource(target, index, { cidr: source.cidr,
                                                        ...(text ? { expiresAt: Number(text) } : {}) });
                                                } })] }), _jsx(Button, { type: "button", variant: "secondary", onClick: () => removeSource(target, index), children: "Remove source" })] }, index)), _jsx(Button, { type: "button", variant: "secondary", onClick: () => addSource(target), children: "Add source" })] }, target)), _jsxs("label", { children: ["Rollback seconds", _jsx("input", { type: "number", min: 60, max: 3600, value: draft.rollbackSeconds, disabled: !writable || busy, onChange: event => {
                                    setDraft({ ...draft, rollbackSeconds: Number(event.target.value) });
                                    setPreview(null);
                                    setConfirmed(false);
                                } })] }), !canManage ? _jsx("p", { children: "This management access policy is read-only for the current actor." }) : null, canManage ? _jsx(Button, { disabled: busy || uncertain, onClick: () => void prepare(), children: "Preview access change" }) : null, preview ? _jsxs("section", { "aria-label": "Management access change confirmation", children: [_jsx(ManagementAccessPolicyPanel, { policy: preview.policy, reviewAvailability: "read_only" }), preview.blockers.length ? _jsx("ul", { "aria-label": "Lifecycle blockers", children: preview.blockers.map(blocker => _jsx("li", { children: blocker }, blocker)) }) : null, preview.allowed && preview.blockers.length === 0 ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: event => setConfirmed(event.target.checked) }), "I confirm this reviewed access policy and recovery risk"] }), _jsx(Button, { disabled: busy || uncertain || !confirmed, onClick: () => void apply(), children: "Apply management access policy" })] }) : null] }) : _jsx(ManagementAccessPolicyPanel, { policy: state.policy, reviewAvailability: "read_only" })] }) : busy ? _jsx("p", { role: "status", children: "Loading management access policy\u2026" }) : null] });
}
