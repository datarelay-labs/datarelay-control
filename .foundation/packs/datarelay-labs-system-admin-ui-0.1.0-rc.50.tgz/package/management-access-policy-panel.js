import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { MANAGEMENT_ACCESS_BLOCKERS } from "@datarelay-labs/system-contracts";
const BLOCKER_LABELS = {
    INVALID_ROLLBACK_WINDOW: "Rollback timer must be 60–3600 seconds",
    OFFLINE_RECOVERY_REQUIRED: "Offline recovery console must be confirmed",
    SSH_ENFORCEMENT_UNAVAILABLE: "Host SSH ingress enforcement is unavailable",
    WEB_SELF_LOCKOUT: "Web/API management source would be locked out",
    SSH_SELF_LOCKOUT: "Host SSH management source would be locked out"
};
const REASONS = [
    "ALLOW_DISABLED", "ALLOW_CIDR", "DENY_POLICY_UNAVAILABLE",
    "DENY_UNKNOWN_SOURCE", "DENY_NO_MATCH", "DENY_EXPIRED"
];
const CODE = /^[a-z][a-z0-9_.-]{0,95}$/;
const MAX_TIMESTAMP = 253402300799;
function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function keys(value, permitted) {
    return Object.keys(value).every((key) => permitted.includes(key));
}
/** Conservative display boundary only. Real CIDR parsing and canonicalization
 * is performed by the product using the Foundation Python ACL primitives. */
function displayCidr(value) {
    if (typeof value !== "string" || value.length < 3 || value.length > 64)
        return false;
    const parts = value.split("/");
    if (parts.length !== 2 || !/^(0|[1-9][0-9]{0,2})$/.test(parts[1]))
        return false;
    const prefix = Number(parts[1]);
    const address = parts[0];
    if (address.includes(":")) {
        if (prefix < 1 || prefix > 128 || !/^[0-9a-fA-F:]+$/.test(address))
            return false;
        if (address.split(":").length > 9 ||
            !address.split(":").every((piece) => piece.length <= 4))
            return false;
        return address.includes("::") || address.split(":").length === 8;
    }
    const octets = address.split(".");
    return prefix >= 1 && prefix <= 32 && octets.length === 4 &&
        octets.every((part) => /^(0|[1-9][0-9]{0,2})$/.test(part) && Number(part) <= 255);
}
function validSurface(value, expected) {
    if (!record(value) ||
        !keys(value, ["target", "revision", "enabled", "sources"]) ||
        value.target !== expected ||
        typeof value.revision !== "string" || !CODE.test(value.revision) ||
        typeof value.enabled !== "boolean" ||
        !Array.isArray(value.sources) || value.sources.length > 64 ||
        (value.enabled && value.sources.length === 0))
        return false;
    const cidrs = new Set();
    for (const item of value.sources) {
        if (!record(item) || !keys(item, ["cidr", "expiresAt"]) ||
            !displayCidr(item.cidr) || cidrs.has(item.cidr) ||
            (item.expiresAt !== undefined && item.expiresAt !== null &&
                (typeof item.expiresAt !== "number" ||
                    !Number.isSafeInteger(item.expiresAt) ||
                    item.expiresAt <= 0 || item.expiresAt > MAX_TIMESTAMP)))
            return false;
        cidrs.add(item.cidr);
    }
    return true;
}
function validDecision(value, enabled) {
    if (!record(value) || !keys(value, ["allowed", "reason"]) ||
        typeof value.allowed !== "boolean" || typeof value.reason !== "string" ||
        !REASONS.includes(value.reason))
        return false;
    if (value.allowed)
        return value.reason === (enabled ? "ALLOW_CIDR" : "ALLOW_DISABLED");
    return enabled && value.reason.startsWith("DENY_");
}
function validPolicy(value) {
    if (!record(value) || !keys(value, ["ssh", "web", "preview"]) ||
        !validSurface(value.ssh, "ssh") || !validSurface(value.web, "web"))
        return false;
    if (value.preview !== undefined) {
        const p = value.preview;
        if (!record(p) ||
            !keys(p, ["sshRevision", "webRevision", "safe", "blockers",
                "sshDecision", "webDecision", "rollbackSeconds"]) ||
            typeof p.sshRevision !== "string" || !CODE.test(p.sshRevision) ||
            typeof p.webRevision !== "string" || !CODE.test(p.webRevision) ||
            typeof p.safe !== "boolean" ||
            !Array.isArray(p.blockers) ||
            p.blockers.length > MANAGEMENT_ACCESS_BLOCKERS.length ||
            !Number.isSafeInteger(p.rollbackSeconds) ||
            typeof p.rollbackSeconds !== "number" ||
            p.rollbackSeconds < 0 || p.rollbackSeconds > 86400 ||
            !validDecision(p.sshDecision, value.ssh.enabled) ||
            !validDecision(p.webDecision, value.web.enabled))
            return false;
        const seen = new Set();
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !MANAGEMENT_ACCESS_BLOCKERS.includes(blocker) ||
                seen.has(blocker))
                return false;
            seen.add(blocker);
        }
        if (p.safe !== (p.blockers.length === 0))
            return false;
        if (p.safe && (p.rollbackSeconds < 60 || p.rollbackSeconds > 3600 ||
            !p.sshDecision.allowed ||
            !p.webDecision.allowed))
            return false;
    }
    return true;
}
function displayExpiry(seconds) {
    return seconds == null ? "No expiry supplied" :
        "Expires " + new Date(seconds * 1000).toISOString().slice(0, 10) + " UTC";
}
/** Strictly presentation-only; it neither edits firewall/sshd/proxy rules
 * nor trusts this browser as the current management source or actor. */
export function ManagementAccessPolicyPanel({ policy, reviewAvailability = "unknown", onReviewPolicy, pending = false }) {
    const valid = validPolicy(policy);
    const accepted = valid ? policy : undefined;
    const preview = accepted?.preview;
    const stale = Boolean(preview && (preview.sshRevision !== accepted?.ssh.revision ||
        preview.webRevision !== accepted?.web.revision));
    const mayReview = !stale && preview?.safe === true &&
        reviewAvailability === "supported" && typeof onReviewPolicy === "function";
    if (!policy)
        return _jsx(EmptyState, { title: "Management access policy unavailable", description: "Management access policy unavailable. No privileged policy review is possible." });
    return (_jsxs("section", { className: "dr-admin__acl", "aria-label": "Management access policy", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Management access policy" }), _jsx(StatusBadge, { tone: valid && preview?.safe && !stale ? "info" : "neutral", children: valid && preview?.safe && !stale ? "Product safety preview supplied" :
                            "Safety not established" })] }), !valid ? _jsx("p", { children: "Invalid management access policy projection. No sensitive source rules displayed." }) : null, accepted ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "SSH means the product host, not remote service access. Web covers UI and every management API. A UI preview never enforces an ingress rule." }), _jsx("div", { className: "dr-admin__acl-surfaces", children: [accepted.ssh, accepted.web].map((surface) => (_jsxs("section", { "aria-label": surface.target === "ssh" ? "SSH host access" : "Web UI and management API", className: "dr-admin__acl-surface", children: [_jsxs("div", { className: "dr-admin__acl-heading", children: [_jsx("h3", { children: surface.target === "ssh" ? "SSH host access" : "Web UI and management API" }), _jsx(StatusBadge, { tone: surface.enabled ? "warning" : "neutral", children: surface.enabled ? "Enabled — product enforcement required" :
                                                "Disabled — not enforced" })] }), _jsxs("p", { className: "dr-admin__muted", children: [surface.sources.length, " product-authorized source ranges"] }), surface.sources.length ? (_jsx("ul", { "aria-label": surface.target === "ssh" ? "SSH source allowlist" : "Web/API source allowlist", children: surface.sources.map((s) => (_jsxs("li", { children: [_jsx("code", { children: s.cidr }), _jsx("small", { children: displayExpiry(s.expiresAt) })] }, s.cidr))) })) : _jsx("p", { children: "No source ranges configured." })] }, surface.target))) }), !preview ? _jsx("p", { children: "Safety preview unavailable" }) : null, stale ? _jsx("p", { children: "Safety preview is stale" }) : null, preview && !stale ? (_jsxs(_Fragment, { children: [_jsxs("p", { children: ["Rollback timer: ", preview.rollbackSeconds, " seconds (product-provided)"] }), preview.blockers.length > 0 ? (_jsx("ul", { "aria-label": "Management policy blockers", className: "dr-admin__acl-blockers", children: preview.blockers.map((b) => _jsx("li", { children: BLOCKER_LABELS[b] }, b)) })) : _jsx("p", { className: "dr-admin__muted", children: "Product-supplied advisory safety only; current backend must revalidate management sources and rollback." })] })) : null, mayReview ? _jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewPolicy?.(accepted.ssh.revision, accepted.web.revision), children: "Review access policy" }) : _jsx("p", { className: "dr-admin__muted", children: "Policy review requires current product authorization, non-stale preview and recovery safeguards." })] })) : null] }));
}
