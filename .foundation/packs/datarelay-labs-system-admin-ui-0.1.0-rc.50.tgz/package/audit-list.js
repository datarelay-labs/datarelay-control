import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button, EmptyState, TextField } from "@datarelay-labs/ui";
function loadedOutcomes(events) {
    const found = new Map();
    for (const event of events) {
        const label = event.outcome?.trim();
        if (label && !found.has(label.toLowerCase()))
            found.set(label.toLowerCase(), label);
    }
    return [...found.values()].sort((a, b) => a.localeCompare(b));
}
function loadedActions(events) {
    const found = new Map();
    for (const event of events) {
        const label = event.action?.trim();
        if (label && !found.has(label.toLowerCase()))
            found.set(label.toLowerCase(), label);
    }
    return [...found.values()].sort((a, b) => a.localeCompare(b));
}
function loadedActors(events) {
    const found = new Map();
    for (const event of events) {
        const label = event.actor?.trim();
        if (label && !found.has(label.toLowerCase()))
            found.set(label.toLowerCase(), label);
    }
    return [...found.values()].sort((a, b) => a.localeCompare(b));
}
/** Strict UTC calendar date, independent of the browser's local timezone. */
function utcDay(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value))
        return undefined;
    const ms = Date.parse(value + "T00:00:00.000Z");
    return Number.isFinite(ms) && new Date(ms).toISOString().slice(0, 10) === value
        ? ms : undefined;
}
export function AuditList({ events, filterLoadedAuditEvents = false, filterLoadedAuditOutcomes = false, filterLoadedAuditActions = false, filterLoadedAuditActors = false, filterLoadedAuditTimeRange = false, sortLoadedAuditEvents = false, customizeLoadedAuditColumns = false, resetLoadedAuditFilters = false }) {
    const [query, setQuery] = useState("");
    const [selectedOutcome, setSelectedOutcome] = useState("");
    const [selectedAction, setSelectedAction] = useState("");
    const [selectedActor, setSelectedActor] = useState("");
    const [utcFrom, setUtcFrom] = useState("");
    const [utcThrough, setUtcThrough] = useState("");
    const [selectedSort, setSelectedSort] = useState("");
    const [visibleColumns, setVisibleColumns] = useState({
        actor: true, outcome: true, reference: true
    });
    const labelId = useId().replaceAll(":", "");
    const localSearch = filterLoadedAuditEvents || filterLoadedAuditOutcomes || filterLoadedAuditActions
        || filterLoadedAuditActors;
    const localControls = localSearch || sortLoadedAuditEvents || customizeLoadedAuditColumns || filterLoadedAuditTimeRange;
    const showActor = !customizeLoadedAuditColumns || visibleColumns.actor;
    const showOutcome = !customizeLoadedAuditColumns || visibleColumns.outcome;
    const showReference = !customizeLoadedAuditColumns || visibleColumns.reference;
    const outcomeOptions = filterLoadedAuditOutcomes ? loadedOutcomes(events) : [];
    const activeOutcome = outcomeOptions.some((x) => x.toLowerCase() === selectedOutcome)
        ? selectedOutcome : "";
    const actionOptions = filterLoadedAuditActions ? loadedActions(events) : [];
    const activeAction = actionOptions.some((x) => x.toLowerCase() === selectedAction)
        ? selectedAction : "";
    const actorOptions = filterLoadedAuditActors ? loadedActors(events) : [];
    const activeActor = actorOptions.some((x) => x.toLowerCase() === selectedActor)
        ? selectedActor : "";
    const fromDay = utcFrom ? utcDay(utcFrom) : undefined;
    const throughDay = utcThrough ? utcDay(utcThrough) : undefined;
    const utcRangeActive = filterLoadedAuditTimeRange && Boolean(utcFrom || utcThrough);
    const utcRangeInvalid = utcRangeActive &&
        (Boolean(utcFrom && fromDay === undefined) ||
            Boolean(utcThrough && throughDay === undefined) ||
            (fromDay !== undefined && throughDay !== undefined && fromDay > throughDay));
    const throughExclusive = throughDay === undefined ? undefined : throughDay + 86_400_000;
    const hasActiveLoadedFilters = Boolean(query.trim()
        || (filterLoadedAuditOutcomes && activeOutcome)
        || (filterLoadedAuditActions && activeAction)
        || (filterLoadedAuditActors && activeActor)
        || utcRangeActive);
    useEffect(() => {
        if (selectedOutcome && !outcomeOptions.some((x) => x.toLowerCase() === selectedOutcome)) {
            setSelectedOutcome("");
        }
    }, [events, filterLoadedAuditOutcomes, selectedOutcome]);
    useEffect(() => {
        if (selectedAction && !actionOptions.some((x) => x.toLowerCase() === selectedAction)) {
            setSelectedAction("");
        }
    }, [events, filterLoadedAuditActions, selectedAction]);
    useEffect(() => {
        if (selectedActor && !actorOptions.some((x) => x.toLowerCase() === selectedActor)) {
            setSelectedActor("");
        }
    }, [events, filterLoadedAuditActors, selectedActor]);
    if (events.length === 0) {
        return _jsx(EmptyState, { title: "No audit events", description: "No events match the current product query." });
    }
    const text = localSearch ? query.trim().toLowerCase() : "";
    // Local search must never imply a server-wide audit query, permission or count.
    const visible = events.filter((event) => (!text || [event.timestamp, event.action, event.actor, event.outcome,
        event.summary, event.reference, event.id]
        .some((value) => value?.toLowerCase().includes(text)))
        && (!filterLoadedAuditOutcomes || !activeOutcome ||
            event.outcome?.trim().toLowerCase() === activeOutcome)
        && (!filterLoadedAuditActions || !activeAction ||
            event.action?.trim().toLowerCase() === activeAction)
        && (!filterLoadedAuditActors || !activeActor ||
            event.actor?.trim().toLowerCase() === activeActor)
        && (!utcRangeActive || (!utcRangeInvalid && (() => {
            const time = Date.parse(event.timestamp);
            return Number.isFinite(time) &&
                (fromDay === undefined || time >= fromDay) &&
                (throughExclusive === undefined || time < throughExclusive);
        })())));
    // Both directions reorder the *current supplied page* only. Invalid/missing
    // timestamps remain last, and equal instant values retain the adapter order.
    const ordered = sortLoadedAuditEvents && selectedSort
        ? [...visible].sort((a, b) => {
            const left = Date.parse(a.timestamp);
            const right = Date.parse(b.timestamp);
            const leftValid = Number.isFinite(left);
            const rightValid = Number.isFinite(right);
            if (!leftValid || !rightValid)
                return leftValid === rightValid ? 0 : leftValid ? -1 : 1;
            return selectedSort === "newest" ? right - left : left - right;
        })
        : visible;
    const table = (_jsx("div", { className: "dr-admin__audit-table-wrap", role: "region", "aria-label": "Audit history", tabIndex: 0, children: _jsxs("table", { className: "dr-admin__audit-table", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Time" }), _jsx("th", { children: "Action" }), showActor ? _jsx("th", { children: "Actor" }) : null, showOutcome ? _jsx("th", { children: "Outcome" }) : null, showReference ? _jsx("th", { children: "Reference" }) : null] }) }), _jsx("tbody", { children: ordered.map((event) => (_jsxs("tr", { children: [_jsx("td", { children: event.timestamp }), _jsxs("td", { children: [_jsx("strong", { children: event.action }), event.summary ? _jsx("small", { children: event.summary }) : null] }), showActor ? _jsx("td", { children: event.actor ?? "—" }) : null, showOutcome ? _jsx("td", { children: event.outcome ?? "—" }) : null, showReference ? _jsx("td", { children: event.reference ?? event.id }) : null] }, event.id))) })] }) }));
    if (!localControls)
        return table;
    return (_jsxs("div", { className: "dr-admin__audit-search-layout", children: [localSearch ? (_jsx("div", { role: "search", children: _jsx(TextField, { id: labelId + "-search", type: "search", label: "Find loaded audit events", value: query, maxLength: 120, autoComplete: "off", onChange: (event) => setQuery(event.target.value) }) })) : null, filterLoadedAuditOutcomes ? (_jsxs("div", { className: "dr-admin__audit-outcome", children: [_jsx("label", { htmlFor: labelId + "-outcome", children: "Filter loaded audit outcome" }), _jsxs("select", { id: labelId + "-outcome", value: activeOutcome, onChange: (event) => setSelectedOutcome(event.target.value), children: [_jsx("option", { value: "", children: "All loaded outcomes" }), outcomeOptions.map((value) => _jsx("option", { value: value.toLowerCase(), children: value }, value.toLowerCase()))] })] })) : null, filterLoadedAuditActions ? (_jsxs("div", { className: "dr-admin__audit-action", children: [_jsx("label", { htmlFor: labelId + "-action", children: "Filter loaded audit action" }), _jsxs("select", { id: labelId + "-action", value: activeAction, onChange: (event) => setSelectedAction(event.target.value), children: [_jsx("option", { value: "", children: "All loaded actions" }), actionOptions.map((value) => _jsx("option", { value: value.toLowerCase(), children: value }, value.toLowerCase()))] })] })) : null, filterLoadedAuditActors ? (_jsxs("div", { className: "dr-admin__audit-actor", children: [_jsx("label", { htmlFor: labelId + "-actor", children: "Filter loaded audit actor" }), _jsxs("select", { id: labelId + "-actor", value: activeActor, onChange: (event) => setSelectedActor(event.target.value), children: [_jsx("option", { value: "", children: "All loaded actors" }), actorOptions.map((value) => _jsx("option", { value: value.toLowerCase(), children: value }, value.toLowerCase()))] })] })) : null, filterLoadedAuditTimeRange ? (_jsxs("div", { className: "dr-admin__audit-date-range", role: "group", "aria-label": "Loaded audit UTC date window", children: [_jsx(TextField, { id: labelId + "-utc-from", type: "date", label: "From loaded UTC date", value: utcFrom, onChange: (event) => setUtcFrom(event.target.value) }), _jsx(TextField, { id: labelId + "-utc-through", type: "date", label: "Through loaded UTC date", value: utcThrough, onChange: (event) => setUtcThrough(event.target.value) })] })) : null, utcRangeInvalid ? (_jsx("p", { className: "dr-admin__job-error", role: "alert", children: "Start UTC date must be on or before through UTC date; only valid dates are allowed." })) : null, customizeLoadedAuditColumns ? (_jsxs("fieldset", { className: "dr-admin__audit-columns", children: [_jsx("legend", { children: "Loaded audit columns" }), [
                        { key: "actor", label: "actor" },
                        { key: "outcome", label: "outcome" },
                        { key: "reference", label: "reference" }
                    ].map(({ key, label }) => (_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: visibleColumns[key], onChange: (event) => setVisibleColumns((previous) => ({
                                    ...previous, [key]: event.target.checked
                                })) }), "Show " + label + " column"] }, key)))] })) : null, sortLoadedAuditEvents ? (_jsxs("div", { className: "dr-admin__audit-order", children: [_jsx("label", { htmlFor: labelId + "-order", children: "Order loaded audit events" }), _jsxs("select", { id: labelId + "-order", value: selectedSort, onChange: (event) => setSelectedSort(event.target.value), children: [_jsx("option", { value: "", children: "Adapter order" }), _jsx("option", { value: "newest", children: "Newest loaded first" }), _jsx("option", { value: "oldest", children: "Oldest loaded first" })] })] })) : null, resetLoadedAuditFilters && hasActiveLoadedFilters && localControls ? (_jsx(Button, { type: "button", variant: "secondary", className: "dr-admin__audit-reset", onClick: () => {
                    setQuery("");
                    setSelectedOutcome("");
                    setSelectedAction("");
                    setSelectedActor("");
                    setUtcFrom("");
                    setUtcThrough("");
                    const firstControlId = localSearch ? labelId + "-search" : labelId + "-utc-from";
                    document.getElementById(firstControlId)?.focus();
                }, children: "Clear loaded audit filters" })) : null, _jsxs("p", { className: "dr-admin__muted", role: "status", "aria-live": "polite", children: ["Showing ", ordered.length, " of ", events.length, " loaded audit events. Only events supplied by the product adapter are displayed."] }), ordered.length ? table : (_jsx(EmptyState, { title: "No matching loaded audit events", description: "No matching loaded event; server-wide audit search was not performed." }))] }));
}
