export type ManagedRole = {
    ref: string;
    label: string;
    administrator: boolean;
    capabilities: string[];
};
export type RoleAccountBinding = {
    id: string;
    roleRef: string;
    status: "active" | "disabled";
};
export type RoleDirectory = {
    revision: string;
    currentUserId: string;
    complete: boolean;
    registryCapabilities: string[];
    roles: ManagedRole[];
    accounts: RoleAccountBinding[];
};
export type RoleAssignmentDraft = {
    subjectRef: string;
    toRoleRef: string;
    expectedRevision: string;
};
export type RoleAssignmentPreview = {
    allowed: boolean;
    blockers: string[];
    gained: string[];
    lost: string[];
    draft: RoleAssignmentDraft;
    previewToken: string;
    expiresAt: number;
};
export type RoleAssignmentReceipt = RoleDirectory & {
    auditReference: string;
};
export type RoleManagementAdapter = {
    read: () => Promise<RoleDirectory>;
    previewAssignment: (draft: RoleAssignmentDraft) => Promise<RoleAssignmentPreview>;
    applyAssignment: (request: {
        draft: RoleAssignmentDraft;
        previewToken: string;
        confirm: true;
    }) => Promise<RoleAssignmentReceipt>;
};
export type RoleManagementPageProps = {
    adapter: RoleManagementAdapter;
    canRead?: boolean;
    canManage?: boolean;
};
export declare function validRoleDirectory(value: unknown): value is RoleDirectory;
export declare function RoleManagementPage({ adapter, canRead, canManage }: RoleManagementPageProps): import("react").JSX.Element;
