import type { AuthSessionSummary } from "./types";
export type SessionListProps = {
    sessions: readonly AuthSessionSummary[];
    onRevoke?: (sessionId: string) => void | Promise<void>;
    revokingSessionId?: string;
    /** Opt in to filtering only consumer-authorized, already-loaded sessions. */
    filterLoadedSessions?: boolean;
    /** Opt in to an exact, current-page status facet. Never changes session authority. */
    filterLoadedSessionStates?: boolean;
    /** Opt-in selection only; never performs server revocation or confirmation. */
    selectLoadedSessions?: boolean;
    /** Product-owned review action; the product must authorize/confirm any mutation. */
    onReviewSelectedSessions?: (sessionIds: readonly string[]) => void | Promise<void>;
};
export declare function SessionList({ sessions, onRevoke, revokingSessionId, filterLoadedSessions, filterLoadedSessionStates, selectLoadedSessions, onReviewSelectedSessions }: SessionListProps): import("react").JSX.Element;
