import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { NETWORK_TRUST_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const BLOCKERS = {
    dns_unverified: "DNS resolution not verified",
    ntp_unverified: "Time synchronization not verified",
    proxy_unverified: "Outbound proxy connectivity not verified",
    ca_unverified: "Enterprise CA trust not verified",
    management_lockout: "Management reconnection path not verified",
    rollback_unavailable: "Rollback recovery is not ready",
    permission_denied: "Actor authorization not verified",
    mfa_required: "Recent MFA verification not confirmed",
    audit_unavailable: "Audit persistence not verified",
    stale_revision: "Network change preview is stale"
};
const CELLS = [
    ["DNS resolver mode", "dns", "mode"],
    ["NTP synchronization", "ntp", "mode"],
    ["Outbound proxy", "proxy", "enabled"],
    ["Trusted enterprise CA", "trustedCa", "mode"]
];
function object(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function exact(o, allowed) {
    return Object.keys(o).every((key) => allowed.includes(key));
}
function validConfig(v) {
    if (!object(v) || !exact(v, ["dns", "ntp", "proxy", "trustedCa"]) ||
        !object(v.dns) || !exact(v.dns, ["mode"]) ||
        (v.dns.mode !== "system" && v.dns.mode !== "custom") ||
        !object(v.ntp) || !exact(v.ntp, ["mode"]) ||
        !["system", "external", "disabled"].includes(String(v.ntp.mode)) ||
        !object(v.proxy) || !exact(v.proxy, ["enabled"]) ||
        typeof v.proxy.enabled !== "boolean" ||
        !object(v.trustedCa) || !exact(v.trustedCa, ["mode"]) ||
        !["system", "enterprise"].includes(String(v.trustedCa.mode)))
        return false;
    return true;
}
function valid(v) {
    if (!object(v) || !exact(v, ["revision", "effective", "proposed", "preflight"]) ||
        typeof v.revision !== "string" || !REF.test(v.revision) ||
        !validConfig(v.effective) || (v.proposed !== undefined && !validConfig(v.proposed)))
        return false;
    if (v.preflight !== undefined) {
        const p = v.preflight;
        if (!object(p) || !exact(p, [
            "expectedRevision", "maySubmitToProductAuthority", "blockers", "productApplyRequired",
            "dnsVerified", "ntpVerified", "proxyVerified", "caVerified",
            "managementPathVerified", "rollbackReady", "actorAuthorized",
            "recentMfaVerified", "auditReady"
        ]) || typeof p.expectedRevision !== "string" || !REF.test(p.expectedRevision) ||
            typeof p.maySubmitToProductAuthority !== "boolean" ||
            p.productApplyRequired !== true ||
            !Array.isArray(p.blockers) || p.blockers.length > NETWORK_TRUST_BLOCKERS.length)
            return false;
        const bools = ["dnsVerified", "ntpVerified", "proxyVerified", "caVerified",
            "managementPathVerified", "rollbackReady", "actorAuthorized",
            "recentMfaVerified", "auditReady"];
        if (bools.some((field) => typeof p[field] !== "boolean"))
            return false;
        const seen = new Set();
        for (const b of p.blockers) {
            if (typeof b !== "string" ||
                !NETWORK_TRUST_BLOCKERS.includes(b) ||
                seen.has(b))
                return false;
            seen.add(b);
        }
        if (p.maySubmitToProductAuthority && p.blockers.length > 0)
            return false;
    }
    return true;
}
function equal(a, b) {
    return a.dns.mode === b.dns.mode && a.ntp.mode === b.ntp.mode &&
        a.proxy.enabled === b.proxy.enabled && a.trustedCa.mode === b.trustedCa.mode;
}
function configValue(policy, field) {
    switch (field) {
        case "dns": return policy.dns.mode;
        case "ntp": return policy.ntp.mode;
        case "proxy": return policy.proxy.enabled;
        case "trustedCa": return policy.trustedCa.mode;
    }
}
function label(field, value) {
    if (field === "dns")
        return value === "custom" ? "Product-managed custom" : "System";
    if (field === "ntp")
        return value === "external" ? "External time source" :
            value === "disabled" ? "Disabled" : "System";
    if (field === "proxy")
        return value === true ? "Enabled" : "Disabled";
    return value === "enterprise" ? "Enterprise-trusted" : "System";
}
/** Complement SystemDoctor diagnostic *status* with configuration intent.
 * Never configure resolvers, NTP, Proxy, trust stores or OS/system services. */
export function NetworkTrustReviewPanel({ projection, reviewAvailability = "unknown", onReviewNetworkSettings, pending = false }) {
    const safe = valid(projection);
    const value = safe ? projection : undefined;
    const proposed = value?.proposed;
    const preflight = value?.preflight;
    const changed = Boolean(value && proposed && !equal(value.effective, proposed));
    const disabledNtp = proposed?.ntp.mode === "disabled";
    const stale = Boolean(preflight && preflight.expectedRevision !== value?.revision);
    const verified = Boolean(preflight && preflight.dnsVerified && preflight.ntpVerified &&
        preflight.proxyVerified && preflight.caVerified && preflight.managementPathVerified &&
        preflight.rollbackReady && preflight.actorAuthorized && preflight.recentMfaVerified &&
        preflight.auditReady);
    const eligible = Boolean(changed && !disabledNtp && !stale && verified &&
        preflight?.maySubmitToProductAuthority && preflight.blockers.length === 0);
    const mayReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewNetworkSettings === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Network settings unavailable", description: "Network settings unavailable. No product configuration or change is inferred." });
    return (_jsxs("section", { className: "dr-admin__network-trust", "aria-label": "Network and trust settings review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Network and trust settings" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Network settings: ", eligible ? "review eligible" : safe ? "review unavailable" : "unknown"] })] }), !safe ? _jsx("p", { children: "Invalid network settings evidence. No configuration details displayed." }) : null, value ? (_jsxs(_Fragment, { children: [_jsx("h3", { children: "Product effective configuration" }), _jsx("p", { className: "dr-admin__muted", children: "Product-supplied preflight is advisory and never changes network settings." }), _jsx("div", { className: "dr-admin__network-trust-table", children: _jsxs("table", { "aria-label": "Product network and trust configuration", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsx("tbody", { children: CELLS.map(([title, group]) => (_jsxs("tr", { children: [_jsx("th", { scope: "row", children: title }), _jsx("td", { children: label(group, configValue(value.effective, group)) }), _jsx("td", { children: proposed ? label(group, configValue(proposed, group)) : "Unknown" })] }, title))) })] }) }), !changed ? _jsx("p", { children: "No network settings changes proposed" }) : null, disabledNtp ? _jsx("p", { children: "NTP synchronization must remain enabled for MFA clock integrity" }) : null, !preflight ? _jsx("p", { children: "Product network change preflight unavailable" }) : null, stale ? _jsx("p", { children: "Network change preview is stale" }) : null, preflight ? (_jsxs("div", { className: "dr-admin__network-trust-checks", children: [!preflight.dnsVerified ? _jsx("p", { children: "DNS resolution not verified" }) : null, !preflight.ntpVerified ? _jsx("p", { children: "Time synchronization not verified" }) : null, !preflight.proxyVerified ? _jsx("p", { children: "Outbound proxy connectivity not verified" }) : null, !preflight.caVerified ? _jsx("p", { children: "Enterprise CA trust not verified" }) : null, !preflight.managementPathVerified ? _jsx("p", { children: "Management reconnection path not verified" }) : null, !preflight.rollbackReady ? _jsx("p", { children: "Rollback recovery is not ready" }) : null, !preflight.actorAuthorized ? _jsx("p", { children: "Actor authorization not verified" }) : null, !preflight.recentMfaVerified ? _jsx("p", { children: "Recent MFA verification not confirmed" }) : null, !preflight.auditReady ? _jsx("p", { children: "Audit persistence not verified" }) : null, preflight.blockers.map((b) => _jsx("p", { children: BLOCKERS[b] }, b))] })) : null, mayReview ? _jsx(Button, { variant: "secondary", type: "button", disabled: pending, onClick: () => onReviewNetworkSettings?.(value.revision), children: "Review network settings" }) : _jsx("p", { className: "dr-admin__muted", children: "Product permissions, current revision, diagnostic probes and rollback are prerequisites." })] })) : null] }));
}
