import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { RoleChangeReviewPanel } from "./role-change-review-panel.js";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const txt = (v, max = 256) => typeof v === "string" && v.length > 0 && v.length <= max && !/[\u0000-\u001f\u007f]/.test(v);
export function validRoleDirectory(value) {
    if (!value || typeof value !== "object")
        return false;
    const d = value;
    if (!REF.test(d.revision ?? "") || !REF.test(d.currentUserId ?? "") || typeof d.complete !== "boolean" ||
        !Array.isArray(d.registryCapabilities) || !Array.isArray(d.roles) || !Array.isArray(d.accounts) ||
        d.registryCapabilities.length > 2048 || !d.roles.length || d.roles.length > 256 || d.accounts.length > 10000)
        return false;
    const registry = new Set();
    for (const c of d.registryCapabilities) {
        if (!REF.test(c) || registry.has(c))
            return false;
        registry.add(c);
    }
    const roles = new Set();
    for (const role of d.roles) {
        if (!role || !REF.test(role.ref) || !txt(role.label) || typeof role.administrator !== "boolean" ||
            !Array.isArray(role.capabilities) || roles.has(role.ref))
            return false;
        const seen = new Set();
        for (const c of role.capabilities) {
            if (!registry.has(c) || seen.has(c))
                return false;
            seen.add(c);
        }
        roles.add(role.ref);
    }
    const ids = new Set();
    for (const account of d.accounts) {
        if (!account || !REF.test(account.id) || !roles.has(account.roleRef) ||
            !["active", "disabled"].includes(account.status) || ids.has(account.id))
            return false;
        ids.add(account.id);
    }
    return !d.complete || ids.has(d.currentUserId);
}
const same = (a, b) => a.subjectRef === b.subjectRef &&
    a.toRoleRef === b.toRoleRef && a.expectedRevision === b.expectedRevision;
function validPreview(value, draft) {
    if (!value || typeof value !== "object")
        return false;
    const p = value;
    return typeof p.allowed === "boolean" && Array.isArray(p.blockers) && p.blockers.every(x => txt(x, 128)) &&
        Array.isArray(p.gained) && p.gained.every(x => REF.test(x)) &&
        Array.isArray(p.lost) && p.lost.every(x => REF.test(x)) &&
        Boolean(p.draft) && same(p.draft, draft) && txt(p.previewToken, 4096) &&
        Number.isFinite(p.expiresAt) && p.expiresAt > Date.now();
}
export function RoleManagementPage({ adapter, canRead = false, canManage = false }) {
    const live = useRef({ adapter, canRead, canManage, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead || live.current.canManage !== canManage)
        live.current = { adapter, canRead, canManage, epoch: live.current.epoch + 1 };
    const serial = useRef(0);
    const [data, setData] = useState(null);
    const directory = data?.source === adapter && canRead ? data.value : null;
    const [subjectRef, setSubjectRef] = useState("");
    const [toRoleRef, setToRoleRef] = useState("");
    const [preview, setPreview] = useState(null);
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false);
    const [uncertain, setUncertain] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead &&
        (!write || live.current.canManage);
    const writable = canRead && canManage && directory?.complete === true;
    const clear = () => { setPreview(null); setConfirmed(false); };
    useEffect(() => { if (!canRead || !canManage)
        clear(); }, [adapter, canRead, canManage]);
    useEffect(() => { void load(); return () => { serial.current++; live.current.epoch++; }; }, [adapter, canRead]);
    async function load() {
        if (!canRead) {
            setData(null);
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        try {
            const value = await adapter.read();
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validRoleDirectory(value))
                throw Error("invalid");
            setData({ source: adapter, value });
            setSubjectRef(current => value.accounts.some(a => a.id === current) ? current :
                value.accounts.find(a => a.id !== value.currentUserId)?.id ?? value.accounts[0]?.id ?? "");
            setToRoleRef(current => value.roles.some(role => role.ref === current) ? current : value.roles[0]?.ref ?? "");
            clear();
            setUncertain(false);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setData(null);
                setError("Cannot read a valid current role directory.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    const subject = directory?.accounts.find(account => account.id === subjectRef);
    const currentRole = subject && directory?.roles.find(role => role.ref === subject.roleRef);
    const targetRole = directory?.roles.find(role => role.ref === toRoleRef);
    const noChange = Boolean(currentRole && targetRole && currentRole.ref === targetRole.ref);
    async function prepare() {
        if (!writable || busy || uncertain || !directory || !subject || !targetRole || noChange)
            return;
        const draft = {
            subjectRef: subject.id, toRoleRef: targetRole.ref, expectedRevision: directory.revision
        };
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        clear();
        try {
            const result = await adapter.previewAssignment(draft);
            if (!fresh(epoch, true))
                return;
            if (!validPreview(result, draft))
                throw Error("invalid");
            setPreview(result);
            if (!result.allowed || result.blockers.length)
                setError("Current product safety checks block this role assignment.");
        }
        catch {
            if (fresh(epoch, true))
                setError("Cannot obtain a current authorized role-change preview.");
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    async function apply() {
        if (!writable || busy || uncertain || !directory || !subject || !targetRole || !preview ||
            !preview.allowed || preview.blockers.length || !confirmed || preview.expiresAt <= Date.now())
            return;
        const draft = {
            subjectRef: subject.id, toRoleRef: targetRole.ref, expectedRevision: directory.revision
        };
        if (!same(preview.draft, draft))
            return;
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        setUncertain(true);
        try {
            const before = await adapter.read();
            if (!fresh(epoch, true) || !validRoleDirectory(before) || before.revision !== draft.expectedRevision)
                throw Error("stale");
            const receipt = await adapter.applyAssignment({
                draft, previewToken: preview.previewToken, confirm: true
            });
            if (!fresh(epoch, true))
                return;
            const after = await adapter.read();
            if (!validRoleDirectory(after) || after.revision === before.revision ||
                after.revision !== receipt.revision || !txt(receipt.auditReference))
                throw Error("unverified");
            const changed = after.accounts.find(account => account.id === draft.subjectRef);
            if (!changed || changed.roleRef !== draft.toRoleRef)
                throw Error("unverified");
            setData({ source: adapter, value: after });
            setUncertain(false);
            clear();
            setNotice("Role assignment applied and verified.");
        }
        catch {
            if (fresh(epoch)) {
                clear();
                setError("Role assignment status is unknown or stale. Refresh and inspect audit before retrying.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "Role management", children: _jsx("p", { role: "status", children: "Role management is not authorized." }) });
    const reviewChange = preview && currentRole && targetRole ? {
        currentRoleRef: currentRole.ref, proposedRoleRef: targetRole.ref,
        currentRevision: preview.draft.expectedRevision,
        preview: {
            fromRoleRef: currentRole.ref, toRoleRef: targetRole.ref,
            expectedCurrentRevision: preview.draft.expectedRevision,
            gained: preview.gained, lost: preview.lost,
            blockers: preview.blockers,
            maySubmitToProductAuthority: preview.allowed, productWriteRequired: true
        }
    } : undefined;
    return _jsxs("section", { className: "dr-admin__role-management", "aria-label": "Role management", children: [_jsxs("header", { children: [_jsx("h3", { children: "Roles & Permissions" }), _jsx("p", { children: "Assign current product roles after MFA, last-administrator, approval, rollback and audit checks." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh roles" }), directory ? _jsxs(_Fragment, { children: [_jsxs("p", { children: [directory.roles.length, " roles \u00B7 ", directory.registryCapabilities.length, " registered capabilities"] }), _jsx("ul", { "aria-label": "Product roles", children: directory.roles.map(role => _jsxs("li", { children: [_jsx("strong", { children: role.label }), " ", _jsx("code", { children: role.ref }), role.administrator ? " · Administrator" : "", " \u00B7 ", role.capabilities.length, " capabilities"] }, role.ref)) }), _jsxs("label", { children: ["Account", _jsx("select", { value: subjectRef, disabled: !writable || busy || uncertain, onChange: event => { setSubjectRef(event.target.value); clear(); setError(""); }, children: directory.accounts.map(account => _jsxs("option", { value: account.id, children: [account.id, " \u00B7 ", account.roleRef, " \u00B7 ", account.status] }, account.id)) })] }), _jsxs("label", { children: ["Target role", _jsx("select", { value: toRoleRef, disabled: !writable || busy || uncertain, onChange: event => { setToRoleRef(event.target.value); clear(); setError(""); }, children: directory.roles.map(role => _jsx("option", { value: role.ref, children: role.label }, role.ref)) })] }), !writable ? _jsx("p", { children: "Role assignments are read-only for the current actor." }) : null, noChange ? _jsx("p", { children: "The selected account already has this role." }) : null, writable ? _jsx(Button, { disabled: busy || uncertain || noChange, onClick: () => void prepare(), children: "Preview role change" }) : null, preview && reviewChange ? _jsxs("section", { "aria-label": "Role assignment confirmation", children: [_jsx(RoleChangeReviewPanel, { change: reviewChange, reviewAvailability: "read_only" }), preview.allowed && preview.blockers.length === 0 ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: event => setConfirmed(event.target.checked) }), "I confirm this reviewed role assignment"] }), _jsx(Button, { disabled: busy || uncertain || !confirmed, onClick: () => void apply(), children: "Apply role assignment" })] }) : null] }) : null] }) : busy ? _jsx("p", { role: "status", children: "Loading roles\u2026" }) : null] });
}
