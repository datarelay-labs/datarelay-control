import type { TimezoneAdapter } from "@datarelay-labs/system-contracts";
export type DisplayTimezoneSettingsState = {
    resolvedTimezone: string;
    userTimezone: string | null;
    platformDefaultTimezone: string;
};
export type DisplayTimezoneSettingsDraft = {
    scope: "personal" | "platform";
    timezone: string | null;
    expectedRevision: string;
};
export type DisplayTimezoneSettingsProps = {
    /** Authoritative product adapter; never writes to browser-only fake state. */
    adapter: TimezoneAdapter<DisplayTimezoneSettingsState, DisplayTimezoneSettingsDraft>;
    /** Product-verified actor access, independent of the availability declaration. */
    canEditPersonal?: boolean;
    /** Requires a real product Administrator with platform settings privilege. */
    canEditPlatform?: boolean;
};
/**
 * Shared Control-equivalent timezone form: full IANA selection, two distinct
 * authorization scopes, optimistic-concurrency protection and server read-back.
 * A UI callback never grants privilege; Core must enforce exact revision and RBAC.
 */
export declare function DisplayTimezoneSettings({ adapter, canEditPersonal, canEditPlatform }: DisplayTimezoneSettingsProps): import("react").JSX.Element;
