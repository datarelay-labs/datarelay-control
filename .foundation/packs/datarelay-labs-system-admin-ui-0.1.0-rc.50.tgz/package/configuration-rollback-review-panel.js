import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { CONFIG_ROLLBACK_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const PATH = /^[a-z][a-z0-9_.-]{0,127}$/;
const HIDDEN = /password|passwd|secret|token|apikey|api_key|credential|private|master_key|recovery|key_material/;
const MAX_UNIX_SECONDS = 253402300799;
const MAX_PATHS = 128;
const LABELS = {
    nonhistorical_target: "Target revision is not older",
    wrong_revision: "Current configuration revision is stale",
    no_target: "Product target configuration not found",
    same_revision: "Current and target revisions are the same",
    unsupported: "Product rollback backend unavailable",
    unauthorized: "Actor lacks product rollback permission",
    mfa_required: "Recent privileged MFA required",
    backup_missing: "Verified current backup missing",
    recovery_unavailable: "Verified rollback path unavailable",
    out_of_band_required: "Out-of-band recovery channel missing",
    audit_unavailable: "Audit persistence not verified",
    nonreversible_field: "A changed field is not reversible by this product"
};
const FLAGS = [
    ["currentBackupVerified", "Current backup verification unavailable"],
    ["rollbackPathVerified", "Rollback path is not verified"],
    ["offlineConsoleRecoveryReady", "Out-of-band recovery not ready"],
    ["actorAuthorized", "Actor permission not verified"],
    ["recentMfaVerified", "Recent privileged MFA not verified"],
    ["auditReady", "Rollback audit persistence not ready"]
];
function obj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function exact(v, keys) {
    return Object.keys(v).every((k) => keys.includes(k));
}
function revision(v) {
    return typeof v === "string" && REF.test(v);
}
function time(v) {
    return typeof v === "number" && Number.isSafeInteger(v) && v >= 0 &&
        v <= MAX_UNIX_SECONDS;
}
function safePath(v) {
    return typeof v === "string" && PATH.test(v) &&
        !v.includes("..") && v.split(".").every((s) => s.length && !HIDDEN.test(s));
}
function valid(v) {
    if (!obj(v) || !exact(v, ["current", "target", "preview"]) ||
        !obj(v.current) || !exact(v.current, ["productRef", "revision", "createdAt"]) ||
        !revision(v.current.productRef) || !revision(v.current.revision) ||
        !time(v.current.createdAt) ||
        !obj(v.target) || !exact(v.target, ["productRef", "revision", "createdAt"]) ||
        !revision(v.target.productRef) || !revision(v.target.revision) ||
        !time(v.target.createdAt))
        return false;
    if (v.preview !== undefined) {
        const p = v.preview;
        if (!obj(p) || !exact(p, [
            "productRef", "fromRevision", "targetRevision", "expectedCurrentRevision",
            "changedPaths", "blockers", "maySubmitToProductAuthority",
            "productApplyRequired", ...FLAGS.map(([k]) => k)
        ]) || !revision(p.productRef) || !revision(p.fromRevision) ||
            !revision(p.targetRevision) || !revision(p.expectedCurrentRevision) ||
            !Array.isArray(p.changedPaths) || p.changedPaths.length > MAX_PATHS ||
            !Array.isArray(p.blockers) || p.blockers.length > CONFIG_ROLLBACK_BLOCKERS.length ||
            typeof p.maySubmitToProductAuthority !== "boolean" ||
            p.productApplyRequired !== true ||
            FLAGS.some(([k]) => typeof p[k] !== "boolean"))
            return false;
        const paths = new Set(), blockers = new Set();
        for (const path of p.changedPaths) {
            if (!safePath(path) || paths.has(path))
                return false;
            paths.add(path);
        }
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !CONFIG_ROLLBACK_BLOCKERS.includes(blocker) ||
                blockers.has(blocker))
                return false;
            blockers.add(blocker);
        }
        if (p.maySubmitToProductAuthority && p.blockers.length > 0)
            return false;
    }
    return true;
}
/** Strict preview of allowlisted field paths only. Real product applies under
 * actor authorization, CAS, backup and tested rollback. No secret values. */
export function ConfigurationRollbackReviewPanel({ projection, reviewAvailability = "unknown", onReviewRollback, pending = false }) {
    const isValid = valid(projection), accepted = isValid ? projection : undefined;
    const current = accepted?.current, target = accepted?.target;
    const preview = accepted?.preview;
    const wrongProduct = Boolean(current && target && current.productRef !== target.productRef);
    const sameRevision = Boolean(current && target && current.revision === target.revision);
    const notHistorical = Boolean(current && target && target.createdAt > current.createdAt);
    const stale = Boolean(preview && preview.expectedCurrentRevision !== current?.revision ||
        preview && preview.fromRevision !== current?.revision);
    const targetMismatch = Boolean(preview && preview.targetRevision !== target?.revision);
    const previewProductMismatch = Boolean(preview && preview.productRef !== current?.productRef);
    const hasChange = Boolean(preview && preview.changedPaths.length > 0);
    const verified = Boolean(preview && FLAGS.every(([k]) => preview[k] === true));
    const eligible = Boolean(preview && preview.maySubmitToProductAuthority &&
        preview.blockers.length === 0 && hasChange && verified &&
        !wrongProduct && !sameRevision && !notHistorical &&
        !stale && !targetMismatch && !previewProductMismatch);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewRollback === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Configuration rollback evidence unavailable", description: "No product-config source and target revision evidence is available." });
    return (_jsxs("section", { className: "dr-admin__config-rollback", "aria-label": "Configuration rollback review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Configuration rollback preflight" }), _jsx(StatusBadge, { tone: eligible ? "info" : "neutral", children: eligible ? "Review eligible — product evidence only" : "Review not established" })] }), !isValid ? _jsx("p", { children: "Invalid configuration rollback evidence" }) : null, accepted && current && target ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "Product-supplied advisory preview; no configuration rollback is executed." }), wrongProduct ? _jsx("p", { children: "Cannot rollback between different products" }) : null, sameRevision ? _jsx("p", { children: "Current and target configuration revisions are identical" }) : null, notHistorical ? _jsx("p", { children: "Target revision is not historical" }) : null, !preview ? _jsx("p", { children: "Product rollback preview unavailable" }) : (_jsxs(_Fragment, { children: [_jsxs("p", { children: [preview.changedPaths.length, " product-allowlisted configuration fields"] }), preview.changedPaths.length ? (_jsx("ul", { className: "dr-admin__config-rollback-paths", "aria-label": "Allowlisted configuration changes", children: preview.changedPaths.map((path) => _jsx("li", { children: _jsx("code", { children: path }) }, path)) })) : _jsx("p", { children: "No configuration changes reported" }), _jsxs("div", { className: "dr-admin__config-rollback-blockers", children: [stale ? _jsx("p", { children: "Configuration preview current revision is stale" }) : null, targetMismatch ? _jsx("p", { children: "Configuration preview target revision mismatch" }) : null, previewProductMismatch ? _jsx("p", { children: "Configuration preview product does not match" }) : null, FLAGS.map(([k, text]) => preview[k] ? null : _jsx("p", { children: text }, k)), preview.blockers.map((b) => _jsx("p", { children: LABELS[b] }, b))] })] })), canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewRollback?.(current.revision, target.revision), children: "Review configuration rollback" })) : _jsx("p", { className: "dr-admin__muted", children: "Reversible settings and current product revision, MFA, backup, audit and recovery are required." })] })) : null] }));
}
