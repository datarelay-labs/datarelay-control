import { type AdministrationConsumerEvidence } from "./administration";
import { type AdministrationTaskAuthorityCase } from "./administration-authority";
import { type ConformanceReport } from "./types";
/**
 * Read-only, role-specific coverage proof over TWO independent Testkit contracts.
 * A valid consumer composition alone may omit backend evidence, and a valid
 * backend sample alone may omit a displayed task. Neither may yield PASS here.
 *
 * Callers supply product-owned fixtures at one exact product source HEAD.
 * This function never fetches routes, probes APIs, or changes permissions;
 * an ok result is only fixture consistency, not product User E2E.
 */
export declare function verifyAdministrationAuthorityCoverage(consumer: AdministrationConsumerEvidence, roleId: string, cases: readonly AdministrationTaskAuthorityCase[]): ConformanceReport;
