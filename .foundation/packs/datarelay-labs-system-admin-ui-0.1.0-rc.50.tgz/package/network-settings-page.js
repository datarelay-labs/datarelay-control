import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button } from "@datarelay-labs/ui";
function validPort(value) {
    if (!/^(0|[1-9][0-9]{0,4})$/.test(value.trim()))
        return null;
    const port = Number(value.trim());
    return Number.isInteger(port) && port >= 1 && port <= 65535 ? port : null;
}
export function validateNetworkPorts(httpValue, httpsValue) {
    const httpPort = validPort(httpValue);
    if (!httpPort)
        return "HTTP Port must be a valid TCP port between 1 and 65535.";
    const httpsPort = validPort(httpsValue);
    if (!httpsPort)
        return "HTTPS Port must be a valid TCP port between 1 and 65535.";
    if (httpPort === httpsPort)
        return "HTTP Port and HTTPS Port cannot match.";
    return { httpPort, httpsPort };
}
function readBackValid(value) {
    if (typeof value !== "object" || value === null)
        return false;
    const row = value;
    const s = row.effective;
    if (!s || typeof s !== "object" || typeof s.pendingApply !== "boolean")
        return false;
    return [s.httpPort, s.httpsPort, s.activeHttpPort, s.activeHttpsPort].every((n) => Number.isSafeInteger(n) && n >= 1 && n <= 65535) &&
        s.httpPort !== s.httpsPort && s.activeHttpPort !== s.activeHttpsPort;
}
function safePreview(value, revision) {
    const d = value?.detail;
    return Boolean(value?.supported === true && d && d.safe === true &&
        d.rollbackAvailable === true && Array.isArray(d.blockers) && d.blockers.length === 0 &&
        typeof revision === "string" && d.expectedRevision === revision);
}
/**
 * Reusable Control Save->Apply->Reconnect UI. Never treats an interrupted
 * connection as successful. Client cannot start or control a host service.
 */
export function NetworkSettingsPage({ adapter, canManage = false }) {
    const instance = useId().replaceAll(":", "");
    const [loaded, setLoaded] = useState(null);
    const [http, setHttp] = useState("");
    const [https, setHttps] = useState("");
    const [preview, setPreview] = useState(null);
    const [accepted, setAccepted] = useState(false);
    const [applyAccepted, setApplyAccepted] = useState(false);
    const [savedForApply, setSavedForApply] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const state = loaded?.effective;
    const editor = canManage && typeof adapter.preview === "function" &&
        typeof adapter.saveDesired === "function" && typeof adapter.apply === "function" &&
        typeof loaded?.revision === "string" && Boolean(loaded.revision);
    const parsed = validateNetworkPorts(http, https);
    const dirty = Boolean(state && (http !== String(state.httpPort) || https !== String(state.httpsPort)));
    const reviewReady = editor && dirty && typeof parsed !== "string" &&
        safePreview(preview, loaded?.revision);
    const applyReady = editor && savedForApply && state?.pendingApply === true;
    useEffect(() => {
        let mounted = true;
        setBusy(true);
        void adapter.read().then((result) => {
            if (!mounted)
                return;
            if (!readBackValid(result))
                throw new Error("Invalid network settings returned by product Core.");
            setLoaded(result);
            setHttp(String(result.effective.httpPort));
            setHttps(String(result.effective.httpsPort));
            setError("");
        }).catch((reason) => {
            if (mounted)
                setError(reason instanceof Error ? reason.message : "Network settings unavailable.");
        }).finally(() => { if (mounted)
            setBusy(false); });
        return () => { mounted = false; };
    }, [adapter]);
    function clearReview() {
        setPreview(null);
        setAccepted(false);
        setApplyAccepted(false);
        setSavedForApply(false);
        setError("");
        setNotice("");
    }
    async function reload() {
        if (busy)
            return;
        setBusy(true);
        setError("");
        setNotice("");
        try {
            const result = await adapter.read();
            if (!readBackValid(result))
                throw new Error("Invalid network settings returned by product Core.");
            setLoaded(result);
            setHttp(String(result.effective.httpPort));
            setHttps(String(result.effective.httpsPort));
            setPreview(null);
            setAccepted(false);
            setApplyAccepted(false);
            setSavedForApply(false);
        }
        catch (reason) {
            setError(reason instanceof Error ? reason.message : "Cannot reload network settings.");
        }
        finally {
            setBusy(false);
        }
    }
    async function prepare() {
        if (!editor || !loaded?.revision || !dirty || busy)
            return;
        setPreview(null);
        setAccepted(false);
        setError("");
        setNotice("");
        if (typeof parsed === "string") {
            setError(parsed);
            return;
        }
        setBusy(true);
        try {
            const fresh = await adapter.read();
            if (!readBackValid(fresh) || fresh.revision !== loaded.revision) {
                throw new Error("Network settings changed since you loaded this page. Refresh before saving.");
            }
            const result = await adapter.preview({ ...parsed, expectedRevision: loaded.revision });
            const detail = result.detail;
            if (!detail || !Array.isArray(detail.blockers) || typeof detail.safe !== "boolean" ||
                typeof detail.rollbackAvailable !== "boolean" ||
                detail.expectedRevision !== loaded.revision) {
                throw new Error("Native network recovery preview is missing, unsafe or stale.");
            }
            setPreview(result);
            if (!safePreview(result, loaded.revision)) {
                setError("Native network change is blocked until a safe rollback/recovery path is proven.");
            }
        }
        catch (reason) {
            setError(reason instanceof Error ? reason.message : "Cannot preview network change.");
        }
        finally {
            setBusy(false);
        }
    }
    async function save() {
        if (!reviewReady || !accepted || !loaded?.revision || typeof parsed === "string" || busy)
            return;
        setBusy(true);
        setError("");
        setNotice("");
        const beforeRevision = loaded.revision;
        try {
            const latest = await adapter.read();
            if (!readBackValid(latest) || latest.revision !== beforeRevision) {
                throw new Error("Network settings changed since you previewed. Refresh and review again.");
            }
            await adapter.saveDesired({ ...parsed, expectedRevision: beforeRevision });
            const after = await adapter.read();
            if (!readBackValid(after))
                throw new Error("Invalid network state returned by Core after save.");
            setLoaded(after);
            if (after.revision === beforeRevision || after.effective.httpPort !== parsed.httpPort ||
                after.effective.httpsPort !== parsed.httpsPort || after.effective.pendingApply !== true) {
                throw new Error("Port configuration not confirmed by authoritative read-back.");
            }
            setHttp(String(after.effective.httpPort));
            setHttps(String(after.effective.httpsPort));
            setSavedForApply(true);
            setApplyAccepted(false);
            setNotice("Port configuration saved and verified. Apply is still required.");
        }
        catch (reason) {
            setSavedForApply(false);
            setError(reason instanceof Error ? reason.message : "Network save failed.");
        }
        finally {
            setBusy(false);
        }
    }
    async function apply() {
        if (!applyReady || !applyAccepted || !loaded?.revision || busy)
            return;
        setBusy(true);
        setError("");
        setNotice("");
        const expectedRevision = loaded.revision;
        try {
            const fresh = await adapter.read();
            if (!readBackValid(fresh) || fresh.revision !== expectedRevision ||
                !fresh.effective.pendingApply) {
                throw new Error("Saved network state changed before apply. Refresh and review.");
            }
            await adapter.apply(expectedRevision);
            const after = await adapter.read();
            if (!readBackValid(after))
                throw new Error("Native proxy state cannot be verified.");
            setLoaded(after);
            if (after.revision === expectedRevision || after.effective.pendingApply ||
                after.effective.activeHttpPort !== after.effective.httpPort ||
                after.effective.activeHttpsPort !== after.effective.httpsPort) {
                throw new Error("Proxy apply not confirmed by authoritative read-back.");
            }
            setSavedForApply(false);
            setApplyAccepted(false);
            setPreview(null);
            setAccepted(false);
            setNotice("Reverse proxy applied and verified.");
        }
        catch (reason) {
            // No blind retry: the proxy may have restarted while the request dropped.
            const message = reason instanceof Error ? reason.message : "Network apply state unknown.";
            setError(/failed to fetch|networkerror|connection.*(reset|closed|aborted)/i.test(message)
                ? "Network apply status unknown after connection interruption. Reconnect and refresh before retrying."
                : message);
            setSavedForApply(false);
            setApplyAccepted(false);
        }
        finally {
            setBusy(false);
        }
    }
    return (_jsxs("section", { className: "dr-admin__network", "aria-label": "Network settings", children: [_jsxs("header", { children: [_jsx("h3", { children: "Network / Reverse Proxy Settings" }), _jsx("p", { children: "Review published ports, save desired state, then apply and reconnect. Native Core owns reverse proxy restarts." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, !state && busy ? _jsx("p", { role: "status", children: "Loading network settings\u2026" }) : null, _jsxs("ol", { className: "dr-admin__network-steps", "aria-label": "Save, apply, and reconnect workflow", children: [_jsxs("li", { children: [_jsx("strong", { children: "1. Save ports" }), _jsx("span", { children: "Persist desired ports in product Core" })] }), _jsxs("li", { children: [_jsx("strong", { children: "2. Apply reverse proxy" }), _jsx("span", { children: "Authorized listener/reconnect transition" })] }), _jsxs("li", { children: [_jsx("strong", { children: "3. Reconnect / verify" }), _jsx("span", { children: "Confirm new active listener state" })] })] }), state ? (_jsxs(_Fragment, { children: [_jsxs("dl", { className: "dr-admin__timezone-facts", children: [_jsxs("div", { children: [_jsx("dt", { children: "Saved HTTP port" }), _jsx("dd", { children: state.httpPort })] }), _jsxs("div", { children: [_jsx("dt", { children: "Saved HTTPS port" }), _jsx("dd", { children: state.httpsPort })] }), _jsxs("div", { children: [_jsx("dt", { children: "Active ports" }), _jsxs("dd", { children: [state.activeHttpPort, " / ", state.activeHttpsPort] })] }), _jsxs("div", { children: [_jsx("dt", { children: "Apply required" }), _jsx("dd", { children: state.pendingApply ? "Yes" : "No" })] })] }), _jsxs("div", { className: "dr-admin__network-inputs", children: [_jsx("label", { htmlFor: instance + "-http", children: "HTTP Port" }), _jsx("input", { id: instance + "-http", inputMode: "numeric", value: http, disabled: !editor || busy || savedForApply, onChange: (event) => { clearReview(); setHttp(event.target.value); } }), _jsx("label", { htmlFor: instance + "-https", children: "HTTPS Port" }), _jsx("input", { id: instance + "-https", inputMode: "numeric", value: https, disabled: !editor || busy || savedForApply, onChange: (event) => { clearReview(); setHttps(event.target.value); } })] }), editor && dirty ? _jsx(Button, { type: "button", disabled: busy, onClick: () => void prepare(), children: "Preview port change" }) : null, preview ? (_jsxs("section", { className: "dr-admin__network-review", "aria-label": "Network change safety review", children: [_jsx("h4", { children: "Review network change" }), preview.summary ? _jsx("p", { children: preview.summary }) : null, preview.detail?.blockers?.length ? _jsx("ul", { children: preview.detail.blockers.map((reason) => _jsx("li", { children: reason }, reason)) }) : null, preview.detail?.httpUrl ? _jsxs("p", { children: ["Reconnect HTTP: ", preview.detail.httpUrl] }) : null, preview.detail?.httpsUrl ? _jsxs("p", { children: ["Reconnect HTTPS: ", preview.detail.httpsUrl] }) : null, reviewReady ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: accepted, disabled: busy, onChange: (event) => setAccepted(event.target.checked) }), "I understand the network change and recovery plan"] }), _jsx(Button, { disabled: !accepted || busy, onClick: () => void save(), children: "Save port configuration" })] }) : null] })) : null, applyReady ? (_jsxs("section", { className: "dr-admin__network-review", "aria-label": "Apply pending network change", children: [_jsx("h4", { children: "Apply saved ports" }), _jsx("p", { children: "The current browser connection may be interrupted. This operation will not be treated as successful without Core read-back." }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: applyAccepted, disabled: busy, onChange: (event) => setApplyAccepted(event.target.checked) }), "I confirm apply may interrupt this browser connection"] }), _jsx(Button, { disabled: !applyAccepted || busy, onClick: () => void apply(), children: "Apply reverse proxy" })] })) : null, !editor ? _jsx("p", { className: "dr-admin__muted", children: "Administrator permission and a safe product apply adapter are required to change published ports." }) : null, _jsx(Button, { variant: "secondary", type: "button", disabled: busy, onClick: () => void reload(), children: "Refresh settings" })] })) : !busy ? _jsx(Button, { onClick: () => void reload(), children: "Retry loading" }) : null] }));
}
