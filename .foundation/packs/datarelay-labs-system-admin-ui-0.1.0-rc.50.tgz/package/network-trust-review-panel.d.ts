import { type CapabilityAvailability, type NetworkTrustReviewProjection } from "@datarelay-labs/system-contracts";
export type NetworkTrustReviewPanelProps = {
    /** Sanitized product-effective/proposed configuration modes only. */
    projection?: NetworkTrustReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Product review only. No DNS/NTP/Proxy/CA write or raw transport access. */
    onReviewNetworkSettings?: (currentRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Complement SystemDoctor diagnostic *status* with configuration intent.
 * Never configure resolvers, NTP, Proxy, trust stores or OS/system services. */
export declare function NetworkTrustReviewPanel({ projection, reviewAvailability, onReviewNetworkSettings, pending }: NetworkTrustReviewPanelProps): import("react").JSX.Element;
