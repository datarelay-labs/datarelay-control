import { type ReactNode } from "react";
import type { AccountProjection } from "@datarelay-labs/system-contracts";
export type AccountListProps<RoleValue = string> = {
    accounts: readonly AccountProjection<RoleValue>[];
    actions?: (account: AccountProjection<RoleValue>) => ReactNode;
    /** Opt-in local search of *loaded* product-supplied rows, never a server-wide query. */
    filterLoadedAccounts?: boolean;
    /** Opt-in exact status/role facets derived only from currently loaded rows. Also enables local search. */
    filterLoadedAccountFacets?: boolean;
    /** Opt-in local ordering of visible loaded rows; never requests a server sort. */
    sortLoadedAccounts?: boolean;
    /** Opt-in one-click reset for only the loaded-list search and status/role facets. */
    resetLoadedAccountFilters?: boolean;
    /** Review-only native selection; no product account mutation or permission inferred. */
    selectLoadedAccounts?: boolean;
    /** Product-owned authorization/review action, never invoked by checking a row. */
    onReviewSelectedAccounts?: (ids: readonly string[]) => void;
};
export declare function AccountList<RoleValue = string>({ accounts, actions, filterLoadedAccounts, filterLoadedAccountFacets, sortLoadedAccounts, resetLoadedAccountFilters, selectLoadedAccounts, onReviewSelectedAccounts }: AccountListProps<RoleValue>): import("react").JSX.Element;
