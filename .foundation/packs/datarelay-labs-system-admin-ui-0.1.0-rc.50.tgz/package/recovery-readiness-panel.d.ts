import { type RecoveryBackupProjection } from "@datarelay-labs/system-contracts";
export type RecoveryReadinessPanelProps = {
    /** Read-only product-authorized backup/restore metadata and preflight receipts. */
    backups: readonly RecoveryBackupProjection[];
    /** Default-OFF attention triage over already supplied rows only. */
    triageLoadedBackups?: boolean;
};
/** PF-12: product-neutral information surface only.
 * Never opens archives, performs a restore, grants permission or stores credentials.
 * For actual destructive apply, each product must use its authenticated backend
 * and the separate Foundation MutationReview acknowledgement contract. */
export declare function RecoveryReadinessPanel({ backups, triageLoadedBackups }: RecoveryReadinessPanelProps): import("react").JSX.Element;
