import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, StatusBadge } from "@datarelay-labs/ui";
import { ROLE_CHANGE_BLOCKERS } from "@datarelay-labs/system-contracts";
const REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const MAX_CHANGED_CAPABILITIES = 128;
const BLOCKER_LABELS = {
    no_product_backend: "Product role-management backend unavailable",
    permission_denied: "Actor lacks product role-management permission",
    mfa_required: "Recent MFA verification required",
    stale_role: "Current role revision is stale",
    unknown_capability: "Proposed capability is not in the product registry",
    last_admin_lockout: "Last administrator access must be preserved",
    self_escalation: "Self-escalation is not permitted",
    escalation_approval_required: "Independent privilege escalation approval required",
    audit_unavailable: "Product audit persistence is unavailable",
    rollback_unavailable: "Product role rollback is not ready"
};
function record(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function allowedKeys(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function codes(value, allowed) {
    if (!Array.isArray(value) || value.length > MAX_CHANGED_CAPABILITIES)
        return false;
    const seen = new Set();
    for (const code of value) {
        if (typeof code !== "string" || !REFERENCE.test(code) || seen.has(code) ||
            (allowed && !allowed.includes(code)))
            return false;
        seen.add(code);
    }
    return true;
}
function validChange(value) {
    if (!record(value) ||
        !allowedKeys(value, ["currentRoleRef", "proposedRoleRef", "currentRevision", "preview"]) ||
        typeof value.currentRoleRef !== "string" || !REFERENCE.test(value.currentRoleRef) ||
        typeof value.proposedRoleRef !== "string" || !REFERENCE.test(value.proposedRoleRef) ||
        typeof value.currentRevision !== "string" || !REFERENCE.test(value.currentRevision))
        return false;
    if (value.preview !== undefined) {
        const p = value.preview;
        if (!record(p) ||
            !allowedKeys(p, [
                "fromRoleRef", "toRoleRef", "expectedCurrentRevision", "gained", "lost",
                "blockers", "maySubmitToProductAuthority", "productWriteRequired"
            ]) ||
            typeof p.fromRoleRef !== "string" || !REFERENCE.test(p.fromRoleRef) ||
            typeof p.toRoleRef !== "string" || !REFERENCE.test(p.toRoleRef) ||
            typeof p.expectedCurrentRevision !== "string" || !REFERENCE.test(p.expectedCurrentRevision) ||
            !codes(p.gained) || !codes(p.lost) ||
            !codes(p.blockers, ROLE_CHANGE_BLOCKERS) ||
            p.gained.some((item) => p.lost.includes(item)) ||
            typeof p.maySubmitToProductAuthority !== "boolean" ||
            p.productWriteRequired !== true ||
            (p.maySubmitToProductAuthority && p.blockers.length > 0))
            return false;
    }
    return true;
}
function ready(value) {
    const p = value.preview;
    return p !== undefined &&
        p.fromRoleRef === value.currentRoleRef &&
        p.toRoleRef === value.proposedRoleRef &&
        p.expectedCurrentRevision === value.currentRevision &&
        p.maySubmitToProductAuthority === true && p.blockers.length === 0 &&
        (p.gained.length + p.lost.length > 0);
}
/** Product-neutral role/capability impact preflight. No role store, session
 * mutation, self-escalation, impersonation or permission issuing. */
export function RoleChangeReviewPanel({ change, reviewAvailability = "unknown", onReviewRoleChange, pending = false }) {
    const valid = validChange(change);
    const actual = valid ? change : undefined;
    const preview = actual?.preview;
    const eligible = actual ? ready(actual) : false;
    const verdict = !actual || !preview ? "unknown" : eligible ? "review eligible" : "blocked";
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewRoleChange === "function";
    return (_jsxs("section", { className: "dr-admin__role-review", "aria-label": "Role change review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Role and capability impact" }), _jsxs(StatusBadge, { tone: eligible ? "info" : verdict === "blocked" ? "warning" : "neutral", children: ["Role change: ", verdict] })] }), _jsx("p", { className: "dr-admin__muted", children: "Product-supplied advisory evidence only. The server still authorizes every role change." }), !change ? _jsx("p", { children: "No product role-change preview supplied." }) : null, change && !valid ? _jsx("p", { children: "Invalid or unsupported role-change evidence withheld." }) : null, actual && !preview ? _jsx("p", { children: "No product role-change preview supplied." }) : null, preview ? (_jsxs(_Fragment, { children: [_jsxs("p", { role: "status", "aria-live": "polite", className: "dr-admin__muted", children: [preview.gained.length, " capabilities gained; ", preview.lost.length, " capability lost"] }), !preview.gained.length && !preview.lost.length ?
                        _jsx("p", { children: "No capability changes reported" }) : null, _jsxs("div", { className: "dr-admin__role-lists", children: [_jsxs("div", { children: [_jsx("h3", { children: "Gained capabilities" }), preview.gained.length ? (_jsx("ul", { "aria-label": "Gained capabilities", children: preview.gained.map((code) => _jsx("li", { children: _jsx("code", { children: code }) }, code)) })) : _jsx("p", { children: "None" })] }), _jsxs("div", { children: [_jsx("h3", { children: "Removed capabilities" }), preview.lost.length ? (_jsx("ul", { "aria-label": "Removed capabilities", children: preview.lost.map((code) => _jsx("li", { children: _jsx("code", { children: code }) }, code)) })) : _jsx("p", { children: "None" })] })] }), preview.expectedCurrentRevision !== actual?.currentRevision ?
                        _jsx("p", { children: "Current role revision no longer matches" }) : null, preview.fromRoleRef !== actual?.currentRoleRef ||
                        preview.toRoleRef !== actual?.proposedRoleRef ?
                        _jsx("p", { children: "Role source/target reference mismatch" }) : null, preview.blockers.length ? (_jsx("ul", { className: "dr-admin__role-blockers", "aria-label": "Product role change blockers", children: preview.blockers.map((code) => _jsx("li", { children: BLOCKER_LABELS[code] }, code)) })) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewRoleChange?.(actual.currentRoleRef, actual.proposedRoleRef, actual.currentRevision), children: "Review role change" })) : _jsx("p", { className: "dr-admin__muted", children: "Privilege changes require an authorized product-specific review, MFA and rollback." })] })) : null] }));
}
