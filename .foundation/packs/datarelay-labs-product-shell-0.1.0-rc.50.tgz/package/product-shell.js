import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { DataRelayIcon } from "@datarelay-labs/icons";
function capabilityAvailable(capabilities, required) {
    if (!required)
        return true;
    if (!capabilities)
        return false;
    const value = capabilities[required];
    return value === true || value === "supported" || value === "read_only";
}
function defaultActive(item, currentPath) {
    if (currentPath === item.path)
        return true;
    if (item.path === "/")
        return false;
    const normalized = item.path.endsWith("/") ? item.path.slice(0, -1) : item.path;
    return currentPath.startsWith(normalized + "/");
}
function initials(value) {
    const parts = value
        .trim()
        .split(/[._\-\s]+/)
        .filter(Boolean);
    if (parts.length === 0)
        return "—";
    if (parts.length === 1)
        return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
}
function useControlledBoolean(controlled, defaultValue, onChange) {
    const [internal, setInternal] = useState(defaultValue);
    const value = controlled ?? internal;
    const setValue = (next) => {
        if (controlled === undefined)
            setInternal(next);
        onChange?.(next);
    };
    return [value, setValue];
}
function useMobileViewport() {
    const [mobile, setMobile] = useState(false);
    useEffect(() => {
        if (typeof window === "undefined" || typeof window.matchMedia !== "function")
            return;
        const query = window.matchMedia("(max-width: 767px)");
        const update = () => setMobile(query.matches);
        update();
        query.addEventListener("change", update);
        return () => query.removeEventListener("change", update);
    }, []);
    return mobile;
}
function isParent(item) {
    return "children" in item;
}
function eligibleNavigation(items, capabilities) {
    const visible = [];
    const sections = new Map();
    for (const item of items) {
        if (!capabilityAvailable(capabilities, item.requiredCapability))
            continue;
        if (isParent(item)) {
            const children = item.children.filter((child) => capabilityAvailable(capabilities, child.requiredCapability));
            if (children.length > 0)
                visible.push({ ...item, children });
            continue;
        }
        const section = item.section;
        if (!section) {
            visible.push(item);
            continue;
        }
        if (!capabilityAvailable(capabilities, section.requiredCapability))
            continue;
        const earlier = sections.get(section.id);
        if (earlier) {
            const parent = {
                ...earlier.parent,
                children: [...earlier.parent.children, item]
            };
            visible[earlier.index] = parent;
            sections.set(section.id, { ...earlier, parent });
        }
        else {
            const parent = {
                id: section.id, label: section.label,
                ...(section.icon ? { icon: section.icon } : {}),
                ...(section.defaultExpanded ? { defaultExpanded: true } : {}),
                ...(section.requiredCapability ? {
                    requiredCapability: section.requiredCapability
                } : {}),
                children: [item]
            };
            sections.set(section.id, { index: visible.length, parent });
            visible.push(parent);
        }
    }
    return visible;
}
function groupNavigation(items) {
    const groups = [];
    const byKey = new Map();
    for (const item of items) {
        const key = item.group ? `group:${item.group}` : "ungrouped";
        let group = byKey.get(key);
        if (!group) {
            group = {
                id: key,
                ...(item.group ? { label: item.group } : {}),
                items: []
            };
            byKey.set(key, group);
            groups.push(group);
        }
        group.items.push(item);
    }
    return groups;
}
const ENVIRONMENT_LABELS = {
    production: "Production",
    development: "Development",
    staging: "Staging",
    test: "Test",
    unknown: "Unknown"
};
export function ProductEnvironmentStatus({ environment, compact = false }) {
    // Product input must be explicit; an unexpected runtime value cannot become Production.
    const normalized = Object.hasOwn(ENVIRONMENT_LABELS, environment)
        ? environment
        : "unknown";
    const label = ENVIRONMENT_LABELS[normalized];
    return (_jsxs("div", { className: "dr-shell__environment", "data-environment": normalized, "data-testid": "shell-environment-status", role: "status", "aria-label": `Environment: ${label}`, title: compact ? `Environment: ${label}` : undefined, children: [_jsx("span", { className: "dr-shell__environment-dot", "aria-hidden": "true" }), !compact ? (_jsxs("span", { className: "dr-shell__environment-info", "aria-hidden": "true", children: [_jsx("span", { className: "dr-shell__environment-label", children: "Environment" }), _jsx("strong", { className: "dr-shell__environment-value", children: label })] })) : null] }));
}
export function DataRelayWordmark({ collapsed = false }) {
    if (collapsed) {
        return (_jsxs("span", { className: "dr-shell__mark", "aria-hidden": true, children: [_jsx("span", { children: "D" }), _jsx("span", { children: "R" })] }));
    }
    return (_jsxs("span", { className: "dr-shell__wordmark", "aria-hidden": true, children: [_jsx("span", { children: "Data" }), _jsx("span", { className: "dr-shell__wordmark-relay", children: "Relay" })] }));
}
export function ProductShell({ product, navigation, currentPath, onNavigate, capabilities, isNavigationItemActive = defaultActive, pageTitle, pageSubtitle, headerContext, principal, environment, accountActions, headerActions, quickNavigation = false, quickNavigationShortcut = true, breadcrumbs = false, sidebarTopSlot, sidebarFooterSlot, userActions, children, className, contentId = "dr-main-content", collapsed: controlledCollapsed, defaultCollapsed = false, onCollapsedChange, mobileOpen: controlledMobileOpen, defaultMobileOpen = false, onMobileOpenChange }) {
    const [collapsed, setCollapsed] = useControlledBoolean(controlledCollapsed, defaultCollapsed, onCollapsedChange);
    const [mobileOpen, setMobileOpen] = useControlledBoolean(controlledMobileOpen, defaultMobileOpen, onMobileOpenChange);
    const mobileViewport = useMobileViewport();
    const sidebarRef = useRef(null);
    const menuButtonRef = useRef(null);
    const contentRef = useRef(null);
    const quickTriggerRef = useRef(null);
    const quickSearchRef = useRef(null);
    const focusedQuickResultRef = useRef(null);
    const quickRestoreFocusRef = useRef(null);
    const [quickOpen, setQuickOpen] = useState(false);
    const [quickQuery, setQuickQuery] = useState("");
    const quickPrefix = useId().replaceAll(":", "");
    useEffect(() => {
        if (quickOpen)
            quickSearchRef.current?.focus();
    }, [quickOpen]);
    useEffect(() => {
        if (!quickNavigation || !quickNavigationShortcut)
            return;
        const onShortcut = (event) => {
            if (event.defaultPrevented || event.isComposing || event.altKey || event.shiftKey ||
                (!event.ctrlKey && !event.metaKey) || event.key.toLowerCase() !== "k")
                return;
            event.preventDefault();
            if (quickOpen) {
                quickSearchRef.current?.focus();
                quickSearchRef.current?.select();
            }
            else {
                quickRestoreFocusRef.current =
                    document.activeElement instanceof HTMLElement ? document.activeElement : quickTriggerRef.current;
                setQuickOpen(true);
            }
        };
        document.addEventListener("keydown", onShortcut);
        return () => document.removeEventListener("keydown", onShortcut);
    }, [quickNavigation, quickNavigationShortcut, quickOpen]);
    useEffect(() => {
        if (!quickNavigation || !quickOpen)
            return;
        const dismissOnEscape = (event) => {
            if (event.key !== "Escape" || event.defaultPrevented || event.isComposing)
                return;
            event.preventDefault();
            setQuickOpen(false);
            setQuickQuery("");
            const restoreTarget = quickRestoreFocusRef.current ?? quickTriggerRef.current;
            quickRestoreFocusRef.current = null;
            queueMicrotask(() => restoreTarget?.focus());
        };
        // A nonmodal popover must remain dismissible even after its user moves
        // focus to another header/main action; do not override handled Escape.
        document.addEventListener("keydown", dismissOnEscape);
        return () => document.removeEventListener("keydown", dismissOnEscape);
    }, [quickNavigation, quickOpen]);
    const visibleNavigation = useMemo(() => eligibleNavigation(navigation, capabilities), [capabilities, navigation]);
    const groups = useMemo(() => groupNavigation(visibleNavigation), [visibleNavigation]);
    // Render only the exact current leaf of an already permitted section.
    // Displaying a label cannot authorize a route or a privileged action.
    const breadcrumbTrail = useMemo(() => {
        if (!breadcrumbs)
            return null;
        for (const entry of visibleNavigation) {
            if (!isParent(entry) || entry.disabled)
                continue;
            const child = entry.children.find((item) => !item.disabled && item.path === currentPath);
            if (child)
                return { section: entry.label, leaf: child.label };
        }
        return null;
    }, [breadcrumbs, currentPath, visibleNavigation]);
    const quickPages = useMemo(() => visibleNavigation.flatMap((entry) => {
        if (isParent(entry)) {
            if (entry.disabled)
                return [];
            return entry.children.filter((item) => !item.disabled)
                .map((item) => ({ item, context: entry.label }));
        }
        return entry.disabled ? [] : [{ item: entry, context: entry.group ?? "" }];
    }), [visibleNavigation]);
    const quickTerm = quickQuery.trim().toLowerCase();
    const allMatchingQuickPages = quickPages.filter(({ item, context }) => !quickTerm || [item.label, item.id, context].some(value => value.toLowerCase().includes(quickTerm)));
    const matchingQuickPages = allMatchingQuickPages.slice(0, 30);
    // A consumer may revoke a capability while its result owns keyboard focus.
    // When React removes that button, keep focus in the live search control.
    useEffect(() => {
        const focused = focusedQuickResultRef.current;
        if (quickNavigation && quickOpen && focused && !focused.isConnected) {
            focusedQuickResultRef.current = null;
            quickSearchRef.current?.focus();
        }
    }, [quickNavigation, quickOpen, quickPages]);
    const navPrefix = useId();
    const [expandedParents, setExpandedParents] = useState(() => eligibleNavigation(navigation, capabilities)
        .filter(isParent)
        .filter((item) => item.defaultExpanded || item.children.some((child) => isNavigationItemActive(child, currentPath)))
        .map((item) => item.id));
    // Deep links and back/forward navigation reveal their currently active child.
    // Do not collapse the section just because a sibling was selected.
    useEffect(() => {
        const current = visibleNavigation
            .filter(isParent)
            .filter((item) => item.children.some((child) => isNavigationItemActive(child, currentPath)))
            .map((item) => item.id);
        setExpandedParents((previous) => {
            if (current.every((id) => previous.includes(id)))
                return previous;
            return [...previous, ...current.filter((id) => !previous.includes(id))];
        });
    }, [currentPath, visibleNavigation, isNavigationItemActive]);
    useEffect(() => {
        if (mobileViewport && mobileOpen) {
            sidebarRef.current?.focus();
        }
    }, [mobileOpen, mobileViewport]);
    function closeMobile({ restoreFocus = false } = {}) {
        setMobileOpen(false);
        if (restoreFocus) {
            queueMicrotask(() => menuButtonRef.current?.focus());
        }
    }
    function navigate(item) {
        if (item.disabled)
            return;
        onNavigate(item.path, item);
        if (mobileViewport) {
            setMobileOpen(false);
            queueMicrotask(() => contentRef.current?.focus());
        }
    }
    function openQuickNavigation() {
        if (!quickNavigation)
            return;
        quickRestoreFocusRef.current =
            document.activeElement instanceof HTMLElement ? document.activeElement : quickTriggerRef.current;
        setQuickQuery("");
        setQuickOpen(true);
    }
    function closeQuickNavigation({ restoreFocus = true } = {}) {
        const restoreTarget = quickRestoreFocusRef.current ?? quickTriggerRef.current;
        quickRestoreFocusRef.current = null;
        setQuickOpen(false);
        setQuickQuery("");
        if (restoreFocus)
            queueMicrotask(() => restoreTarget?.focus());
    }
    function selectQuickPage(item) {
        // Results are computed only from the consumer's current capability-projected,
        // non-disabled navigation. The product still owns actual route/API RBAC.
        if (!quickPages.some(({ item: allowed }) => allowed.id === item.id && allowed.path === item.path))
            return;
        closeQuickNavigation({ restoreFocus: false });
        navigate(item);
        if (!mobileViewport)
            queueMicrotask(() => contentRef.current?.focus());
    }
    function onQuickPanelKeyDown(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            closeQuickNavigation();
        }
        else if (event.key === "ArrowDown" && event.target === quickSearchRef.current) {
            const button = event.currentTarget.querySelector(".dr-shell__quick-results button:not([disabled])");
            if (button) {
                event.preventDefault();
                button.focus();
            }
        }
        else if ((event.key === "ArrowUp" || event.key === "ArrowDown") &&
            event.target instanceof HTMLButtonElement) {
            const buttons = Array.from(event.currentTarget.querySelectorAll(".dr-shell__quick-results button:not([disabled])"));
            const current = buttons.indexOf(event.target);
            if (current >= 0) {
                event.preventDefault();
                if (event.key === "ArrowUp" && current === 0) {
                    quickSearchRef.current?.focus();
                }
                else {
                    const next = event.key === "ArrowDown"
                        ? Math.min(current + 1, buttons.length - 1)
                        : current - 1;
                    buttons[next]?.focus();
                }
            }
        }
        else if (event.key === "Enter" && event.target === quickSearchRef.current &&
            matchingQuickPages.length > 0) {
            event.preventDefault();
            selectQuickPage(matchingQuickPages[0].item);
        }
    }
    function selectAccountAction(action) {
        if (action.disabled)
            return;
        action.onSelect();
        if (mobileViewport) {
            setMobileOpen(false);
            queueMicrotask(() => contentRef.current?.focus());
        }
    }
    function onSidebarKeyDown(event) {
        if (event.key !== "Escape")
            return;
        const target = event.target;
        const nested = target instanceof HTMLElement
            ? target.closest("[data-nav-submenu]")
            : null;
        const parentId = nested?.dataset.navSubmenu;
        if (parentId && expandedParents.includes(parentId)) {
            event.preventDefault();
            setExpandedParents((prev) => prev.filter((id) => id !== parentId));
            const button = Array.from(sidebarRef.current?.querySelectorAll("[data-nav-parent-id]") ?? []).find((el) => el.dataset.navParentId === parentId);
            button?.focus();
            return;
        }
        if (mobileViewport && mobileOpen) {
            event.preventDefault();
            closeMobile({ restoreFocus: true });
        }
    }
    function toggleNavigationParent(item) {
        if (item.disabled)
            return;
        if (collapsed && !mobileViewport) {
            setCollapsed(false);
            setExpandedParents((prev) => prev.includes(item.id) ? prev : [...prev, item.id]);
            return;
        }
        setExpandedParents((prev) => prev.includes(item.id)
            ? prev.filter((id) => id !== item.id)
            : [...prev, item.id]);
    }
    const offCanvas = mobileViewport && !mobileOpen;
    const compactNavigation = collapsed && !mobileViewport;
    function navigateHome() {
        onNavigate(product.homePath);
        if (mobileViewport) {
            setMobileOpen(false);
            queueMicrotask(() => contentRef.current?.focus());
        }
    }
    return (_jsxs("div", { className: ["dr-product-shell", className].filter(Boolean).join(" "), "data-sidebar-collapsed": collapsed ? "true" : "false", "data-mobile-open": mobileOpen ? "true" : "false", children: [_jsx("a", { className: "dr-shell__skip-link", href: `#${contentId}`, children: "Skip to content" }), _jsx("button", { type: "button", className: "dr-shell__backdrop", "aria-label": "Close navigation", tabIndex: mobileOpen ? 0 : -1, onClick: () => closeMobile({ restoreFocus: true }) }), _jsxs("aside", { ref: sidebarRef, className: "dr-shell__sidebar", "aria-label": "Primary navigation", tabIndex: -1, "aria-hidden": offCanvas ? true : undefined, ...(offCanvas ? { inert: true } : {}), onKeyDown: onSidebarKeyDown, children: [_jsxs("div", { className: "dr-shell__brand-row", children: [_jsxs("button", { type: "button", className: "dr-shell__brand", "aria-label": `${product.name} home`, onClick: navigateHome, children: [_jsx("span", { className: "dr-shell__brand-mark", children: product.mark ?? _jsx(DataRelayWordmark, { collapsed: true }) }), !compactNavigation ? (_jsxs("span", { className: "dr-shell__brand-copy", children: [_jsx(DataRelayWordmark, {}), _jsx("span", { className: "dr-shell__product-name", children: product.name }), product.subtitle ? (_jsx("span", { className: "dr-shell__product-subtitle", children: product.subtitle })) : null] })) : null] }), _jsx("button", { type: "button", className: "dr-shell__collapse-button", "aria-label": collapsed ? "Expand navigation" : "Collapse navigation", "aria-expanded": !collapsed, onClick: () => setCollapsed(!collapsed), children: _jsx(DataRelayIcon, { name: collapsed ? "panelOpen" : "panelClose", width: 17, height: 17 }) })] }), sidebarTopSlot ? (_jsx("div", { className: "dr-shell__sidebar-top-slot", children: sidebarTopSlot })) : null, _jsx("nav", { className: "dr-shell__nav", "aria-label": "Product", children: groups.map((group) => (_jsxs("div", { className: "dr-shell__nav-group", children: [group.label && !compactNavigation ? (_jsx("div", { className: "dr-shell__nav-group-label", children: group.label })) : group.label ? (_jsx("div", { className: "dr-shell__nav-divider", "aria-hidden": true })) : null, group.items.map((item) => {
                                    if (isParent(item)) {
                                        const children = item.children;
                                        const active = children.some((child) => isNavigationItemActive(child, currentPath));
                                        const expanded = expandedParents.includes(item.id) && !compactNavigation;
                                        const controls = navPrefix + "-" + item.id;
                                        return (_jsxs("div", { className: "dr-shell__nav-section", children: [_jsxs("button", { type: "button", className: "dr-shell__nav-item dr-shell__nav-parent", "data-nav-parent-id": item.id, "data-active": active ? "true" : "false", "aria-expanded": expanded, "aria-controls": controls, "aria-label": compactNavigation ? item.label : undefined, title: compactNavigation ? item.label : undefined, disabled: item.disabled, onClick: () => toggleNavigationParent(item), children: [item.icon ? (_jsx(DataRelayIcon, { name: item.icon, className: "dr-shell__nav-icon", width: 17, height: 17 })) : (_jsx("span", { className: "dr-shell__nav-icon-placeholder", "aria-hidden": true })), !compactNavigation ? (_jsx("span", { className: "dr-shell__nav-label", children: item.label })) : null, !compactNavigation ? (_jsx(DataRelayIcon, { name: "chevronDown", className: "dr-shell__nav-parent-chevron", width: 16, height: 16 })) : null] }), _jsx("div", { id: controls, className: "dr-shell__nav-submenu", role: "group", "aria-label": item.label + " pages", "data-nav-submenu": item.id, hidden: !expanded, children: children.map((child) => {
                                                        const childActive = isNavigationItemActive(child, currentPath);
                                                        return (_jsxs("button", { type: "button", className: "dr-shell__nav-item dr-shell__nav-item--child", "data-active": childActive ? "true" : "false", "aria-current": childActive ? "page" : undefined, disabled: child.disabled || item.disabled, onClick: () => navigate(child), children: [child.icon ? (_jsx(DataRelayIcon, { name: child.icon, className: "dr-shell__nav-icon", width: 17, height: 17 })) : null, _jsx("span", { className: "dr-shell__nav-label", children: child.label })] }, child.id));
                                                    }) })] }, item.id));
                                    }
                                    const active = isNavigationItemActive(item, currentPath);
                                    return (_jsxs("button", { type: "button", className: "dr-shell__nav-item", "data-active": active ? "true" : "false", "aria-current": active ? "page" : undefined, "aria-label": compactNavigation ? item.label : undefined, title: compactNavigation ? item.label : undefined, disabled: item.disabled, onClick: () => navigate(item), children: [item.icon ? (_jsx(DataRelayIcon, { name: item.icon, className: "dr-shell__nav-icon", width: 17, height: 17 })) : (_jsx("span", { className: "dr-shell__nav-icon-placeholder", "aria-hidden": true })), !compactNavigation ? (_jsx("span", { className: "dr-shell__nav-label", children: item.label })) : null] }, item.id));
                                })] }, group.id))) }), _jsxs("div", { className: "dr-shell__sidebar-footer", children: [sidebarFooterSlot ? (_jsx("div", { className: "dr-shell__sidebar-footer-slot", children: sidebarFooterSlot })) : null, environment !== undefined ? (_jsx(ProductEnvironmentStatus, { environment: environment, compact: compactNavigation })) : null, principal ? (_jsxs("div", { className: "dr-shell__principal", title: compactNavigation ? principal.displayName : undefined, children: [_jsx("span", { className: "dr-shell__principal-avatar", "aria-hidden": true, children: initials(principal.displayName) }), !compactNavigation ? (_jsxs("span", { className: "dr-shell__principal-copy", children: [_jsx("span", { className: "dr-shell__principal-name", children: principal.displayName }), principal.detail ? (_jsx("span", { className: "dr-shell__principal-detail", children: principal.detail })) : null] })) : null] })) : null, accountActions?.length ? (_jsx("nav", { className: "dr-shell__account-actions", "aria-label": "Account actions", children: accountActions.map((action) => (_jsxs("button", { type: "button", className: "dr-shell__account-action", "data-tone": action.tone ?? "default", title: compactNavigation ? action.label : undefined, "aria-label": action.label, disabled: action.disabled, onClick: () => selectAccountAction(action), children: [_jsx(DataRelayIcon, { name: action.icon, width: 16, height: 16 }), !compactNavigation ? _jsx("span", { children: action.label }) : null] }, action.id))) })) : !compactNavigation && userActions ? (_jsx("div", { className: "dr-shell__user-actions", children: userActions })) : null] })] }), _jsxs("div", { className: "dr-shell__workspace", children: [_jsxs("header", { className: "dr-shell__header", children: [_jsx("button", { ref: menuButtonRef, type: "button", className: "dr-shell__menu-button", "aria-label": "Open navigation", "aria-expanded": mobileOpen, onClick: () => setMobileOpen(true), children: _jsx(DataRelayIcon, { name: "menu", width: 18, height: 18 }) }), _jsxs("div", { className: "dr-shell__page-heading", children: [_jsx("h1", { children: pageTitle }), pageSubtitle ? _jsx("p", { children: pageSubtitle }) : null] }), headerContext ? _jsx("div", { className: "dr-shell__header-context", children: headerContext }) : null, quickNavigation ? (_jsxs("div", { className: "dr-shell__quick-nav", children: [_jsxs("button", { ref: quickTriggerRef, type: "button", className: "dr-shell__quick-trigger", "aria-label": "Search product navigation", "aria-expanded": quickOpen, "aria-controls": quickOpen ? quickPrefix + "-quick-panel" : undefined, onClick: () => quickOpen ? closeQuickNavigation() : openQuickNavigation(), children: ["Find pages ", quickNavigationShortcut ? _jsx("kbd", { children: "Ctrl/\u2318 K" }) : null] }), quickOpen ? (_jsxs("div", { id: quickPrefix + "-quick-panel", className: "dr-shell__quick-panel", role: "search", "aria-label": "Product navigation search", onKeyDown: onQuickPanelKeyDown, children: [_jsx("label", { htmlFor: quickPrefix + "-quick-input", children: "Search pages" }), _jsx("input", { ref: quickSearchRef, id: quickPrefix + "-quick-input", type: "search", maxLength: 120, autoComplete: "off", value: quickQuery, onChange: (event) => setQuickQuery(event.target.value) }), _jsx("p", { className: "dr-shell__quick-count", role: "status", "aria-live": "polite", children: matchingQuickPages.length === 0
                                                    ? "No matching pages"
                                                    : allMatchingQuickPages.length > matchingQuickPages.length
                                                        ? `Showing first ${matchingQuickPages.length} of ${allMatchingQuickPages.length} matching pages`
                                                        : matchingQuickPages.length + (matchingQuickPages.length === 1 ? " page" : " pages") }), matchingQuickPages.length > 0 ? (_jsx("ul", { className: "dr-shell__quick-results", "aria-label": "Matching pages", children: matchingQuickPages.map(({ item, context }) => (_jsx("li", { children: _jsxs("button", { type: "button", "aria-label": item.label, "aria-current": isNavigationItemActive(item, currentPath) ? "page" : undefined, onClick: () => selectQuickPage(item), onFocus: (event) => { focusedQuickResultRef.current = event.currentTarget; }, onBlur: (event) => {
                                                            if (focusedQuickResultRef.current === event.currentTarget) {
                                                                focusedQuickResultRef.current = null;
                                                            }
                                                        }, children: [_jsx("strong", { children: item.label }), context ? _jsx("span", { children: context }) : null] }) }, item.id))) })) : null] })) : null] })) : null, headerActions ? (_jsx("div", { className: "dr-shell__header-actions", children: headerActions })) : null] }), _jsxs("main", { ref: contentRef, id: contentId, className: "dr-shell__content", tabIndex: -1, children: [breadcrumbTrail ? (_jsx("nav", { className: "dr-shell__breadcrumbs", "aria-label": "Breadcrumb", children: _jsxs("ol", { children: [_jsx("li", { children: breadcrumbTrail.section }), _jsxs("li", { children: [_jsx("span", { className: "dr-shell__breadcrumb-separator", "aria-hidden": "true", children: "\u203A" }), _jsx("span", { "aria-current": "page", children: breadcrumbTrail.leaf })] })] }) })) : null, children] })] })] }));
}
