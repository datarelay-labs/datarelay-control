function method(value, name) {
    return Boolean(value &&
        typeof value === "object" &&
        typeof value[name] === "function");
}
function binding(id, state, metadata) {
    const authority = state === "manage"
        ? { availability: "supported", access: "manage" }
        : state === "view"
            ? { availability: "read_only", access: "view" }
            : { availability: "unavailable", access: "none" };
    const target = state === "none"
        ? {}
        : { target: { kind: "action", actionId: id } };
    return metadata
        ? { ...authority, ...target, ...metadata }
        : { ...authority, ...target };
}
function accessFor(id, pages) {
    switch (id) {
        case "core.https": {
            const page = pages.https;
            if (!page || !method(page.adapter, "read"))
                return "none";
            return page.canManage &&
                method(page.adapter, "preview") &&
                method(page.adapter, "apply")
                ? "manage"
                : "view";
        }
        case "core.users": {
            const page = pages.userManagement;
            if (page) {
                if (!page.canRead || !method(page.adapter, "read"))
                    return "none";
                return page.canManage &&
                    method(page.adapter, "preview") &&
                    method(page.adapter, "apply")
                    ? "manage"
                    : "view";
            }
            return Array.isArray(pages.users?.accounts) ? "view" : "none";
        }
        case "core.password": {
            const page = pages.passwordManagement;
            if (!page || !page.canRead || !method(page.adapter, "read"))
                return "none";
            return page.canChange && method(page.adapter, "change") ? "manage" : "view";
        }
        case "core.acl": {
            const page = pages.aclManagement;
            if (page) {
                if (!page.canRead || !method(page.adapter, "read"))
                    return "none";
                return page.canManage &&
                    method(page.adapter, "preview") &&
                    method(page.adapter, "apply")
                    ? "manage"
                    : "view";
            }
            return pages.acl?.policy ? "view" : "none";
        }
        case "core.mfa": {
            const page = pages.mfaManagement;
            if (page) {
                if (!page.canRead || !method(page.adapter, "read"))
                    return "none";
                const mutation = (method(page.adapter, "beginEnrollment") &&
                    method(page.adapter, "confirmEnrollment")) ||
                    method(page.adapter, "regenerateRecoveryCodes") ||
                    method(page.adapter, "disable") ||
                    method(page.adapter, "setRequirement") ||
                    method(page.adapter, "reset");
                return page.canManage && mutation ? "manage" : "view";
            }
            return pages.mfa ? "view" : "none";
        }
        case "core.rbac": {
            const page = pages.roleManagement;
            if (page) {
                if (!page.canRead || !method(page.adapter, "read"))
                    return "none";
                return page.canManage &&
                    method(page.adapter, "previewAssignment") &&
                    method(page.adapter, "applyAssignment")
                    ? "manage"
                    : "view";
            }
            return pages.rbac?.change ? "view" : "none";
        }
        case "core.sessions": {
            const page = pages.sessionManagement;
            if (page) {
                if (!page.canRead || !method(page.adapter, "read"))
                    return "none";
                return page.canRevoke && method(page.adapter, "revoke")
                    ? "manage"
                    : "view";
            }
            return Array.isArray(pages.sessions?.sessions) ? "view" : "none";
        }
        case "core.timezone": {
            const page = pages.timezone;
            if (!page || !method(page.adapter, "read"))
                return "none";
            return method(page.adapter, "configure") &&
                (page.canEditPersonal || page.canEditPlatform)
                ? "manage"
                : "view";
        }
        case "core.network": {
            const page = pages.network;
            if (!page || !method(page.adapter, "read"))
                return "none";
            return page.canManage &&
                method(page.adapter, "preview") &&
                method(page.adapter, "saveDesired") &&
                method(page.adapter, "apply")
                ? "manage"
                : "view";
        }
        case "core.retention": {
            const page = pages.retention;
            if (!page || !method(page.adapter, "read"))
                return "none";
            return page.canManage &&
                method(page.adapter, "previewPolicy") &&
                method(page.adapter, "configure") &&
                method(page.adapter, "dryRun") &&
                method(page.adapter, "run")
                ? "manage"
                : "view";
        }
        case "core.backup-import": {
            const page = pages.transfer;
            if (!page)
                return "none";
            const readable = (page.canExport && method(page.adapter, "exportWorkspace")) ||
                (page.canPreview && method(page.adapter, "previewImport"));
            if (!readable)
                return "none";
            return page.canApply &&
                page.canPreview &&
                method(page.adapter, "previewImport") &&
                method(page.adapter, "applyImport") &&
                method(page.adapter, "readImport")
                ? "manage"
                : "view";
        }
        case "core.audit": {
            const page = pages.auditExplorer;
            if (page?.canRead && method(page.adapter, "query"))
                return "view";
            return Array.isArray(pages.audit?.events) ? "view" : "none";
        }
        case "core.health": {
            const page = pages.healthPage;
            if (page) {
                if (!page.canRead || !method(page.adapter, "readSummary"))
                    return "none";
                const alertsManage = Boolean(page.alerts?.canRead &&
                    page.alerts.canManage &&
                    method(page.alerts.adapter, "read") &&
                    method(page.alerts.adapter, "preview") &&
                    method(page.alerts.adapter, "configure"));
                const alertsTest = Boolean(page.alerts?.canRead &&
                    page.alerts.canTest &&
                    method(page.alerts.adapter, "read") &&
                    method(page.alerts.adapter, "test"));
                const supportGenerate = Boolean(page.support?.canGenerate &&
                    method(page.support.adapter, "prepare") &&
                    method(page.support.adapter, "read"));
                const supportDownload = Boolean(page.support?.canDownload &&
                    method(page.support.adapter, "read") &&
                    method(page.support.adapter, "download"));
                return alertsManage || alertsTest || supportGenerate || supportDownload
                    ? "manage"
                    : "view";
            }
            return pages.health?.health || pages.health?.info ? "view" : "none";
        }
    }
}
export function deriveSystemManagementBindings(pages, metadata = {}) {
    const ids = [
        "core.https",
        "core.users",
        "core.password",
        "core.acl",
        "core.mfa",
        "core.rbac",
        "core.sessions",
        "core.timezone",
        "core.network",
        "core.retention",
        "core.backup-import",
        "core.audit",
        "core.health"
    ];
    const bindings = {};
    for (const id of ids) {
        bindings[id] = binding(id, accessFor(id, pages), metadata[id]);
    }
    return bindings;
}
/**
 * Minimal consumer integration: products provide native adapters and their
 * authoritative permission flags once in pages. Foundation derives the
 * matching task bindings so consumers do not duplicate 13 availability/access
 * declarations by hand.
 */
export function createSystemManagementConsumer(config) {
    const { bindingMetadata, ...workspace } = config;
    return {
        ...workspace,
        bindings: deriveSystemManagementBindings(workspace.pages, bindingMetadata)
    };
}
