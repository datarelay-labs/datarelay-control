import type { AuthErrorCategory, LoginSubmission } from "./types";
export type ControlLoginFormProps = {
    onSubmit: (submission: LoginSubmission) => void | Promise<void>;
    busy?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
    infoMessage?: string;
    initialUsername?: string;
    submitLabel?: string;
    allowPasswordReveal?: boolean;
    usernamePlaceholder?: string;
    passwordPlaceholder?: string;
    accountNotice?: string;
};
/**
 * Exact Control credential form presentation. Authentication remains delegated
 * to the consumer through onSubmit; no credential or session storage lives here.
 */
export declare function ControlLoginForm({ onSubmit, busy, errorCategory, errorMessage, infoMessage, initialUsername, submitLabel, allowPasswordReveal, usernamePlaceholder, passwordPlaceholder, accountNotice }: ControlLoginFormProps): import("react").JSX.Element;
