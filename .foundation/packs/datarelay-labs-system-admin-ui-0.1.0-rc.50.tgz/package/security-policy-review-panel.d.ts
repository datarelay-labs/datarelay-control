import { type CapabilityAvailability, type SecurityPolicyReviewProjection } from "@datarelay-labs/system-contracts";
export type SecurityPolicyReviewPanelProps = {
    /** Effective/review values from a real product authority, no account passwords. */
    policy?: SecurityPolicyReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Product-owned confirmation only. Never update auth/session policy here. */
    onReviewPolicy?: (expectedCurrentRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Pure shared policy review UX. Its preview is product-generated, NOT a
 * native Python "change policy" API or real server-side permission check. */
export declare function SecurityPolicyReviewPanel({ policy, reviewAvailability, onReviewPolicy, pending }: SecurityPolicyReviewPanelProps): import("react").JSX.Element;
