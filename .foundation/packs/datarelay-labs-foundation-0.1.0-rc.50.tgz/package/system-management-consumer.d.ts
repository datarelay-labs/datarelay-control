import type { StandardAdministrationTaskBinding, StandardAdministrationTaskBindings, StandardAdministrationTaskId } from "@datarelay-labs/system-admin-ui";
import type { FoundationManagementPages, SystemManagementWorkspaceProps } from "./system-management";
type BindingMetadata = Omit<StandardAdministrationTaskBinding, "availability" | "access">;
export type SystemManagementBindingMetadata = Partial<Record<StandardAdministrationTaskId, BindingMetadata>>;
export type SystemManagementConsumerConfig = Omit<SystemManagementWorkspaceProps, "bindings"> & {
    /**
     * Optional display/audit metadata only. Authority is always derived from the
     * page adapter plus product-supplied canRead/canManage flags and cannot be
     * overridden here.
     */
    bindingMetadata?: SystemManagementBindingMetadata;
};
export declare function deriveSystemManagementBindings(pages: FoundationManagementPages, metadata?: SystemManagementBindingMetadata): StandardAdministrationTaskBindings;
/**
 * Minimal consumer integration: products provide native adapters and their
 * authoritative permission flags once in pages. Foundation derives the
 * matching task bindings so consumers do not duplicate 13 availability/access
 * declarations by hand.
 */
export declare function createSystemManagementConsumer(config: SystemManagementConsumerConfig): SystemManagementWorkspaceProps;
export {};
