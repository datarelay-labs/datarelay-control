export type ConfigurationChangeHistoryField = {
    field: string;
    before?: string;
    after?: string;
    note?: string;
    /** Masked values are never rendered even when a consumer accidentally supplies them. */
    masked?: boolean;
};
export type ConfigurationChangeHistoryEntry = {
    id: string;
    timestamp: string;
    target: string;
    actor?: string;
    outcome?: string;
    auditReference?: string;
    summary?: string;
    changes: readonly ConfigurationChangeHistoryField[];
};
export type ConfigurationChangeHistoryProps = {
    entries: readonly ConfigurationChangeHistoryEntry[];
};
export declare function ConfigurationChangeHistory({ entries }: ConfigurationChangeHistoryProps): import("react").JSX.Element;
