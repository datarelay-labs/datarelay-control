"""Common private support JSON generation, privacy proof and audited byte transfer.

Collection and content-aware redaction/privacy scans remain native typed ports;
there is deliberately no fallback keyword scrubber or arbitrary file collector.
Foundation serializes only the four support categories, binds scans to actual
bytes, retains safe immutable content and rechecks current evidence on download.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import json
import math
import re
import time

CATEGORIES = ('system_diagnostics', 'operation_status', 'configuration_summary', 'audit_metadata')
MAX_BYTES = 50 * 1024 * 1024
_REF = re.compile(r'[a-z][a-z0-9_.-]{0,95}\Z', re.ASCII)
_HASH = re.compile(r'[0-9a-f]{64}\Z', re.ASCII)
from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict


class SupportBundleUnavailable(RuntimeError):
    """Artifact/privacy/audit state was not proven; no bytes may be released."""


def _ref(value: object) -> str:
    if not isinstance(value, str) or not _REF.fullmatch(value):
        raise SettingsValidationError('A current opaque support reference is required.')
    return value


def _hash(value: object) -> str:
    if not isinstance(value, str) or not _HASH.fullmatch(value):
        raise SettingsValidationError('An actual SHA-256 byte digest is required.')
    return value


def _time(value: object) -> int:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402296000:
        raise SettingsValidationError('Invalid native support evidence time.')
    return int(value)


def _json_bytes(sections: object, now: int) -> bytes:
    if (not isinstance(sections, dict) or not sections or not set(sections) <= set(CATEGORIES)
            or any(not isinstance(v, dict) for v in sections.values())):
        raise SettingsValidationError('Only the four bounded support diagnostic categories are permitted.')
    stack = [(sections, 0)]; count = 0
    while stack:
        value, depth = stack.pop(); count += 1
        if count > 100000 or depth > 32:
            raise SettingsValidationError('Native support evidence is too complex.')
        if isinstance(value, (list, dict)):
            if count + len(stack) + len(value) > 100000:
                raise SettingsValidationError('Native support evidence is too complex.')
            if isinstance(value, dict) and any(not isinstance(k, str) or len(k) > 4096 for k in value):
                raise SettingsValidationError('Support evidence must use bounded JSON keys.')
            stack.extend((v, depth + 1) for v in (value.values() if isinstance(value, dict) else value))
        elif type(value) is str:
            if len(value) > MAX_BYTES:
                raise SettingsValidationError('Support evidence exceeds the 50 MiB limit.')
        elif value is None or type(value) is bool:
            pass
        elif type(value) is int:
            if not -(2**53 - 1) <= value <= 2**53 - 1:
                raise SettingsValidationError('Support JSON integers must retain wire precision.')
        elif type(value) is float:
            if not math.isfinite(value):
                raise SettingsValidationError('Support JSON numbers must be finite.')
        else:
            raise SettingsValidationError('Support evidence must contain JSON values only.')
    envelope = {'format': 'datarelay-support-json-v1',
                'generatedAt': datetime.fromtimestamp(now, timezone.utc).isoformat(), 'sections': sections}
    try:
        content = json.dumps(envelope, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(',', ':')).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise SettingsValidationError('Native support evidence is not portable JSON.') from None
    if not 0 < len(content) <= MAX_BYTES:
        raise SettingsValidationError('Support evidence exceeds the 50 MiB limit.')
    return content


@dataclass(frozen=True)
class CollectedSupportEvidence:
    source_revision: str
    sections: dict[str, Any]


@dataclass(frozen=True)
class SupportPrivacyReport:
    sha256: str
    redaction_verified: bool
    credential_scan_passed: bool
    personal_data_scan_passed: bool
    customer_payload_excluded: bool

    def __post_init__(self) -> None:
        _hash(self.sha256)
        if any(type(v) is not bool for k, v in vars(self).items() if k != 'sha256'):
            raise SettingsValidationError('Privacy reports require actual native Boolean evidence.')

    @property
    def safe(self) -> bool:
        return all(v for k, v in vars(self).items() if k != 'sha256')


@dataclass(frozen=True)
class SupportReadiness:
    recent_mfa_verified: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        if type(self.recent_mfa_verified) is not bool or type(self.audit_ready) is not bool:
            raise SettingsValidationError('Native support readiness requires Boolean facts.')


@dataclass(frozen=True)
class SupportArchive:
    reference: str
    revision: str
    owner: str
    created_at: int
    expires_at: int
    categories: tuple[str, ...]
    size_bytes: int
    sha256: str
    report: SupportPrivacyReport
    content: bytes | None
    generation_audit: str


@dataclass(frozen=True)
class SupportDownload:
    content: bytes
    filename: str
    audit_reference: str


class SupportCollector(Protocol):
    """Collect a consistent native scope/permission-bound diagnostic projection.

    Bounded native calls only: never accept a browser-supplied path, query, file
    name or category. Exclude raw customer payloads and use native secret/personal
    data inventories to redact before returning diagnostic JSON. Categories alone
    are not proof of safety; the final exact bytes must also pass native scans.
    """
    def collect(self, actor: SettingsActor) -> CollectedSupportEvidence: ...


class SupportPrivacyScanner(Protocol):
    """Inspect the actual immutable JSON bytes under CURRENT native privacy policy.

    Report the exact SHA-256 scanned. Flags require actual redaction, credential,
    personal-data and customer-payload checks, not a caller hint, cached unrelated
    archive, regex-only guess or a fixture. No fallback scanner is installed.
    """
    def inspect(self, actor: SettingsActor, content: bytes) -> SupportPrivacyReport: ...


class SupportStore(Protocol):
    """Native encrypted/restricted, TTL-bound immutable artifact store plus audit.

    read enforces current native actor/resource scope and ownership. create runs
    guard under the native transaction and commits artifact+audit atomically or
    nothing. Failed privacy artifacts retain metadata only, never unsafe bytes.
    audit_download reads and locks the immutable artifact/revision, runs the
    current-authority/privacy guard and commits its audit before returning any
    content. Download audit records authorization, not proof of a client receiving or saving the file. Never transparently repeat callbacks; never mutate an existing
    artifact in place. Native retention/rate limits apply to actual storage.
    """
    def create(self, actor: SettingsActor, archive: SupportArchive, event: Mapping[str, Any], guard: Callable[[], None]) -> None: ...
    def read(self, actor: SettingsActor, reference: str) -> SupportArchive: ...
    def read_audit(self, reference: str) -> Mapping[str, Any] | None: ...
    def audit_download(self, actor: SettingsActor, reference: str, expected_revision: str,
                       guard: Callable[[SupportArchive], Mapping[str, Any]]) -> tuple[SupportArchive, Mapping[str, Any]]: ...


class MemorySupportStore:
    """Bounded synthetic reference, never an actual host-file archive store."""
    def __init__(self) -> None:
        self._archives: dict[str, SupportArchive] = {}; self._audit = []; self._lock = RLock()

    def create(self, actor: SettingsActor, archive: SupportArchive, event: Mapping[str, Any], guard: Callable[[], None]) -> None:
        with self._lock:
            if archive.reference in self._archives or archive.owner != actor.subject:
                raise SettingsRevisionConflict('Support artifact identity is not available.')
            copied = deepcopy(dict(event)); _ref(copied.get('id'))
            total = sum(len(r.content or b'') for r in self._archives.values()) + len(archive.content or b'')
            if len(self._archives) >= 128 or total > 64 * 1024 * 1024:
                raise SettingsValidationError('Native support artifact capacity exceeded.')
            guard()
            self._archives[archive.reference] = deepcopy(archive); self._audit.append(copied)

    def read(self, actor: SettingsActor, reference: str) -> SupportArchive:
        with self._lock:
            artifact = self._archives.get(reference)
            if artifact is None or artifact.owner != actor.subject:
                raise SettingsPermissionError('This native support artifact is not available to the current actor.')
            return deepcopy(artifact)

    def read_audit(self, reference: str) -> Mapping[str, Any] | None:
        with self._lock:
            return deepcopy(next((e for e in self._audit if e['id'] == reference), None))

    def audit_download(self, actor: SettingsActor, reference: str, expected_revision: str,
                       guard: Callable[[SupportArchive], Mapping[str, Any]]) -> tuple[SupportArchive, Mapping[str, Any]]:
        with self._lock:
            archive = self.read(actor, reference)
            if archive.revision != expected_revision:
                raise SettingsRevisionConflict('Support bundle revision changed.')
            event = deepcopy(dict(guard(archive))); _ref(event.get('id'))
            self._audit.append(event)
            return archive, deepcopy(event)

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class SupportBundleService:
    def __init__(self, store: SupportStore, collector: SupportCollector, scanner: SupportPrivacyScanner, *,
                 authorize: Callable[[SettingsActor, str], bool], readiness: Callable[[SettingsActor], SupportReadiness],
                 clock: Callable[[], float] = time.time, lifetime_seconds: int = 600) -> None:
        if not callable(authorize) or not callable(readiness) or type(lifetime_seconds) is not int or not 10 <= lifetime_seconds <= 3600:
            raise SettingsValidationError('Native support authority/readiness and a bounded artifact lifetime are required.')
        self.store = store; self.collector = collector; self.scanner = scanner
        self.authorize = authorize; self.readiness = readiness; self.clock = clock; self.lifetime_seconds = lifetime_seconds

    def _allowed(self, actor: SettingsActor, right: str) -> bool:
        try:
            return isinstance(actor, SettingsActor) and right in actor.capabilities and self.authorize(actor, right) is True
        except Exception:
            return False

    def _require(self, actor: SettingsActor, right: str) -> None:
        if not self._allowed(actor, right):
            raise SettingsPermissionError('Current native authority is required for this support operation.')

    def _scan(self, actor: SettingsActor, content: bytes) -> SupportPrivacyReport:
        try:
            report = self.scanner.inspect(actor, content)
        except Exception:
            raise SupportBundleUnavailable('Native support privacy verification is unavailable. No artifact is released.') from None
        if not isinstance(report, SupportPrivacyReport) or report.sha256 != sha256(content).hexdigest():
            raise SettingsValidationError('Native privacy proof does not describe the actual archive bytes.')
        return report

    def _archive(self, actor: SettingsActor, reference: str) -> SupportArchive:
        _ref(reference)
        try:
            archive = self.store.read(actor, reference)
        except SettingsPermissionError:
            raise SettingsPermissionError('This native support artifact is not available to the current actor.') from None
        except Exception:
            raise SupportBundleUnavailable('Native support artifact state is unavailable.') from None
        if (not isinstance(archive, SupportArchive) or archive.reference != reference or archive.owner != actor.subject
                or not isinstance(archive.report, SupportPrivacyReport) or type(archive.created_at) is not int
                or type(archive.expires_at) is not int or archive.expires_at <= archive.created_at
                or not isinstance(archive.categories, tuple) or not archive.categories or len(archive.categories) > 4
                or len(set(archive.categories)) != len(archive.categories) or any(c not in CATEGORIES for c in archive.categories)
                or type(archive.size_bytes) is not int or not 0 < archive.size_bytes <= MAX_BYTES
                or (archive.content is not None and not isinstance(archive.content, bytes))):
            raise SettingsValidationError('Invalid native support artifact metadata.')
        _ref(archive.revision); _hash(archive.sha256); _ref(archive.generation_audit)
        _time(archive.created_at); _time(archive.expires_at)
        return archive

    def _evidence(self, actor: SettingsActor, archive: SupportArchive) -> dict[str, Any]:
        self._require(actor, 'support.read')
        integrity = (archive.content is not None and len(archive.content) == archive.size_bytes
                     and sha256(archive.content).hexdigest() == archive.sha256)
        report = self._scan(actor, archive.content) if integrity else archive.report
        try:
            ready = self.readiness(actor)
        except Exception:
            ready = SupportReadiness()
        if not isinstance(ready, SupportReadiness):
            raise SettingsValidationError('Invalid current native support readiness.')
        self._require(actor, 'support.read')
        now = _time(self.clock()); authorized = self._allowed(actor, 'support.download')
        checks = {'archiveBytesVerified': bool(integrity), 'redactionVerified': report.redaction_verified,
                  'credentialScanPassed': report.credential_scan_passed, 'personalDataScanPassed': report.personal_data_scan_passed,
                  'customerPayloadExcluded': report.customer_payload_excluded, 'actorAuthorized': authorized,
                  'recentMfaVerified': ready.recent_mfa_verified, 'auditReady': ready.audit_ready}
        map_blocker = {'archiveBytesVerified': 'archive_integrity_missing', 'redactionVerified': 'redaction_unverified',
            'credentialScanPassed': 'credentials_unverified', 'personalDataScanPassed': 'personal_data_unverified',
            'customerPayloadExcluded': 'customer_payload_present', 'actorAuthorized': 'permission_denied',
            'recentMfaVerified': 'mfa_required', 'auditReady': 'audit_unavailable'}
        blockers = [map_blocker[k] for k, value in checks.items() if not value]
        if not archive.created_at <= now < archive.expires_at:
            blockers.append('expired_bundle')
        proof = {'expectedRevision': archive.revision, 'allowed': not blockers, 'blockers': blockers,
                 'productTransferRequired': True, **checks}
        state = 'ready' if integrity and report.safe else 'failed'
        result: dict[str, Any] = {'filename': 'support-' + archive.reference + '.json', 'projection': {
            'reference': archive.reference, 'revision': archive.revision, 'state': state,
            'checkedAt': now, 'expiresAt': archive.expires_at, 'sizeBytes': archive.size_bytes,
            'categories': list(archive.categories), 'proof': proof}}
        if state == 'ready':
            result['sha256'] = archive.sha256
        return result

    @staticmethod
    def _event(actor: SettingsActor, action: str, now: int, reference: str) -> dict[str, Any]:
        return {'id': 'support-audit-' + uuid4().hex, 'actor': actor.subject,
                'action': action, 'timestamp': now, 'reference': reference}

    def prepare(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, 'support.generate'); self._require(actor, 'support.read')
        try:
            collected = self.collector.collect(actor)
        except Exception:
            raise SupportBundleUnavailable('Native diagnostic collection failed; no host details are exposed.') from None
        if not isinstance(collected, CollectedSupportEvidence):
            raise SettingsValidationError('Native bounded support evidence is required.')
        _ref(collected.source_revision)
        generated = _time(self.clock()); content = _json_bytes(collected.sections, generated)
        report = self._scan(actor, content)
        self._require(actor, 'support.generate'); self._require(actor, 'support.read')
        now = _time(self.clock()); reference = 'bundle-' + uuid4().hex; revision = 'bundle-rev-' + uuid4().hex
        event = self._event(actor, 'support.generated' if report.safe else 'support.privacy_blocked', now, reference)
        archive = SupportArchive(reference, revision, actor.subject, now, now + self.lifetime_seconds,
            tuple(c for c in CATEGORIES if c in collected.sections), len(content), sha256(content).hexdigest(), report,
            content if report.safe else None, event['id'])
        def guard() -> None:
            self._require(actor, 'support.generate'); self._require(actor, 'support.read')
            if not archive.created_at <= _time(self.clock()) < archive.expires_at:
                raise SettingsValidationError('Native support generation evidence expired before storage.')
        try:
            self.store.create(actor, archive, event, guard)
        except (SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict):
            raise
        except Exception:
            raise SupportBundleUnavailable('Native support generation and audit were not verified.') from None
        stored = self._archive(actor, reference)
        if stored != archive or self.store.read_audit(event['id']) != event:
            raise SupportBundleUnavailable('Native support artifact and generation audit were not independently persisted.')
        return self._evidence(actor, stored)

    def read(self, actor: SettingsActor, reference: str) -> dict[str, Any]:
        self._require(actor, 'support.read')
        return self._evidence(actor, self._archive(actor, reference))

    def download(self, actor: SettingsActor, reference: str, expected_revision: str) -> SupportDownload:
        self._require(actor, 'support.read'); self._require(actor, 'support.download'); _ref(reference); _ref(expected_revision)
        # Native owner/scope and exact metadata validation happen before the audit transaction.
        before = self._archive(actor, reference)
        if before.revision != expected_revision:
            raise SettingsRevisionConflict('Support bundle revision changed.')
        def guard(archive: SupportArchive) -> Mapping[str, Any]:
            self._require(actor, 'support.download')
            if archive != before:
                raise SettingsRevisionConflict('Support bundle changed before audited transfer.')
            result = self._evidence(actor, archive)
            if not result['projection']['proof']['allowed']:
                raise SettingsPermissionError('Current support privacy, integrity, expiry, MFA and audit proof must all pass.')
            self._require(actor, 'support.download')
            return self._event(actor, 'support.download.authorized', _time(self.clock()), reference)
        try:
            served, event = self.store.audit_download(actor, reference, expected_revision, guard)
        except (SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict):
            raise
        except Exception:
            raise SupportBundleUnavailable('Native support download audit was not verified; no bytes are released.') from None
        self._require(actor, 'support.download'); self._require(actor, 'support.read')
        if (served != before or served.content is None or self._archive(actor, reference) != served
                or not isinstance(event, Mapping) or event.get('reference') != reference
                or event.get('actor') != actor.subject or event.get('action') != 'support.download.authorized'
                or self.store.read_audit(event.get('id')) != event):
            raise SupportBundleUnavailable('Native support byte transfer and audit were not independently verified.')
        try:
            final_ready = self.readiness(actor)
        except Exception:
            final_ready = SupportReadiness()
        if (not isinstance(final_ready, SupportReadiness) or not final_ready.recent_mfa_verified or not final_ready.audit_ready
                or not served.created_at <= _time(self.clock()) < served.expires_at):
            raise SettingsPermissionError('Support transfer authorization expired or changed before releasing bytes.')
        self._require(actor, 'support.download')
        return SupportDownload(served.content, 'support-' + reference + '.json', event['id'])
