"""Common Control-compatible retention service, never a host cleanup command.

Native products supply authenticated SettingsActor, current readiness and their
atomic policy/record/audit store. The reference memory store archives synthetic
metadata only. Posted payloads cannot supply authority, legal holds or evidence.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import time
from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict

CATEGORIES = ("logs", "runtime_metrics", "preview_cache", "backup_temp")


def _integer(v: object, lo: int, hi: int) -> int:
    if type(v) is not int or not lo <= v <= hi:
        raise SettingsValidationError("Retention value is outside its supported range.")
    return v


def _reference(v: object) -> str:
    if not isinstance(v, str) or not 0 < len(v) <= 256 or any(ord(c) < 33 or ord(c) == 127 for c in v):
        raise SettingsValidationError("A current opaque reference is required.")
    return v


def _now(v: object) -> float:
    if type(v) not in (int, float) or not math.isfinite(v) or not 0 <= v <= 253402300799:
        raise SettingsValidationError("Invalid server time.")
    return float(v)


@dataclass(frozen=True)
class RetentionRecord:
    reference: str
    category: str
    observed_at: float
    protected: bool = False
    legal_hold: bool = False

    def __post_init__(self) -> None:
        _reference(self.reference)
        if self.category not in CATEGORIES:
            raise SettingsValidationError("Unknown retention record category.")
        _now(self.observed_at)
        if type(self.protected) is not bool or type(self.legal_hold) is not bool:
            raise SettingsValidationError("Record guards must be native Boolean facts.")


@dataclass(frozen=True)
class RetentionReadiness:
    """Server-native evidence, not HTTP request fields or a browser grant."""
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    backup_ready: bool = False
    rollback_ready: bool = False

    def __post_init__(self) -> None:
        if any(type(v) is not bool for v in vars(self).values()):
            raise SettingsValidationError("Readiness must contain native Boolean evidence.")


@dataclass(frozen=True)
class RetentionSnapshot:
    revision: str
    value: dict[str, Any]


@dataclass(frozen=True)
class RetentionPlan:
    reference: str
    revision: str
    actor: str
    purpose: str
    expires_at: float
    created_at: float
    projection: dict[str, Any]
    records: tuple[RetentionRecord, ...] = ()


class RetentionStore(Protocol):
    """Existing native storage adapter; do not build a separate production DB.

    scan returns bounded detached metadata from the stated revision. Changes to
    record protection/holds must participate in this version or equivalent native
    transaction guards. commit MUST recheck current native authorization/readiness
    and preview actor/revision/expiry, atomically archive ONLY exact reviewed
    record versions, retain restoration data, persist policy/result + audit and
    consume the preview. Any failure leaves all of these unchanged.
    """
    def read(self) -> RetentionSnapshot: ...
    def scan(self, revision: str, categories: tuple[str, ...], limit: int) -> tuple[RetentionRecord, ...]: ...
    def register_plan(self, plan: RetentionPlan, now: float) -> None: ...
    def get_plan(self, reference: str) -> RetentionPlan: ...
    def commit(self, revision: str, actor: str, plan_ref: str, value: Mapping[str, Any],
               records: tuple[RetentionRecord, ...], audit_event: Mapping[str, Any], now: float) -> RetentionSnapshot: ...


def _state(snapshot: RetentionSnapshot) -> RetentionSnapshot:
    if not isinstance(snapshot, RetentionSnapshot):
        raise SettingsValidationError("A native retention snapshot is required.")
    _reference(snapshot.revision)
    s = snapshot.value
    if not isinstance(s, dict) or not {"schedulerEnabled", "schedulerActive", "intervalMinutes", "batchSize", "lastSweepAt", "categories"} <= set(s):
        raise SettingsValidationError("Invalid stored retention policy.")
    if type(s['schedulerEnabled']) is not bool or type(s['schedulerActive']) is not bool:
        raise SettingsValidationError("Invalid scheduler posture.")
    _integer(s['intervalMinutes'], 5, 1440); _integer(s['batchSize'], 100, 100000)
    if set(s) - {'schedulerEnabled', 'schedulerActive', 'intervalMinutes', 'batchSize', 'lastSweepAt', 'categories', 'lastResult'}:
        raise SettingsValidationError("Unexpected fields in the native retention projection.")
    categories = s['categories']
    if not isinstance(categories, list) or not 1 <= len(categories) <= 4:
        raise SettingsValidationError("Invalid stored retention categories.")
    seen = set()
    for c in categories:
        if not isinstance(c, dict) or c.get('id') not in CATEGORIES or c['id'] in seen:
            raise SettingsValidationError("Unknown or duplicate retention category.")
        seen.add(c['id'])
        if type(c.get('enabled')) is not bool or type(c.get('legalHold')) is not bool:
            raise SettingsValidationError("Invalid retention safeguards.")
        _integer(c.get('minimumDays'), 1, 3650); _integer(c.get('retentionDays'), c['minimumDays'], 3650)
    return RetentionSnapshot(snapshot.revision, deepcopy(s))


class MemoryRetentionStore:
    """Isolated reference/test store. No filesystem, SQL or real record effects."""
    def __init__(self, *, records: list[RetentionRecord] | None = None, policy: dict[str, Any] | None = None) -> None:
        self._lock = RLock(); self._version = 1
        self._value = policy or {
            'schedulerEnabled': True, 'schedulerActive': False, 'intervalMinutes': 60, 'batchSize': 5000, 'lastSweepAt': None,
            'categories': [dict(id=c, enabled=True, retentionDays=days, minimumDays=minimum, legalHold=False)
                           for c, days, minimum in zip(CATEGORIES, (30, 30, 7, 14), (7, 7, 1, 1))]}
        self._value = _state(RetentionSnapshot('retention-1', self._value)).value
        supplied = records or []
        if any(not isinstance(r, RetentionRecord) for r in supplied) or len({r.reference for r in supplied}) != len(supplied):
            raise SettingsValidationError("Invalid reference records.")
        self._records = {r.reference: r for r in supplied}
        self._archive: dict[str, RetentionRecord] = {}
        self._plans: dict[str, RetentionPlan] = {}
        self._consumed: set[str] = set()
        self._audit: list[dict[str, Any]] = []

    def _snapshot(self) -> RetentionSnapshot:
        return RetentionSnapshot('retention-' + str(self._version), deepcopy(self._value))

    def read(self) -> RetentionSnapshot:
        with self._lock: return self._snapshot()

    def _revision(self, expected: str) -> None:
        if expected != self._snapshot().revision:
            raise SettingsRevisionConflict("Retention or protected-record state changed. Refresh and review again.")

    def scan(self, revision: str, categories: tuple[str, ...], limit: int) -> tuple[RetentionRecord, ...]:
        _integer(limit, 100, 100000)
        with self._lock:
            self._revision(revision)
            return tuple(sorted((r for r in self._records.values() if r.category in categories), key=lambda r: (r.observed_at, r.reference))[:limit])

    def register_plan(self, plan: RetentionPlan, now: float) -> None:
        with self._lock:
            self._revision(plan.revision)
            self._plans = {k: p for k, p in self._plans.items() if p.expires_at > now and k not in self._consumed}
            if len(self._plans) >= 1024: raise SettingsValidationError("Reference preview capacity exceeded.")
            self._plans[plan.reference] = deepcopy(plan)

    def get_plan(self, reference: str) -> RetentionPlan:
        with self._lock:
            if reference not in self._plans or reference in self._consumed:
                raise SettingsValidationError("Retention preview is unavailable or consumed.")
            return deepcopy(self._plans[reference])

    def commit(self, revision: str, actor: str, plan_ref: str, value: Mapping[str, Any],
               records: tuple[RetentionRecord, ...], audit_event: Mapping[str, Any], now: float) -> RetentionSnapshot:
        next_value = _state(RetentionSnapshot(revision, dict(value))).value
        event = deepcopy(dict(audit_event)); _reference(event.get('id'))
        with self._lock:
            self._revision(revision); plan = self.get_plan(plan_ref)
            if plan.actor != actor or plan.revision != revision or not plan.created_at <= now < plan.expires_at or plan.projection['allowed'] is not True:
                raise SettingsValidationError("Invalid current retention preview.")
            if tuple(records) != plan.records:
                raise SettingsValidationError("Archive scope differs from the reviewed records.")
            for record in records:
                if self._records.get(record.reference) != record or record.protected or record.legal_hold:
                    raise SettingsRevisionConflict("A reviewed record changed or acquired protection.")
            # Only after every precondition succeeds does one locked operation publish changes.
            for record in records:
                self._archive[record.reference] = self._records.pop(record.reference)
            self._value = next_value; self._audit.append(event); self._consumed.add(plan_ref); self._version += 1
            return self._snapshot()

    def protect_record(self, reference: str) -> None:
        from dataclasses import replace
        with self._lock:
            self._records[reference] = replace(self._records[reference], protected=True); self._version += 1

    @property
    def archived_ids(self) -> tuple[str, ...]:
        with self._lock: return tuple(self._archive)

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock: return deepcopy(self._audit)


class RetentionService:
    """Shared policy/controller algorithm consumed by all three native products."""
    def __init__(self, store: RetentionStore, readiness: Callable[[SettingsActor], RetentionReadiness], *, clock: Callable[[], float] = time.time) -> None:
        self.store = store; self.readiness = readiness; self.clock = clock

    def _require(self, actor: SettingsActor, capability: str) -> None:
        if not isinstance(actor, SettingsActor) or capability not in actor.capabilities:
            raise SettingsPermissionError("Native authorization does not permit this retention operation.")

    def _read(self, actor: SettingsActor, expected: object | None = None) -> RetentionSnapshot:
        self._require(actor, 'retention.read'); s = _state(self.store.read())
        if expected is not None and _reference(expected) != s.revision:
            raise SettingsRevisionConflict("Retention settings changed since review.")
        return s

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        s = self._read(actor)
        return {'effective': s.value, 'revision': s.revision}

    def _proof(self, actor: SettingsActor, purpose: str, revision: str, blockers: list[str]) -> dict[str, Any]:
        evidence = self.readiness(actor)
        if not isinstance(evidence, RetentionReadiness): raise SettingsValidationError("Native readiness is unavailable.")
        for field, code in [('recent_mfa_verified', 'mfa_required'), ('audit_ready', 'audit_unavailable'), ('backup_ready', 'backup_unverified'), ('rollback_ready', 'rollback_unavailable')]:
            if not getattr(evidence, field): blockers.append(code)
        return dict(purpose=purpose, expectedRevision=revision, previewRef='retention-preview-' + uuid4().hex,
                    allowed=not blockers, blockers=blockers, actorAuthorized=True,
                    recentMfaVerified=evidence.recent_mfa_verified, auditReady=evidence.audit_ready,
                    protectedRecordsExcluded=True, backupReady=evidence.backup_ready, rollbackReady=evidence.rollback_ready)

    def _policy(self, state: dict[str, Any], request: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(request, Mapping) or set(request) != {'schedulerEnabled', 'intervalMinutes', 'batchSize', 'expectedRevision', 'categories'}:
            raise SettingsValidationError("Submit only the documented retention policy fields.")
        _reference(request['expectedRevision'])
        if type(request['schedulerEnabled']) is not bool: raise SettingsValidationError("Scheduler flag must be Boolean.")
        _integer(request['intervalMinutes'], 5, 1440); _integer(request['batchSize'], 100, 100000)
        categories = request['categories']; known = {c['id']: c for c in state['categories']}
        if not isinstance(categories, list) or len(categories) != len(known): raise SettingsValidationError("Retention category scope changed.")
        seen = set(); out = deepcopy(state)
        for c in categories:
            if not isinstance(c, dict) or set(c) != {'id', 'enabled', 'retentionDays'} or c.get('id') not in known or c['id'] in seen:
                raise SettingsValidationError("Invalid retention category draft.")
            seen.add(c['id']); old = known[c['id']]
            if type(c['enabled']) is not bool: raise SettingsValidationError("Category flag must be Boolean.")
            _integer(c['retentionDays'], old['minimumDays'], 3650)
            if old['legalHold'] and c['retentionDays'] < old['retentionDays']: raise SettingsValidationError("Legal hold prevents shortening retention.")
            for target in out['categories']:
                if target['id'] == c['id']: target.update(enabled=c['enabled'], retentionDays=c['retentionDays'])
        out.update({k: request[k] for k in ('schedulerEnabled', 'intervalMinutes', 'batchSize')})
        return out

    def _register(self, actor: SettingsActor, s: RetentionSnapshot, purpose: str, projection: dict[str, Any], records: tuple[RetentionRecord, ...] = ()) -> None:
        now = _now(self.clock())
        self.store.register_plan(RetentionPlan(projection['previewRef'], s.revision, actor.subject, purpose, now + 300, now, deepcopy(projection), records), now)

    def preview_policy(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'retention.configure')
        if not isinstance(request, Mapping): raise SettingsValidationError("Invalid policy draft.")
        s = self._read(actor, request.get('expectedRevision')); self._policy(s.value, request)
        projection = {**self._proof(actor, 'policy', s.revision, []), 'draft': deepcopy(dict(request))}
        self._register(actor, s, 'policy', projection); return projection

    def _plan(self, actor: SettingsActor, reference: object, purpose: str, s: RetentionSnapshot) -> RetentionPlan:
        p = self.store.get_plan(_reference(reference))
        if not isinstance(p, RetentionPlan) or p.actor != actor.subject or p.purpose != purpose or p.revision != s.revision or not p.created_at <= _now(self.clock()) < p.expires_at:
            raise SettingsValidationError("Retention preview is expired, stale or bound to another actor/scope.")
        current = self._proof(actor, purpose, s.revision, [])
        if p.projection['allowed'] is not True or current['allowed'] is not True:
            raise SettingsPermissionError("Current native safeguards do not permit this retention change.")
        return p

    def _commit(self, actor: SettingsActor, s: RetentionSnapshot, p: RetentionPlan, value: dict[str, Any], records: tuple[RetentionRecord, ...], event: dict[str, Any]) -> RetentionSnapshot:
        after = _state(self.store.commit(s.revision, actor.subject, p.reference, value, records, event, _now(self.clock())))
        if after.revision == s.revision or after.value != value:
            raise SettingsRevisionConflict("Retention commit was not verified by native read-back.")
        return after

    def _event(self, actor: SettingsActor, action: str, reference: str) -> dict[str, Any]:
        return dict(id='retention-audit-' + uuid4().hex, actor=actor.subject, action=action,
                    timestamp=datetime.fromtimestamp(_now(self.clock()), timezone.utc).isoformat(), previewRef=reference)

    def configure(self, actor: SettingsActor, request: Mapping[str, Any], preview_ref: str) -> dict[str, Any]:
        self._require(actor, 'retention.configure')
        if not isinstance(request, Mapping): raise SettingsValidationError("Invalid policy draft.")
        s = self._read(actor, request.get('expectedRevision')); value = self._policy(s.value, request)
        p = self._plan(actor, preview_ref, 'policy', s)
        if p.projection['draft'] != dict(request): raise SettingsValidationError("Policy differs from the reviewed draft.")
        event = self._event(actor, 'retention.policy.configured', preview_ref)
        after = self._commit(actor, s, p, value, (), event)
        return {'effective': {'effective': after.value, 'revision': after.revision}, 'audit': {'id': event['id']}}

    def _categories(self, request: Mapping[str, Any], s: RetentionSnapshot, fields: set[str]) -> tuple[str, ...]:
        if not isinstance(request, Mapping) or set(request) != fields: raise SettingsValidationError("Invalid cleanup request fields.")
        supplied = request['categories']; known = {c['id'] for c in s.value['categories']}
        if not isinstance(supplied, list) or not 1 <= len(supplied) <= 4 or any(not isinstance(c, str) or c not in known for c in supplied) or len(set(supplied)) != len(supplied):
            raise SettingsValidationError("Choose unique current retention categories.")
        _reference(request['expectedRevision']); return tuple(supplied)

    def dry_run(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'retention.run')
        if not isinstance(request, Mapping): raise SettingsValidationError("Invalid cleanup request.")
        s = self._read(actor, request.get('expectedRevision'))
        ids = self._categories(request, s, {'categories', 'expectedRevision'})
        settings = {c['id']: c for c in s.value['categories']}; blockers = ['legal_hold'] if any(settings[c]['legalHold'] for c in ids) else []
        scanned = self.store.scan(s.revision, ids, s.value['batchSize'])
        if not isinstance(scanned, tuple) or len(scanned) > s.value['batchSize'] or any(not isinstance(r, RetentionRecord) or r.category not in ids for r in scanned) or len({r.reference for r in scanned}) != len(scanned):
            raise SettingsValidationError("Native candidate scan is invalid or exceeds the batch bound.")
        now = _now(self.clock())
        records = tuple(r for r in scanned if settings[r.category]['enabled'] and not settings[r.category]['legalHold'] and
                        not r.protected and not r.legal_hold and r.observed_at < now - settings[r.category]['retentionDays'] * 86400)
        outcomes = [dict(category=c, status='ok' if settings[c]['enabled'] and not settings[c]['legalHold'] else 'skipped',
                         matchedCount=sum(r.category == c for r in records), affectedCount=0) for c in ids]
        projection = {**self._proof(actor, 'cleanup', s.revision, blockers), 'categories': list(ids), 'dryRun': True, 'outcomes': outcomes}
        self._register(actor, s, 'cleanup', projection, records); return projection

    def run(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'retention.run')
        if not isinstance(request, Mapping): raise SettingsValidationError("Invalid cleanup request.")
        s = self._read(actor, request.get('expectedRevision'))
        ids = self._categories(request, s, {'categories', 'expectedRevision', 'previewRef'})
        p = self._plan(actor, request['previewRef'], 'cleanup', s)
        if tuple(p.projection['categories']) != ids: raise SettingsValidationError("Cleanup scope differs from the reviewed categories.")
        settings = {c['id']: c for c in s.value['categories']}
        if any(settings[c]['legalHold'] for c in ids): raise SettingsPermissionError("A category is under legal hold.")
        event = self._event(actor, 'retention.cleanup.completed', p.reference)
        result = dict(previewRef=p.reference, dryRun=False, auditReference=event['id'],
                      outcomes=[{**o, 'affectedCount': o['matchedCount'] if o['status'] == 'ok' else 0} for o in p.projection['outcomes']])
        value = deepcopy(s.value); value.update(lastSweepAt=event['timestamp'], lastResult=result)
        self._commit(actor, s, p, value, p.records, event)
        return deepcopy(result)
