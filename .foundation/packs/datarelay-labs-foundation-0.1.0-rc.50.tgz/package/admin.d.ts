export * from "@datarelay-labs/system-admin-ui";
export { SystemManagementWorkspace } from "./system-management";
export type { FoundationManagementPages, FoundationMfaManagementPage, SystemManagementWorkspaceProps } from "./system-management";
export { createSystemManagementConsumer, deriveSystemManagementBindings } from "./system-management-consumer";
export type { SystemManagementBindingMetadata, SystemManagementConsumerConfig } from "./system-management-consumer";
export { PasswordManagementPage } from "./password-management";
export type { PasswordManagementState, PasswordManagementAdapter, PasswordManagementPageProps, PasswordChangeReceipt } from "./password-management";
