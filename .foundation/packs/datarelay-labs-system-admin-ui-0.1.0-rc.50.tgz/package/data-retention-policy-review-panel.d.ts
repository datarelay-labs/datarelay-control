import { type CapabilityAvailability, type DataRetentionCategory, type DataRetentionPolicyReviewProjection } from "@datarelay-labs/system-contracts";
export type DataRetentionPolicyReviewPanelProps = {
    /** Product-approved one-category retention intent, no record IDs/content. */
    projection?: DataRetentionPolicyReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Opens product-owned review, never cleanup/deletion. */
    onReviewRetention?: (category: DataRetentionCategory, expectedRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Separate from backup archive retention. Classification, legal holds,
 * protected-record exclusions, dry-run and deletion are product-owned. */
export declare function DataRetentionPolicyReviewPanel({ projection, reviewAvailability, onReviewRetention, pending }: DataRetentionPolicyReviewPanelProps): import("react").JSX.Element;
