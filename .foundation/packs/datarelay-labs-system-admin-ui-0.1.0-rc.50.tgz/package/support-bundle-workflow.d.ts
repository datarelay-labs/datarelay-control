import type { SupportBundleReviewProjection } from "@datarelay-labs/system-contracts";
export type PreparedSupportBundle = {
    projection: SupportBundleReviewProjection;
    filename: string;
    sha256?: string;
};
export type SupportBundleAdapter = {
    prepare: () => Promise<PreparedSupportBundle>;
    read: (reference: string) => Promise<PreparedSupportBundle>;
    download: (reference: string, revision: string) => Promise<{
        blob: Blob;
        auditReference: string;
    }>;
};
export type SupportBundleWorkflowProps = {
    adapter: SupportBundleAdapter;
    canGenerate?: boolean;
    canDownload?: boolean;
};
/** Native archive generation plus shared privacy review, exact-byte hash verification and download. */
export declare function SupportBundleWorkflow({ adapter, canGenerate, canDownload }: SupportBundleWorkflowProps): import("react").JSX.Element;
