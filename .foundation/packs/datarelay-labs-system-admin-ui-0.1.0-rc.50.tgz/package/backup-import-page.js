import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
export const MAX_WORKSPACE_JSON_BYTES = 5 * 1024 * 1024;
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const ref = (v) => typeof v === "string" && v.length > 0 && v.length <= 256 && !/[\x00-\x20\x7f]/.test(v);
/** Portable product payload is opaque. Parsing does not run scripts or merge object prototypes. */
export function parseWorkspaceImport(text) {
    if (typeof text !== "string" || text.length > MAX_WORKSPACE_JSON_BYTES || new TextEncoder().encode(text).byteLength > MAX_WORKSPACE_JSON_BYTES)
        throw new Error("Import JSON exceeds the 5 MiB limit.");
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch {
        throw new Error("Enter valid JSON before import preview.");
    }
    if (!record(parsed))
        throw new Error("Import payload must be a JSON object.");
    if (!Object.keys(parsed).length)
        throw new Error("Import payload must not be empty.");
    const stack = [{ value: parsed, depth: 0 }];
    let count = 0;
    while (stack.length) {
        const { value, depth } = stack.pop();
        if (++count > 100000 || depth > 64)
            throw new Error("Import JSON is too complex.");
        if (value && typeof value === "object")
            for (const child of Object.values(value))
                stack.push({ value: child, depth: depth + 1 });
    }
    return parsed;
}
const strings = (v) => Array.isArray(v) && v.length <= 200 && v.every(s => typeof s === "string" && s.length <= 2048);
function validPreview(p, mode) {
    return record(p) && ref(p.previewRef) && ref(p.expectedRevision) && p.mode === mode && typeof p.expiresAt === "string" &&
        Number.isFinite(Date.parse(p.expiresAt)) && ["ok", "actorAuthorized", "recentMfaVerified", "auditReady", "rollbackReady"].every(k => typeof p[k] === "boolean") &&
        strings(p.conflicts) && strings(p.warnings) && Array.isArray(p.counts) && p.counts.length <= 128 && p.counts.every(c => record(c) && typeof c.label === "string" && c.label.length <= 120 && Number.isSafeInteger(c.count) && Number(c.count) >= 0);
}
const safePreview = (p) => p.ok && p.actorAuthorized && p.recentMfaVerified && p.auditReady && p.rollbackReady && p.conflicts.length === 0 && Date.parse(p.expiresAt) > Date.now();
function validReceipt(r, key, p) {
    return record(r) && r.idempotencyKey === key && r.previewRef === p.previewRef && r.mode === p.mode &&
        ["running", "completed", "failed"].includes(String(r.status)) &&
        (r.status !== "completed" || (ref(r.afterRevision) && r.afterRevision !== p.expectedRevision && ref(r.auditReference)));
}
const errorText = (e) => e instanceof Error ? e.message.slice(0, 512) : "Workspace transfer failed.";
/** Common Control JSON export/preview/import, deliberately distinct from database disaster recovery. */
export function BackupImportPage({ adapter, canExport = false, canPreview = false, canApply = false }) {
    const id = useId();
    const op = useRef(0);
    const current = useRef({ adapter, canExport, canPreview, canApply });
    current.current = { adapter, canExport, canPreview, canApply };
    const [text, setText] = useState("");
    const [mode, setMode] = useState("additive");
    const [suffix, setSuffix] = useState(" (copy)");
    const [checkpoints, setCheckpoints] = useState(true);
    const [destinations, setDestinations] = useState(true);
    const [plan, setPlan] = useState(null);
    const [attempt, setAttempt] = useState(null);
    const [busy, setBusy] = useState(false);
    const [ack, setAck] = useState(false);
    const [confirm, setConfirm] = useState("");
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const [final, setFinal] = useState(false);
    const signature = JSON.stringify({ text, mode, suffix });
    const activePlan = canPreview && plan?.signature === signature ? plan : null;
    const editing = !busy && !attempt && !final;
    const alive = (n, right) => op.current === n && current.current.adapter === adapter && current.current[right];
    useEffect(() => { op.current++; setPlan(null); setAttempt(null); setText(""); setAck(false); setConfirm(""); setBusy(false); setFinal(false); setError(""); setNotice(""); return () => { op.current++; }; }, [adapter]);
    useEffect(() => { op.current++; setBusy(false); setPlan(null); setAck(false); setConfirm(""); }, [canExport, canPreview, canApply]);
    useEffect(() => { if (!canPreview)
        setPlan(null); }, [canPreview]);
    function clearPreview() { setPlan(null); setAck(false); setConfirm(""); setError(""); setNotice(""); }
    async function pickFile(file) {
        if (!file || !editing || !canPreview)
            return;
        clearPreview();
        if (file.size > MAX_WORKSPACE_JSON_BYTES) {
            setError("Import file exceeds the 5 MiB limit.");
            return;
        }
        const n = ++op.current;
        setBusy(true);
        try {
            const content = await file.text();
            if (!alive(n, "canPreview"))
                return;
            parseWorkspaceImport(content);
            setText(content);
        }
        catch (e) {
            if (alive(n, "canPreview"))
                setError(errorText(e));
        }
        finally {
            if (op.current === n)
                setBusy(false);
        }
    }
    async function download() {
        if (!canExport || busy || typeof adapter.exportWorkspace !== "function")
            return;
        const n = ++op.current;
        setBusy(true);
        setError("");
        setNotice("");
        try {
            const artifact = await adapter.exportWorkspace({ includeCheckpoints: checkpoints, includeDestinations: destinations });
            if (!alive(n, "canExport"))
                return;
            if (!record(artifact) || !(artifact.blob instanceof Blob) || artifact.blob.size > MAX_WORKSPACE_JSON_BYTES || artifact.redacted !== true ||
                !ref(artifact.auditReference) || !/^[-a-zA-Z0-9_.]{1,120}\.json$/.test(artifact.filename))
                throw new Error("Invalid or unredacted product export.");
            const href = URL.createObjectURL(artifact.blob);
            const link = document.createElement("a");
            link.href = href;
            link.download = artifact.filename;
            link.rel = "noopener";
            document.body.append(link);
            try {
                link.click();
            }
            finally {
                link.remove();
                setTimeout(() => URL.revokeObjectURL(href), 1000);
            }
            setNotice("Workspace download started. Import is separate from export.");
        }
        catch (e) {
            if (alive(n, "canExport"))
                setError(errorText(e));
        }
        finally {
            if (op.current === n)
                setBusy(false);
        }
    }
    async function preview() {
        if (!canPreview || !editing || typeof adapter.previewImport !== "function")
            return;
        clearPreview();
        let intent;
        try {
            intent = { bundle: parseWorkspaceImport(text), mode, ...(mode === "clone" ? { cloneSuffix: suffix } : {}) };
            if (mode === "clone" && (!suffix.trim() || suffix.length > 80))
                throw new Error("Enter a clone suffix of 1–80 characters.");
        }
        catch (e) {
            setError(errorText(e));
            return;
        }
        const n = ++op.current;
        setBusy(true);
        try {
            const result = await adapter.previewImport(intent);
            if (!alive(n, "canPreview"))
                return;
            if (!validPreview(result, mode))
                throw new Error("Invalid product import preview.");
            setPlan({ signature, intent, value: result });
            if (!safePreview(result))
                setError("Import preview is blocked, expired or missing current authorization.");
        }
        catch (e) {
            if (alive(n, "canPreview"))
                setError(errorText(e));
        }
        finally {
            if (op.current === n)
                setBusy(false);
        }
    }
    async function verifyResult(n, key, p, expected) {
        const persisted = await adapter.readImport(key);
        if (!alive(n, "canApply"))
            return;
        if (!validReceipt(persisted, key, p) || (expected && (persisted.status !== expected.status || persisted.afterRevision !== expected.afterRevision || persisted.auditReference !== expected.auditReference)))
            throw new Error("Import result not confirmed by authoritative read-back. Check the same operation again.");
        if (persisted.status === "running") {
            setNotice("Import is still running. Check the result without resubmitting.");
            return;
        }
        if (persisted.status === "failed") {
            setFinal(true);
            setError("Import failed. Review the native audit record before starting another import.");
            return;
        }
        setFinal(true);
        setAttempt(null);
        setPlan(null);
        setText("");
        setNotice("Import completed and verified.");
    }
    async function apply() {
        if (!canApply || busy || attempt || !activePlan || !ack || confirm !== "IMPORT" || !safePreview(activePlan.value) || typeof adapter.applyImport !== "function" || typeof adapter.readImport !== "function")
            return;
        if (typeof crypto.randomUUID !== "function") {
            setError("Secure operation identifiers are unavailable. Use a secure browser context.");
            return;
        }
        const n = ++op.current;
        const key = crypto.randomUUID();
        const p = activePlan;
        setAttempt({ key, plan: p.value });
        setBusy(true);
        setError("");
        setNotice("");
        setAck(false);
        setConfirm("");
        try {
            const result = await adapter.applyImport({ ...p.intent, previewRef: p.value.previewRef, expectedRevision: p.value.expectedRevision, idempotencyKey: key, confirm: true });
            if (!alive(n, "canApply"))
                return;
            if (!validReceipt(result, key, p.value))
                throw new Error("Invalid import result. Check the operation status.");
            await verifyResult(n, key, p.value, result);
        }
        catch (e) {
            if (alive(n, "canApply")) {
                const msg = errorText(e);
                setError(/failed to fetch|networkerror|connection.*(reset|closed|aborted)/i.test(msg) ? "Import status unknown after connection interruption. Check the existing operation; do not resubmit." : msg);
            }
        }
        finally {
            if (op.current === n)
                setBusy(false);
        }
    }
    async function checkResult() {
        if (!canApply || !attempt || busy)
            return;
        const n = ++op.current;
        setBusy(true);
        setError("");
        setNotice("");
        try {
            await verifyResult(n, attempt.key, attempt.plan);
        }
        catch (e) {
            if (alive(n, "canApply"))
                setError(errorText(e));
        }
        finally {
            if (op.current === n)
                setBusy(false);
        }
    }
    return _jsxs("section", { className: "dr-admin__transfer", "aria-label": "Backup and import settings", children: [_jsxs("header", { children: [_jsx("h3", { children: "Backup & Import" }), _jsx("p", { children: "Export \u2192 choose source \u2192 validate and preview \u2192 review impact \u2192 explicit apply." })] }), _jsx("p", { role: "note", children: "JSON import is additive or clone only \u2014 not database disaster recovery. Exported secrets must be masked by the product." }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Export workspace", children: [_jsx("h4", { children: "Export current workspace" }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: checkpoints, disabled: !canExport || busy, onChange: e => setCheckpoints(e.target.checked) }), "Include checkpoints"] }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: destinations, disabled: !canExport || busy, onChange: e => setDestinations(e.target.checked) }), "Include destinations (masked)"] }), canExport ? _jsx(Button, { disabled: busy, onClick: () => void download(), children: "Download JSON" }) : _jsx("p", { children: "Export is not authorized in this session." })] }), _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Import workspace", children: [_jsx("h4", { children: "Choose source and preview" }), _jsx("label", { htmlFor: id + "-file", children: "Choose JSON file" }), _jsx("input", { id: id + "-file", type: "file", accept: "application/json,.json", disabled: !canPreview || !editing, onChange: e => void pickFile(e.target.files?.[0]) }), _jsx("label", { htmlFor: id + "-mode", children: "Import mode" }), _jsxs("select", { id: id + "-mode", value: mode, disabled: !canPreview || !editing, onChange: e => { clearPreview(); setMode(e.target.value === "clone" ? "clone" : "additive"); }, children: [_jsx("option", { value: "additive", children: "Additive \u2014 merge without deleting" }), _jsx("option", { value: "clone", children: "Clone \u2014 suffix names" })] }), mode === "clone" ? _jsxs(_Fragment, { children: [_jsx("label", { htmlFor: id + "-suffix", children: "Clone name suffix" }), _jsx("input", { id: id + "-suffix", value: suffix, maxLength: 80, disabled: !canPreview || !editing, onChange: e => { clearPreview(); setSuffix(e.target.value); } })] }) : null, _jsx("label", { htmlFor: id + "-json", children: "Import JSON payload" }), _jsx("textarea", { id: id + "-json", value: text, maxLength: MAX_WORKSPACE_JSON_BYTES, disabled: !canPreview || !editing, onChange: e => { clearPreview(); setText(e.target.value); }, placeholder: "Paste an exported JSON object" }), canPreview ? _jsx(Button, { disabled: !text.trim() || !editing, onClick: () => void preview(), children: "Validate & preview" }) : _jsx("p", { children: "Import preview is not authorized in this session." })] }), activePlan ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Import review", children: [_jsx("h4", { children: "Import impact preview" }), _jsx("dl", { className: "dr-admin__timezone-facts", children: activePlan.value.counts.map((c, i) => _jsxs("div", { children: [_jsx("dt", { children: c.label }), _jsx("dd", { children: c.count })] }, i)) }), activePlan.value.conflicts.length ? _jsxs("div", { children: [_jsx("strong", { children: "Conflicts" }), _jsx("ul", { children: activePlan.value.conflicts.map((v, i) => _jsx("li", { children: v }, i)) })] }) : null, activePlan.value.warnings.length ? _jsxs("div", { children: [_jsx("strong", { children: "Warnings" }), _jsx("ul", { children: activePlan.value.warnings.map((v, i) => _jsx("li", { children: v }, i)) })] }) : null, canApply && safePreview(activePlan.value) && !attempt && !final ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: ack, disabled: busy, onChange: e => setAck(e.target.checked) }), "I reviewed the preview and want to apply this import"] }), _jsx("label", { htmlFor: id + "-confirm", children: "Type IMPORT to confirm" }), _jsx("input", { id: id + "-confirm", value: confirm, disabled: busy, onChange: e => setConfirm(e.target.value), autoComplete: "off" }), _jsx(Button, { disabled: !ack || confirm !== "IMPORT" || busy, onClick: () => void apply(), children: "Apply import" })] }) : null] }) : null, attempt && !final && canApply ? _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void checkResult(), children: "Check import result" }) : null, final ? _jsx(Button, { variant: "secondary", onClick: () => { setFinal(false); setAttempt(null); setText(""); clearPreview(); }, children: "Start another import" }) : null] });
}
