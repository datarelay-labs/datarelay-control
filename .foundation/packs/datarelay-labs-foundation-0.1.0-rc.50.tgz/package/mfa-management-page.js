import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { MfaEnrollmentPanel, RecoveryCodesPanel } from "@datarelay-labs/auth-ui";
import { Button } from "@datarelay-labs/ui";
const REF = /^[a-z][a-z0-9_.-]{0,127}$/;
const text = (value, max = 256) => typeof value === "string" &&
    value.length > 0 && value.length <= max && !/[\u0000-\u001f\u007f]/.test(value);
export function validMfaState(value) {
    if (!value || typeof value !== "object")
        return false;
    const s = value;
    return text(s.subject, 256) && REF.test(s.revision ?? "") && typeof s.required === "boolean" &&
        typeof s.enrolled === "boolean" && Number.isInteger(s.recoveryCodesRemaining) &&
        s.recoveryCodesRemaining >= 0 && s.recoveryCodesRemaining <= 20 &&
        Number.isSafeInteger(s.sessionEpoch) && s.sessionEpoch >= 0;
}
export function validManagedMfaDirectory(value) {
    if (!value || typeof value !== "object")
        return false;
    const d = value;
    if (!text(d.currentUserId, 256) || typeof d.complete !== "boolean" ||
        !Array.isArray(d.records) || d.records.length > 10000)
        return false;
    const ids = new Set();
    for (const record of d.records) {
        if (!validMfaState(record) || ids.has(record.subject))
            return false;
        ids.add(record.subject);
    }
    return !d.complete || ids.has(d.currentUserId);
}
function validEnrollment(value) {
    if (!value || typeof value !== "object")
        return false;
    const e = value;
    return REF.test(e.revision ?? "") && text(e.enrollmentRef, 256) &&
        Number.isFinite(e.expiresAt) && e.expiresAt > Date.now() && text(e.issuer, 128) &&
        text(e.accountLabel, 256) && text(e.secret, 256) && text(e.otpauthUri, 2048) &&
        e.otpauthUri.startsWith("otpauth://totp/");
}
function validRecovery(value) {
    const r = value;
    return validMfaState(value) && Array.isArray(r.recoveryCodes) && r.recoveryCodes.length > 0 &&
        r.recoveryCodes.length <= 20 && r.recoveryCodes.every(code => text(code, 128));
}
export function MfaManagementPage({ adapter, issuer, accountLabel, canRead = false, canManage = false }) {
    const live = useRef({ adapter, canRead, canManage, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead ||
        live.current.canManage !== canManage)
        live.current = { adapter, canRead, canManage, epoch: live.current.epoch + 1 };
    const serial = useRef(0);
    const [self, setSelf] = useState(null);
    const [managed, setManaged] = useState(null);
    const [enrollment, setEnrollment] = useState(null);
    const [recoveryCodes, setRecoveryCodes] = useState([]);
    const [pending, setPending] = useState(null);
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false), [uncertain, setUncertain] = useState(false);
    const [error, setError] = useState(""), [notice, setNotice] = useState("");
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead &&
        (!write || live.current.canManage);
    const writable = canRead && canManage;
    const clearSensitive = () => {
        setEnrollment(null);
        setRecoveryCodes([]);
        setPending(null);
        setConfirmed(false);
    };
    useEffect(() => { if (!canManage)
        clearSensitive(); }, [adapter, canManage]);
    useEffect(() => { void load(); return () => { serial.current++; live.current.epoch++; }; }, [adapter, canRead, canManage]);
    async function load() {
        if (!canRead) {
            setSelf(null);
            setManaged(null);
            clearSensitive();
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        try {
            const current = await adapter.read();
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validMfaState(current))
                throw Error("invalid");
            let directory = null;
            if (canManage && adapter.readManaged) {
                const value = await adapter.readManaged();
                if (!fresh(epoch, true) || ticket !== serial.current)
                    return;
                if (!validManagedMfaDirectory(value))
                    throw Error("invalid");
                directory = value;
            }
            setSelf(current);
            setManaged(directory);
            clearSensitive();
            setUncertain(false);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setSelf(null);
                setManaged(null);
                clearSensitive();
                setError("Cannot read valid current MFA state.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    function updateRecord(value) {
        setSelf(current => current?.subject === value.subject ? value : current);
        setManaged(current => current ? {
            ...current, records: current.records.map(record => record.subject === value.subject ? value : record)
        } : current);
    }
    async function beginEnrollment() {
        if (!writable || busy || uncertain || !self || self.enrolled || !adapter.beginEnrollment)
            return;
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        clearSensitive();
        try {
            const value = await adapter.beginEnrollment({
                expectedRevision: self.revision, issuer, accountLabel
            });
            if (!fresh(epoch, true))
                return;
            if (!validEnrollment(value))
                throw Error("invalid");
            setEnrollment(value);
        }
        catch {
            if (fresh(epoch, true))
                setError("Cannot start a current authorized MFA enrollment.");
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    async function confirmEnrollment(code) {
        if (!writable || busy || uncertain || !enrollment || !adapter.confirmEnrollment)
            return;
        const epoch = live.current.epoch;
        setBusy(true);
        setError("");
        setNotice("");
        setUncertain(true);
        try {
            const value = await adapter.confirmEnrollment({
                expectedRevision: enrollment.revision, enrollmentRef: enrollment.enrollmentRef, code
            });
            if (!fresh(epoch, true))
                return;
            if (!validRecovery(value) || value.subject !== self?.subject)
                throw Error("unverified");
            updateRecord(value);
            setEnrollment(null);
            setRecoveryCodes(value.recoveryCodes);
            setUncertain(false);
            setNotice("MFA enrollment confirmed and verified.");
        }
        catch {
            if (fresh(epoch)) {
                setEnrollment(null);
                setRecoveryCodes([]);
                setError("MFA enrollment status is unknown or stale. Refresh before retrying.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    function request(action) {
        if (!writable || busy || uncertain)
            return;
        setPending(action);
        setConfirmed(false);
        setError("");
        setNotice("");
    }
    async function runPending() {
        if (!writable || busy || uncertain || !pending || !confirmed)
            return;
        const epoch = live.current.epoch, action = pending;
        setBusy(true);
        setError("");
        setNotice("");
        let submitted = false;
        try {
            let result;
            let codes = [];
            if (action.kind === "regenerate") {
                if (!adapter.regenerateRecoveryCodes)
                    throw Error("unsupported");
                submitted = true;
                const value = await adapter.regenerateRecoveryCodes({ expectedRevision: action.revision, confirm: true });
                if (!validRecovery(value) || value.subject !== action.subject)
                    throw Error("unverified");
                result = value;
                codes = value.recoveryCodes;
            }
            else if (action.kind === "disable") {
                if (!adapter.disable)
                    throw Error("unsupported");
                submitted = true;
                const value = await adapter.disable({ expectedRevision: action.revision, confirm: true });
                if (!validMfaState(value) || value.subject !== action.subject || value.enrolled)
                    throw Error("unverified");
                result = value;
            }
            else if (action.kind === "require") {
                if (!adapter.setRequirement)
                    throw Error("unsupported");
                submitted = true;
                const value = await adapter.setRequirement(action.subject, {
                    expectedRevision: action.revision, required: action.required, confirm: true
                });
                if (!validMfaState(value) || value.subject !== action.subject || value.required !== action.required)
                    throw Error("unverified");
                result = value;
            }
            else {
                if (!adapter.reset)
                    throw Error("unsupported");
                submitted = true;
                const value = await adapter.reset(action.subject, { expectedRevision: action.revision, confirm: true });
                if (!validMfaState(value) || value.subject !== action.subject || value.enrolled)
                    throw Error("unverified");
                result = value;
            }
            if (!fresh(epoch, true))
                return;
            if (result.revision === action.revision)
                throw Error("unverified");
            if (action.subject === self?.subject) {
                const observed = await adapter.read();
                if (!fresh(epoch, true) || !validMfaState(observed) || observed.revision !== result.revision)
                    throw Error("unverified");
                updateRecord(observed);
            }
            else {
                if (!adapter.readManaged)
                    throw Error("unverified");
                const directory = await adapter.readManaged();
                if (!fresh(epoch, true) || !validManagedMfaDirectory(directory))
                    throw Error("unverified");
                const observed = directory.records.find(record => record.subject === action.subject);
                if (!observed || observed.revision !== result.revision)
                    throw Error("unverified");
                setManaged(directory);
            }
            setPending(null);
            setConfirmed(false);
            setUncertain(false);
            setRecoveryCodes(codes);
            setNotice(action.kind === "regenerate" ? "Recovery codes regenerated and verified." :
                action.kind === "disable" ? "MFA disabled and sessions invalidated." :
                    action.kind === "reset" ? "MFA reset and sessions invalidated." :
                        "MFA requirement updated and verified.");
        }
        catch {
            if (fresh(epoch)) {
                setPending(null);
                setConfirmed(false);
                setRecoveryCodes([]);
                setUncertain(submitted);
                setError(submitted ?
                    "MFA change status is unknown. Refresh and inspect audit before another change." :
                    "MFA action is unavailable for the current product authority.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "MFA management", children: _jsx("p", { role: "status", children: "MFA management is not authorized." }) });
    return _jsxs("section", { className: "dr-admin__mfa-management", "aria-label": "MFA management", children: [_jsxs("header", { children: [_jsx("h3", { children: "Multi-Factor Authentication" }), _jsx("p", { children: "Enroll authenticators, rotate recovery codes, enforce MFA policy and perform privileged resets." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh MFA" }), self ? _jsxs("section", { "aria-label": "My MFA status", children: [_jsx("h4", { children: "My MFA" }), _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Enrollment" }), _jsx("dd", { children: self.enrolled ? "Enrolled" : "Not enrolled" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Requirement" }), _jsx("dd", { children: self.required ? "Required" : "Optional" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Recovery codes" }), _jsx("dd", { children: self.recoveryCodesRemaining })] })] }), writable && !self.enrolled && adapter.beginEnrollment && adapter.confirmEnrollment ?
                        _jsx(Button, { disabled: busy || uncertain || Boolean(enrollment), onClick: () => void beginEnrollment(), children: "Enroll MFA" }) : null, writable && self.enrolled && adapter.regenerateRecoveryCodes ?
                        _jsx(Button, { variant: "secondary", disabled: busy || uncertain, onClick: () => request({ kind: "regenerate", subject: self.subject, revision: self.revision }), children: "Regenerate recovery codes" }) : null, writable && self.enrolled && !self.required && adapter.disable ?
                        _jsx(Button, { variant: "danger", disabled: busy || uncertain, onClick: () => request({ kind: "disable", subject: self.subject, revision: self.revision }), children: "Disable MFA" }) : null] }) : busy ? _jsx("p", { role: "status", children: "Loading MFA\u2026" }) : null, enrollment ? _jsxs("section", { "aria-label": "MFA enrollment", children: [_jsx(MfaEnrollmentPanel, { material: enrollment, onConfirm: confirmEnrollment, busy: busy }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => setEnrollment(null), children: "Cancel enrollment" })] }) : null, recoveryCodes.length ? _jsx(RecoveryCodesPanel, { codes: recoveryCodes, onContinue: () => { setRecoveryCodes([]); void load(); } }) : null, managed ? _jsxs("section", { "aria-label": "Managed MFA accounts", children: [_jsx("h4", { children: "Managed accounts" }), _jsx("ul", { children: managed.records.map(record => _jsxs("li", { children: [_jsx("strong", { children: record.subject }), " \u00B7 ", record.enrolled ? "Enrolled" : "Not enrolled", " \u00B7", record.required ? " Required" : " Optional", " \u00B7 ", record.recoveryCodesRemaining, " recovery codes", writable && adapter.setRequirement && record.enrolled ?
                                    _jsxs(Button, { variant: "secondary", disabled: busy || uncertain, onClick: () => request({ kind: "require", subject: record.subject, revision: record.revision,
                                            required: !record.required }), children: [record.required ? "Remove MFA requirement for " : "Require MFA for ", record.subject] }) : null, writable && adapter.reset ?
                                    _jsxs(Button, { variant: "danger", disabled: busy || uncertain, onClick: () => request({ kind: "reset", subject: record.subject, revision: record.revision }), children: ["Reset MFA for ", record.subject] }) : null] }, record.subject)) })] }) : null, pending ? _jsxs("section", { "aria-label": "MFA change confirmation", children: [_jsx("h4", { children: "Confirm MFA change" }), _jsxs("p", { children: [pending.kind === "regenerate" ? "Replace every current recovery code" :
                                pending.kind === "disable" ? "Disable MFA and invalidate current sessions" :
                                    pending.kind === "reset" ? "Reset enrolled MFA material and invalidate current sessions" :
                                        pending.required ? "Require MFA for this account" : "Remove the MFA requirement for this account", ".", " ", "Target: ", _jsx("strong", { children: pending.subject })] }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: event => setConfirmed(event.target.checked) }), "I confirm this MFA change"] }), _jsx(Button, { disabled: busy || uncertain || !confirmed, onClick: () => void runPending(), children: "Apply MFA change" }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => { setPending(null); setConfirmed(false); }, children: "Cancel" })] }) : null] });
}
