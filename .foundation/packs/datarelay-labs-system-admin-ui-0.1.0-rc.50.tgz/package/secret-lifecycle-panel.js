import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { SECRET_ROTATION_BLOCKERS } from "@datarelay-labs/system-contracts";
const KINDS = {
    application_credential: "Application credential",
    encryption_key: "Encryption key",
    tls_private_key: "TLS private key",
    transport_credential: "Transport credential"
};
const HEALTH = {
    invalid_evidence: "Metadata invalid",
    healthy: "Healthy",
    rotation_due: "Rotation due",
    expiring: "Expiring",
    expired: "Expired",
    disabled: "Disabled",
    compromised: "Compromised",
    revoked: "Revoked"
};
const ROTATION_REASONS = {
    unsupported_backend: "Product secret backend unavailable",
    unauthorized: "Actor lacks product rotation permission",
    mfa_required: "Recent MFA verification required",
    stale_revision: "Product secret revision has changed",
    not_active: "Secret is not active",
    rotation_disabled: "Manual rotation is not enabled",
    recovery_not_verified: "Recovery copy not verified",
    rollback_not_ready: "Rollback capability is not ready",
    bindings_unprepared: "Dependent bindings are not prepared",
    active_consumers: "Active consumers require draining",
    audit_unavailable: "Audit persistence is not ready"
};
const REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const MAX_UNIX_SECONDS = 253402300799;
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function onlyKeys(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validSeconds(value) {
    return value === null || value === undefined ||
        (typeof value === "number" && Number.isSafeInteger(value) &&
            value >= 0 && value <= MAX_UNIX_SECONDS);
}
function validLifecycle(value) {
    if (!object(value) || !onlyKeys(value, ["reference", "revision", "kind", "health", "expiresAt",
        "rotatedAt", "dependencyCount", "rotationPreview"]) ||
        typeof value.reference !== "string" || !REFERENCE.test(value.reference) ||
        typeof value.revision !== "string" || !REFERENCE.test(value.revision) ||
        typeof value.kind !== "string" || !Object.hasOwn(KINDS, value.kind) ||
        typeof value.health !== "string" || !Object.hasOwn(HEALTH, value.health) ||
        typeof value.dependencyCount !== "number" ||
        !Number.isSafeInteger(value.dependencyCount) ||
        value.dependencyCount < 0 || value.dependencyCount > 1_000_000 ||
        !validSeconds(value.expiresAt) || !validSeconds(value.rotatedAt))
        return false;
    if (value.rotationPreview !== undefined) {
        const preview = value.rotationPreview;
        if (!object(preview) ||
            !onlyKeys(preview, [
                "reference", "expectedRevision", "canProceedToProductAuthority",
                "blockers", "requiresProductApply"
            ]) ||
            typeof preview.reference !== "string" || !REFERENCE.test(preview.reference) ||
            typeof preview.expectedRevision !== "string" || !REFERENCE.test(preview.expectedRevision) ||
            preview.requiresProductApply !== true ||
            typeof preview.canProceedToProductAuthority !== "boolean" ||
            !Array.isArray(preview.blockers) ||
            preview.blockers.length > SECRET_ROTATION_BLOCKERS.length)
            return false;
        const seen = new Set();
        for (const item of preview.blockers) {
            if (typeof item !== "string" ||
                !SECRET_ROTATION_BLOCKERS.includes(item) ||
                seen.has(item))
                return false;
            seen.add(item);
        }
        if (preview.canProceedToProductAuthority && preview.blockers.length)
            return false;
    }
    return true;
}
function reviewEligible(value) {
    const p = value.rotationPreview;
    return value.health !== "compromised" &&
        value.health !== "revoked" &&
        value.health !== "disabled" &&
        value.health !== "invalid_evidence" &&
        p !== undefined && p.reference === value.reference &&
        p.expectedRevision === value.revision &&
        p.canProceedToProductAuthority === true && p.blockers.length === 0;
}
function dateLabel(seconds) {
    return seconds === null || seconds === undefined
        ? "Not provided by product" : new Date(seconds * 1000).toISOString().slice(0, 10) + " UTC";
}
/** Metadata-only shared UI. Never access secret values, KMS, privileged host,
 * product role state or a rotation endpoint. All labels are safe literals. */
export function SecretLifecyclePanel({ secrets, triageLoadedSecretHealth = false, reviewAvailability = "unknown", onReviewRotation, pendingReviewReference }) {
    const [attentionOnly, setAttentionOnly] = useState(false);
    const loaded = [];
    const seen = new Set();
    for (let index = 0; index < secrets.length; index += 1) {
        const candidate = secrets[index];
        if (!validLifecycle(candidate) || seen.has(candidate.reference))
            continue;
        seen.add(candidate.reference);
        loaded.push({ secret: candidate, index });
    }
    const shown = triageLoadedSecretHealth && attentionOnly
        ? loaded.filter(({ secret }) => secret.health !== "healthy") : loaded;
    const withheld = secrets.length - loaded.length;
    if (secrets.length === 0)
        return _jsx(EmptyState, { title: "No secret lifecycle summaries", description: "No secret lifecycle summaries supplied by the product. No rotation is available." });
    return (_jsxs("section", { className: "dr-admin__secrets", "aria-label": "Key and credential lifecycle", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Key and credential lifecycle" }), _jsx(StatusBadge, { tone: "neutral", children: "Product metadata only" })] }), _jsx("p", { className: "dr-admin__muted", children: "Secret material is never displayed" }), triageLoadedSecretHealth ? (_jsxs("label", { className: "dr-admin__secrets-triage", children: [_jsx("input", { type: "checkbox", checked: attentionOnly, onChange: (event) => setAttentionOnly(event.target.checked) }), "Show only secrets needing attention"] })) : null, _jsxs("p", { role: "status", "aria-live": "polite", className: "dr-admin__muted", children: ["Showing ", shown.length, " of ", secrets.length, " loaded secret summaries."] }), withheld > 0 ? _jsxs("p", { role: "alert", className: "dr-admin__secrets-invalid", children: [withheld, " invalid or duplicate secret entries withheld"] }) : null, shown.length ? (_jsx("ul", { className: "dr-admin__secrets-list", "aria-label": "Loaded secret lifecycle summaries", children: shown.map(({ secret, index }) => {
                    const label = KINDS[secret.kind] + " " + (index + 1);
                    const eligible = reviewEligible(secret);
                    const canReview = eligible && reviewAvailability === "supported" &&
                        typeof onReviewRotation === "function";
                    const preview = secret.rotationPreview;
                    const tone = secret.health === "healthy" ? "success" :
                        secret.health === "compromised" || secret.health === "revoked" ||
                            secret.health === "expired" ? "critical" : "warning";
                    return (_jsxs("li", { className: "dr-admin__secrets-card", children: [_jsxs("div", { className: "dr-admin__secrets-heading", children: [_jsx("strong", { children: label }), _jsx(StatusBadge, { tone: tone, children: HEALTH[secret.health] })] }), _jsxs("dl", { className: "dr-admin__secrets-facts", children: [_jsxs("div", { children: [_jsx("dt", { children: "Dependencies" }), _jsxs("dd", { children: [secret.dependencyCount, " dependent bindings"] })] }), _jsxs("div", { children: [_jsx("dt", { children: "Last rotation" }), _jsx("dd", { children: dateLabel(secret.rotatedAt) })] }), _jsxs("div", { children: [_jsx("dt", { children: "Expires" }), _jsx("dd", { children: dateLabel(secret.expiresAt) })] })] }), preview ? (_jsxs("div", { className: "dr-admin__secrets-preview", children: [preview.reference !== secret.reference ?
                                        _jsx("p", { children: "Rotation preview references another secret" }) : null, preview.expectedRevision !== secret.revision ?
                                        _jsx("p", { children: "Rotation preview revision does not match" }) : null, preview.blockers.map((item) => _jsx("p", { children: ROTATION_REASONS[item] }, item)), eligible ? _jsx("p", { children: "Product rotation review prerequisites supplied" }) : null] })) : _jsx("p", { className: "dr-admin__muted", children: "Product rotation preview unavailable" }), canReview ? (_jsxs(Button, { type: "button", variant: "secondary", disabled: pendingReviewReference === secret.reference, onClick: () => onReviewRotation?.(secret.reference, secret.revision), children: ["Review rotation for ", label] })) : _jsx("p", { className: "dr-admin__muted", children: "Actual rotation requires product authorization and explicit confirmation." })] }, secret.reference));
                }) })) : _jsx("p", { children: "No currently loaded secret requires attention. Product data is unchanged." })] }));
}
