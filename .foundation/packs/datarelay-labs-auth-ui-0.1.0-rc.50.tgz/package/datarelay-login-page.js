import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId, useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { AuthLayout } from "./auth-layout.js";
import { ControlLoginForm } from "./control-login-form.js";
import { MfaChallengeForm } from "./mfa.js";
export const DEFAULT_DATARELAY_LOGIN_RESOURCES = [
    { title: "Documentation", description: "datarelay.run/docs", href: "https://datarelay.run/docs", external: true },
    { title: "Quick Start Guide", description: "datarelay.run/quickstart", href: "https://datarelay.run/quickstart", external: true },
    { title: "Release Notes", description: "datarelay.run/releases", href: "https://datarelay.run/releases", external: true },
    { title: "DataRelay Website", description: "datarelay.run", href: "https://datarelay.run", external: true },
    { title: "Support", description: "support@datarelay.run", href: "mailto:support@datarelay.run" }
];
const DEFAULT_PRODUCT_NAME = "DataRelay";
const DEFAULT_PRODUCT_SUBTITLE = "Operational Data Connector Platform";
const DEFAULT_DESCRIPTION = "Collect. Transform. Deliver. Connect to any source, transform and enrich your data, then deliver it to multiple destinations reliably and securely.";
const DEFAULT_LOGIN_TITLE = "Welcome to DataRelay";
const DEFAULT_LOGIN_SUBTITLE = "Please sign in to continue.";
const DEFAULT_ACCOUNT_NOTICE = "Accounts are created by an administrator. Self-service registration is not available.";
export function DataRelayLogoMark({ label = "DataRelay logo", className, ...props }) {
    const gradientId = `dr-datarelay-login-${useId().replace(/:/g, "")}`;
    return (_jsxs("svg", { ...props, className: ["dr-datarelay-logo", className].filter(Boolean).join(" "), viewBox: "0 0 169 108", fill: "none", role: "img", "aria-label": label, xmlns: "http://www.w3.org/2000/svg", children: [_jsx("defs", { children: _jsxs("linearGradient", { id: gradientId, x1: "0", y1: "0", x2: "169", y2: "108", gradientUnits: "userSpaceOnUse", children: [_jsx("stop", { offset: "0", stopColor: "#2563EB" }), _jsx("stop", { offset: "0.5", stopColor: "#38BDF8" }), _jsx("stop", { offset: "1", stopColor: "#10B981" })] }) }), _jsx("path", { d: "M114 76 L136 107 L168 107 L167 104 L161 97 L146 75 L142 75 L141 76 Z", fill: `url(#${gradientId})` }), _jsx("path", { d: "M164 18 L160 12 L155 7 L146 2 L139 0 L91 0 L92 3 L102 15 L106 23 L135 23 L139 25 L142 28 L144 34 L142 41 L135 46 L101 46 L100 47 L95 47 L88 49 L79 54 L73 60 L63 74 L58 79 L48 84 L29 84 L28 83 L28 37 L12 37 L8 39 L2 48 L2 107 L51 107 L52 106 L60 105 L73 98 L83 88 L92 76 L98 71 L105 70 L106 69 L137 69 L138 68 L143 68 L150 65 L156 61 L161 56 L167 44 L168 31 L167 30 L167 25 Z", fill: `url(#${gradientId})` }), _jsx("path", { d: "M0 1 L3 14 L7 22 L9 23 L51 23 L52 24 L55 24 L64 30 L71 40 L73 49 L85 42 L97 39 L97 37 L92 27 L84 16 L76 9 L65 3 L59 1 L55 1 L54 0 L1 0 Z", fill: `url(#${gradientId})` })] }));
}
function DataRelayLoginCanvas({ presentation, title, subtitle, children }) {
    return (_jsx("div", { className: "dr-login-canvas", children: _jsx(AuthLayout, { className: "dr-login-page", productName: presentation.productName, ...(presentation.productSubtitle ? { productSubtitle: presentation.productSubtitle } : {}), ...(presentation.description ? { description: presentation.description } : {}), title: title, ...(subtitle ? { subtitle } : {}), resources: presentation.resources, brandMark: presentation.brandMark, showWordmark: false, children: children }) }));
}
export function DataRelayLoginPage({ productName = DEFAULT_PRODUCT_NAME, productSubtitle = DEFAULT_PRODUCT_SUBTITLE, description = DEFAULT_DESCRIPTION, title = DEFAULT_LOGIN_TITLE, subtitle = DEFAULT_LOGIN_SUBTITLE, resources = DEFAULT_DATARELAY_LOGIN_RESOURCES, brandMark = _jsx(DataRelayLogoMark, {}), submitLabel = "Sign In", allowPasswordReveal = true, accountNotice = DEFAULT_ACCOUNT_NOTICE, ...formProps }) {
    return (_jsx(DataRelayLoginCanvas, { presentation: { productName, productSubtitle, description, resources, brandMark }, title: title, subtitle: subtitle, children: _jsx(ControlLoginForm, { ...formProps, submitLabel: submitLabel, allowPasswordReveal: allowPasswordReveal, accountNotice: accountNotice }) }));
}
function defaultAuthError(error) {
    return {
        category: "failed",
        message: error instanceof Error ? error.message : "Sign-in failed."
    };
}
export function DataRelayLoginFlow({ adapter, onAuthenticated, onPasswordChangeRequired, mapError = defaultAuthError, productName = DEFAULT_PRODUCT_NAME, productSubtitle = DEFAULT_PRODUCT_SUBTITLE, description = DEFAULT_DESCRIPTION, title = DEFAULT_LOGIN_TITLE, subtitle = DEFAULT_LOGIN_SUBTITLE, resources = DEFAULT_DATARELAY_LOGIN_RESOURCES, brandMark = _jsx(DataRelayLogoMark, {}), submitLabel = "Sign In", allowPasswordReveal = true, accountNotice = DEFAULT_ACCOUNT_NOTICE, initialUsername = "", infoMessage }) {
    const presentation = {
        productName,
        productSubtitle,
        description,
        resources,
        brandMark
    };
    const [step, setStep] = useState({ kind: "credentials", username: initialUsername });
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState(null);
    async function consumeResult(result, username) {
        if (result.state === "authenticated") {
            setError(null);
            setStep({ kind: "credentials", username });
            await onAuthenticated?.(result.principal);
            return;
        }
        if (result.state === "password_change_required") {
            if (onPasswordChangeRequired) {
                setError(null);
                await onPasswordChangeRequired(result.principal);
            }
            else {
                setError({
                    category: "unavailable",
                    message: "Password change is required, but no product password-change handler is available."
                });
            }
            return;
        }
        if (!adapter.verifyMfa) {
            setError({
                category: "unavailable",
                message: "MFA verification is not available. Contact your administrator."
            });
            return;
        }
        setError(null);
        setStep({
            kind: "mfa",
            username,
            methods: result.methods.length ? result.methods : ["totp"],
            ...(result.challengeRef ? { challengeRef: result.challengeRef } : {})
        });
    }
    async function submitCredentials(credentials) {
        setBusy(true);
        setError(null);
        try {
            const result = await adapter.signIn(credentials);
            await consumeResult(result, credentials.username);
        }
        catch (cause) {
            setError(mapError(cause));
        }
        finally {
            setBusy(false);
        }
    }
    async function submitMfa(request) {
        if (!adapter.verifyMfa || step.kind !== "mfa")
            return;
        setBusy(true);
        setError(null);
        try {
            const result = await adapter.verifyMfa(request);
            await consumeResult(result, step.username);
        }
        catch (cause) {
            setError(mapError(cause));
        }
        finally {
            setBusy(false);
        }
    }
    if (step.kind === "mfa") {
        return (_jsx(DataRelayLoginCanvas, { presentation: presentation, title: "Verify your sign-in", subtitle: "Enter the code from your authenticator app, or use a recovery code if available.", children: _jsxs("div", { className: "dr-login-page__form", children: [_jsx(MfaChallengeForm, { methods: step.methods, ...(step.challengeRef ? { challengeRef: step.challengeRef } : {}), onSubmit: submitMfa, busy: busy, autoFocus: true, ...(error ? { errorCategory: error.category, errorMessage: error.message } : {}) }), _jsx(Button, { type: "button", variant: "ghost", disabled: busy, onClick: () => {
                            setError(null);
                            setStep({ kind: "credentials", username: step.username });
                        }, children: "Back to sign in" })] }) }));
    }
    return (_jsx(DataRelayLoginPage, { productName: productName, productSubtitle: productSubtitle, description: description, title: title, subtitle: subtitle, resources: resources, brandMark: brandMark, submitLabel: submitLabel, allowPasswordReveal: allowPasswordReveal, accountNotice: accountNotice, initialUsername: step.username, onSubmit: submitCredentials, busy: busy, ...(infoMessage ? { infoMessage } : {}), ...(error ? { errorCategory: error.category, errorMessage: error.message } : {}) }));
}
