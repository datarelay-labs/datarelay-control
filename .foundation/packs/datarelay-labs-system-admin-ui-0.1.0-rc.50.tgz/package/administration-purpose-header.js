import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { DataRelayIcon } from "@datarelay-labs/icons";
export function AdministrationPurposeHeader({ purpose, actions, help }) {
    const [open, setOpen] = useState(false);
    const triggerRef = useRef(null);
    const closeRef = useRef(null);
    useEffect(() => {
        if (!open)
            return;
        closeRef.current?.focus();
        const onKeyDown = (event) => {
            if (event.key === "Escape") {
                setOpen(false);
                queueMicrotask(() => triggerRef.current?.focus());
            }
        };
        document.addEventListener("keydown", onKeyDown);
        return () => document.removeEventListener("keydown", onKeyDown);
    }, [open]);
    return (_jsxs(_Fragment, { children: [_jsxs("header", { className: "dr-admin-purpose", children: [_jsx("p", { children: purpose }), _jsxs("div", { className: "dr-admin-purpose__actions", children: [actions, _jsxs("button", { ref: triggerRef, type: "button", className: "dr-admin-purpose__button", onClick: () => setOpen(true), "aria-expanded": open, "aria-haspopup": "dialog", children: [_jsx(DataRelayIcon, { name: "help", width: 16, height: 16 }), "Help"] })] })] }), open ? (_jsxs(_Fragment, { children: [_jsx("button", { type: "button", tabIndex: -1, "aria-hidden": "true", className: "dr-admin-purpose__backdrop", onClick: () => setOpen(false) }), _jsxs("aside", { className: "dr-admin-purpose__drawer", role: "dialog", "aria-modal": "true", "aria-label": help.title, children: [_jsxs("div", { className: "dr-admin-purpose__drawer-head", children: [_jsxs("div", { children: [_jsx("small", { children: "Page help" }), _jsx("h2", { children: help.title })] }), _jsx("button", { ref: closeRef, type: "button", className: "dr-admin-purpose__icon-button", "aria-label": "Close help", onClick: () => {
                                            setOpen(false);
                                            queueMicrotask(() => triggerRef.current?.focus());
                                        }, children: _jsx(DataRelayIcon, { name: "close", width: 16, height: 16 }) })] }), _jsxs("div", { className: "dr-admin-purpose__drawer-body", children: [_jsx("p", { children: help.intro }), help.sections.map((section) => (_jsxs("section", { children: [_jsx("h3", { children: section.title }), section.body ? _jsx("p", { children: section.body }) : null, section.bullets?.length ? (_jsx("ul", { children: section.bullets.map((bullet) => _jsx("li", { children: bullet }, bullet)) })) : null] }, section.title)))] })] })] })) : null] }));
}
