import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { BACKUP_POLICY_BLOCKERS } from "@datarelay-labs/system-contracts";
const REVISION = /^[a-z][a-z0-9_.-]{0,95}$/;
const DAY = 86400;
const LABELS = {
    scheduler_unavailable: "Product scheduler unavailable",
    encrypted_storage_unverified: "Encrypted backup storage not verified",
    restore_drill_unverified: "Product restore-drill proof not verified",
    permission_denied: "Product permission denied",
    mfa_required: "Recent privileged MFA is required",
    rollback_unavailable: "Backup policy rollback unavailable",
    audit_unavailable: "Product audit not ready",
    stale_revision: "Backup policy revision changed",
    weakening_prohibited: "Proposed policy weakens recovery safeguards"
};
const FIELDS = [
    ["Backup interval (seconds)", "scheduleSeconds"],
    ["Maximum acceptable backup age (seconds)", "maxAcceptableAgeSeconds"],
    ["Retained backup versions", "keepLast"],
    ["Restore proof maximum age (seconds)", "maxRestoreProofAgeSeconds"],
    ["Backup encryption required", "requireEncryption"],
    ["Verified restore drill required", "requireRestoreDrill"]
];
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exact(value, expected) {
    return Object.keys(value).every((key) => expected.includes(key));
}
function bounded(v, min, max) {
    return typeof v === "number" && Number.isSafeInteger(v) && v >= min && v <= max;
}
function validSnapshot(v) {
    if (!object(v) || !exact(v, [
        "scheduleSeconds", "maxAcceptableAgeSeconds", "keepLast",
        "maxRestoreProofAgeSeconds", "requireEncryption", "requireRestoreDrill"
    ]) || !bounded(v.scheduleSeconds, 3600, 365 * DAY) ||
        !bounded(v.maxAcceptableAgeSeconds, v.scheduleSeconds, 3650 * DAY) ||
        !bounded(v.keepLast, 1, 365) ||
        !bounded(v.maxRestoreProofAgeSeconds, 3600, 3650 * DAY) ||
        typeof v.requireEncryption !== "boolean" ||
        typeof v.requireRestoreDrill !== "boolean")
        return false;
    return true;
}
function valid(v) {
    if (!object(v) || !exact(v, ["revision", "effective", "proposed", "preflight"]) ||
        typeof v.revision !== "string" || !REVISION.test(v.revision) ||
        !validSnapshot(v.effective) ||
        (v.proposed !== undefined && !validSnapshot(v.proposed)))
        return false;
    if (v.preflight !== undefined) {
        const p = v.preflight;
        if (!object(p) || !exact(p, [
            "expectedRevision", "allowed", "blockers", "productApplyRequired",
            "schedulerVerified", "encryptedStorageVerified", "isolatedRestoreDrillVerified",
            "actorAuthorized", "recentMfaVerified", "rollbackReady", "auditReady"
        ]) || typeof p.expectedRevision !== "string" || !REVISION.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" || p.productApplyRequired !== true ||
            !Array.isArray(p.blockers) || p.blockers.length > BACKUP_POLICY_BLOCKERS.length)
            return false;
        for (const key of [
            "schedulerVerified", "encryptedStorageVerified", "isolatedRestoreDrillVerified",
            "actorAuthorized", "recentMfaVerified", "rollbackReady", "auditReady"
        ])
            if (typeof p[key] !== "boolean")
                return false;
        const seen = new Set();
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !BACKUP_POLICY_BLOCKERS.includes(blocker) ||
                seen.has(blocker))
                return false;
            seen.add(blocker);
        }
        if (p.allowed && p.blockers.length > 0)
            return false;
    }
    return true;
}
function changed(a, b) {
    return FIELDS.some(([, key]) => a[key] !== b[key]);
}
function weakens(a, b) {
    return b.scheduleSeconds > a.scheduleSeconds ||
        b.maxAcceptableAgeSeconds > a.maxAcceptableAgeSeconds ||
        b.keepLast < a.keepLast ||
        b.maxRestoreProofAgeSeconds > a.maxRestoreProofAgeSeconds ||
        (a.requireEncryption && !b.requireEncryption) ||
        (a.requireRestoreDrill && !b.requireRestoreDrill);
}
function formatValue(v) {
    return typeof v === "boolean" ? (v ? "Yes" : "No") : String(v);
}
/** Product-neutral schedule, retention and proof-policy review only.
 * No real archive/file/S3/DB/restore access, no task scheduling or mutation. */
export function BackupPolicyReviewPanel({ projection, reviewAvailability = "unknown", onReviewBackupPolicy, pending = false }) {
    const validInput = valid(projection);
    const value = validInput ? projection : undefined;
    const effective = value?.effective;
    const proposed = value?.proposed;
    const preview = value?.preflight;
    const diff = Boolean(effective && proposed && changed(effective, proposed));
    const weakening = Boolean(effective && proposed && weakens(effective, proposed));
    const insecure = Boolean(effective && proposed &&
        (!proposed.requireEncryption || !proposed.requireRestoreDrill));
    const stale = Boolean(preview && preview.expectedRevision !== value?.revision);
    const checks = Boolean(preview && preview.schedulerVerified &&
        preview.encryptedStorageVerified && preview.isolatedRestoreDrillVerified &&
        preview.actorAuthorized && preview.recentMfaVerified &&
        preview.rollbackReady && preview.auditReady);
    const eligible = Boolean(diff && !weakening && !insecure && !stale &&
        checks && preview?.allowed && preview.blockers.length === 0);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewBackupPolicy === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Backup policy unavailable", description: "Backup policy unavailable. No retention or scheduler settings are inferred." });
    return (_jsxs("section", { className: "dr-admin__backup-policy", "aria-label": "Backup schedule and retention review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Backup schedule and retention" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Backup policy: ", eligible ? "review eligible" : validInput ? "review unavailable" : "unknown"] })] }), !validInput ? _jsx("p", { children: "Invalid backup policy projection" }) : null, value && effective ? (_jsxs(_Fragment, { children: [_jsx("h3", { children: "Current product backup policy" }), _jsx("p", { children: "A configuration export does not prove operational disaster recovery" }), _jsx("p", { className: "dr-admin__muted", children: "Read-only product scheduling preview; no backup is created." }), _jsx("div", { className: "dr-admin__backup-policy-table", children: _jsxs("table", { "aria-label": "Backup policy comparison", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsx("tbody", { children: FIELDS.map(([text, key]) => (_jsxs("tr", { children: [_jsx("th", { scope: "row", children: text }), _jsx("td", { children: formatValue(effective[key]) }), _jsx("td", { children: proposed ? formatValue(proposed[key]) : "Not supplied" })] }, key))) })] }) }), !diff ? _jsx("p", { children: "No backup policy changes proposed" }) : null, weakening ? _jsx("p", { children: "Proposed backup policy weakens the effective recovery safeguards" }) : null, insecure ? _jsx("p", { children: "Operational backups require encryption and restore-drill evidence" }) : null, !preview ? _jsx("p", { children: "Product backup policy change preview unavailable" }) : null, stale ? _jsx("p", { children: "Backup policy preview is stale" }) : null, preview ? (_jsxs("div", { className: "dr-admin__backup-policy-preflight", children: [!preview.schedulerVerified ? _jsx("p", { children: "Product backup scheduler not verified" }) : null, !preview.encryptedStorageVerified ? _jsx("p", { children: "Encrypted backup storage not verified" }) : null, !preview.isolatedRestoreDrillVerified ? _jsx("p", { children: "Isolated test restore not verified" }) : null, !preview.actorAuthorized ? _jsx("p", { children: "Actor authorization not verified" }) : null, !preview.recentMfaVerified ? _jsx("p", { children: "Recent MFA verification not confirmed" }) : null, !preview.rollbackReady ? _jsx("p", { children: "Rollback readiness not verified" }) : null, !preview.auditReady ? _jsx("p", { children: "Audit readiness not verified" }) : null, preview.blockers.map((b) => _jsx("p", { children: LABELS[b] }, b))] })) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewBackupPolicy?.(value.revision), children: "Review backup policy" })) : (_jsx("p", { className: "dr-admin__muted", children: "Product authorization and verified retention, encryption, restore and rollback are required." }))] })) : null] }));
}
