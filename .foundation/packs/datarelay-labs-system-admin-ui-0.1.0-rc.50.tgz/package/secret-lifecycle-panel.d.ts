import { type CapabilityAvailability, type SecretLifecycleProjection } from "@datarelay-labs/system-contracts";
export type SecretLifecyclePanelProps = {
    /** Validated, current, already-authorized Python SecretPublicSummary projection. */
    secrets: readonly SecretLifecycleProjection[];
    /** Opt-in attention filtering over only already-loaded secret metadata. */
    triageLoadedSecretHealth?: boolean;
    /** Product's current authoritative actor access, not inferred from frontend roles. */
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Opens a product-owned review only; no actual secret material or rotation. */
    onReviewRotation?: (reference: string, revision: string) => void | Promise<void>;
    pendingReviewReference?: string;
};
/** Metadata-only shared UI. Never access secret values, KMS, privileged host,
 * product role state or a rotation endpoint. All labels are safe literals. */
export declare function SecretLifecyclePanel({ secrets, triageLoadedSecretHealth, reviewAvailability, onReviewRotation, pendingReviewReference }: SecretLifecyclePanelProps): import("react").JSX.Element;
