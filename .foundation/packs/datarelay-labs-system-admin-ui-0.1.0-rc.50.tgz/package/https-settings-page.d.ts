import type { OperationPreview, TlsAdapter } from "@datarelay-labs/system-contracts";
export type HttpsConfiguration = {
    enabled: boolean;
    certificateIpAddresses: readonly string[];
    certificateDnsNames: readonly string[];
    redirectHttpToHttps: boolean;
    certificateValidDays: number;
};
export type HttpsSettingsState = HttpsConfiguration & {
    httpListenerActive: boolean;
    httpsListenerActive: boolean;
    redirectEffective: boolean;
    proxyStatus: "ok" | "degraded" | "unknown" | "not_configured";
    proxyHealthOk: boolean | null;
    currentAccessUrl: string;
    browserHttpUrl: string;
    browserHttpsUrl: string | null;
    certificateNotAfter: string | null;
    restartRequired: boolean;
    proxyFallbackToHttp: boolean;
};
export type HttpsSettingsDraft = HttpsConfiguration & {
    regenerateCertificate: boolean;
    expectedRevision: string;
};
export type HttpsSafetyEvidence = {
    expectedRevision: string;
    safe: boolean;
    blockers: readonly string[];
    rollbackAvailable: boolean;
    recentMfaVerified: boolean;
    recoveryUrl?: string;
};
export type HttpsSettingsAdapter = TlsAdapter<HttpsSettingsState, HttpsSettingsDraft, HttpsSafetyEvidence> & {
    preview: (draft: HttpsSettingsDraft) => Promise<OperationPreview<HttpsSafetyEvidence>>;
};
export type HttpsSettingsPageProps = {
    adapter: HttpsSettingsAdapter;
    canManage?: boolean;
};
/** Common SAN validation; certificate/key/chain/issuer policy remains enforced by Core. */
export declare function validateHttpsConfiguration(value: unknown): string | null;
/** Complete Control-reference form. Only the injected, authorized TLS adapter has host effects. */
export declare function HttpsSettingsPage({ adapter, canManage }: HttpsSettingsPageProps): import("react").JSX.Element;
