import type { AuditEventProjection } from "@datarelay-labs/system-contracts";
export type AuditListProps = {
    events: readonly AuditEventProjection[];
    /** Local substring search over events already supplied by the product. */
    filterLoadedAuditEvents?: boolean;
    /** Exact outcome selector over only the currently loaded events; also enables search. */
    filterLoadedAuditOutcomes?: boolean;
    /** Exact local action/type facet over already loaded event actions; also enables search. */
    filterLoadedAuditActions?: boolean;
    /** Exact local actor-label facet, derived solely from loaded product audit projections. */
    filterLoadedAuditActors?: boolean;
    /** Optional date-only UTC window over events currently loaded by the product. */
    filterLoadedAuditTimeRange?: boolean;
    /** Opt in to sorting only the visible, product-supplied audit rows. */
    sortLoadedAuditEvents?: boolean;
    /** Opt-in local display selection of existing loaded audit columns. */
    customizeLoadedAuditColumns?: boolean;
    /** Optional reset of local search, outcome, action and UTC date filters. */
    resetLoadedAuditFilters?: boolean;
};
export declare function AuditList({ events, filterLoadedAuditEvents, filterLoadedAuditOutcomes, filterLoadedAuditActions, filterLoadedAuditActors, filterLoadedAuditTimeRange, sortLoadedAuditEvents, customizeLoadedAuditColumns, resetLoadedAuditFilters }: AuditListProps): import("react").JSX.Element;
