import type { AuthErrorCategory, LoginSubmission } from "./types";
export type LoginFormProps = {
    onSubmit: (submission: LoginSubmission) => void | Promise<void>;
    busy?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
    infoMessage?: string;
    initialUsername?: string;
    submitLabel?: string;
    usernamePlaceholder?: string;
    passwordPlaceholder?: string;
    /** Opt in to an accessible plaintext reveal toggle; default is masked. */
    allowPasswordReveal?: boolean;
};
export declare function LoginForm({ onSubmit, busy, errorCategory, errorMessage, infoMessage, initialUsername, submitLabel, usernamePlaceholder, passwordPlaceholder, allowPasswordReveal }: LoginFormProps): import("react").JSX.Element;
