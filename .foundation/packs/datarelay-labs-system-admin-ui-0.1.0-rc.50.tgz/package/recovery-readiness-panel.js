import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { RECOVERY_BACKUP_PROBLEMS, RECOVERY_RESTORE_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const KINDS = { configuration_export: "Configuration export", disaster_recovery: "Operational recovery backup" };
const STATES = { succeeded: "succeeded", failed: "failed", incomplete: "incomplete" };
const BACKUP_REASONS = {
    wrong_backup_kind: "Logical configuration export is not an operational backup",
    not_complete: "Backup has not completed successfully",
    zero_length: "Backup has no recorded archive bytes",
    unencrypted: "Backup lacks encrypted-at-rest proof",
    future_evidence: "Backup or drill evidence is future-dated",
    overdue: "Backup does not meet the product age policy",
    restore_not_verified: "No verified restore drill was reported",
    restore_evidence_stale: "Restore drill evidence is stale"
};
const RESTORE_REASONS = {
    wrong_product: "Backup belongs to another product",
    stale_backup_revision: "Backup revision is stale",
    not_operational_backup: "This is not an operational disaster recovery backup",
    incomplete_backup: "Backup is incomplete",
    unencrypted_backup: "Backup encryption is missing",
    restore_proof_missing: "Restore-drill proof is missing",
    future_evidence: "Restore evidence was recorded in the future",
    restore_proof_stale: "Restore proof is stale",
    unsupported: "Product restore backend is unavailable",
    permission_denied: "Actor lacks product restore permission",
    mfa_required: "Recent privileged MFA is required",
    integrity_unverified: "Backup artifact byte integrity is not verified",
    schema_unverified: "Backup schema compatibility is unverified",
    restore_drill_missing: "Isolated test restore was not verified",
    current_backup_missing: "Current state backup is not verified",
    rollback_not_ready: "Rollback capability is not ready",
    offline_recovery_required: "Out-of-band recovery path is unavailable",
    audit_unavailable: "Recovery audit readiness is unavailable"
};
function record(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function exact(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validEnumList(value, options) {
    if (!Array.isArray(value) || value.length > options.length)
        return false;
    const seen = new Set();
    for (const item of value) {
        if (typeof item !== "string" || !options.includes(item) || seen.has(item))
            return false;
        seen.add(item);
    }
    return true;
}
function validBackup(value) {
    if (!record(value) ||
        !exact(value, ["reference", "revision", "kind", "state", "assessment", "restorePreview"]) ||
        typeof value.reference !== "string" || !REF.test(value.reference) ||
        typeof value.revision !== "string" || !REF.test(value.revision) ||
        typeof value.kind !== "string" || !Object.hasOwn(KINDS, value.kind) ||
        typeof value.state !== "string" || !Object.hasOwn(STATES, value.state))
        return false;
    if (value.assessment !== undefined) {
        const a = value.assessment;
        if (!record(a) || !exact(a, ["healthy", "problems"]) ||
            typeof a.healthy !== "boolean" || !validEnumList(a.problems, RECOVERY_BACKUP_PROBLEMS) ||
            (a.healthy !== (a.problems.length === 0)) ||
            (value.state !== "succeeded" && a.healthy))
            return false;
    }
    if (value.restorePreview !== undefined) {
        const p = value.restorePreview;
        if (!record(p) ||
            !exact(p, ["backupRef", "expectedRevision", "blockers", "maySubmitToProductAuthority",
                "productApplyRequired", "freshnessChecked"]) ||
            typeof p.backupRef !== "string" || !REF.test(p.backupRef) ||
            typeof p.expectedRevision !== "string" || !REF.test(p.expectedRevision) ||
            !validEnumList(p.blockers, RECOVERY_RESTORE_BLOCKERS) ||
            typeof p.maySubmitToProductAuthority !== "boolean" ||
            p.productApplyRequired !== true || typeof p.freshnessChecked !== "boolean" ||
            (p.maySubmitToProductAuthority && p.blockers.length !== 0))
            return false;
    }
    return true;
}
function advisoryEligible(b) {
    const p = b.restorePreview;
    return b.kind === "disaster_recovery" && b.state === "succeeded" &&
        b.assessment?.healthy === true && b.assessment.problems.length === 0 &&
        p !== undefined && p.backupRef === b.reference &&
        p.expectedRevision === b.revision && p.freshnessChecked === true &&
        p.maySubmitToProductAuthority === true && p.productApplyRequired === true &&
        p.blockers.length === 0;
}
/** PF-12: product-neutral information surface only.
 * Never opens archives, performs a restore, grants permission or stores credentials.
 * For actual destructive apply, each product must use its authenticated backend
 * and the separate Foundation MutationReview acknowledgement contract. */
export function RecoveryReadinessPanel({ backups, triageLoadedBackups = false }) {
    const [attentionOnly, setAttentionOnly] = useState(false);
    const rows = [];
    const refs = new Set();
    for (let index = 0; index < backups.length; index += 1) {
        const value = backups[index];
        if (!validBackup(value) || refs.has(value.reference))
            continue;
        refs.add(value.reference);
        rows.push({ backup: value, index });
    }
    const invalidCount = backups.length - rows.length;
    const visible = triageLoadedBackups && attentionOnly
        ? rows.filter(({ backup }) => !advisoryEligible(backup))
        : rows;
    if (backups.length === 0)
        return _jsx(EmptyState, { title: "No backup evidence", description: "No backup evidence supplied by the product. Nothing is qualified for restoration." });
    return (_jsxs("section", { className: "dr-admin__recovery-readiness", "aria-label": "Recovery readiness", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Backup and recovery readiness" }), _jsx(StatusBadge, { tone: "neutral", children: "Product evidence only" })] }), _jsx("p", { className: "dr-admin__muted", children: "Configuration exports are not operational disaster recovery. No restore is performed from this view." }), triageLoadedBackups ? (_jsxs("label", { className: "dr-admin__recovery-triage", children: [_jsx("input", { type: "checkbox", checked: attentionOnly, onChange: (event) => setAttentionOnly(event.target.checked) }), "Show only backups needing attention"] })) : null, _jsxs("p", { role: "status", "aria-live": "polite", className: "dr-admin__muted", children: ["Showing ", visible.length, " of ", backups.length, " loaded backup snapshots."] }), invalidCount ? (_jsxs("p", { role: "alert", className: "dr-admin__recovery-warning", children: [invalidCount, " invalid or duplicate backup entries withheld"] })) : null, visible.length ? (_jsx("ul", { className: "dr-admin__recovery-list", "aria-label": "Loaded backup evidence", children: visible.map(({ backup, index }) => {
                    const eligible = advisoryEligible(backup);
                    const p = backup.restorePreview;
                    return (_jsxs("li", { className: "dr-admin__recovery-card", children: [_jsxs("div", { className: "dr-admin__recovery-heading", children: [_jsxs("strong", { children: [KINDS[backup.kind], " ", index + 1] }), _jsx(StatusBadge, { tone: eligible ? "info" : "warning", children: STATES[backup.state] })] }), backup.kind === "configuration_export" ? (_jsx("p", { children: "Configuration export is not an operational disaster recovery backup." })) : null, _jsx("p", { className: "dr-admin__recovery-verdict", children: eligible ? "Review eligible — product-supplied evidence only" :
                                    "Not qualified for restore review" }), _jsxs("details", { className: "dr-admin__recovery-details", open: !eligible, children: [_jsx("summary", { onKeyDown: (event) => {
                                            if (event.key === "Enter" || event.key === " ") {
                                                event.preventDefault();
                                                const details = event.currentTarget.closest("details");
                                                if (details)
                                                    details.open = !details.open;
                                            }
                                        }, children: "Restore evidence details" }), _jsxs("div", { className: "dr-admin__recovery-evidence", children: [!backup.assessment ? _jsx("p", { children: "Backup assessment was not supplied" }) : null, backup.assessment?.problems.map((reason) => _jsx("p", { children: BACKUP_REASONS[reason] }, reason)), !p ? _jsx("p", { children: "Restore preflight was not supplied" }) : null, p && p.backupRef !== backup.reference ?
                                                _jsx("p", { children: "Restore proof references a different backup" }) : null, p && p.expectedRevision !== backup.revision ?
                                                _jsx("p", { children: "Backup revision mismatch" }) : null, p && !p.freshnessChecked ?
                                                _jsx("p", { children: "Restore-proof freshness was not checked" }) : null, p && !p.maySubmitToProductAuthority && p.blockers.length === 0 ?
                                                _jsx("p", { children: "Product has not established restore review readiness" }) : null, p?.blockers.map((reason) => _jsx("p", { children: RESTORE_REASONS[reason] }, reason)), eligible ? _jsx("p", { children: "Product reports no preview blockers; independent recovery proof remains with the product." }) : null] })] }), _jsx("p", { className: "dr-admin__muted", children: "This view does not independently verify archive bytes or authorize restore." })] }, backup.reference));
                }) })) : _jsx("p", { children: "No currently loaded backup requires attention. Product data and server queries are unchanged." })] }));
}
