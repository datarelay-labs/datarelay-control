import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { AdminTaskCatalog } from "./admin-task-catalog.js";
/** Control-reference grouping is presentation metadata, not product configuration authority. */
export const ADMINISTRATION_CORE_GROUPS = [
    {
        id: "access-security",
        title: "Access & security",
        description: "TLS, platform accounts, and credential changes."
    },
    {
        id: "platform-network",
        title: "Platform & network",
        description: "Display timezone, published ports, and reverse-proxy apply workflow."
    },
    {
        id: "lifecycle-recovery",
        title: "Lifecycle & recovery",
        description: "Retention policy and portable workspace snapshots."
    },
    {
        id: "operations-audit",
        title: "Operations & audit",
        description: "Configuration history and operational health evidence."
    }
];
const PRODUCT_ID = /^[a-z][a-z0-9-]*$/;
const CAPABILITY_ID = /^[a-z][a-z0-9._-]*$/;
function invariant(condition, reason) {
    if (!condition)
        throw new Error("ADMINISTRATION_HUB_INVALID=" + reason);
}
function validateTarget(target, taskId) {
    if (!target)
        return null;
    if (target.kind === "path") {
        invariant(typeof target.path === "string" &&
            target.path.startsWith("/") &&
            !target.path.startsWith("//") &&
            !/\s/.test(target.path), "invalid-path:" + taskId);
        return "path:" + target.path;
    }
    if (target.kind === "action") {
        invariant(typeof target.actionId === "string" && CAPABILITY_ID.test(target.actionId), "invalid-action:" + taskId);
        return "action:" + target.actionId;
    }
    throw new Error("ADMINISTRATION_HUB_INVALID=invalid-target:" + taskId);
}
export function effectiveAdministrationAvailability(task) {
    if (task.availability === "unavailable" || task.access === "none")
        return "unavailable";
    if (task.availability === "read_only" || task.access === "view")
        return "read_only";
    return "supported";
}
/** Fail closed on malformed or conflicting product-defined task/extension composition. */
export function validateAdministrationHub({ productId, tasks, extensionGroups = [] }) {
    invariant(PRODUCT_ID.test(productId), "product-id");
    const coreIds = new Set(ADMINISTRATION_CORE_GROUPS.map((group) => group.id));
    const groupIds = new Set(coreIds);
    const taskIds = new Set();
    const targets = new Set();
    const validateTask = (task, extension) => {
        invariant(typeof task.id === "string" && CAPABILITY_ID.test(task.id), "task-id");
        invariant(!taskIds.has(task.id), "duplicate-task:" + task.id);
        taskIds.add(task.id);
        invariant(typeof task.label === "string" && task.label.trim().length > 0, "task-label:" + task.id);
        invariant(task.availability === "supported" ||
            task.availability === "read_only" ||
            task.availability === "unavailable", "task-availability:" + task.id);
        invariant(task.access === "manage" || task.access === "view" || task.access === "none", "task-access:" + task.id);
        if (extension)
            invariant(task.id.startsWith(productId + "."), "task-namespace:" + task.id);
        if (effectiveAdministrationAvailability(task) !== "unavailable") {
            invariant(task.target !== undefined, "missing-target:" + task.id);
        }
        const targetKey = validateTarget(task.target, task.id);
        if (targetKey) {
            invariant(!targets.has(targetKey), "duplicate-target:" + targetKey);
            targets.add(targetKey);
        }
    };
    for (const task of tasks) {
        invariant(coreIds.has(task.groupId), "unknown-core-group:" + String(task.groupId));
        validateTask(task, false);
    }
    for (const group of extensionGroups) {
        invariant(typeof group.id === "string" &&
            group.id.startsWith(productId + ".") &&
            CAPABILITY_ID.test(group.id), "extension-namespace:" + String(group.id));
        invariant(!groupIds.has(group.id), "duplicate-group:" + group.id);
        groupIds.add(group.id);
        invariant(typeof group.title === "string" && group.title.trim().length > 0, "extension-title:" + group.id);
        invariant(typeof group.description === "string" && group.description.trim().length > 0, "extension-description:" + group.id);
        invariant(group.after === undefined || coreIds.has(group.after), "extension-placement:" + group.id);
        for (const task of group.tasks)
            validateTask(task, true);
    }
}
export function AdministrationHub({ productId, tasks, extensionGroups = [], showUnavailable = false, showHeader = true, onOpen, intro, headerActions, searchable = false, keyboardSearchShortcut = false }) {
    validateAdministrationHub({ productId, tasks, extensionGroups });
    const prefix = useId().replaceAll(":", "");
    const rootRef = useRef(null);
    const searchRef = useRef(null);
    const focusedTaskActionRef = useRef(null);
    const [searchText, setSearchText] = useState("");
    const normalizedSearch = searchable ? searchText.trim().toLowerCase() : "";
    useEffect(() => setSearchText(""), [productId]);
    useEffect(() => {
        if (!searchable || !keyboardSearchShortcut)
            return;
        const focusSearch = (event) => {
            if (event.defaultPrevented || event.altKey || (!event.ctrlKey && !event.metaKey) ||
                event.shiftKey || event.key.toLowerCase() !== "k" || event.isComposing)
                return;
            event.preventDefault();
            searchRef.current?.focus();
            searchRef.current?.select();
        };
        document.addEventListener("keydown", focusSearch);
        return () => document.removeEventListener("keydown", focusSearch);
    }, [searchable, keyboardSearchShortcut]);
    const grouped = ADMINISTRATION_CORE_GROUPS.flatMap((core) => [
        {
            id: core.id,
            title: core.title,
            description: core.description,
            tasks: tasks.filter((task) => task.groupId === core.id)
        },
        ...extensionGroups
            .filter((group) => group.after === core.id)
            .map((group) => ({ id: group.id, title: group.title, description: group.description, tasks: group.tasks }))
    ]);
    grouped.push(...extensionGroups
        .filter((group) => group.after === undefined)
        .map((group) => ({ id: group.id, title: group.title, description: group.description, tasks: group.tasks })));
    const searchableGroups = grouped.map((group) => {
        const permitted = group.tasks.filter((task) => task.access !== "none" && (showUnavailable || effectiveAdministrationAvailability(task) !== "unavailable"));
        const matches = normalizedSearch
            ? permitted.filter((task) => [task.label, task.description, task.id, group.title]
                .some((field) => field?.toLowerCase().includes(normalizedSearch)))
            : group.tasks.filter((task) => task.access !== "none");
        return { ...group, tasks: matches };
    });
    const matchingCount = searchableGroups.reduce((count, group) => count + group.tasks.filter((task) => showUnavailable ||
        effectiveAdministrationAvailability(task) !== "unavailable").length, 0);
    const displayedGroups = normalizedSearch
        ? searchableGroups.filter((group) => group.tasks.length > 0)
        : searchableGroups;
    // Keep keyboard users inside the task finder if the consumer revokes the
    // focused task, instead of leaving focus on the document body.
    useEffect(() => {
        const focused = focusedTaskActionRef.current;
        if (searchable && focused && !focused.isConnected) {
            focusedTaskActionRef.current = null;
            searchRef.current?.focus();
        }
    }, [searchable, tasks, extensionGroups, searchText, showUnavailable]);
    function onSearchKeyDown(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            setSearchText("");
        }
        else if (event.key === "ArrowDown") {
            const target = rootRef.current?.querySelector(".dr-admin-hub__group button:not([disabled])");
            if (target) {
                event.preventDefault();
                target.focus();
            }
        }
    }
    function onHubKeyDown(event) {
        if (!searchable || event.defaultPrevented ||
            !["ArrowDown", "ArrowUp", "Escape"].includes(event.key) ||
            !(event.target instanceof HTMLButtonElement))
            return;
        const actions = Array.from(rootRef.current?.querySelectorAll(".dr-admin-hub__group button:not([disabled])") ?? []);
        const current = actions.indexOf(event.target);
        if (current < 0)
            return;
        event.preventDefault();
        if (event.key === "Escape") {
            setSearchText("");
            searchRef.current?.focus();
        }
        else if (event.key === "ArrowUp" && current === 0) {
            searchRef.current?.focus();
        }
        else {
            const next = event.key === "ArrowDown"
                ? Math.min(current + 1, actions.length - 1)
                : current - 1;
            actions[next]?.focus();
        }
    }
    return (_jsxs("div", { ref: rootRef, className: "dr-admin-hub", "data-testid": "foundation-administration-hub", onKeyDown: onHubKeyDown, onFocusCapture: (event) => {
            if (event.target instanceof HTMLButtonElement &&
                event.target.closest(".dr-admin-hub__group")) {
                focusedTaskActionRef.current = event.target;
            }
        }, onBlurCapture: (event) => {
            if (event.target instanceof HTMLButtonElement &&
                focusedTaskActionRef.current === event.target) {
                focusedTaskActionRef.current = null;
            }
        }, children: [showHeader ? (_jsxs("header", { className: "dr-admin-hub__header", children: [_jsxs("div", { children: [_jsx("h1", { children: "Administration" }), _jsx("p", { children: "Choose an administration task for this product." })] }), headerActions ? _jsx("div", { className: "dr-admin-hub__header-actions", children: headerActions }) : null] })) : null, intro ? _jsx("div", { className: "dr-admin-hub__intro", children: intro }) : null, searchable ? (_jsxs("div", { className: "dr-admin-hub__search", role: "search", children: [_jsx("label", { htmlFor: prefix + "-task-search", children: "Find administration tasks" }), _jsx("input", { ref: searchRef, id: prefix + "-task-search", type: "search", maxLength: 120, autoComplete: "off", value: searchText, onChange: (event) => setSearchText(event.target.value), onKeyDown: onSearchKeyDown }), _jsx("p", { className: "dr-admin-hub__search-count", role: "status", "aria-live": "polite", children: normalizedSearch && matchingCount === 0
                            ? "No matching administration tasks"
                            : matchingCount + (matchingCount === 1 ? " task" : " tasks") })] })) : null, displayedGroups.map((group) => {
                const visibleTasks = group.tasks.filter((task) => task.access !== "none");
                const projectedTasks = visibleTasks.map((task) => ({
                    ...task,
                    availability: effectiveAdministrationAvailability(task)
                }));
                return (_jsxs("section", { className: "dr-admin-hub__group", "aria-labelledby": prefix + "-" + group.id + "-heading", "data-group-id": group.id, children: [_jsxs("div", { className: "dr-admin-hub__group-heading", children: [_jsx("h2", { id: prefix + "-" + group.id + "-heading", children: group.title }), _jsx("p", { children: group.description })] }), _jsx(AdminTaskCatalog, { tasks: projectedTasks, showUnavailable: showUnavailable, taskSpecificActionNames: true, ...(onOpen
                                ? {
                                    onOpen: (selected) => {
                                        const original = visibleTasks.find((task) => task.id === selected.id);
                                        if (original) {
                                            const availability = effectiveAdministrationAvailability(original);
                                            if (availability !== "unavailable") {
                                                onOpen({
                                                    ...original,
                                                    availability,
                                                    access: availability === "supported" ? "manage" : "view"
                                                });
                                            }
                                        }
                                    }
                                }
                                : {}) })] }, group.id));
            })] }));
}
