import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { PasswordManagementPage } from "./password-management.js";
import { useEffect, useRef, useState } from "react";
import { MfaChallengeForm, MfaEnrollmentPanel, RecoveryCodesPanel, PasswordChangeForm, SessionList } from "@datarelay-labs/auth-ui";
import { UserManagementPage, AccountList, AdministrationHub, AuditList, AuditExplorerPage, BackupImportPage, DisplayTimezoneSettings, ManagementAccessPage, ManagementAccessPolicyPanel, HttpsSettingsPage, NetworkSettingsPage, RetentionSettingsPage, SystemHealthPage, RoleChangeReviewPanel, RoleManagementPage, SystemStatus, createStandardAdministrationTasks, STANDARD_ADMINISTRATION_TASKS, effectiveAdministrationAvailability } from "@datarelay-labs/system-admin-ui";
import { Button } from "@datarelay-labs/ui";
import { SessionManagementPage } from "./session-management-page.js";
import { MfaManagementPage } from "./mfa-management-page.js";
function pageAvailable(id, p) {
    switch (id) {
        case "core.backup-import": return typeof p.transfer?.adapter.previewImport === "function" || typeof p.transfer?.adapter.exportWorkspace === "function";
        case "core.retention": return typeof p.retention?.adapter.read === "function";
        case "core.https": return typeof p.https?.adapter.read === "function";
        case "core.users": return p.userManagement ? p.userManagement.canRead === true && typeof p.userManagement.adapter.read === "function" : Array.isArray(p.users?.accounts);
        case "core.timezone": return typeof p.timezone?.adapter.read === "function";
        case "core.network": return typeof p.network?.adapter.read === "function";
        case "core.password": return p.passwordManagement ? p.passwordManagement.canRead === true && typeof p.passwordManagement.adapter.read === "function" : typeof p.password?.onSubmit === "function";
        case "core.mfa":
            if (p.mfaManagement)
                return p.mfaManagement.canRead === true &&
                    typeof p.mfaManagement.adapter.read === "function";
            return p.mfa?.mode === "challenge" ? typeof p.mfa.challenge.onSubmit === "function"
                : p.mfa?.mode === "enrollment" ? typeof p.mfa.enrollment.onConfirm === "function"
                    : p.mfa?.mode === "recovery" ? Array.isArray(p.mfa.recovery.codes) : false;
        case "core.acl": return p.aclManagement ? p.aclManagement.canRead === true && typeof p.aclManagement.adapter.read === "function" : Boolean(p.acl?.policy);
        case "core.rbac": return p.roleManagement
            ? p.roleManagement.canRead === true && typeof p.roleManagement.adapter.read === "function"
            : Boolean(p.rbac?.change);
        case "core.sessions": return p.sessionManagement
            ? p.sessionManagement.canRead === true && typeof p.sessionManagement.adapter.read === "function"
            : Array.isArray(p.sessions?.sessions);
        case "core.audit": return p.auditExplorer ? p.auditExplorer.canRead === true && typeof p.auditExplorer.adapter.query === "function" : Array.isArray(p.audit?.events);
        case "core.health": return p.healthPage ? p.healthPage.canRead === true && typeof p.healthPage.adapter.readSummary === "function" : Boolean(p.health?.health || p.health?.info);
        default: return false;
    }
}
const READ_ONLY_PAGES = [
    "core.users", "core.acl", "core.rbac", "core.sessions", "core.audit", "core.health"
];
/** Whole Administration workspace composition, navigation and safe access gate. */
export function SystemManagementWorkspace({ productId, bindings, pages, actor, onPageChange, initialTask = null, showHeader = true, searchable = true, hubIntro }) {
    const [requested, setRequested] = useState(initialTask);
    const titleRef = useRef(null);
    // A missing page, even with an asserted product capability, is unavailable.
    // An absent binding is never converted to an authorization or support claim.
    const safeBindings = {};
    for (const task of STANDARD_ADMINISTRATION_TASKS) {
        const binding = Object.hasOwn(bindings, task.id) ? bindings[task.id] : undefined;
        if (!binding) {
            safeBindings[task.id] = { availability: "unavailable", access: "view" };
        }
        else if (!pageAvailable(task.id, pages)) {
            safeBindings[task.id] = { ...binding, availability: "unavailable" };
        }
        else if (((task.id === "core.password" && !pages.passwordManagement) ||
            (task.id === "core.mfa" && pages.mfa?.mode === "enrollment")) &&
            (binding.availability !== "supported" || binding.access !== "manage")) {
            // A mutation-only form cannot be represented as an authorized View.
            safeBindings[task.id] = { ...binding, availability: "unavailable" };
        }
        else if (task.id === "core.backup-import" && binding.availability === "supported" &&
            (!pages.transfer?.canApply || !pages.transfer.canPreview || !pages.transfer.adapter.applyImport || !pages.transfer.adapter.readImport)) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.retention" && binding.availability === "supported" &&
            (!pages.retention?.canManage || !pages.retention.adapter.configure || !pages.retention.adapter.previewPolicy || !pages.retention.adapter.dryRun || !pages.retention.adapter.run)) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.https" && binding.availability === "supported" &&
            (!pages.https?.canManage || !pages.https.adapter.preview || !pages.https.adapter.apply)) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.timezone" && binding.availability === "supported" &&
            (!pages.timezone?.adapter.configure ||
                (!pages.timezone.canEditPersonal && !pages.timezone.canEditPlatform))) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.network" && binding.availability === "supported" &&
            (!pages.network?.canManage || !pages.network.adapter.preview ||
                !pages.network.adapter.saveDesired || !pages.network.adapter.apply)) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.audit" && pages.auditExplorer?.canRead) {
            safeBindings[task.id] = binding;
        }
        else if (task.id === "core.health" && pages.healthPage && binding.availability === "supported" &&
            (pages.healthPage.alerts?.canManage || pages.healthPage.alerts?.canTest || pages.healthPage.support?.canGenerate || pages.healthPage.support?.canDownload)) {
            safeBindings[task.id] = binding;
        }
        else if (task.id === "core.password" && pages.passwordManagement && binding.availability === "supported" &&
            (!pages.passwordManagement.canChange || typeof pages.passwordManagement.adapter.change !== "function")) {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.acl" && pages.aclManagement && binding.availability === "supported") {
            safeBindings[task.id] = pages.aclManagement.canManage &&
                typeof pages.aclManagement.adapter.preview === "function" &&
                typeof pages.aclManagement.adapter.apply === "function"
                ? binding : { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.mfa" && pages.mfaManagement && binding.availability === "supported") {
            const mfaAdapter = pages.mfaManagement.adapter;
            const mfaMutation = Boolean(pages.mfaManagement.canManage) && ((typeof mfaAdapter.beginEnrollment === "function" && typeof mfaAdapter.confirmEnrollment === "function") ||
                typeof mfaAdapter.regenerateRecoveryCodes === "function" || typeof mfaAdapter.disable === "function" ||
                typeof mfaAdapter.setRequirement === "function" || typeof mfaAdapter.reset === "function");
            safeBindings[task.id] = mfaMutation ? binding : { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.users" && pages.userManagement?.canManage && typeof pages.userManagement.adapter.preview === "function" && typeof pages.userManagement.adapter.apply === "function") {
            safeBindings[task.id] = binding;
        }
        else if (task.id === "core.rbac" && pages.roleManagement && binding.availability === "supported") {
            safeBindings[task.id] = pages.roleManagement.canManage &&
                typeof pages.roleManagement.adapter.previewAssignment === "function" &&
                typeof pages.roleManagement.adapter.applyAssignment === "function"
                ? binding : { ...binding, availability: "read_only" };
        }
        else if (task.id === "core.sessions" && pages.sessionManagement && binding.availability === "supported") {
            safeBindings[task.id] = pages.sessionManagement.canRevoke &&
                typeof pages.sessionManagement.adapter.revoke === "function"
                ? binding : { ...binding, availability: "read_only" };
        }
        else if (READ_ONLY_PAGES.includes(task.id) && binding.availability === "supported") {
            safeBindings[task.id] = { ...binding, availability: "read_only" };
        }
        else {
            safeBindings[task.id] = binding;
        }
    }
    const tasks = createStandardAdministrationTasks(safeBindings);
    const activeTask = tasks.find((task) => task.id === requested && effectiveAdministrationAvailability(task) !== "unavailable");
    const current = activeTask?.id ?? null;
    // Revoking actor access while a panel is open must hide its contents in the
    // same render and return focus to the task hub once React updates.
    useEffect(() => {
        if (requested && !activeTask)
            setRequested(null);
    }, [requested, activeTask]);
    useEffect(() => {
        titleRef.current?.focus();
    }, [current]);
    function navigate(id) {
        if (id && !tasks.some((task) => task.id === id &&
            effectiveAdministrationAvailability(task) !== "unavailable"))
            return;
        setRequested(id);
        onPageChange?.(id);
    }
    let page = null;
    switch (current) {
        case "core.backup-import":
            page = pages.transfer ? _jsx(BackupImportPage, { adapter: pages.transfer.adapter, canExport: Boolean(pages.transfer.canExport), canPreview: Boolean(pages.transfer.canPreview), canApply: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.transfer.canApply) }) : null;
            break;
        case "core.retention":
            page = pages.retention ? _jsx(RetentionSettingsPage, { adapter: pages.retention.adapter, canManage: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.retention.canManage) }) : null;
            break;
        case "core.https":
            page = pages.https ? _jsx(HttpsSettingsPage, { adapter: pages.https.adapter, canManage: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.https.canManage) }) : null;
            break;
        case "core.users":
            page = pages.userManagement ? _jsx(UserManagementPage, { adapter: pages.userManagement.adapter, canRead: Boolean(pages.userManagement.canRead), canManage: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.userManagement.canManage) }) : pages.users ? _jsx(AccountList, { accounts: pages.users.accounts, filterLoadedAccounts: true, filterLoadedAccountFacets: true, sortLoadedAccounts: true, resetLoadedAccountFilters: true }) : null;
            break;
        case "core.password":
            page = pages.passwordManagement ? _jsx(PasswordManagementPage, { adapter: pages.passwordManagement.adapter, canRead: Boolean(pages.passwordManagement.canRead), canChange: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.passwordManagement.canChange) }) : pages.password ? _jsx(PasswordChangeForm, { allowPasswordReveal: true, ...pages.password }) : null;
            break;
        case "core.timezone":
            page = pages.timezone ? _jsx(DisplayTimezoneSettings, { adapter: pages.timezone.adapter, canEditPersonal: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.timezone.canEditPersonal), canEditPlatform: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.timezone.canEditPlatform) }) : null;
            break;
        case "core.network":
            page = pages.network ? _jsx(NetworkSettingsPage, { adapter: pages.network.adapter, canManage: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.network.canManage) }) : null;
            break;
        case "core.mfa":
            page = pages.mfaManagement ? _jsx(MfaManagementPage, { adapter: pages.mfaManagement.adapter, issuer: pages.mfaManagement.issuer, accountLabel: pages.mfaManagement.accountLabel, canRead: Boolean(pages.mfaManagement.canRead), canManage: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.mfaManagement.canManage) })
                : pages.mfa?.mode === "challenge" ? _jsx(MfaChallengeForm, { ...pages.mfa.challenge })
                    : pages.mfa?.mode === "enrollment" ? _jsx(MfaEnrollmentPanel, { ...pages.mfa.enrollment })
                        : pages.mfa?.mode === "recovery" ? _jsx(RecoveryCodesPanel, { ...pages.mfa.recovery }) : null;
            break;
        case "core.acl":
            page = pages.aclManagement ? _jsx(ManagementAccessPage, { adapter: pages.aclManagement.adapter, canRead: Boolean(pages.aclManagement.canRead), canManage: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.aclManagement.canManage) })
                : pages.acl?.policy ? _jsx(ManagementAccessPolicyPanel, { policy: pages.acl.policy, reviewAvailability: "read_only" }) : null;
            break;
        case "core.rbac":
            page = pages.roleManagement ? _jsx(RoleManagementPage, { adapter: pages.roleManagement.adapter, canRead: Boolean(pages.roleManagement.canRead), canManage: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.roleManagement.canManage) })
                : pages.rbac?.change ? _jsx(RoleChangeReviewPanel, { change: pages.rbac.change, reviewAvailability: "read_only" }) : null;
            break;
        case "core.sessions":
            page = pages.sessionManagement ? _jsx(SessionManagementPage, { adapter: pages.sessionManagement.adapter, canRead: Boolean(pages.sessionManagement.canRead), canRevoke: effectiveAdministrationAvailability(activeTask) === "supported" &&
                    Boolean(pages.sessionManagement.canRevoke), ...(pages.sessionManagement.subject ? { subject: pages.sessionManagement.subject } : {}) })
                : pages.sessions ? _jsx(SessionList, { sessions: pages.sessions.sessions, filterLoadedSessions: true, filterLoadedSessionStates: true }) : null;
            break;
        case "core.audit":
            page = pages.auditExplorer ? _jsx(AuditExplorerPage, { adapter: pages.auditExplorer.adapter, canRead: Boolean(pages.auditExplorer.canRead), ...(pages.auditExplorer.formatTimestamp ? { formatTimestamp: pages.auditExplorer.formatTimestamp } : {}) })
                : pages.audit ? _jsx(AuditList, { filterLoadedAuditEvents: true, filterLoadedAuditOutcomes: true, filterLoadedAuditActions: true, filterLoadedAuditTimeRange: true, ...pages.audit }) : null;
            break;
        case "core.health":
            page = pages.healthPage ? _jsx(SystemHealthPage, { adapter: pages.healthPage.adapter, canRead: Boolean(pages.healthPage.canRead), ...(pages.healthPage.alerts ? { alerts: { ...pages.healthPage.alerts,
                        canManage: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.healthPage.alerts.canManage),
                        canTest: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.healthPage.alerts.canTest) } } : {}), ...(pages.healthPage.support ? { support: { ...pages.healthPage.support,
                        canGenerate: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.healthPage.support.canGenerate),
                        canDownload: effectiveAdministrationAvailability(activeTask) === "supported" && Boolean(pages.healthPage.support.canDownload) } } : {}) })
                : pages.health ? _jsx(SystemStatus, { triageLoadedHealthChecks: true, ...pages.health }) : null;
            break;
    }
    return (_jsx("section", { className: "dr-management", "aria-label": "System Management", children: current && activeTask ? (_jsxs(_Fragment, { children: [_jsx("div", { className: "dr-management__return", children: _jsx(Button, { variant: "secondary", onClick: () => navigate(null), children: "Back to Administration" }) }), _jsxs("header", { className: "dr-management__page-heading", children: [_jsx("h2", { ref: titleRef, tabIndex: -1, children: activeTask.label }), _jsx("p", { children: activeTask.description })] }), _jsx("div", { className: "dr-management__page-content", children: page })] })) : (_jsx(AdministrationHub, { productId: productId, tasks: tasks, showHeader: showHeader, showUnavailable: true, searchable: searchable, intro: hubIntro ?? (_jsxs("div", { className: "dr-management__context", role: "status", children: [_jsx("strong", { children: actor ? "Signed in as " + actor.label + "." : "Access context unavailable." }), _jsxs("p", { children: [actor?.detail ?? "The product supplies current role and capability authorization.", " ", "Privileged changes require authoritative product confirmation and read-back."] })] })), onOpen: (task) => navigate(task.id) })) }));
}
