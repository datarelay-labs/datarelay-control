import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
export const CONTROL_RETENTION_CATEGORIES = { logs: "Logs", runtime_metrics: "Runtime metrics", preview_cache: "Preview cache", backup_temp: "Backup temp" };
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const integer = (v, lo, hi) => typeof v === "number" && Number.isSafeInteger(v) && v >= lo && v <= hi;
const ref = (v) => typeof v === "string" && v.length > 0 && v.length <= 256 && !/[\x00-\x20\x7f]/.test(v);
const category = (v) => typeof v === "string" && Object.hasOwn(CONTROL_RETENTION_CATEGORIES, v);
const equalIds = (a, b) => a.length === b.length && new Set(a).size === a.length && [...a].sort().every((v, i) => v === [...b].sort()[i]);
function validState(value) {
    if (!record(value) || typeof value.schedulerEnabled !== "boolean" || typeof value.schedulerActive !== "boolean" ||
        !integer(value.intervalMinutes, 5, 1440) || !integer(value.batchSize, 100, 100000) || !Array.isArray(value.categories) ||
        value.categories.length < 1 || value.categories.length > 4)
        return false;
    const ids = new Set();
    for (const c of value.categories) {
        if (!record(c) || !category(c.id) || ids.has(c.id) || typeof c.enabled !== "boolean" ||
            typeof c.legalHold !== "boolean" || !integer(c.retentionDays, 1, 3650) || !integer(c.minimumDays, 1, 3650) || c.retentionDays < c.minimumDays)
            return false;
        ids.add(c.id);
    }
    if (value.lastResult !== undefined) {
        const r = value.lastResult;
        if (!record(r) || !ref(r.previewRef) || !ref(r.auditReference) || r.dryRun !== false || !Array.isArray(r.outcomes) ||
            !r.outcomes.every(o => record(o) && category(o.category)) || !outcomesValid(r.outcomes, r.outcomes.map(o => o.category), false))
            return false;
    }
    return value.lastSweepAt === null || (typeof value.lastSweepAt === "string" && Number.isFinite(Date.parse(value.lastSweepAt)));
}
function readValid(v) { return record(v) && validState(v.effective); }
const toDraft = (s, expectedRevision) => ({
    schedulerEnabled: s.schedulerEnabled, intervalMinutes: s.intervalMinutes, batchSize: s.batchSize, expectedRevision,
    categories: s.categories.map(c => ({ id: c.id, enabled: c.enabled, retentionDays: c.retentionDays }))
});
export function validateRetentionPolicy(state, draft) {
    if (!validState(state) || !record(draft) || typeof draft.schedulerEnabled !== "boolean" || !ref(draft.expectedRevision))
        return "Invalid retention state or revision.";
    if (!integer(draft.intervalMinutes, 5, 1440))
        return "Cleanup interval must be 5–1440 minutes.";
    if (!integer(draft.batchSize, 100, 100000))
        return "Cleanup batch size must be 100–100000.";
    if (!Array.isArray(draft.categories) || !equalIds(state.categories.map(c => c.id), draft.categories.map(c => c?.id)))
        return "Retention categories must match the loaded policy.";
    for (const item of draft.categories) {
        const current = state.categories.find(c => c.id === item.id);
        if (typeof item.enabled !== "boolean" || !integer(item.retentionDays, 1, 3650))
            return "Retention days must be 1–3650.";
        if (item.retentionDays < current.minimumDays)
            return CONTROL_RETENTION_CATEGORIES[item.id] + " is below the product retention minimum.";
        if (current.legalHold && item.retentionDays < current.retentionDays)
            return "A legal hold prevents shortening retention.";
    }
    return null;
}
function equalPolicy(a, b) {
    return a.schedulerEnabled === b.schedulerEnabled && a.intervalMinutes === b.intervalMinutes && a.batchSize === b.batchSize &&
        equalIds(a.categories.map(c => c.id), b.categories.map(c => c.id)) && a.categories.every(c => {
        const d = b.categories.find(v => v.id === c.id);
        return d?.enabled === c.enabled && d?.retentionDays === c.retentionDays;
    });
}
function proofValid(p, purpose, revision) {
    return record(p) && p.purpose === purpose && p.expectedRevision === revision && ref(p.previewRef) &&
        ["allowed", "actorAuthorized", "recentMfaVerified", "auditReady", "protectedRecordsExcluded", "backupReady", "rollbackReady"].every(k => typeof p[k] === "boolean") &&
        Array.isArray(p.blockers) && p.blockers.length <= 32 && p.blockers.every(b => typeof b === "string" && b.length > 0 && b.length <= 512);
}
const proofSafe = (p) => p.allowed && p.actorAuthorized && p.recentMfaVerified && p.auditReady &&
    p.protectedRecordsExcluded && p.backupReady && p.rollbackReady && p.blockers.length === 0;
function outcomesValid(outcomes, ids, dry) {
    return Array.isArray(outcomes) && equalIds(outcomes.map(o => o?.category), ids) && outcomes.every(o => record(o) &&
        ["ok", "skipped", "not_applicable", "error"].includes(String(o.status)) && integer(o.matchedCount, 0, Number.MAX_SAFE_INTEGER) &&
        integer(o.affectedCount, 0, o.matchedCount) && (!dry || o.affectedCount === 0) && (o.status === "ok" || o.affectedCount === 0));
}
const errorText = (e) => e instanceof Error ? e.message.slice(0, 512) : "Retention operation failed.";
/** Common Control Retention workflow. No storage or scheduler is changed without the native adapter. */
export function RetentionSettingsPage({ adapter, canManage = false }) {
    const id = useId();
    const seq = useRef(0);
    const live = useRef({ adapter, canManage });
    live.current = { adapter, canManage };
    const [loaded, setLoaded] = useState(null);
    const [draft, setDraft] = useState(null);
    const [selected, setSelected] = useState([]);
    const [policyPlan, setPolicyPlan] = useState(null);
    const [cleanupPlan, setCleanupPlan] = useState(null);
    const [policyAck, setPolicyAck] = useState(false);
    const [cleanupAck, setCleanupAck] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const row = loaded?.adapter === adapter ? loaded.row : null;
    const state = row?.effective;
    const editor = canManage && ref(row?.revision) && [adapter.previewPolicy, adapter.configure, adapter.dryRun, adapter.run].every(f => typeof f === "function");
    const changed = Boolean(draft && state && !equalPolicy(draft, toDraft(state, draft.expectedRevision)));
    const validPlan = editor && draft && policyPlan && proofValid(policyPlan, "policy", draft.expectedRevision) && equalPolicy(policyPlan.draft, draft);
    const validCleanup = editor && !changed && cleanupPlan && row?.revision === cleanupPlan.expectedRevision && equalIds(selected, cleanupPlan.categories);
    const alive = (n, write = true) => seq.current === n && live.current.adapter === adapter && (!write || live.current.canManage);
    function invalidate() { setPolicyPlan(null); setCleanupPlan(null); setPolicyAck(false); setCleanupAck(false); setError(""); setNotice(""); }
    function accept(r) { setLoaded({ adapter, row: r }); setDraft(toDraft(r.effective, ref(r.revision) ? r.revision : "")); }
    useEffect(() => {
        const n = ++seq.current;
        setLoaded(null);
        setDraft(null);
        invalidate();
        setBusy(true);
        void adapter.read().then(r => {
            if (!alive(n, false))
                return;
            if (!readValid(r))
                throw new Error("Invalid retention state returned by Core.");
            accept(r);
            setSelected(r.effective.categories.filter(c => c.enabled && !c.legalHold).map(c => c.id));
        }).catch(e => { if (alive(n, false))
            setError(errorText(e)); }).finally(() => { if (alive(n, false))
            setBusy(false); });
        return () => { seq.current++; };
    }, [adapter, canManage]);
    async function refresh() {
        if (busy)
            return;
        const n = ++seq.current;
        invalidate();
        setBusy(true);
        try {
            const r = await adapter.read();
            if (!alive(n, false))
                return;
            if (!readValid(r))
                throw new Error("Invalid retention read-back.");
            accept(r);
            setSelected(r.effective.categories.filter(c => c.enabled && !c.legalHold).map(c => c.id));
        }
        catch (e) {
            if (alive(n, false))
                setError(errorText(e));
        }
        finally {
            if (alive(n, false))
                setBusy(false);
        }
    }
    function edit(next) { invalidate(); setDraft(next); }
    async function preparePolicy() {
        if (!editor || busy || !draft || !state || !changed)
            return;
        invalidate();
        const issue = validateRetentionPolicy(state, draft);
        if (issue) {
            setError(issue);
            return;
        }
        const n = ++seq.current;
        setBusy(true);
        try {
            const p = await adapter.previewPolicy(draft);
            if (!alive(n))
                return;
            if (!proofValid(p, "policy", draft.expectedRevision) || !record(p.draft) || validateRetentionPolicy(state, p.draft) || !equalPolicy(p.draft, draft))
                throw new Error("Invalid or mismatched retention preview.");
            setPolicyPlan(p);
            if (!proofSafe(p))
                setError("Product policy preview is blocked.");
        }
        catch (e) {
            if (alive(n))
                setError(errorText(e));
        }
        finally {
            if (alive(n, false))
                setBusy(false);
        }
    }
    async function savePolicy() {
        if (!validPlan || !policyPlan || !proofSafe(policyPlan) || !policyAck || busy || !draft)
            return;
        const n = ++seq.current;
        const p = policyPlan;
        setBusy(true);
        invalidate();
        try {
            const before = await adapter.read();
            if (!alive(n))
                return;
            if (!readValid(before) || before.revision !== draft.expectedRevision)
                throw new Error("Retention policy changed since review. Refresh and retry.");
            const issue = validateRetentionPolicy(before.effective, draft);
            if (issue)
                throw new Error(issue);
            await adapter.configure(draft, p.previewRef);
            if (!alive(n))
                return;
            const after = await adapter.read();
            if (!alive(n))
                return;
            if (!readValid(after))
                throw new Error("Invalid retention read-back.");
            accept(after);
            if (!ref(after.revision) || after.revision === before.revision || !equalPolicy(draft, toDraft(after.effective, after.revision)))
                throw new Error("Retention policy not confirmed by authoritative read-back.");
            setNotice("Retention policy saved and verified.");
        }
        catch (e) {
            if (alive(n))
                setError(errorText(e));
        }
        finally {
            if (alive(n, false))
                setBusy(false);
        }
    }
    async function dryRun() {
        if (!editor || busy || changed || !row || !ref(row.revision) || !selected.length)
            return;
        const n = ++seq.current;
        invalidate();
        setBusy(true);
        try {
            const p = await adapter.dryRun({ categories: [...selected], expectedRevision: row.revision });
            if (!alive(n))
                return;
            if (!proofValid(p, "cleanup", row.revision) || p.dryRun !== true || !equalIds(p.categories, selected) || !outcomesValid(p.outcomes, selected, true))
                throw new Error("Invalid or mismatched cleanup dry-run.");
            setCleanupPlan(p);
            if (!proofSafe(p))
                setError("Cleanup preview is blocked by native safeguards.");
        }
        catch (e) {
            if (alive(n))
                setError(errorText(e));
        }
        finally {
            if (alive(n, false))
                setBusy(false);
        }
    }
    async function runCleanup() {
        if (!validCleanup || !cleanupPlan || (!proofSafe(cleanupPlan) || cleanupPlan.outcomes.some(o => o.status === "error")) || !cleanupAck || busy || !row || !ref(row.revision))
            return;
        const n = ++seq.current;
        const p = cleanupPlan;
        invalidate();
        setBusy(true);
        try {
            const before = await adapter.read();
            if (!alive(n))
                return;
            if (!readValid(before) || before.revision !== p.expectedRevision)
                throw new Error("Retention state changed since dry-run.");
            if (before.effective.categories.some(c => selected.includes(c.id) && c.legalHold))
                throw new Error("A selected category is under legal hold.");
            const result = await adapter.run({ previewRef: p.previewRef, expectedRevision: p.expectedRevision, categories: [...selected] });
            if (!alive(n))
                return;
            if (!record(result) || result.previewRef !== p.previewRef || result.dryRun !== false || !ref(result.auditReference) || !outcomesValid(result.outcomes, selected, false))
                throw new Error("Invalid cleanup result from Core.");
            const after = await adapter.read();
            if (!alive(n))
                return;
            if (!readValid(after))
                throw new Error("Invalid retention read-back.");
            accept(after);
            const persisted = after.effective.lastResult;
            if (!ref(after.revision) || after.revision === before.revision || !persisted || persisted.previewRef !== result.previewRef ||
                persisted.auditReference !== result.auditReference || persisted.dryRun !== false || !outcomesValid(persisted.outcomes, selected, false) ||
                !persisted.outcomes.every(o => result.outcomes.some(v => v.category === o.category && v.status === o.status && v.matchedCount === o.matchedCount && v.affectedCount === o.affectedCount)))
                throw new Error("Cleanup result not confirmed by authoritative read-back.");
            if (result.outcomes.some(o => o.status === "error"))
                throw new Error("Cleanup reported an error; inspect category results.");
            setNotice("Cleanup completed and verified.");
        }
        catch (e) {
            if (alive(n))
                setError(errorText(e));
        }
        finally {
            if (alive(n, false))
                setBusy(false);
        }
    }
    const outcomes = (items) => _jsx("div", { className: "dr-admin__retention-table", children: _jsxs("table", { children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Category" }), _jsx("th", { children: "Status" }), _jsx("th", { children: "Matched" }), _jsx("th", { children: "Affected" })] }) }), _jsx("tbody", { children: items.map(o => _jsxs("tr", { children: [_jsx("td", { children: category(o.category) ? CONTROL_RETENTION_CATEGORIES[o.category] : o.category }), _jsx("td", { children: o.status }), _jsx("td", { children: o.matchedCount }), _jsx("td", { children: o.affectedCount })] }, o.category)) })] }) });
    return _jsxs("section", { className: "dr-admin__retention", "aria-label": "Retention settings", children: [_jsxs("header", { children: [_jsx("h3", { children: "Retention / cleanup" }), _jsx("p", { children: "Review scheduler posture and category policies. Saving policy and running cleanup are separate operations." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, !state && busy ? _jsx("p", { role: "status", children: "Loading retention settings\u2026" }) : null, state && draft ? _jsxs(_Fragment, { children: [_jsxs("dl", { className: "dr-admin__timezone-facts", children: [_jsxs("div", { children: [_jsx("dt", { children: "Scheduler" }), _jsx("dd", { children: state.schedulerActive ? "Running" : "Not running" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Policy" }), _jsx("dd", { children: state.schedulerEnabled ? "Enabled" : "Disabled" })] }), _jsxs("div", { children: [_jsx("dt", { children: "Interval" }), _jsxs("dd", { children: [state.intervalMinutes, " minutes"] })] }), _jsxs("div", { children: [_jsx("dt", { children: "Last sweep" }), _jsx("dd", { children: state.lastSweepAt ?? "Not reported" })] })] }), _jsx("div", { className: "dr-admin__retention-table", children: _jsxs("table", { children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Category" }), _jsx("th", { children: "Enabled" }), _jsx("th", { children: "Retention days" }), _jsx("th", { children: "Minimum days" }), _jsx("th", { children: "Hold" })] }) }), _jsx("tbody", { children: state.categories.map(c => { const d = draft.categories.find(v => v.id === c.id); const label = CONTROL_RETENTION_CATEGORIES[c.id]; return _jsxs("tr", { children: [_jsx("th", { scope: "row", children: label }), _jsx("td", { children: _jsx("input", { type: "checkbox", "aria-label": label + " cleanup enabled", checked: d.enabled, disabled: !editor || busy, onChange: e => edit({ ...draft, categories: draft.categories.map(v => v.id === c.id ? { ...v, enabled: e.target.checked } : v) }) }) }), _jsx("td", { children: _jsx("input", { type: "number", "aria-label": label + " retention days", value: Number.isFinite(d.retentionDays) ? d.retentionDays : "", min: c.minimumDays, max: 3650, disabled: !editor || busy, onChange: e => edit({ ...draft, categories: draft.categories.map(v => v.id === c.id ? { ...v, retentionDays: Number(e.target.value) } : v) }) }) }), _jsx("td", { children: c.minimumDays }), _jsx("td", { children: c.legalHold ? "Active" : "None" })] }, c.id); }) })] }) }), _jsxs("div", { className: "dr-admin__retention-form", children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: draft.schedulerEnabled, disabled: !editor || busy, onChange: e => edit({ ...draft, schedulerEnabled: e.target.checked }) }), "Enable cleanup scheduler"] }), _jsx("label", { htmlFor: id + "-interval", children: "Cleanup interval (minutes)" }), _jsx("input", { id: id + "-interval", type: "number", min: 5, max: 1440, value: draft.intervalMinutes, disabled: !editor || busy, onChange: e => edit({ ...draft, intervalMinutes: Number(e.target.value) }) }), _jsx("label", { htmlFor: id + "-batch", children: "Cleanup batch size" }), _jsx("input", { id: id + "-batch", type: "number", min: 100, max: 100000, value: draft.batchSize, disabled: !editor || busy, onChange: e => edit({ ...draft, batchSize: Number(e.target.value) }) })] }), editor ? _jsx(Button, { disabled: busy || !changed, onClick: () => void preparePolicy(), children: "Preview retention policy" }) : _jsx("p", { className: "dr-admin__muted", children: "Retention settings are read-only for this session." }), validPlan && policyPlan ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Retention policy review", children: [_jsx("h4", { children: "Review retention policy" }), policyPlan.blockers.length ? _jsx("ul", { children: policyPlan.blockers.map((b, i) => _jsx("li", { children: b }, i)) }) : null, proofSafe(policyPlan) ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: policyAck, disabled: busy, onChange: e => setPolicyAck(e.target.checked) }), "I confirm the retention policy change"] }), _jsx(Button, { disabled: !policyAck || busy, onClick: () => void savePolicy(), children: "Save retention policy" })] }) : null] }) : null, editor ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Cleanup actions", children: [_jsx("h4", { children: "Cleanup scope" }), state.categories.map(c => _jsxs("label", { children: [_jsx("input", { type: "checkbox", "aria-label": "Include " + CONTROL_RETENTION_CATEGORIES[c.id], checked: selected.includes(c.id), disabled: busy || c.legalHold, onChange: e => { invalidate(); setSelected(e.target.checked ? [...selected, c.id] : selected.filter(v => v !== c.id)); } }), CONTROL_RETENTION_CATEGORIES[c.id]] }, c.id)), _jsx(Button, { disabled: busy || changed || !selected.length, onClick: () => void dryRun(), children: "Dry-run cleanup" }), changed ? _jsx("p", { children: "Save or discard policy changes before cleanup." }) : null] }) : null, validCleanup && cleanupPlan ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Cleanup dry-run", children: [_jsx("h4", { children: "Dry-run results" }), outcomes(cleanupPlan.outcomes), cleanupPlan.blockers.length ? _jsx("ul", { children: cleanupPlan.blockers.map((b, i) => _jsx("li", { children: b }, i)) }) : null, proofSafe(cleanupPlan) && cleanupPlan.outcomes.every(o => o.status !== "error") ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: cleanupAck, disabled: busy, onChange: e => setCleanupAck(e.target.checked) }), "I confirm the reviewed cleanup scope"] }), _jsx(Button, { variant: "danger", disabled: !cleanupAck || busy, onClick: () => void runCleanup(), children: "Run confirmed cleanup" })] }) : null] }) : null, state.lastResult && outcomesValid(state.lastResult.outcomes, state.lastResult.outcomes.map(o => o.category), false) ? _jsxs("section", { "aria-label": "Last cleanup result", children: [_jsx("h4", { children: "Last cleanup result" }), outcomes(state.lastResult.outcomes)] }) : null] }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void refresh(), children: "Refresh retention settings" })] });
}
