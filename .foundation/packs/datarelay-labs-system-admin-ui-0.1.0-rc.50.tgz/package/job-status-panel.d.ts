import type { ReactNode } from "react";
import { type CapabilityAvailability, type JobProjection, type JobRetryReviewProjection } from "@datarelay-labs/system-contracts";
export type JobStatusPanelProps<Result = unknown> = {
    job: JobProjection<Result>;
    onCancel?: (jobId: string) => void | Promise<void>;
    /** Optional context label for multiple cancellable job cards. */
    cancelAccessibleLabel?: string;
    renderResult?: (result: Result) => ReactNode;
    /** Product-provided retry review evidence is opt-in and never a re-run command. */
    retryReview?: JobRetryReviewProjection;
    /** Product-owned job CAS revision, independent of unversioned JobProjection. */
    retryJobRevision?: string;
    retryAvailability?: CapabilityAvailability | "unknown";
    onReviewRetry?: (jobId: string, jobRevision: string) => void | Promise<void>;
    retryPending?: boolean;
};
export declare function JobStatusPanel<Result = unknown>({ job, onCancel, cancelAccessibleLabel, renderResult, retryReview, retryJobRevision, retryAvailability, onReviewRetry, retryPending }: JobStatusPanelProps<Result>): import("react").JSX.Element;
