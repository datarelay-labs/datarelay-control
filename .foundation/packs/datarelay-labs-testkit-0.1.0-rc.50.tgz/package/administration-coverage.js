import { effectiveAdministrationAvailability } from "@datarelay-labs/system-admin-ui";
import { verifyAdministrationConsumer } from "./administration.js";
import { verifyAdministrationTaskAuthority } from "./administration-authority.js";
import { report } from "./types.js";
const STABLE_ID = /^[a-z0-9][a-z0-9._-]{0,63}$/;
/** Actual shared AdminHub button level, including product availability. */
const displayedAccess = (task) => {
    const effective = effectiveAdministrationAvailability(task);
    return effective === "supported" ? "manage" : effective === "read_only" ? "view" : "none";
};
const issue = (id, message) => ({ id, message });
/**
 * Read-only, role-specific coverage proof over TWO independent Testkit contracts.
 * A valid consumer composition alone may omit backend evidence, and a valid
 * backend sample alone may omit a displayed task. Neither may yield PASS here.
 *
 * Callers supply product-owned fixtures at one exact product source HEAD.
 * This function never fetches routes, probes APIs, or changes permissions;
 * an ok result is only fixture consistency, not product User E2E.
 */
export function verifyAdministrationAuthorityCoverage(consumer, roleId, cases) {
    const structural = verifyAdministrationConsumer(consumer);
    if (!structural.ok)
        return structural;
    if (typeof roleId !== "string" || !STABLE_ID.test(roleId)) {
        return report([issue("ADMIN_AUTHORITY_ROLE_INVALID", "A stable non-sensitive product role ID is required.")]);
    }
    const checked = verifyAdministrationTaskAuthority(cases);
    const findings = [...checked.findings];
    if (!Array.isArray(cases))
        return report(findings);
    const tasks = [
        ...consumer.composition.tasks,
        ...(consumer.composition.extensionGroups ?? []).flatMap((group) => [...group.tasks])
    ];
    const byId = new Map(tasks.map((task) => [task.id, task]));
    const covered = new Set();
    // The underlying checker diagnoses malformed/duplicate cases separately.
    // Never reflect arbitrary submitted values in messages.
    for (const entry of cases) {
        if (!entry ||
            typeof entry.taskId !== "string" || !STABLE_ID.test(entry.taskId) ||
            typeof entry.productId !== "string" || !STABLE_ID.test(entry.productId) ||
            typeof entry.roleId !== "string" || !STABLE_ID.test(entry.roleId)) {
            continue;
        }
        if (entry.productId !== consumer.composition.productId || entry.roleId !== roleId) {
            findings.push(issue("ADMIN_AUTHORITY_SCOPE_MISMATCH", "An authority case belongs to another product or actor role."));
            continue;
        }
        const actualTask = byId.get(entry.taskId);
        if (!actualTask) {
            findings.push(issue("ADMIN_AUTHORITY_TASK_NOT_IN_COMPOSITION", "An authority case refers to a task absent from the product's Administration composition."));
            continue;
        }
        covered.add(entry.taskId);
        if (entry.presentedAccess !== displayedAccess(actualTask)) {
            findings.push(issue("ADMIN_AUTHORITY_PRESENTATION_MISMATCH", "Claimed task display access differs from the composed AdministrationHub button."));
        }
    }
    for (const task of tasks) {
        if (displayedAccess(task) !== "none" && !covered.has(task.id)) {
            findings.push(issue("ADMIN_AUTHORITY_TASK_UNCOVERED", "A displayed Administration task has no matching product role/backend evidence."));
        }
    }
    return report(findings);
}
