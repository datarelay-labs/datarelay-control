import { type CapabilityAvailability, type NotificationRoutingReviewProjection } from "@datarelay-labs/system-contracts";
export type NotificationRoutingReviewPanelProps = {
    /** One currently authorized product SMTP/Webhook destination snapshot. */
    projection?: NotificationRoutingReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Only opens a product-owned review, never changes credentials or sends. */
    onReviewPolicy?: (destinationRef: string, expectedRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Deliberately does NOT implement Grafana Alertmanager group timing.
 * Only displays Foundation Python NotificationRetryPolicy and destination
 * enabled state, bound to a separate product-admin change preflight. */
export declare function NotificationRoutingReviewPanel({ projection, reviewAvailability, onReviewPolicy, pending }: NotificationRoutingReviewPanelProps): import("react").JSX.Element;
