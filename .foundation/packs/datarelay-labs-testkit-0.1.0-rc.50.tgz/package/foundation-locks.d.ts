import { type ConformanceReport } from "./types";
/** Read-only checked-in source lock projections, NOT proof of installed bytes. */
export type FoundationPackageLock = {
    source_head: string;
    version: string;
    packages: readonly {
        name: string;
        sha256: string;
        archive_sha256?: string;
    }[];
};
export type FoundationConsumerPin = {
    productId: "control" | "link" | "grant";
    /** Exact consumer repository HEAD, never a branch name. */
    consumerHead: string;
    /** Read from that commit's product-owned foundation.lock.json. */
    lock: FoundationPackageLock;
};
/** Optional stricter declared archive-identity check; never real archive-byte proof. */
export type FoundationLockConvergenceOptions = {
    requireArchiveDigests?: boolean;
};
/**
 * Checks Foundation pin convergence across the THREE product-owned checked-in
 * locks at three exact product commits. It does not read source/archives itself,
 * verify a package was installed, inspect runtime RBAC or grant user/release PASS.
 *
 * The expected lock MUST come from a separately authenticated Foundation source
 * candidate. A consumer-supplied expected lock is not an authority boundary.
 */
export declare function verifyFoundationConsumerLocks(expected: FoundationPackageLock, consumers: readonly FoundationConsumerPin[], options?: FoundationLockConvergenceOptions): ConformanceReport;
