import { type AuthSessionSummary } from "@datarelay-labs/auth-ui";
export type SessionManagementState = {
    revision: string;
    subject: string;
    complete: boolean;
    sessions: AuthSessionSummary[];
};
export type SessionRevokeReceipt = SessionManagementState & {
    auditReference: string;
};
export type SessionManagementAdapter = {
    read: (subject?: string) => Promise<SessionManagementState>;
    revoke: (request: {
        subjectRef: string;
        sessionId: string;
        expectedRevision: string;
        confirm: true;
    }) => Promise<SessionRevokeReceipt>;
};
export type SessionManagementPageProps = {
    adapter: SessionManagementAdapter;
    canRead?: boolean;
    canRevoke?: boolean;
    subject?: string;
};
export declare function validSessionManagementState(value: unknown): value is SessionManagementState;
export declare function SessionManagementPage({ adapter, canRead, canRevoke, subject }: SessionManagementPageProps): import("react").JSX.Element;
