import { type ReactNode } from "react";
import { type JobProjection } from "@datarelay-labs/system-contracts";
/**
 * Product-provided job snapshots only: no global inventory, background polling,
 * cancellation authority, server query, retry or progress inference.
 */
export type JobListProps<Result = unknown> = {
    jobs: readonly JobProjection<Result>[];
    /** Opt-in local search and state facet over currently loaded jobs only. */
    filterLoadedJobs?: boolean;
    /** Independent opt-in one-action reset of local label search and status only. */
    resetLoadedJobFilters?: boolean;
    /** Independent default-off local ordering of currently provided job labels. */
    sortLoadedJobs?: boolean;
    /** Optional user-controlled hiding of only already-loaded SUCCEEDED jobs. */
    hideLoadedSuccessfulJobs?: boolean;
    /** Optional native per-row details disclosure for already-loaded jobs. */
    discloseLoadedJobDetails?: boolean;
    /** Delegated to the product exactly as in JobStatusPanel. */
    onCancel?: (jobId: string) => void | Promise<void>;
    renderResult?: (result: Result) => ReactNode;
};
export declare function JobList<Result = unknown>({ jobs, filterLoadedJobs, resetLoadedJobFilters, sortLoadedJobs, hideLoadedSuccessfulJobs, discloseLoadedJobDetails, onCancel, renderResult }: JobListProps<Result>): import("react").JSX.Element;
