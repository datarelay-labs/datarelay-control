import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, StatusBadge } from "@datarelay-labs/ui";
import { DIAGNOSTIC_AREAS } from "@datarelay-labs/system-contracts";
/** All labels are first-party and static: backend probe errors, raw URLs, and credentials
 * must never be passed through to the UI. See PF-11 product adapter contract. */
const AREAS = {
    dns: "DNS", ntp: "NTP", proxy: "Proxy",
    trusted_ca: "Trusted enterprise CA", certificate: "TLS certificate"
};
const REASONS = {
    healthy: "Healthy", evidence_stale: "Diagnostic evidence is stale",
    evidence_unavailable: "Diagnostic evidence is unavailable",
    dns_failure: "DNS resolution failed",
    time_not_synchronized: "Time synchronization is disabled or failing",
    time_offset_high: "Time offset exceeds failure threshold",
    time_offset_warning: "Time offset exceeds warning threshold",
    proxy_disabled: "Proxy is disabled", proxy_failure: "Proxy connectivity failed",
    trusted_ca_not_configured: "Enterprise CA is not configured",
    trusted_ca_failure: "Enterprise CA verification failed",
    certificate_missing: "Certificate evidence is unavailable",
    certificate_expired: "Certificate has expired",
    certificate_expiring: "Certificate expires soon"
};
const REMEDIATIONS = {
    none: "No action required", collect_diagnostics: "Collect fresh diagnostics",
    check_dns: "Check product DNS configuration",
    restore_ntp: "Restore time synchronization",
    verify_proxy: "Verify outbound proxy configuration",
    check_enterprise_ca: "Check trusted enterprise CA",
    renew_certificate: "Review and renew the certificate"
};
/** Verify enum pairings at the UI trust boundary; a forged source report must
 * never represent a DNS failure as "pass" or attach irrelevant remediation. */
const REASON_RULES = {
    healthy: { severity: "pass", remediation: "none" },
    evidence_stale: { severity: "unknown", remediation: "collect_diagnostics" },
    evidence_unavailable: { severity: "unknown", remediation: "collect_diagnostics" },
    dns_failure: { severity: "fail", remediation: "check_dns", area: "dns" },
    time_not_synchronized: { severity: "fail", remediation: "restore_ntp", area: "ntp" },
    time_offset_high: { severity: "fail", remediation: "restore_ntp", area: "ntp" },
    time_offset_warning: { severity: "warn", remediation: "restore_ntp", area: "ntp" },
    proxy_disabled: { severity: "skipped", remediation: "none", area: "proxy" },
    proxy_failure: { severity: "fail", remediation: "verify_proxy", area: "proxy" },
    trusted_ca_not_configured: { severity: "skipped", remediation: "none", area: "trusted_ca" },
    trusted_ca_failure: { severity: "fail", remediation: "check_enterprise_ca", area: "trusted_ca" },
    certificate_missing: { severity: "unknown", remediation: "collect_diagnostics", area: "certificate" },
    certificate_expired: { severity: "fail", remediation: "renew_certificate", area: "certificate" },
    certificate_expiring: { severity: "warn", remediation: "renew_certificate", area: "certificate" }
};
const SEVERITIES = {
    pass: "pass", warn: "warn", fail: "fail",
    unknown: "unknown", skipped: "skipped"
};
function isSafeReport(report) {
    if (!report || !Number.isSafeInteger(report.collectedAt) || report.collectedAt < 0 ||
        !Object.hasOwn(SEVERITIES, report.status) || !Array.isArray(report.findings) ||
        report.findings.length > DIAGNOSTIC_AREAS.length)
        return false;
    const seen = new Set();
    for (const finding of report.findings) {
        if (!finding || typeof finding.area !== "string" || !Object.hasOwn(AREAS, finding.area) ||
            typeof finding.severity !== "string" || !Object.hasOwn(SEVERITIES, finding.severity) ||
            typeof finding.code !== "string" || !Object.hasOwn(REASON_RULES, finding.code) ||
            typeof finding.remediation !== "string" || !Object.hasOwn(REMEDIATIONS, finding.remediation) ||
            !Number.isSafeInteger(finding.checkedAt) ||
            finding.checkedAt !== report.collectedAt || seen.has(finding.area))
            return false;
        const rule = REASON_RULES[finding.code];
        if (rule.severity !== finding.severity || rule.remediation !== finding.remediation ||
            (rule.area !== undefined && rule.area !== finding.area))
            return false;
        seen.add(finding.area);
    }
    return true;
}
function expectedSeverity(report) {
    if (report.findings.some((f) => f.severity === "fail"))
        return "fail";
    if (report.findings.some((f) => f.severity === "unknown"))
        return "unknown";
    if (report.findings.some((f) => f.severity === "warn"))
        return "warn";
    return "pass"; // Python diagnostic engine considers no failures/unknowns/warnings a pass.
}
/** Presentation only. It never runs a probe, fetches privileged data, authorizes a
 * user or treats a missing/contradictory product report as evidence of health. */
export function SystemDoctor({ report, runAvailability = "unknown", onRunDiagnostics, running = false }) {
    const valid = isSafeReport(report);
    const accepted = valid ? report : undefined;
    const byArea = new Map(accepted?.findings.map((finding) => [finding.area, finding]));
    const complete = accepted?.findings.length === DIAGNOSTIC_AREAS.length;
    const status = accepted && complete && expectedSeverity(accepted) === accepted.status
        ? accepted.status : "unknown";
    const mayRun = runAvailability === "supported" && typeof onRunDiagnostics === "function";
    return (_jsxs("section", { className: "dr-admin__doctor", "aria-label": "System Doctor", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "System Doctor" }), _jsxs(StatusBadge, { tone: status === "pass" ? "success" : status === "fail" ? "critical" :
                            status === "warn" ? "warning" : "neutral", children: ["Diagnosis: ", status] })] }), _jsx("p", { className: "dr-admin__muted", children: "Product-supplied read-only DNS, time, proxy, enterprise CA and certificate evidence." }), mayRun ? (_jsx(Button, { type: "button", variant: "secondary", disabled: running, onClick: () => onRunDiagnostics(), children: "Run diagnostics" })) : (_jsx("p", { className: "dr-admin__muted", children: "Running diagnostics is not available with the current product permission." })), !report ? _jsx("p", { children: "No verified diagnostic report was supplied by the product." }) : null, report && !valid ? _jsx("p", { children: "Invalid diagnostic report. No findings displayed." }) : null, accepted ? (_jsxs(_Fragment, { children: [_jsxs("p", { className: "dr-admin__muted", role: "status", "aria-live": "polite", children: [accepted.findings.length, " of ", DIAGNOSTIC_AREAS.length, " diagnostic areas supplied.", !complete ? " Missing areas remain unknown." : "", complete && status === "unknown" && expectedSeverity(accepted) !== accepted.status
                                ? " Contradictory severity evidence." : ""] }), _jsx("ol", { className: "dr-admin__doctor-list", "aria-label": "Product diagnostic findings", children: DIAGNOSTIC_AREAS.map((area) => {
                            const finding = byArea.get(area);
                            return (_jsxs("li", { children: [_jsxs("div", { className: "dr-admin__doctor-row", children: [_jsx("strong", { children: AREAS[area] }), _jsx("span", { children: finding?.severity ?? "unknown" })] }), finding ? (_jsxs("div", { className: "dr-admin__doctor-detail", children: [_jsx("span", { children: REASONS[finding.code] }), _jsx("small", { children: REMEDIATIONS[finding.remediation] })] })) : _jsxs("span", { children: [AREAS[area], ": no evidence supplied"] })] }, area));
                        }) })] })) : null] }));
}
