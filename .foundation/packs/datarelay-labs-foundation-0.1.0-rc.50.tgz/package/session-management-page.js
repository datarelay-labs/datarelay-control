import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { SessionList } from "@datarelay-labs/auth-ui";
import { Button } from "@datarelay-labs/ui";
const text = (value, max = 512) => typeof value === "string" &&
    value.length > 0 && value.length <= max && !/[\u0000-\u001f\u007f]/.test(value);
const timestamp = (value) => typeof value === "string" && Number.isFinite(Date.parse(value));
export function validSessionManagementState(value) {
    if (!value || typeof value !== "object")
        return false;
    const state = value;
    if (!text(state.revision, 256) || !text(state.subject, 256) || typeof state.complete !== "boolean" ||
        !Array.isArray(state.sessions) || state.sessions.length > 10000)
        return false;
    const ids = new Set();
    let current = 0;
    for (const session of state.sessions) {
        if (!session || !text(session.id, 256) || ids.has(session.id) || !timestamp(session.createdAt) ||
            (session.lastSeenAt !== undefined && !timestamp(session.lastSeenAt)) ||
            (session.expiresAt !== undefined && !timestamp(session.expiresAt)) ||
            (session.deviceLabel !== undefined && !text(session.deviceLabel, 256)) ||
            (session.source !== undefined && !text(session.source, 512)) ||
            (session.current !== undefined && typeof session.current !== "boolean") ||
            (session.revoked !== undefined && typeof session.revoked !== "boolean") ||
            (session.revocable !== undefined && typeof session.revocable !== "boolean"))
            return false;
        if (session.current === true) {
            current++;
            if (session.revocable === true || session.revoked === true)
                return false;
        }
        if (session.revoked === true && session.revocable === true)
            return false;
        ids.add(session.id);
    }
    return current <= 1;
}
export function SessionManagementPage({ adapter, canRead = false, canRevoke = false, subject }) {
    const live = useRef({ adapter, canRead, canRevoke, subject, epoch: 0 });
    if (live.current.adapter !== adapter || live.current.canRead !== canRead ||
        live.current.canRevoke !== canRevoke || live.current.subject !== subject)
        live.current = { adapter, canRead, canRevoke, subject, epoch: live.current.epoch + 1 };
    const [state, setState] = useState(null);
    const [pending, setPending] = useState("");
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false);
    const [uncertain, setUncertain] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const serial = useRef(0);
    const fresh = (epoch, write = false) => live.current.epoch === epoch && live.current.canRead &&
        (!write || live.current.canRevoke);
    useEffect(() => { void load(); return () => { serial.current++; live.current.epoch++; }; }, [adapter, canRead, subject]);
    useEffect(() => { if (!canRevoke) {
        setPending("");
        setConfirmed(false);
    } }, [canRevoke, adapter]);
    async function load() {
        if (!canRead) {
            setState(null);
            return;
        }
        const epoch = live.current.epoch, ticket = ++serial.current;
        setBusy(true);
        setError("");
        try {
            const value = await adapter.read(subject);
            if (!fresh(epoch) || ticket !== serial.current)
                return;
            if (!validSessionManagementState(value) || (subject !== undefined && value.subject !== subject))
                throw Error("invalid");
            setState(value);
            setPending("");
            setConfirmed(false);
            setUncertain(false);
        }
        catch {
            if (fresh(epoch) && ticket === serial.current) {
                setState(null);
                setError("Cannot read a valid current session registry.");
            }
        }
        finally {
            if (fresh(epoch) && ticket === serial.current)
                setBusy(false);
        }
    }
    function review(sessionId) {
        if (!canRevoke || busy || uncertain || !state)
            return;
        const target = state.sessions.find(item => item.id === sessionId);
        if (!target || target.current || target.revoked || target.revocable !== true)
            return;
        setPending(sessionId);
        setConfirmed(false);
        setError("");
        setNotice("");
    }
    async function revoke() {
        if (!canRevoke || busy || uncertain || !state || !pending || !confirmed)
            return;
        const target = state.sessions.find(item => item.id === pending);
        if (!target || target.current || target.revoked || target.revocable !== true)
            return;
        const epoch = live.current.epoch;
        const beforeRevision = state.revision;
        setBusy(true);
        setError("");
        setNotice("");
        setUncertain(true);
        try {
            const before = await adapter.read(subject);
            if (!fresh(epoch, true) || !validSessionManagementState(before) ||
                before.revision !== beforeRevision || before.subject !== state.subject)
                throw Error("stale");
            const current = before.sessions.find(item => item.id === pending);
            if (!current || current.current || current.revoked || current.revocable !== true)
                throw Error("stale");
            const receipt = await adapter.revoke({
                subjectRef: before.subject, sessionId: pending, expectedRevision: before.revision, confirm: true
            });
            if (!fresh(epoch, true))
                return;
            const after = await adapter.read(subject);
            const changed = validSessionManagementState(after) ? after.sessions.find(item => item.id === pending) : undefined;
            if (!validSessionManagementState(after) || after.revision === before.revision ||
                after.revision !== receipt.revision || !text(receipt.auditReference, 256) ||
                !changed || changed.revoked !== true || changed.revocable === true)
                throw Error("unverified");
            setState(after);
            setPending("");
            setConfirmed(false);
            setUncertain(false);
            setNotice("Session revoked and verified.");
        }
        catch {
            if (fresh(epoch)) {
                setPending("");
                setConfirmed(false);
                setError("Session revoke status is unknown or stale. Refresh and inspect audit before retrying.");
            }
        }
        finally {
            if (fresh(epoch))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("section", { "aria-label": "Session management", children: _jsx("p", { role: "status", children: "Session management is not authorized." }) });
    const selected = state?.sessions.find(item => item.id === pending);
    return _jsxs("section", { className: "dr-admin__session-management", "aria-label": "Session management", children: [_jsxs("header", { children: [_jsx("h3", { children: "Sessions" }), _jsx("p", { children: "Review authoritative product sessions and revoke non-current sessions." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void load(), children: "Refresh sessions" }), state ? _jsx(SessionList, { sessions: state.sessions, filterLoadedSessions: true, filterLoadedSessionStates: true, ...(canRevoke && !uncertain ? { onRevoke: (id) => review(id),
                    ...(busy && pending ? { revokingSessionId: pending } : {}) } : {}) }) : busy ? _jsx("p", { role: "status", children: "Loading sessions\u2026" }) : null, selected && canRevoke ? _jsxs("section", { "aria-label": "Session revoke confirmation", children: [_jsxs("p", { children: ["Revoke ", _jsx("strong", { children: selected.deviceLabel ?? "Browser session" }), "? The current session is never eligible here."] }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: event => setConfirmed(event.target.checked) }), "I confirm this session revoke"] }), _jsx(Button, { variant: "danger", disabled: busy || !confirmed || uncertain, onClick: () => void revoke(), children: "Confirm revoke session" }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => { setPending(""); setConfirmed(false); }, children: "Cancel" })] }) : null] });
}
