import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { NOTIFICATION_TEST_BLOCKERS } from "@datarelay-labs/system-contracts";
const KINDS = { smtp: "SMTP", webhook: "Webhook" };
const OUTCOMES = {
    accepted: "Product sender accepted last attempt",
    retry_pending: "Product retry pending",
    dead_letter: "Product marked delivery dead letter"
};
const BLOCKER_LABELS = {
    destination_disabled: "Destination disabled",
    stale_destination: "Destination revision is stale",
    permission_denied: "Insufficient product permissions",
    mfa_required: "Recent MFA verification required",
    sender_unavailable: "Product sender unavailable",
    destination_unverified: "Destination not verified",
    credential_unavailable: "Credential readiness unavailable",
    tls_unverified: "Secure transport not verified",
    audit_unavailable: "Product audit unavailable"
};
const SAFE_REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const MAX_COUNT = 1_000_000_000;
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exactFields(value, keys) {
    return Object.keys(value).every((key) => keys.includes(key));
}
function validCounter(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= MAX_COUNT;
}
function validDestination(value) {
    if (!object(value) ||
        !exactFields(value, ["reference", "revision", "kind", "enabled", "queue", "lastOutcome", "testPreview"]) ||
        typeof value.reference !== "string" || !SAFE_REF.test(value.reference) ||
        typeof value.revision !== "string" || !SAFE_REF.test(value.revision) ||
        typeof value.kind !== "string" || !Object.hasOwn(KINDS, value.kind) ||
        typeof value.enabled !== "boolean")
        return false;
    if (value.lastOutcome !== undefined &&
        (typeof value.lastOutcome !== "string" || !Object.hasOwn(OUTCOMES, value.lastOutcome)))
        return false;
    if (value.queue !== undefined) {
        if (!object(value.queue) ||
            !exactFields(value.queue, ["queued", "retryPending", "deadLetter"]) ||
            !validCounter(value.queue.queued) || !validCounter(value.queue.retryPending) ||
            !validCounter(value.queue.deadLetter))
            return false;
    }
    if (value.testPreview !== undefined) {
        const preview = value.testPreview;
        if (!object(preview) ||
            !exactFields(preview, ["expectedRevision", "blockers", "maySubmitToProductSender", "productSendRequired"]) ||
            typeof preview.expectedRevision !== "string" || !SAFE_REF.test(preview.expectedRevision) ||
            typeof preview.maySubmitToProductSender !== "boolean" ||
            preview.productSendRequired !== true || !Array.isArray(preview.blockers) ||
            preview.blockers.length > NOTIFICATION_TEST_BLOCKERS.length)
            return false;
        const seenBlockers = new Set();
        for (const blocker of preview.blockers) {
            if (typeof blocker !== "string" || !NOTIFICATION_TEST_BLOCKERS.includes(blocker) ||
                seenBlockers.has(blocker))
                return false;
            seenBlockers.add(blocker);
        }
        if (preview.maySubmitToProductSender && preview.blockers.length)
            return false;
    }
    return true;
}
function requiresAttention(item) {
    return !item.enabled || !item.queue || item.lastOutcome !== "accepted" ||
        item.queue.queued > 0 || item.queue.retryPending > 0 || item.queue.deadLetter > 0;
}
function reasonForUnavailable(item) {
    if (!item.enabled)
        return "Destination disabled";
    if (!item.testPreview)
        return "Test readiness not supplied";
    if (item.testPreview.expectedRevision !== item.revision)
        return "Destination revision is stale";
    if (item.testPreview.blockers.length)
        return "Product test-send is blocked";
    return "Product did not authorize test send";
}
/** PF-11: loaded-only code-safe destination status and test admission.
 * It never stores/configures credentials, sends mail, invokes a Webhook,
 * advances a durable queue or claims that a downstream recipient received data. */
export function NotificationDeliveryPanel({ destinations, triageLoadedNotificationDestinations = false, testAvailability = "unknown", onRequestTest, pendingTestReference }) {
    const [attentionOnly, setAttentionOnly] = useState(false);
    const validRows = [];
    const seen = new Set();
    for (let index = 0; index < destinations.length; index += 1) {
        const candidate = destinations[index];
        if (!validDestination(candidate) || seen.has(candidate.reference))
            continue;
        seen.add(candidate.reference);
        validRows.push({ destination: candidate, index });
    }
    const invalidCount = destinations.length - validRows.length;
    const visible = triageLoadedNotificationDestinations && attentionOnly
        ? validRows.filter((row) => requiresAttention(row.destination))
        : validRows;
    if (destinations.length === 0)
        return _jsx(EmptyState, { title: "No notification destinations", description: "No notification destinations supplied by the product. No test-send is available." });
    return (_jsxs("section", { className: "dr-admin__notification-delivery", "aria-label": "Notification delivery", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Notification delivery" }), _jsx(StatusBadge, { tone: "neutral", children: "Product snapshot only" })] }), _jsx("p", { className: "dr-admin__muted", children: "Only already-authorized SMTP and Webhook destinations are shown. No credentials or endpoint addresses are displayed." }), triageLoadedNotificationDestinations ? (_jsxs("label", { className: "dr-admin__notification-triage", children: [_jsx("input", { type: "checkbox", checked: attentionOnly, onChange: (event) => setAttentionOnly(event.target.checked) }), "Show only destinations needing attention"] })) : null, _jsxs("p", { role: "status", "aria-live": "polite", className: "dr-admin__muted", children: ["Showing ", visible.length, " of ", destinations.length, " loaded notification destinations."] }), invalidCount ? (_jsxs("p", { className: "dr-admin__notification-warning", role: "alert", children: [invalidCount, " invalid or duplicate destination entries withheld."] })) : null, _jsx("p", { className: "dr-admin__muted", children: "Downstream delivery is not independently confirmed by a sender acknowledgement." }), visible.length ? (_jsx("ul", { className: "dr-admin__notification-list", "aria-label": "Loaded notification destinations", children: visible.map(({ destination, index }) => {
                    const kind = KINDS[destination.kind];
                    const label = kind + " destination " + (index + 1);
                    const preview = destination.testPreview;
                    const mayTest = Boolean(destination.enabled &&
                        testAvailability === "supported" && typeof onRequestTest === "function" &&
                        preview?.maySubmitToProductSender === true &&
                        preview.expectedRevision === destination.revision && preview.blockers.length === 0);
                    return (_jsxs("li", { className: "dr-admin__notification-entry", children: [_jsxs("div", { className: "dr-admin__notification-heading", children: [_jsx("strong", { children: label }), _jsx(StatusBadge, { tone: destination.enabled ? "info" : "neutral", children: destination.enabled ? "Enabled" : "Disabled" })] }), destination.queue ? (_jsxs("div", { className: "dr-admin__notification-counts", children: [_jsxs("span", { children: [destination.queue.queued, " queued"] }), _jsxs("span", { children: [destination.queue.retryPending, " retry pending"] }), _jsxs("span", { children: [destination.queue.deadLetter, " dead letter"] })] })) : _jsx("p", { className: "dr-admin__muted", children: "Queue counts not supplied." }), _jsx("p", { className: "dr-admin__muted", children: destination.lastOutcome ? OUTCOMES[destination.lastOutcome] :
                                    "No last product delivery outcome supplied" }), mayTest ? (_jsxs(Button, { type: "button", variant: "secondary", disabled: pendingTestReference === destination.reference, onClick: () => onRequestTest?.(destination.reference, destination.revision), children: ["Test ", label] })) : testAvailability === "supported" && typeof onRequestTest === "function" ? (_jsxs("div", { className: "dr-admin__notification-blockers", children: [_jsx("p", { children: reasonForUnavailable(destination) }), preview && preview.expectedRevision === destination.revision &&
                                        preview.blockers.map((blocker) => (_jsx("span", { children: BLOCKER_LABELS[blocker] }, blocker)))] })) : null] }, destination.reference));
                }) })) : (_jsx("p", { className: "dr-admin__muted", children: "No currently loaded notification destination matches this view. Product data and server queries are unchanged." }))] }));
}
