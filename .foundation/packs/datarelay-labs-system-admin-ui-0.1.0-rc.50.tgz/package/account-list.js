import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { Button, EmptyState, StatusBadge, TextField } from "@datarelay-labs/ui";
/** Only display/compare values already made visible by the consuming product. */
function loadedFacetOptions(values) {
    const unique = new Map();
    for (const raw of values) {
        const label = raw?.trim();
        if (label && !unique.has(label.toLowerCase()))
            unique.set(label.toLowerCase(), label);
    }
    return [...unique.values()].sort((left, right) => left.localeCompare(right));
}
export function AccountList({ accounts, actions, filterLoadedAccounts = false, filterLoadedAccountFacets = false, sortLoadedAccounts = false, resetLoadedAccountFilters = false, selectLoadedAccounts = false, onReviewSelectedAccounts }) {
    const [query, setQuery] = useState("");
    const [selectedStatus, setSelectedStatus] = useState("");
    const [selectedRole, setSelectedRole] = useState("");
    const [loadedSort, setLoadedSort] = useState("");
    const [selectedAccountIds, setSelectedAccountIds] = useState([]);
    const reviewEnabled = selectLoadedAccounts && typeof onReviewSelectedAccounts === "function";
    const labelId = useId();
    const localSearchEnabled = filterLoadedAccounts || filterLoadedAccountFacets;
    const localControlsEnabled = localSearchEnabled || sortLoadedAccounts;
    const statuses = filterLoadedAccountFacets
        ? loadedFacetOptions(accounts.map((account) => account.status)) : [];
    const roles = filterLoadedAccountFacets
        ? loadedFacetOptions(accounts.map((account) => account.role?.label)) : [];
    const activeStatus = statuses.some((label) => label.toLowerCase() === selectedStatus) ? selectedStatus : "";
    const activeRole = roles.some((label) => label.toLowerCase() === selectedRole) ? selectedRole : "";
    const hasActiveLoadedFilters = Boolean(query.trim() || (filterLoadedAccountFacets && (activeStatus || activeRole)));
    // Never retain a facet that stopped being supplied by the product adapter.
    useEffect(() => {
        if (selectedStatus && !statuses.some((label) => label.toLowerCase() === selectedStatus)) {
            setSelectedStatus("");
        }
        if (selectedRole && !roles.some((label) => label.toLowerCase() === selectedRole)) {
            setSelectedRole("");
        }
    }, [accounts, filterLoadedAccountFacets, selectedRole, selectedStatus]);
    const normalized = localSearchEnabled ? query.trim().toLowerCase() : "";
    const visible = accounts.filter((account) => (!normalized || [account.displayName, account.role?.label, account.status]
        .some((text) => text?.toLowerCase().includes(normalized)))
        && (!filterLoadedAccountFacets || !activeStatus || account.status?.trim().toLowerCase() === activeStatus)
        && (!filterLoadedAccountFacets || !activeRole || account.role?.label.trim().toLowerCase() === activeRole));
    // A selected row must still be present in the current product-provided,
    // filtered page. This prevents removed/hidden IDs from being submitted.
    const visibleIds = new Set(visible.map((account) => account.id));
    const currentSelection = reviewEnabled
        ? selectedAccountIds.filter((id) => visibleIds.has(id)) : [];
    useEffect(() => {
        setSelectedAccountIds((previous) => {
            const next = reviewEnabled ? previous.filter((id) => visibleIds.has(id)) : [];
            return next.length === previous.length && next.every((id, index) => id === previous[index])
                ? previous : next;
        });
    }, [accounts, normalized, activeStatus, activeRole, reviewEnabled]);
    if (accounts.length === 0) {
        return _jsx(EmptyState, { title: "No accounts", description: "No accounts are available from the product adapter." });
    }
    // Sorting is presentation-only. Unspecified values remain last in both
    // directions, and equal labels keep the product adapter's source order.
    const ordered = sortLoadedAccounts && loadedSort
        ? [...visible].sort((left, right) => {
            const sortLabel = (account) => loadedSort.startsWith("name-") ? account.displayName
                : loadedSort.startsWith("role-") ? account.role?.label : account.status;
            const a = sortLabel(left)?.trim() ?? "";
            const b = sortLabel(right)?.trim() ?? "";
            if (!a || !b)
                return !a && !b ? 0 : !a ? 1 : -1;
            const direction = loadedSort.endsWith("-desc") ? -1 : 1;
            return direction * a.localeCompare(b, undefined, { sensitivity: "base", numeric: true });
        })
        : visible;
    const accountRows = (_jsx("ul", { className: "dr-admin__account-list", "aria-label": "Accounts", children: ordered.map((account) => {
            const relationships = account.relationships ?? [];
            return (_jsxs("li", { className: "dr-admin__account", children: [_jsxs("div", { className: "dr-admin__account-content", children: [reviewEnabled ? (_jsxs("label", { className: "dr-admin__account-select", children: [_jsx("input", { type: "checkbox", "aria-label": `Select loaded account ${account.displayName} for review`, checked: currentSelection.includes(account.id), onChange: (event) => {
                                            const checked = event.currentTarget.checked;
                                            setSelectedAccountIds((previous) => {
                                                const valid = previous.filter((id) => visibleIds.has(id));
                                                if (!checked)
                                                    return valid.filter((id) => id !== account.id);
                                                if (!visibleIds.has(account.id) || valid.includes(account.id))
                                                    return valid;
                                                return [...valid, account.id];
                                            });
                                        } }), _jsx("span", { children: "Include in review" })] })) : null, _jsxs("div", { className: "dr-admin__account-title", children: [_jsx("strong", { children: account.displayName }), account.status ? _jsx(StatusBadge, { tone: "neutral", children: account.status }) : null] }), account.role ? _jsxs("p", { children: ["Role: ", account.role.label] }) : null, account.detail ? _jsx("p", { children: account.detail }) : null, account.capabilities?.length ? (_jsxs("p", { className: "dr-admin__muted", children: ["Capabilities: ", account.capabilities.join(", ")] })) : null, relationships.length ? (_jsxs("details", { className: "dr-admin__account-relationships", children: [_jsxs("summary", { children: ["Access relationships (", relationships.length, ")"] }), _jsx("ul", { className: "dr-admin__relationship-list", "aria-label": "Access relationships for " + account.displayName, children: relationships.map((relationship) => (_jsxs("li", { className: "dr-admin__relationship", children: [_jsx("span", { className: "dr-admin__relationship-kind", children: relationship.kind }), _jsxs("div", { children: [_jsx("strong", { children: relationship.label }), relationship.detail ? _jsx("p", { children: relationship.detail }) : null] })] }, relationship.id))) })] })) : null] }), actions ? _jsx("div", { className: "dr-admin__account-actions", children: actions(account) }) : null] }, account.id));
        }) }));
    const list = reviewEnabled ? (_jsxs("div", { className: "dr-admin__account-review", children: [accountRows, _jsxs("p", { className: "dr-admin__muted", "aria-live": "polite", children: ["Selected ", currentSelection.length, " loaded ", currentSelection.length === 1 ? "account" : "accounts", " for review"] }), _jsx(Button, { type: "button", variant: "secondary", disabled: !currentSelection.length, onClick: () => {
                    if (!onReviewSelectedAccounts || !currentSelection.length)
                        return;
                    const chosen = new Set(currentSelection);
                    const ids = [...new Set(visible.filter((account) => chosen.has(account.id))
                            .map((account) => account.id))];
                    if (ids.length)
                        onReviewSelectedAccounts(ids);
                }, children: "Review selected accounts" })] })) : accountRows;
    if (!localControlsEnabled)
        return list;
    return (_jsxs("div", { className: "dr-admin__account-search-layout", children: [localSearchEnabled ? (_jsx("div", { role: "search", children: _jsx(TextField, { type: "search", label: "Find loaded accounts", id: labelId + "-query", value: query, maxLength: 120, autoComplete: "off", onChange: (event) => setQuery(event.target.value) }) })) : null, filterLoadedAccountFacets ? (_jsxs("div", { className: "dr-admin__account-facets", role: "group", "aria-label": "Loaded account filters", children: [_jsxs("div", { className: "dr-admin__account-facet", children: [_jsx("label", { htmlFor: labelId + "-status", children: "Filter loaded status" }), _jsxs("select", { id: labelId + "-status", value: activeStatus, onChange: (event) => setSelectedStatus(event.target.value), children: [_jsx("option", { value: "", children: "All loaded statuses" }), statuses.map((status) => _jsx("option", { value: status.toLowerCase(), children: status }, status.toLowerCase()))] })] }), _jsxs("div", { className: "dr-admin__account-facet", children: [_jsx("label", { htmlFor: labelId + "-role", children: "Filter loaded role" }), _jsxs("select", { id: labelId + "-role", value: activeRole, onChange: (event) => setSelectedRole(event.target.value), children: [_jsx("option", { value: "", children: "All loaded roles" }), roles.map((role) => _jsx("option", { value: role.toLowerCase(), children: role }, role.toLowerCase()))] })] })] })) : null, sortLoadedAccounts ? (_jsxs("div", { className: "dr-admin__account-facet dr-admin__account-sort", children: [_jsx("label", { htmlFor: labelId + "-sort", children: "Sort loaded accounts" }), _jsxs("select", { id: labelId + "-sort", value: loadedSort, onChange: (event) => setLoadedSort(event.target.value), children: [_jsx("option", { value: "", children: "Adapter order" }), _jsx("option", { value: "name-asc", children: "Name (A\u2013Z)" }), _jsx("option", { value: "name-desc", children: "Name (Z\u2013A)" }), _jsx("option", { value: "role-asc", children: "Role (A\u2013Z)" }), _jsx("option", { value: "role-desc", children: "Role (Z\u2013A)" }), _jsx("option", { value: "status-asc", children: "Status (A\u2013Z)" }), _jsx("option", { value: "status-desc", children: "Status (Z\u2013A)" })] })] })) : null, localSearchEnabled && resetLoadedAccountFilters && hasActiveLoadedFilters ? (_jsx("button", { type: "button", className: "dr-admin__account-reset", onClick: () => {
                    setQuery("");
                    setSelectedStatus("");
                    setSelectedRole("");
                    document.getElementById(labelId + "-query")?.focus();
                }, children: "Clear loaded filters" })) : null, _jsxs("p", { className: "dr-admin__muted", role: "status", "aria-live": "polite", children: ["Showing ", ordered.length, " of ", accounts.length, " loaded accounts. Only accounts supplied by the product adapter are displayed."] }), ordered.length
                ? list
                : _jsx(EmptyState, { title: "No matching loaded accounts", description: "No loaded account matches this filter; server-wide results were not queried." })] }));
}
