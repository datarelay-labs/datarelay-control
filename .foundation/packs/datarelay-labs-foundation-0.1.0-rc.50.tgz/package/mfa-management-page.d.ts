export type MfaManagementState = {
    subject: string;
    revision: string;
    required: boolean;
    enrolled: boolean;
    recoveryCodesRemaining: number;
    sessionEpoch: number;
};
export type ManagedMfaDirectory = {
    currentUserId: string;
    complete: boolean;
    records: MfaManagementState[];
};
export type MfaEnrollmentStart = {
    revision: string;
    enrollmentRef: string;
    expiresAt: number;
    issuer: string;
    accountLabel: string;
    secret: string;
    otpauthUri: string;
};
export type MfaRecoveryResult = MfaManagementState & {
    recoveryCodes: readonly string[];
};
export type MfaManagementAdapter = {
    read: () => Promise<MfaManagementState>;
    readManaged?: () => Promise<ManagedMfaDirectory>;
    beginEnrollment?: (request: {
        expectedRevision: string;
        issuer: string;
        accountLabel: string;
    }) => Promise<MfaEnrollmentStart>;
    confirmEnrollment?: (request: {
        expectedRevision: string;
        enrollmentRef: string;
        code: string;
    }) => Promise<MfaRecoveryResult>;
    regenerateRecoveryCodes?: (request: {
        expectedRevision: string;
        confirm: true;
    }) => Promise<MfaRecoveryResult>;
    disable?: (request: {
        expectedRevision: string;
        confirm: true;
    }) => Promise<MfaManagementState>;
    setRequirement?: (subject: string, request: {
        expectedRevision: string;
        required: boolean;
        confirm: true;
    }) => Promise<MfaManagementState>;
    reset?: (subject: string, request: {
        expectedRevision: string;
        confirm: true;
    }) => Promise<MfaManagementState>;
};
export type MfaManagementPageProps = {
    adapter: MfaManagementAdapter;
    issuer: string;
    accountLabel: string;
    canRead?: boolean;
    canManage?: boolean;
};
export declare function validMfaState(value: unknown): value is MfaManagementState;
export declare function validManagedMfaDirectory(value: unknown): value is ManagedMfaDirectory;
export declare function MfaManagementPage({ adapter, issuer, accountLabel, canRead, canManage }: MfaManagementPageProps): import("react").JSX.Element;
