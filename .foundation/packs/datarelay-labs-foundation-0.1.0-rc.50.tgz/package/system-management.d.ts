import { type PasswordManagementPageProps } from "./password-management";
import { type ReactNode } from "react";
import { type MfaChallengeFormProps, type MfaEnrollmentPanelProps, type RecoveryCodesPanelProps, type PasswordChangeFormProps, type SessionListProps } from "@datarelay-labs/auth-ui";
import { type UserManagementPageProps, type AccountListProps, type StandardAdministrationTaskId, type StandardAdministrationTaskBindings, type AuditListProps, type SystemHealthPageProps, type AuditExplorerPageProps, type BackupImportPageProps, type RetentionSettingsPageProps, type HttpsSettingsPageProps, type DisplayTimezoneSettingsProps, type NetworkSettingsPageProps, type ManagementAccessPageProps, type ManagementAccessPolicyPanelProps, type RoleChangeReviewPanelProps, type RoleManagementPageProps, type SystemStatusProps } from "@datarelay-labs/system-admin-ui";
import { type SessionManagementPageProps } from "./session-management-page";
import { type MfaManagementPageProps } from "./mfa-management-page";
export type FoundationMfaManagementPage = {
    mode: "challenge";
    challenge: MfaChallengeFormProps;
} | {
    mode: "enrollment";
    enrollment: MfaEnrollmentPanelProps;
} | {
    mode: "recovery";
    recovery: RecoveryCodesPanelProps;
};
/**
 * All shared panels in this workspace are rendered by Foundation. Products
 * supply authoritative projections and native adapter functions, never a
 * replacement implementation of these common pages.
 *
 * The unlisted original Control settings pages remain unavailable until their
 * complete common workflows are implemented. A bound capability alone must
 * NEVER turn an unfinished panel into a working Manage button.
 */
export type FoundationManagementPages = {
    userManagement?: UserManagementPageProps;
    users?: AccountListProps;
    passwordManagement?: PasswordManagementPageProps;
    password?: PasswordChangeFormProps;
    transfer?: BackupImportPageProps;
    retention?: RetentionSettingsPageProps;
    https?: HttpsSettingsPageProps;
    timezone?: DisplayTimezoneSettingsProps;
    network?: NetworkSettingsPageProps;
    mfaManagement?: MfaManagementPageProps;
    mfa?: FoundationMfaManagementPage;
    aclManagement?: ManagementAccessPageProps;
    acl?: ManagementAccessPolicyPanelProps;
    roleManagement?: RoleManagementPageProps;
    rbac?: RoleChangeReviewPanelProps;
    sessionManagement?: SessionManagementPageProps;
    sessions?: SessionListProps;
    auditExplorer?: AuditExplorerPageProps;
    audit?: AuditListProps;
    healthPage?: SystemHealthPageProps;
    health?: SystemStatusProps;
};
export type SystemManagementWorkspaceProps = {
    productId: string;
    bindings: StandardAdministrationTaskBindings;
    pages: FoundationManagementPages;
    actor?: {
        label: string;
        detail?: string;
    };
    onPageChange?: (task: StandardAdministrationTaskId | null) => void;
    initialTask?: StandardAdministrationTaskId | null;
    /** Omit duplicate Administration H1 when the consuming ProductShell owns it. */
    showHeader?: boolean;
    /** Keep optional task discovery opt-in so the Control baseline can remain unchanged. */
    searchable?: boolean;
    /** Optional consumer-owned access-context presentation for exact shell parity. */
    hubIntro?: ReactNode;
};
/** Whole Administration workspace composition, navigation and safe access gate. */
export declare function SystemManagementWorkspace({ productId, bindings, pages, actor, onPageChange, initialTask, showHeader, searchable, hubIntro }: SystemManagementWorkspaceProps): import("react").JSX.Element;
