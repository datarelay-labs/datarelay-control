import type { MutationOutcome, OperationPreview, ReadBack } from "@datarelay-labs/system-contracts";
/** Product Core owns actual listeners, reverse proxy and rollback guarantees. */
export type NetworkSettingsState = {
    httpPort: number;
    httpsPort: number;
    activeHttpPort: number;
    activeHttpsPort: number;
    pendingApply: boolean;
};
export type NetworkSettingsDraft = {
    httpPort: number;
    httpsPort: number;
    expectedRevision: string;
};
export type NetworkSafetyEvidence = {
    safe: boolean;
    blockers: readonly string[];
    expectedRevision: string;
    rollbackAvailable: boolean;
    httpUrl?: string;
    httpsUrl?: string;
};
/**
 * Strict stronger-than-basic NetworkAdapter product boundary.
 * Every host-side save/apply is both role-authorized AND revision-bound in Core;
 * safe preview with verified recovery is mandatory before any write.
 */
export type NetworkSettingsAdapter = {
    read: () => Promise<ReadBack<NetworkSettingsState>>;
    preview: (draft: NetworkSettingsDraft) => Promise<OperationPreview<NetworkSafetyEvidence>>;
    saveDesired: (draft: NetworkSettingsDraft) => Promise<ReadBack<NetworkSettingsState>>;
    apply: (expectedRevision: string) => Promise<MutationOutcome<NetworkSettingsState>>;
};
export type NetworkSettingsPageProps = {
    adapter: NetworkSettingsAdapter;
    /** Product-supplied authoritative permission; never inferred from a role label. */
    canManage?: boolean;
};
export declare function validateNetworkPorts(httpValue: string, httpsValue: string): {
    httpPort: number;
    httpsPort: number;
} | string;
/**
 * Reusable Control Save->Apply->Reconnect UI. Never treats an interrupted
 * connection as successful. Client cannot start or control a host service.
 */
export declare function NetworkSettingsPage({ adapter, canManage }: NetworkSettingsPageProps): import("react").JSX.Element;
