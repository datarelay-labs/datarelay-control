export type AuditPageQuery = {
    action?: string;
    entityType?: string;
    result?: "success" | "failure";
    limit: number;
    offset: number;
};
export type AuditExplorerRecord = {
    id: string;
    timestamp: string;
    actor?: string | null;
    action: string;
    entityType?: string | null;
    entityId?: string | null;
    result: string;
    summary?: string | null;
};
export type AuditQueryResult = {
    items: readonly AuditExplorerRecord[];
    total: number;
    offset: number;
    limit: number;
};
export type AuditExplorerAdapter = {
    query: (query: AuditPageQuery) => Promise<AuditQueryResult>;
};
export type AuditExplorerPageProps = {
    adapter: AuditExplorerAdapter;
    canRead?: boolean;
    formatTimestamp?: (timestamp: string) => string;
};
/** Complete read-only Control query surface: adapter owns server filtering and total count. */
export declare function AuditExplorerPage({ adapter, canRead, formatTimestamp }: AuditExplorerPageProps): import("react").JSX.Element;
