import { type ConformanceReport } from "./types";
/**
 * Product-authoritative role/route evidence is supplied by the consumer.
 * This is a pure, read-only consistency check: it does not query the backend,
 * grant permissions, certify any real deployment, or replace User E2E.
 */
export type AdministrationActorAccess = "none" | "view" | "manage";
export type AdministrationBackendAccess = AdministrationActorAccess | "unknown";
export type AdministrationAdmission = "allowed" | "denied" | "unknown";
export type AdministrationRequiredRead = {
    /** A non-sensitive stable ID, NOT a URL, token or request body. */
    id: string;
    admission: AdministrationAdmission;
};
export type AdministrationTaskAuthorityCase = {
    /** Stable product and role labels, never user-specific identifiers. */
    productId: string;
    roleId: string;
    taskId: string;
    /** Actor access advertised by the product's shared Administration UI. */
    presentedAccess: AdministrationActorAccess;
    /** Independent product-owned effective API permission for this task. */
    backendAccess: AdministrationBackendAccess;
    /** Product-owned navigation/action target's actual admission. */
    targetAdmission: AdministrationAdmission;
    /**
     * The consumer attests that all mandatory initial requests are listed below.
     * A claimed true value is NOT evidence that a live browser flow was verified.
     */
    pageLoadCovered: boolean;
    requiredReads: readonly AdministrationRequiredRead[];
};
/**
 * Compare an actor's UI-displayed administrative tasks against independent
 * product route/API authority and *all mandatory* initial page-load reads.
 *
 * No backend requests are made, and a passing result says only that the
 * provided product fixture is internally consistent, NOT that it is true.
 */
export declare function verifyAdministrationTaskAuthority(cases: readonly AdministrationTaskAuthorityCase[]): ConformanceReport;
