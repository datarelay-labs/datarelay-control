export declare const MAX_WORKSPACE_JSON_BYTES: number;
export type WorkspaceImportMode = "additive" | "clone";
export type WorkspaceImportIntent = {
    bundle: Record<string, unknown>;
    mode: WorkspaceImportMode;
    cloneSuffix?: string;
};
export type WorkspaceImportPreview = {
    previewRef: string;
    expectedRevision: string;
    mode: WorkspaceImportMode;
    expiresAt: string;
    ok: boolean;
    counts: readonly {
        label: string;
        count: number;
    }[];
    conflicts: readonly string[];
    warnings: readonly string[];
    actorAuthorized: boolean;
    recentMfaVerified: boolean;
    auditReady: boolean;
    rollbackReady: boolean;
};
export type WorkspaceImportReceipt = {
    idempotencyKey: string;
    previewRef: string;
    mode: WorkspaceImportMode;
    status: "running" | "completed" | "failed";
    afterRevision?: string;
    auditReference?: string;
};
export type WorkspaceExport = {
    blob: Blob;
    filename: string;
    redacted: true;
    auditReference: string;
};
/** Adapters atomically bind preview to bundle/mode/revision and honor idempotency on every apply. */
export type WorkspaceTransferAdapter = {
    exportWorkspace: (options: {
        includeCheckpoints: boolean;
        includeDestinations: boolean;
    }) => Promise<WorkspaceExport>;
    previewImport: (intent: WorkspaceImportIntent) => Promise<WorkspaceImportPreview>;
    applyImport: (request: WorkspaceImportIntent & {
        previewRef: string;
        expectedRevision: string;
        idempotencyKey: string;
        confirm: true;
    }) => Promise<WorkspaceImportReceipt>;
    readImport: (idempotencyKey: string) => Promise<WorkspaceImportReceipt | null>;
};
export type BackupImportPageProps = {
    adapter: WorkspaceTransferAdapter;
    canExport?: boolean;
    canPreview?: boolean;
    canApply?: boolean;
};
/** Portable product payload is opaque. Parsing does not run scripts or merge object prototypes. */
export declare function parseWorkspaceImport(text: string): Record<string, unknown>;
/** Common Control JSON export/preview/import, deliberately distinct from database disaster recovery. */
export declare function BackupImportPage({ adapter, canExport, canPreview, canApply }: BackupImportPageProps): import("react").JSX.Element;
