import { type ReactNode } from "react";
import type { NavigationActiveResolver, ProductCapabilityMap, ProductIdentity, ProductNavigationItem, ProductNavigationEntry, ProductShellPrincipal, ProductRuntimeEnvironment, ProductAccountAction } from "./types";
export type ProductShellProps = {
    product: ProductIdentity;
    navigation: readonly ProductNavigationEntry[];
    currentPath: string;
    onNavigate: (path: string, item?: ProductNavigationItem) => void;
    capabilities?: ProductCapabilityMap;
    isNavigationItemActive?: NavigationActiveResolver;
    pageTitle: string;
    pageSubtitle?: string;
    /** Optional Control-style runtime/status context rendered beside the page title. */
    headerContext?: ReactNode;
    principal?: ProductShellPrincipal;
    /** Optional, authoritative consumer-reported environment; absent means no badge. */
    environment?: ProductRuntimeEnvironment;
    /** Product-owned account/menu actions that remain accessible when collapsed. */
    accountActions?: readonly ProductAccountAction[];
    headerActions?: ReactNode;
    /** Opt-in capability-filtered command search over the product's existing navigation. */
    quickNavigation?: boolean;
    /** Optional Ctrl/Cmd+K shortcut control. Defaults on with quick navigation for compatibility. */
    quickNavigationShortcut?: boolean;
    /** Opt-in presentation-only breadcrumb for an exact visible two-level route. */
    breadcrumbs?: boolean;
    sidebarTopSlot?: ReactNode;
    sidebarFooterSlot?: ReactNode;
    userActions?: ReactNode;
    children: ReactNode;
    /** Optional scoped shell class for a canonical product-family presentation. */
    className?: string;
    contentId?: string;
    collapsed?: boolean;
    defaultCollapsed?: boolean;
    onCollapsedChange?: (collapsed: boolean) => void;
    mobileOpen?: boolean;
    defaultMobileOpen?: boolean;
    onMobileOpenChange?: (open: boolean) => void;
};
export declare function ProductEnvironmentStatus({ environment, compact }: {
    environment: ProductRuntimeEnvironment;
    compact?: boolean;
}): import("react").JSX.Element;
export declare function DataRelayWordmark({ collapsed }: {
    collapsed?: boolean;
}): import("react").JSX.Element;
export declare function ProductShell({ product, navigation, currentPath, onNavigate, capabilities, isNavigationItemActive, pageTitle, pageSubtitle, headerContext, principal, environment, accountActions, headerActions, quickNavigation, quickNavigationShortcut, breadcrumbs, sidebarTopSlot, sidebarFooterSlot, userActions, children, className, contentId, collapsed: controlledCollapsed, defaultCollapsed, onCollapsedChange, mobileOpen: controlledMobileOpen, defaultMobileOpen, onMobileOpenChange }: ProductShellProps): import("react").JSX.Element;
