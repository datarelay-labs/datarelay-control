import type { ReadBack } from "@datarelay-labs/system-contracts";
export type AlertChannelKind = "webhook" | "slack" | "email";
export type OperationalAlertRule = {
    id: string;
    enabled: boolean;
    severity: "WARNING" | "CRITICAL";
    lastTriggeredAt: string | null;
};
export type OperationalAlertChannel = {
    kind: AlertChannelKind;
    configured: boolean;
    revision: string;
    label: string;
    supported: boolean;
};
export type OperationalAlertReceipt = {
    id: string;
    ruleId: string;
    channel: string;
    status: string;
    timestamp: string;
    detail?: string;
};
export type AlertPolicyState = {
    monitorEnabled: boolean;
    cooldownSeconds: number;
    rules: readonly OperationalAlertRule[];
    channels: readonly OperationalAlertChannel[];
    history: readonly OperationalAlertReceipt[];
};
export type AlertPolicyDraft = {
    expectedRevision: string;
    monitorEnabled: boolean;
    cooldownSeconds: number;
    rules: readonly Pick<OperationalAlertRule, "id" | "enabled" | "severity">[];
    /** Absent: keep, null: clear, string: replace. Never return these values in public read-back. */
    destinations: Partial<Record<AlertChannelKind, string | null>>;
};
export type AlertPolicyPreview = {
    expectedRevision: string;
    previewRef: string;
    allowed: boolean;
    blockers: readonly string[];
    actorAuthorized: boolean;
    recentMfaVerified: boolean;
    auditReady: boolean;
    destinationsVerified: boolean;
};
export type OperationalAlertsAdapter = {
    read: () => Promise<ReadBack<AlertPolicyState>>;
    preview: (draft: AlertPolicyDraft) => Promise<AlertPolicyPreview>;
    configure: (draft: AlertPolicyDraft, previewRef: string) => Promise<{
        auditReference: string;
        revision: string;
    }>;
    test: (request: {
        ruleId: string;
        expectedRevision: string;
    }) => Promise<OperationalAlertReceipt>;
};
export type OperationalAlertsProps = {
    adapter: OperationalAlertsAdapter;
    canRead?: boolean;
    canManage?: boolean;
    canTest?: boolean;
};
export declare function OperationalAlerts({ adapter, canRead, canManage, canTest }: OperationalAlertsProps): import("react").JSX.Element;
