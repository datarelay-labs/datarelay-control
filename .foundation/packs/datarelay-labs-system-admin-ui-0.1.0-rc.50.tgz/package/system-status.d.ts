import type { HealthProjection, SystemInfoProjection } from "@datarelay-labs/system-contracts";
export type SystemStatusProps = {
    health?: HealthProjection;
    info?: SystemInfoProjection;
    /** Opt-in display-only triage over checks already loaded from the product. */
    triageLoadedHealthChecks?: boolean;
};
export declare function SystemStatus({ health, info, triageLoadedHealthChecks }: SystemStatusProps): import("react").JSX.Element;
