import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { DATA_RETENTION_CATEGORIES, DATA_RETENTION_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const CATEGORY_LABELS = {
    audit_events: "Audit events",
    operation_history: "Operation history",
    notification_jobs: "Notification delivery jobs",
    configuration_revisions: "Configuration revisions",
    support_artifacts: "Support artifacts"
};
const BLOCKER_LABELS = {
    permission_denied: "Product permission denied",
    mfa_required: "Recent privileged MFA required",
    audit_unavailable: "Product audit unavailable",
    legal_hold: "Product legal hold prevents cleanup",
    protected_record: "Protected records are ineligible for deletion",
    dry_run_missing: "Deletion dry-run not verified",
    backup_unverified: "Source backup not verified",
    rollback_unavailable: "Product rollback unavailable",
    scheduler_unavailable: "Product scheduler unavailable",
    storage_unverified: "Product data storage boundary not verified",
    stale_revision: "Current retention revision changed",
    retention_minimum: "Proposed retention is below product-required minimum"
};
function object(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function only(v, keys) {
    return Object.keys(v).every((key) => keys.includes(key));
}
function bounded(v, low, high) {
    return typeof v === "number" && Number.isSafeInteger(v) &&
        v >= low && v <= high;
}
function validPolicy(v) {
    return object(v) &&
        only(v, ["retentionDays", "cleanupIntervalHours", "cleanupEnabled"]) &&
        bounded(v.retentionDays, 1, 36500) &&
        bounded(v.cleanupIntervalHours, 1, 720) &&
        typeof v.cleanupEnabled === "boolean";
}
function valid(v) {
    if (!object(v) ||
        !only(v, ["category", "revision", "effective", "proposed", "requirements", "preflight"]) ||
        typeof v.category !== "string" ||
        !DATA_RETENTION_CATEGORIES.includes(v.category) ||
        typeof v.revision !== "string" || !REF.test(v.revision) ||
        !validPolicy(v.effective) ||
        (v.proposed !== undefined && !validPolicy(v.proposed)) ||
        !object(v.requirements) ||
        !only(v.requirements, ["minimumDays", "legalHoldActive"]) ||
        !bounded(v.requirements.minimumDays, 1, 36500) ||
        typeof v.requirements.legalHoldActive !== "boolean")
        return false;
    if (v.preflight !== undefined) {
        const p = v.preflight;
        if (!object(p) ||
            !only(p, [
                "expectedRevision", "allowed", "blockers", "productApplyRequired",
                "estimatedRecordsToDelete", "dryRunVerified", "retentionWindowVerified",
                "legalHoldExcluded", "protectedRecordsExcluded", "backupVerified",
                "storageBoundaryVerified", "schedulerReady", "rollbackReady",
                "actorAuthorized", "recentMfaVerified", "auditReady"
            ]) ||
            typeof p.expectedRevision !== "string" || !REF.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" || p.productApplyRequired !== true ||
            !bounded(p.estimatedRecordsToDelete, 0, 1_000_000_000) ||
            !Array.isArray(p.blockers) || p.blockers.length > DATA_RETENTION_BLOCKERS.length)
            return false;
        const flags = [
            "dryRunVerified", "retentionWindowVerified", "legalHoldExcluded",
            "protectedRecordsExcluded", "backupVerified", "storageBoundaryVerified",
            "schedulerReady", "rollbackReady", "actorAuthorized",
            "recentMfaVerified", "auditReady"
        ];
        if (flags.some((key) => typeof p[key] !== "boolean"))
            return false;
        const seen = new Set();
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !DATA_RETENTION_BLOCKERS.includes(blocker) ||
                seen.has(blocker))
                return false;
            seen.add(blocker);
        }
        if (p.allowed && p.blockers.length > 0)
            return false;
    }
    return true;
}
function changed(a, b) {
    return a.retentionDays !== b.retentionDays ||
        a.cleanupIntervalHours !== b.cleanupIntervalHours ||
        a.cleanupEnabled !== b.cleanupEnabled;
}
/** Separate from backup archive retention. Classification, legal holds,
 * protected-record exclusions, dry-run and deletion are product-owned. */
export function DataRetentionPolicyReviewPanel({ projection, reviewAvailability = "unknown", onReviewRetention, pending = false }) {
    const inputValid = valid(projection);
    const current = inputValid ? projection : undefined;
    const next = current?.proposed;
    const preflight = current?.preflight;
    const different = Boolean(current && next && changed(current.effective, next));
    const belowMinimum = Boolean(current && next &&
        next.retentionDays < current.requirements.minimumDays);
    const shortenedOnHold = Boolean(current && next &&
        current.requirements.legalHoldActive &&
        next.retentionDays < current.effective.retentionDays);
    const cleanupDisabled = Boolean(current && next &&
        current.effective.cleanupEnabled && !next.cleanupEnabled);
    const stale = Boolean(preflight && preflight.expectedRevision !== current?.revision);
    const checks = Boolean(preflight && preflight.dryRunVerified &&
        preflight.retentionWindowVerified && preflight.legalHoldExcluded &&
        preflight.protectedRecordsExcluded && preflight.backupVerified &&
        preflight.storageBoundaryVerified && preflight.schedulerReady &&
        preflight.rollbackReady && preflight.actorAuthorized &&
        preflight.recentMfaVerified && preflight.auditReady);
    const eligible = Boolean(different && next?.cleanupEnabled &&
        !belowMinimum && !shortenedOnHold && !cleanupDisabled && !stale &&
        checks && preflight?.allowed && preflight.blockers.length === 0);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewRetention === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Data retention policy unavailable", description: "No product-authorized data lifecycle configuration was provided." });
    return (_jsxs("section", { className: "dr-admin__data-retention", "aria-label": "Product data retention policy review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Data retention review" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Data retention: ", eligible ? "review eligible" : inputValid ? "review unavailable" : "unknown"] })] }), !inputValid ? _jsx("p", { children: "Invalid product data retention policy evidence" }) : null, current ? (_jsxs(_Fragment, { children: [_jsx("h3", { children: CATEGORY_LABELS[current.category] }), _jsx("p", { children: "Product data cleanup is separate from backup archive retention" }), _jsxs("p", { children: ["Product minimum retention: ", current.requirements.minimumDays, " days"] }), _jsx("div", { className: "dr-admin__data-retention-table", children: _jsxs("table", { "aria-label": "Data retention policy comparison", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsxs("tbody", { children: [_jsxs("tr", { children: [_jsx("th", { scope: "row", children: "Retention duration" }), _jsxs("td", { children: [current.effective.retentionDays, " days"] }), _jsx("td", { children: next ? next.retentionDays + " days" : "Not supplied" })] }), _jsxs("tr", { children: [_jsx("th", { scope: "row", children: "Cleanup schedule interval" }), _jsxs("td", { children: [current.effective.cleanupIntervalHours, " hours"] }), _jsx("td", { children: next ? next.cleanupIntervalHours + " hours" : "Not supplied" })] }), _jsxs("tr", { children: [_jsx("th", { scope: "row", children: "Cleanup enabled" }), _jsx("td", { children: current.effective.cleanupEnabled ? "Enabled" : "Disabled" }), _jsx("td", { children: next ? (next.cleanupEnabled ? "Enabled" : "Disabled") : "Not supplied" })] })] })] }) }), !different ? _jsx("p", { children: "No data retention policy changes proposed" }) : null, belowMinimum ? _jsx("p", { children: "Proposed retention violates the product-required minimum" }) : null, shortenedOnHold ? _jsx("p", { children: "Legal hold prevents shortening product data retention" }) : null, cleanupDisabled ? _jsx("p", { children: "Disabling required cleanup needs product-specific policy authority" }) : null, !preflight ? _jsx("p", { children: "Product retention change preflight unavailable" }) : null, stale ? _jsx("p", { children: "Product retention change preview is stale" }) : null, preflight ? (_jsxs("div", { className: "dr-admin__data-retention-checks", children: [preflight.dryRunVerified ?
                                _jsxs("p", { children: ["Product dry-run estimate: ", preflight.estimatedRecordsToDelete.toLocaleString("en-US"), " eligible records (not deleted)"] }) :
                                _jsx("p", { children: "Product deletion dry-run is not verified" }), !preflight.retentionWindowVerified ? _jsx("p", { children: "Retention window is not verified" }) : null, !preflight.legalHoldExcluded ? _jsx("p", { children: "Legal hold exclusion has not been verified" }) : null, !preflight.protectedRecordsExcluded ? _jsx("p", { children: "Protected records exclusion has not been verified" }) : null, !preflight.backupVerified ? _jsx("p", { children: "Product backup not verified" }) : null, !preflight.storageBoundaryVerified ? _jsx("p", { children: "Product data storage boundaries are not verified" }) : null, !preflight.schedulerReady ? _jsx("p", { children: "Cleanup scheduler readiness is not verified" }) : null, !preflight.rollbackReady ? _jsx("p", { children: "Rollback and recovery are not verified" }) : null, !preflight.actorAuthorized ? _jsx("p", { children: "Current actor lacks verified permission" }) : null, !preflight.recentMfaVerified ? _jsx("p", { children: "Recent privileged MFA not verified" }) : null, !preflight.auditReady ? _jsx("p", { children: "Product audit persistence not ready" }) : null, preflight.blockers.map((blocker) => _jsx("p", { children: BLOCKER_LABELS[blocker] }, blocker))] })) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewRetention?.(current.category, current.revision), children: "Review data retention policy" })) : _jsx("p", { className: "dr-admin__muted", children: "Only a product-verified, current-revision dry-run and authorized lifecycle policy may be reviewed." })] })) : null] }));
}
