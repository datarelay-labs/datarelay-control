import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { NOTIFICATION_ROUTING_BLOCKERS } from "@datarelay-labs/system-contracts";
const REFERENCE = /^[a-z][a-z0-9_.-]{0,95}$/;
const KINDS = { smtp: "SMTP", webhook: "Webhook" };
const LABELS = {
    permission_denied: "Product permission denied",
    mfa_required: "Recent privileged MFA verification is required",
    sender_unavailable: "Product notification sender is unavailable",
    destination_unverified: "Destination validation is missing",
    credential_unavailable: "Credential readiness is unverified",
    tls_unverified: "Secure transport has not been verified",
    drain_unverified: "Outstanding notification queue transition is unverified",
    rollback_unavailable: "Product rollback is not ready",
    audit_unavailable: "Product audit readiness is unavailable",
    stale_revision: "Notification destination revision is stale"
};
const DISPLAY = [
    ["Destination enabled", "enabled"],
    ["Maximum send attempts", "maxAttempts"],
    ["Initial retry delay (seconds)", "initialDelaySeconds"],
    ["Maximum retry delay (seconds)", "maxDelaySeconds"]
];
function object(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function allowedKeys(v, allowed) {
    return Object.keys(v).every((key) => allowed.includes(key));
}
function boundedInt(v, min, max) {
    return typeof v === "number" && Number.isSafeInteger(v) && v >= min && v <= max;
}
function validRetry(v) {
    return object(v) &&
        allowedKeys(v, ["maxAttempts", "initialDelaySeconds", "maxDelaySeconds"]) &&
        boundedInt(v.maxAttempts, 1, 20) &&
        boundedInt(v.initialDelaySeconds, 1, 3600) &&
        boundedInt(v.maxDelaySeconds, v.initialDelaySeconds, 86400);
}
function valid(v) {
    if (!object(v) ||
        !allowedKeys(v, ["destination", "effective", "proposed", "preflight"]) ||
        !object(v.destination) ||
        !allowedKeys(v.destination, ["reference", "revision", "kind", "enabled"]) ||
        typeof v.destination.reference !== "string" || !REFERENCE.test(v.destination.reference) ||
        typeof v.destination.revision !== "string" || !REFERENCE.test(v.destination.revision) ||
        typeof v.destination.kind !== "string" || !Object.hasOwn(KINDS, v.destination.kind) ||
        typeof v.destination.enabled !== "boolean" || !validRetry(v.effective))
        return false;
    if (v.proposed !== undefined) {
        if (!object(v.proposed) ||
            !allowedKeys(v.proposed, ["enabled", "retryPolicy"]) ||
            typeof v.proposed.enabled !== "boolean" ||
            !validRetry(v.proposed.retryPolicy))
            return false;
    }
    if (v.preflight !== undefined) {
        const p = v.preflight;
        if (!object(p) ||
            !allowedKeys(p, [
                "expectedRevision", "allowed", "blockers", "productApplyRequired",
                "senderReady", "destinationValidated", "credentialReady", "tlsVerified",
                "queueDrainVerified", "rollbackReady", "actorAuthorized",
                "recentMfaVerified", "auditReady"
            ]) ||
            typeof p.expectedRevision !== "string" || !REFERENCE.test(p.expectedRevision) ||
            typeof p.allowed !== "boolean" || p.productApplyRequired !== true ||
            !Array.isArray(p.blockers) || p.blockers.length > NOTIFICATION_ROUTING_BLOCKERS.length)
            return false;
        for (const key of [
            "senderReady", "destinationValidated", "credentialReady", "tlsVerified",
            "queueDrainVerified", "rollbackReady", "actorAuthorized",
            "recentMfaVerified", "auditReady"
        ])
            if (typeof p[key] !== "boolean")
                return false;
        const seen = new Set();
        for (const code of p.blockers) {
            if (typeof code !== "string" ||
                !NOTIFICATION_ROUTING_BLOCKERS.includes(code) ||
                seen.has(code))
                return false;
            seen.add(code);
        }
        if (p.allowed && p.blockers.length > 0)
            return false;
    }
    return true;
}
function changed(v) {
    const p = v.proposed, e = v.effective;
    return p !== undefined && (p.enabled !== v.destination.enabled ||
        p.retryPolicy.maxAttempts !== e.maxAttempts ||
        p.retryPolicy.initialDelaySeconds !== e.initialDelaySeconds ||
        p.retryPolicy.maxDelaySeconds !== e.maxDelaySeconds);
}
function weakened(v) {
    const p = v.proposed, e = v.effective;
    return Boolean(p && (p.retryPolicy.maxAttempts < e.maxAttempts ||
        p.retryPolicy.initialDelaySeconds > e.initialDelaySeconds ||
        p.retryPolicy.maxDelaySeconds > e.maxDelaySeconds));
}
function formatted(v) {
    return typeof v === "boolean" ? (v ? "Enabled" : "Disabled") : String(v);
}
function policyValue(v, field) {
    switch (field) {
        case "maxAttempts": return v.maxAttempts;
        case "initialDelaySeconds": return v.initialDelaySeconds;
        default: return v.maxDelaySeconds;
    }
}
/** Deliberately does NOT implement Grafana Alertmanager group timing.
 * Only displays Foundation Python NotificationRetryPolicy and destination
 * enabled state, bound to a separate product-admin change preflight. */
export function NotificationRoutingReviewPanel({ projection, reviewAvailability = "unknown", onReviewPolicy, pending = false }) {
    const isValid = valid(projection);
    const value = isValid ? projection : undefined;
    const proposed = value?.proposed;
    const preflight = value?.preflight;
    const hasChange = Boolean(value && changed(value));
    const weaker = Boolean(value && weakened(value));
    const stale = Boolean(preflight && preflight.expectedRevision !== value?.destination.revision);
    const checks = Boolean(preflight && preflight.senderReady &&
        preflight.destinationValidated && preflight.credentialReady &&
        preflight.tlsVerified && preflight.queueDrainVerified &&
        preflight.rollbackReady && preflight.actorAuthorized &&
        preflight.recentMfaVerified && preflight.auditReady);
    const eligible = Boolean(hasChange && !weaker && !stale && checks &&
        preflight?.allowed && preflight.blockers.length === 0);
    const canReview = eligible && reviewAvailability === "supported" &&
        typeof onReviewPolicy === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Notification routing policy unavailable", description: "No current product-authorized SMTP/Webhook configuration was supplied." });
    return (_jsxs("section", { className: "dr-admin__notification-routing", "aria-label": "Notification routing policy review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Notification routing policy" }), _jsxs(StatusBadge, { tone: eligible ? "info" : "neutral", children: ["Notification policy: ", eligible ? "review eligible" : isValid ? "review unavailable" : "unknown"] })] }), !isValid ? _jsx("p", { children: "Invalid notification routing policy evidence" }) : null, value ? (_jsxs(_Fragment, { children: [_jsxs("p", { children: [KINDS[value.destination.kind], " destination"] }), _jsx("h3", { children: "Current product retry policy" }), _jsx("p", { className: "dr-admin__muted", children: "Product routing state, not proof of recipient delivery." }), _jsx("div", { className: "dr-admin__notification-routing-table", children: _jsxs("table", { "aria-label": "Delivery and retry configuration", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Setting" }), _jsx("th", { children: "Current" }), _jsx("th", { children: "Proposed" })] }) }), _jsx("tbody", { children: DISPLAY.map(([title, field]) => {
                                        const current = field === "enabled" ? value.destination.enabled :
                                            policyValue(value.effective, field);
                                        const target = field === "enabled" ? proposed?.enabled :
                                            proposed ? policyValue(proposed.retryPolicy, field) : undefined;
                                        return (_jsxs("tr", { children: [_jsx("th", { scope: "row", children: title }), _jsx("td", { children: formatted(current) }), _jsx("td", { children: target === undefined ? "Not supplied" : formatted(target) })] }, field));
                                    }) })] }) }), _jsx("p", { children: "Product preflight only; no SMTP or Webhook request is sent." }), !hasChange ? _jsx("p", { children: "No notification policy changes proposed" }) : null, weaker ? _jsx("p", { children: "Proposed retry policy weakens delivery safeguards" }) : null, !preflight ? _jsx("p", { children: "Product notification change preview unavailable" }) : null, stale ? _jsx("p", { children: "Notification policy preview revision is stale" }) : null, preflight ? (_jsxs("div", { className: "dr-admin__notification-routing-blockers", children: [!preflight.senderReady ? _jsx("p", { children: "Product notification sender is unavailable" }) : null, !preflight.destinationValidated ? _jsx("p", { children: "Destination validation is missing" }) : null, !preflight.credentialReady ? _jsx("p", { children: "Credential readiness is unverified" }) : null, !preflight.tlsVerified ? _jsx("p", { children: "Secure transport has not been verified" }) : null, !preflight.queueDrainVerified ? _jsx("p", { children: "Outstanding notification queue transition is unverified" }) : null, !preflight.rollbackReady ? _jsx("p", { children: "Product rollback is not ready" }) : null, !preflight.actorAuthorized ? _jsx("p", { children: "Actor authority not confirmed" }) : null, !preflight.recentMfaVerified ? _jsx("p", { children: "Recent privileged MFA verification is required" }) : null, !preflight.auditReady ? _jsx("p", { children: "Product audit readiness is unavailable" }) : null, preflight.blockers.map((code) => _jsx("p", { children: LABELS[code] }, code))] })) : null, canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewPolicy?.(value.destination.reference, value.destination.revision), children: "Review notification policy" })) : _jsx("p", { className: "dr-admin__muted", children: "Only product-authenticated, fresh, reversible changes can enter a product-owned review." })] })) : null] }));
}
