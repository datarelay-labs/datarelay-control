"""Reusable DataRelay domain services and security primitives, not a running server."""
from .asgi import WebManagementAclGuard
from .audit import (
    AdminAuditEvent, AuditOutcome, AuditTransport, DeliveryStatus,
    ForwardReceipt, SAFE_DETAIL_KEYS, canonical_event, encode_rfc5424,
    forward_event,
)
from .acl import (
    AccessChangePreview, AllowEntry, Decision, ManagementPolicy, Reason,
    SurfacePolicy, authorize, authorize_management, canonical_network,
    preview_change, resolve_web_source,
)
from .offline_upgrade import (
    ArtifactKind, ArtifactProof, InstalledProduct, OfflineArtifact,
    UpgradeBlocker, UpgradeEvidence, UpgradePreview,
    UpgradeRollbackBlocker, UpgradeRollbackEvidence, UpgradeRollbackPreview,
    preview_offline_rollback, preview_offline_upgrade,
    verify_stream_sha256,
)
from .backup_recovery import (
    BackupAssessment, BackupEvidence, BackupKind, BackupPolicy,
    BackupProblem, BackupState, RestoreBlocker, RestoreEvidence,
    RestorePreview, assess_backup, preview_restore,
)
from .configuration_history import (
    ConfigChange, ConfigDiff, ConfigField, ConfigRevision,
    RollbackBlocker, RollbackEvidence, RollbackPreview,
    diff_configurations, preview_config_rollback,
)
from .connectivity_diagnostics import (
    DiagnosticArea, DiagnosticFinding, DiagnosticPolicy, DiagnosticReport,
    NetworkEvidence, Reason as ConnectivityReason, Remediation, Severity,
    diagnose_network,
)
from .notification_delivery import (
    AttemptDecision, AttemptOutcome, NotificationDestination,
    NotificationError, NotificationJob, NotificationKind,
    NotificationRetryPolicy, NotificationState, TestSendBlocker,
    TestSendEvidence, TestSendPreview, admit_delivery_attempt,
    preview_test_send, record_delivery_attempt,
)
from .role_policy import (
    Access, Availability, CapabilityProjection, RoleCapabilities,
    RoleChangeBlocker, RoleChangeEvidence, RoleChangePreview,
    effective_access, preview_role_change,
)
from .secrets_lifecycle import (
    RotationBlocker, RotationEvidence, RotationPreview, SecretHealth,
    SecretKind, SecretLifecyclePolicy, SecretMetadata, SecretPublicSummary,
    SecretState, describe_secret, preview_secret_rotation,
)
from .session_policy import (
    LoginAttemptSnapshot, LoginDisposition, LoginThrottlePolicy,
    PasswordAssessment, PasswordIssue, PasswordPolicy, SessionDecision,
    SessionEvidence, SessionPolicy, SessionReason, allow_additional_session,
    assess_login_attempt, assess_session, evaluate_new_password,
    stricter_password_policy,
)
from .totp import (
    PasswordResult, UserMfaState, code_at, new_recovery_codes,
    new_totp_secret, provisioning_uri, recovery_code_digest, verify_totp,
)

from .timezone_service import (
    DisplayTimezoneService, MemoryTimezoneStore, SettingsActor,
    SettingsPermissionError, SettingsRevisionConflict, SettingsValidationError,
    TimezoneStore, VersionedTimezoneState,
)

from .retention_service import (
    RetentionService, RetentionStore, RetentionRecord, RetentionReadiness,
    RetentionSnapshot, RetentionPlan, MemoryRetentionStore,
)

from .network_service import (
    NetworkSettingsService, NetworkStore, NetworkHostDriver, NetworkReadiness,
    NetworkSnapshot, NetworkPreview, NetworkApplyClaim, NetworkApplyUnverified,
    MemoryNetworkStore,
)

from .user_service import (
    UserManagementService, UserStore, UserPasswordHasher, UserSnapshot, UserPreview,
    UserMutation, UserChangeUnverified, MemoryUserStore,
)

from .https_service import (
    HttpsSettingsService, HttpsStore, HttpsHostDriver, HttpsReadiness, HttpsObservation,
    HttpsSnapshot, HttpsPreview, HttpsApplyClaim, HttpsApplyUnverified, MemoryHttpsStore,
)

from .workspace_transfer_service import (
    WorkspaceTransferService, WorkspaceStore, WorkspaceInterpreter, WorkspaceSnapshot,
    WorkspaceReadiness, WorkspaceImportAnalysis, WorkspaceExportProjection,
    WorkspaceExportArtifact, WorkspaceImportPlan, WorkspaceImportOperation,
    WorkspaceDecision, WorkspaceCommitResult, WorkspaceTransferUnverified, MemoryWorkspaceStore,
)

from .audit_query_service import (
    AuditExplorerService, AuditQueryStore, AuditReadScope, AuditExplorerRecord,
    AuditQueryPlan, AuditSelection, AuditQueryUnavailable, MemoryAuditQueryStore,
)

from .system_health_service import (
    SystemHealthService, SystemHealthSource, HealthMetricSample, HealthSummarySnapshot,
    HealthMetadata, HealthReadUnavailable,
)

from .operational_alert_service import (
    OperationalAlertService, AlertStore, AlertTransport, AlertReadiness, AlertSnapshot,
    AlertPreview, AlertJob, AlertMutation, AlertDeliveryObservation, AlertOperationUnverified, MemoryAlertStore,
)

from .support_bundle_service import (
    SupportBundleService, SupportStore, SupportCollector, SupportPrivacyScanner, CollectedSupportEvidence,
    SupportPrivacyReport, SupportReadiness, SupportArchive, SupportDownload, SupportBundleUnavailable, MemorySupportStore,
)

from .management_access_service import (
    ManagementAccessService, ManagementAccessDriver, ManagementAccessStore,
    ManagementAccessContext, ManagementAccessObservation, ManagementAccessSnapshot,
    ManagementAccessPreview, ManagementAccessClaim, ManagementAccessUnverified,
    MemoryManagementAccessStore,
)

from .mfa_service import (
    MfaLifecycleService, MfaNativeDriver, MfaStore, MfaRecoveryCodec, MfaReadiness,
    MfaChallenge, PendingEnrollment, MfaSnapshot, MfaMutation,
    MfaVerificationUnverified, MemoryMfaStore,
)

from .role_management_service import (
    RoleManagementService, RoleManagementDriver, RoleManagementStore,
    RoleManagementReadiness, RoleDirectorySnapshot, RoleAssignmentPreview,
    RoleDirectoryMutation, MemoryRoleManagementStore,
)

from .session_management_service import (
    SessionManagementService, SessionManagementDriver, SessionManagementStore,
    SessionManagementReadiness, ManagedSession, SessionDirectorySnapshot,
    SessionMutation, MemorySessionManagementStore,
)

__all__ = [
    "SessionManagementService", "SessionManagementDriver", "SessionManagementStore",
    "SessionManagementReadiness", "ManagedSession", "SessionDirectorySnapshot",
    "SessionMutation", "MemorySessionManagementStore",
    "RoleManagementService", "RoleManagementDriver", "RoleManagementStore",
    "RoleManagementReadiness", "RoleDirectorySnapshot", "RoleAssignmentPreview",
    "RoleDirectoryMutation", "MemoryRoleManagementStore",
    "MfaLifecycleService", "MfaNativeDriver", "MfaStore", "MfaRecoveryCodec", "MfaReadiness",
    "MfaChallenge", "PendingEnrollment", "MfaSnapshot", "MfaMutation",
    "MfaVerificationUnverified", "MemoryMfaStore",
    "ManagementAccessService", "ManagementAccessDriver", "ManagementAccessStore",
    "ManagementAccessContext", "ManagementAccessObservation", "ManagementAccessSnapshot",
    "ManagementAccessPreview", "ManagementAccessClaim", "ManagementAccessUnverified",
    "MemoryManagementAccessStore",
    "SupportBundleService", "SupportStore", "SupportCollector", "SupportPrivacyScanner", "CollectedSupportEvidence",
    "SupportPrivacyReport", "SupportReadiness", "SupportArchive", "SupportDownload", "SupportBundleUnavailable", "MemorySupportStore",
    "OperationalAlertService", "AlertStore", "AlertTransport", "AlertReadiness", "AlertSnapshot",
    "AlertPreview", "AlertJob", "AlertMutation", "AlertDeliveryObservation", "AlertOperationUnverified", "MemoryAlertStore",
    "SystemHealthService", "SystemHealthSource", "HealthMetricSample", "HealthSummarySnapshot",
    "HealthMetadata", "HealthReadUnavailable",
    "AuditExplorerService", "AuditQueryStore", "AuditReadScope", "AuditExplorerRecord",
    "AuditQueryPlan", "AuditSelection", "AuditQueryUnavailable", "MemoryAuditQueryStore",
    "WorkspaceTransferService", "WorkspaceStore", "WorkspaceInterpreter", "WorkspaceSnapshot",
    "WorkspaceReadiness", "WorkspaceImportAnalysis", "WorkspaceExportProjection",
    "WorkspaceExportArtifact", "WorkspaceImportPlan", "WorkspaceImportOperation",
    "WorkspaceDecision", "WorkspaceCommitResult", "WorkspaceTransferUnverified", "MemoryWorkspaceStore",
    "HttpsSettingsService", "HttpsStore", "HttpsHostDriver", "HttpsReadiness", "HttpsObservation",
    "HttpsSnapshot", "HttpsPreview", "HttpsApplyClaim", "HttpsApplyUnverified", "MemoryHttpsStore",
    "UserManagementService", "UserStore", "UserPasswordHasher", "UserSnapshot", "UserPreview",
    "UserMutation", "UserChangeUnverified", "MemoryUserStore",
    "NetworkSettingsService", "NetworkStore", "NetworkHostDriver", "NetworkReadiness",
    "NetworkSnapshot", "NetworkPreview", "NetworkApplyClaim", "NetworkApplyUnverified",
    "MemoryNetworkStore",

    "RetentionService", "RetentionStore", "RetentionRecord", "RetentionReadiness",
    "RetentionSnapshot", "RetentionPlan", "MemoryRetentionStore",

    "DisplayTimezoneService", "MemoryTimezoneStore", "SettingsActor",
    "SettingsPermissionError", "SettingsRevisionConflict", "SettingsValidationError",
    "TimezoneStore", "VersionedTimezoneState",
    "ArtifactKind", "ArtifactProof", "InstalledProduct", "OfflineArtifact",
    "UpgradeBlocker", "UpgradeEvidence", "UpgradePreview",
    "UpgradeRollbackBlocker", "UpgradeRollbackEvidence",
    "UpgradeRollbackPreview", "preview_offline_rollback",
    "preview_offline_upgrade", "verify_stream_sha256",
    "BackupAssessment", "BackupEvidence", "BackupKind", "BackupPolicy",
    "BackupProblem", "BackupState", "RestoreBlocker", "RestoreEvidence",
    "RestorePreview", "assess_backup", "preview_restore",
    "ConfigChange", "ConfigDiff", "ConfigField", "ConfigRevision",
    "RollbackBlocker", "RollbackEvidence", "RollbackPreview",
    "diff_configurations", "preview_config_rollback",
    "DiagnosticArea", "DiagnosticFinding", "DiagnosticPolicy",
    "DiagnosticReport", "NetworkEvidence", "ConnectivityReason",
    "Remediation", "Severity", "diagnose_network",
    "AttemptDecision", "AttemptOutcome", "NotificationDestination",
    "NotificationError", "NotificationJob", "NotificationKind",
    "NotificationRetryPolicy", "NotificationState",
    "TestSendBlocker", "TestSendEvidence", "TestSendPreview",
    "admit_delivery_attempt", "preview_test_send", "record_delivery_attempt",
    "Access", "Availability", "CapabilityProjection", "RoleCapabilities",
    "RoleChangeBlocker", "RoleChangeEvidence", "RoleChangePreview",
    "effective_access", "preview_role_change",
    "RotationBlocker", "RotationEvidence", "RotationPreview", "SecretHealth",
    "SecretKind", "SecretLifecyclePolicy", "SecretMetadata",
    "SecretPublicSummary", "SecretState", "describe_secret",
    "preview_secret_rotation",
    "LoginAttemptSnapshot", "LoginDisposition", "LoginThrottlePolicy",
    "PasswordAssessment", "PasswordIssue", "PasswordPolicy", "SessionDecision",
    "SessionEvidence", "SessionPolicy", "SessionReason",
    "allow_additional_session", "assess_login_attempt", "assess_session",
    "evaluate_new_password", "stricter_password_policy",
    "AdminAuditEvent", "AuditOutcome", "AuditTransport", "DeliveryStatus",
    "ForwardReceipt", "SAFE_DETAIL_KEYS", "canonical_event", "encode_rfc5424",
    "forward_event",
    "WebManagementAclGuard",
    "AccessChangePreview", "AllowEntry", "Decision", "ManagementPolicy", "Reason",
    "SurfacePolicy", "authorize", "authorize_management", "canonical_network",
    "preview_change", "resolve_web_source", "PasswordResult", "UserMfaState",
    "code_at", "new_recovery_codes", "new_totp_secret", "provisioning_uri",
    "recovery_code_digest", "verify_totp",
]
