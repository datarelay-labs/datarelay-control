import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
import { OFFLINE_UPGRADE_BLOCKERS } from "@datarelay-labs/system-contracts";
const REF = /^[a-z][a-z0-9_.-]{0,95}$/;
const VERSION = /^(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})$/;
const BLOCKERS = {
    wrong_product: "Artifact belongs to a different product",
    wrong_kind: "Host/OS upgrades are not generic product releases",
    not_newer: "Proposed version must be newer",
    major_upgrade_untested: "Major release migration untested",
    artifact_hash_mismatch: "Artifact SHA256 differs from pinned manifest",
    manifest_hash_mismatch: "Manifest SHA256 differs from pinned evidence",
    publisher_mismatch: "Publisher key does not match pinned authority",
    artifact_integrity_missing: "Artifact bytes were not independently hashed",
    manifest_integrity_missing: "Manifest bytes were not independently hashed",
    signature_unverified: "Publisher signature not verified",
    publisher_untrusted: "Publisher trust anchor not verified",
    provenance_unverified: "Release provenance not verified",
    stale_installation: "Product installation changed",
    installer_unavailable: "Product native installer unavailable",
    permission_denied: "Product actor unauthorized",
    mfa_required: "Recent product MFA required",
    schema_unverified: "Schema compatibility not proved",
    migration_untested: "Migration not tested",
    backup_unverified: "Backup and restore drill not verified",
    rollback_unverified: "Rollback package not verified",
    offline_recovery_required: "Offline recovery path required",
    maintenance_not_authorized: "Maintenance window not authorized",
    audit_unavailable: "Product audit unavailable"
};
const FLAGS = [
    ["schemaCompatible", "Schema compatibility unverified"],
    ["schemaMigrationTested", "Schema migration test unverified"],
    ["backupRestoreDrillVerified", "Isolated backup restore not verified"],
    ["rollbackArtifactVerified", "Rollback artifact not verified"],
    ["offlineConsoleRecoveryReady", "Offline console recovery not ready"],
    ["maintenanceWindowAuthorized", "Maintenance window not authorized"],
    ["actorAuthorized", "Actor authorization not confirmed"],
    ["recentMfaVerified", "Recent MFA verification not confirmed"],
    ["auditReady", "Audit readiness not confirmed"]
];
function obj(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}
function exactKeys(v, allow) {
    return Object.keys(v).every((k) => allow.includes(k));
}
function version(v) {
    return typeof v === "string" && VERSION.test(v);
}
function newer(current, target) {
    const a = current.split(".").map(Number), b = target.split(".").map(Number);
    for (let i = 0; i < 3; i += 1) {
        if (b[i] > a[i])
            return true;
        if (b[i] < a[i])
            return false;
    }
    return false;
}
function valid(v) {
    if (!obj(v) || !exactKeys(v, ["installed", "artifact", "proof", "preview"]) ||
        !obj(v.installed) || !exactKeys(v.installed, ["productRef", "revision", "version"]) ||
        typeof v.installed.productRef !== "string" || !REF.test(v.installed.productRef) ||
        typeof v.installed.revision !== "string" || !REF.test(v.installed.revision) ||
        !version(v.installed.version) ||
        !obj(v.artifact) || !exactKeys(v.artifact, ["productRef", "releaseRef", "version", "kind"]) ||
        typeof v.artifact.productRef !== "string" || !REF.test(v.artifact.productRef) ||
        typeof v.artifact.releaseRef !== "string" || !REF.test(v.artifact.releaseRef) ||
        !version(v.artifact.version) ||
        !["product_release", "platform_os_upgrade"].includes(String(v.artifact.kind)))
        return false;
    if (v.proof !== undefined) {
        if (!obj(v.proof) ||
            !exactKeys(v.proof, [
                "artifactBytesHashed", "manifestBytesHashed",
                "manifestSignatureVerified", "publisherTrustVerified",
                "provenanceVerified"
            ]) ||
            ["artifactBytesHashed", "manifestBytesHashed",
                "manifestSignatureVerified", "publisherTrustVerified",
                "provenanceVerified"].some((k) => typeof v.proof[k] !== "boolean"))
            return false;
    }
    if (v.preview !== undefined) {
        const p = v.preview;
        if (!obj(p) || !exactKeys(p, [
            "productRef", "releaseRef", "expectedInstalledRevision",
            "installedVersion", "targetVersion", "blockers", "maySubmitToProductInstaller",
            "productApplyRequired", ...FLAGS.map(([k]) => k)
        ]) || typeof p.productRef !== "string" || !REF.test(p.productRef) ||
            typeof p.releaseRef !== "string" || !REF.test(p.releaseRef) ||
            typeof p.expectedInstalledRevision !== "string" || !REF.test(p.expectedInstalledRevision) ||
            !version(p.installedVersion) || !version(p.targetVersion) ||
            p.productApplyRequired !== true ||
            typeof p.maySubmitToProductInstaller !== "boolean" ||
            !Array.isArray(p.blockers) || p.blockers.length > OFFLINE_UPGRADE_BLOCKERS.length ||
            FLAGS.some(([k]) => typeof p[k] !== "boolean"))
            return false;
        const seen = new Set();
        for (const blocker of p.blockers) {
            if (typeof blocker !== "string" ||
                !OFFLINE_UPGRADE_BLOCKERS.includes(blocker) ||
                seen.has(blocker))
                return false;
            seen.add(blocker);
        }
        if (p.maySubmitToProductInstaller && p.blockers.length > 0)
            return false;
    }
    return true;
}
/** PF-12 product-neutral offline upgrade review: zero I/O, no signing or
 * cryptographic publisher authentication by the UI, no host/DB update. */
export function OfflineUpgradeReviewPanel({ projection, reviewAvailability = "unknown", onReviewUpgrade, pending = false }) {
    const isValid = valid(projection);
    const value = isValid ? projection : undefined;
    const installed = value?.installed, artifact = value?.artifact;
    const proof = value?.proof, preview = value?.preview;
    const badProduct = Boolean(value && installed.productRef !== artifact.productRef);
    const wrongKind = Boolean(value && artifact.kind === "platform_os_upgrade");
    const notNewer = Boolean(value && !newer(installed.version, artifact.version));
    const stale = Boolean(preview && preview.expectedInstalledRevision !== installed?.revision);
    const differentProduct = Boolean(preview && preview.productRef !== installed?.productRef);
    const mismatchedRelease = Boolean(preview && preview.releaseRef !== artifact?.releaseRef);
    const installedMismatch = Boolean(preview && preview.installedVersion !== installed?.version);
    const targetMismatch = Boolean(preview && preview.targetVersion !== artifact?.version);
    const proofReady = Boolean(proof && Object.values(proof).every((x) => x === true));
    const previewReady = Boolean(preview && preview.maySubmitToProductInstaller &&
        preview.blockers.length === 0 && FLAGS.every(([k]) => preview[k] === true));
    const ready = Boolean(value && proofReady && previewReady && !badProduct &&
        !wrongKind && !notNewer && !stale && !differentProduct && !mismatchedRelease &&
        !installedMismatch && !targetMismatch);
    const canReview = ready && reviewAvailability === "supported" &&
        typeof onReviewUpgrade === "function";
    if (!projection)
        return _jsx(EmptyState, { title: "Offline update readiness unavailable", description: "No product-authorized release/installer evidence is available." });
    return (_jsxs("section", { className: "dr-admin__offline-upgrade", "aria-label": "Offline product update review", children: [_jsxs("div", { className: "dr-admin__section-heading", children: [_jsx("h2", { children: "Offline product update readiness" }), _jsx(StatusBadge, { tone: ready ? "info" : "neutral", children: ready ? "Review eligible — product evidence only" : "Review not established" })] }), !isValid ? _jsx("p", { children: "Invalid offline update review evidence" }) : null, value && installed && artifact ? (_jsxs(_Fragment, { children: [_jsx("p", { className: "dr-admin__muted", children: "Source-only review; no package installation or rollback is executed by Foundation." }), _jsxs("p", { children: ["Current version: ", installed.version] }), _jsxs("p", { children: ["Proposed version: ", artifact.version] }), _jsx("p", { children: artifact.kind === "product_release" ? "Product release artifact" : "Privileged host upgrade artifact" }), badProduct ? _jsx("p", { children: "Artifact belongs to a different product" }) : null, wrongKind ?
                        _jsx("p", { children: "Host/OS upgrades require a separate platform-authorized workflow" }) : null, notNewer ? _jsx("p", { children: "Proposed version is not newer than the installed version" }) : null, !proof ? _jsx("p", { children: "Product integrity proof unavailable" }) : (_jsx("div", { className: "dr-admin__offline-upgrade-evidence", children: proofReady ?
                            _jsx("p", { children: "Installer evidence and signature were verified by the product" }) : (_jsxs(_Fragment, { children: [!proof.artifactBytesHashed ? _jsx("p", { children: "Artifact bytes were not independently hashed" }) : null, !proof.manifestBytesHashed ? _jsx("p", { children: "Manifest bytes were not independently hashed" }) : null, !proof.manifestSignatureVerified ? _jsx("p", { children: "Publisher signature has not been verified" }) : null, !proof.publisherTrustVerified ? _jsx("p", { children: "Pinned publisher trust has not been verified" }) : null, !proof.provenanceVerified ? _jsx("p", { children: "Artifact provenance has not been verified" }) : null] })) })), !preview ? _jsx("p", { children: "Product offline upgrade preview unavailable" }) : (_jsxs("div", { className: "dr-admin__offline-upgrade-evidence", children: [stale ? _jsx("p", { children: "Installation revision no longer matches" }) : null, differentProduct ? _jsx("p", { children: "Upgrade preview product does not match" }) : null, mismatchedRelease ? _jsx("p", { children: "Upgrade release identity does not match" }) : null, installedMismatch ? _jsx("p", { children: "Current version and product preview do not match" }) : null, targetMismatch ? _jsx("p", { children: "Proposed version and product preview do not match" }) : null, FLAGS.map(([flag, description]) => preview[flag] ? null : _jsx("p", { children: description }, flag)), preview.blockers.map((code) => _jsx("p", { children: BLOCKERS[code] }, code))] })), canReview ? (_jsx(Button, { type: "button", variant: "secondary", disabled: pending, onClick: () => onReviewUpgrade?.(installed.revision, artifact.releaseRef), children: "Review offline update" })) : _jsx("p", { className: "dr-admin__muted", children: "A product-authorized, exact-revision verified artifact and rollback plan are required." })] })) : null] }));
}
