"""Common management-session listing and revocation over native session storage.

Foundation exposes only bounded display metadata and opaque action references.
The consuming product remains responsible for session issuance/cookies/tokens,
authentication admission and durable persistence. Revocation is atomic with audit,
current permission/MFA evidence and independent read-back; the actor's current
session is deliberately not revocable from this management page.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import time
import unicodedata

from .timezone_service import (
    SettingsActor,
    SettingsPermissionError,
    SettingsRevisionConflict,
    SettingsValidationError,
)


def _visible(value: object, maximum: int, label: str, *, whitespace: bool = False) -> str:
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= maximum
        or any(unicodedata.category(char).startswith("C") for char in value)
        or (not whitespace and any(char.isspace() for char in value))
    ):
        raise SettingsValidationError("Invalid " + label + ".")
    return value


def _stamp(value: object, label: str) -> int:
    if type(value) is not int or not 0 <= value <= 253402300799:
        raise SettingsValidationError("Invalid session " + label + ".")
    return value


def _epoch(value: object) -> int:
    if type(value) is not int or not 0 <= value < 2**53 - 1:
        raise SettingsValidationError("Invalid session authentication epoch.")
    return value


def _clock(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402300799:
        raise SettingsValidationError("Invalid native session clock.")
    return float(value)


def _iso(value: int) -> str:
    return datetime.fromtimestamp(value, timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class ManagedSession:
    id: str
    subject: str
    device_label: str | None
    source: str | None
    created_at: int
    last_seen_at: int
    expires_at: int
    auth_epoch: int
    revoked: bool
    revocable: bool

    def __post_init__(self) -> None:
        _visible(self.id, 256, "session reference")
        _visible(self.subject, 256, "session subject")
        if self.device_label is not None:
            _visible(self.device_label, 256, "session device label", whitespace=True)
        if self.source is not None:
            _visible(self.source, 512, "session source", whitespace=True)
        created = _stamp(self.created_at, "creation time")
        last = _stamp(self.last_seen_at, "last-seen time")
        expires = _stamp(self.expires_at, "expiry")
        if not created <= last <= expires:
            raise SettingsValidationError("Session timestamps are inconsistent.")
        _epoch(self.auth_epoch)
        if type(self.revoked) is not bool or type(self.revocable) is not bool:
            raise SettingsValidationError("Session state requires actual Boolean values.")


@dataclass(frozen=True)
class SessionManagementReadiness:
    revoke_supported: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    session_store_current: bool = False

    def __post_init__(self) -> None:
        if any(type(value) is not bool for value in vars(self).values()):
            raise SettingsValidationError("Session readiness requires actual native Boolean evidence.")

    @property
    def safe(self) -> bool:
        return all(vars(self).values())


@dataclass(frozen=True)
class SessionDirectorySnapshot:
    revision: str
    sessions: tuple[ManagedSession, ...]


@dataclass(frozen=True)
class SessionMutation:
    sessions: tuple[ManagedSession, ...]
    event: dict[str, Any]


class SessionManagementDriver(Protocol):
    """Native authenticated request/session context; never body-supplied."""

    def current_session_id(self, actor: SettingsActor) -> str | None: ...
    def readiness(
        self,
        actor: SettingsActor,
        subject: str,
        session_id: str,
    ) -> SessionManagementReadiness: ...


class SessionManagementStore(Protocol):
    """Existing product session registry with atomic revoke + audit."""

    def read(self) -> SessionDirectorySnapshot: ...

    def transact(
        self,
        expected_revision: str,
        build: Callable[[SessionDirectorySnapshot], SessionMutation],
    ) -> SessionDirectorySnapshot: ...

    def read_audit(self, reference: str) -> Mapping[str, Any] | None: ...


def _session_from_mapping(value: Mapping[str, Any]) -> ManagedSession:
    if not isinstance(value, Mapping) or set(value) != {
        "id",
        "subject",
        "deviceLabel",
        "source",
        "createdAt",
        "lastSeenAt",
        "expiresAt",
        "authEpoch",
        "revoked",
        "revocable",
    }:
        raise SettingsValidationError("Invalid native session record.")
    return ManagedSession(
        value["id"],
        value["subject"],
        value["deviceLabel"],
        value["source"],
        value["createdAt"],
        value["lastSeenAt"],
        value["expiresAt"],
        value["authEpoch"],
        value["revoked"],
        value["revocable"],
    )


class MemorySessionManagementStore:
    """Thread-safe synthetic registry; never a production session backend."""

    def __init__(self, sessions: list[Mapping[str, Any]]) -> None:
        if not isinstance(sessions, list) or len(sessions) > 100000:
            raise SettingsValidationError("Invalid reference session registry.")
        parsed = tuple(_session_from_mapping(item) for item in sessions)
        ids = [item.id for item in parsed]
        if len(ids) != len(set(ids)):
            raise SettingsValidationError("Session references must be unique.")
        self._sessions = parsed
        self._version = 1
        self._lock = RLock()
        self._audit: list[dict[str, Any]] = []

    def read(self) -> SessionDirectorySnapshot:
        with self._lock:
            return SessionDirectorySnapshot(
                "sessions-" + str(self._version),
                deepcopy(self._sessions),
            )

    def transact(
        self,
        expected_revision: str,
        build: Callable[[SessionDirectorySnapshot], SessionMutation],
    ) -> SessionDirectorySnapshot:
        with self._lock:
            before = self.read()
            if before.revision != _visible(expected_revision, 256, "session revision"):
                raise SettingsRevisionConflict("Session registry changed.")
            mutation = build(before)
            if not isinstance(mutation, SessionMutation):
                raise SettingsValidationError("Invalid atomic session mutation.")
            sessions = tuple(mutation.sessions)
            if not all(isinstance(item, ManagedSession) for item in sessions):
                raise SettingsValidationError("Invalid session mutation records.")
            ids = [item.id for item in sessions]
            if len(ids) != len(set(ids)):
                raise SettingsValidationError("Session mutation contains duplicate references.")
            event = deepcopy(dict(mutation.event))
            _visible(event.get("id"), 256, "audit reference")
            _visible(event.get("subject"), 256, "audit subject")
            _visible(event.get("sessionRef"), 256, "audit session reference")
            if event.get("action") != "sessions.revoked":
                raise SettingsValidationError("Invalid session audit event.")
            self._sessions = deepcopy(sessions)
            self._version += 1
            self._audit.append(event)
            return self.read()

    def read_audit(self, reference: str) -> Mapping[str, Any] | None:
        with self._lock:
            return deepcopy(next((event for event in self._audit if event["id"] == reference), None))

    def bump_for_test(self) -> None:
        with self._lock:
            self._version += 1

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class SessionManagementService:
    def __init__(
        self,
        store: SessionManagementStore,
        driver: SessionManagementDriver,
        *,
        authorize: Callable[[SettingsActor, str], bool],
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not callable(authorize):
            raise SettingsValidationError("Current native session authority is required.")
        self.store = store
        self.driver = driver
        self.authorize = authorize
        self.clock = clock

    def _now(self) -> float:
        return _clock(self.clock())

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = (
                isinstance(actor, SettingsActor)
                and permission in actor.capabilities
                and self.authorize(actor, permission) is True
            )
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError("Current native authority does not allow this session operation.")

    def _snapshot(self, expected: str | None = None) -> SessionDirectorySnapshot:
        value = self.store.read()
        if not isinstance(value, SessionDirectorySnapshot):
            raise SettingsValidationError("Invalid native session registry snapshot.")
        _visible(value.revision, 256, "session revision")
        if not isinstance(value.sessions, tuple) or not all(
            isinstance(session, ManagedSession) for session in value.sessions
        ):
            raise SettingsValidationError("Invalid native session registry.")
        ids = [session.id for session in value.sessions]
        if len(ids) != len(set(ids)):
            raise SettingsValidationError("Native session registry contains duplicate references.")
        if expected is not None and value.revision != _visible(expected, 256, "session revision"):
            raise SettingsRevisionConflict("Session registry changed. Refresh and retry.")
        return deepcopy(value)

    def _current_id(
        self,
        actor: SettingsActor,
        snapshot: SessionDirectorySnapshot,
    ) -> str | None:
        try:
            current = self.driver.current_session_id(actor)
        except Exception:
            raise SettingsValidationError("Current native session evidence is unavailable.") from None
        if current is None:
            return None
        current = _visible(current, 256, "current session reference")
        record = next((item for item in snapshot.sessions if item.id == current), None)
        if record is None or record.subject != actor.subject or record.revoked:
            raise SettingsValidationError("Current native session is not present in the authoritative registry.")
        return current

    def _read_permission(self, actor: SettingsActor, subject: str) -> str:
        return "sessions.read.self" if subject == actor.subject else "sessions.read.any"

    def _revoke_permission(self, actor: SettingsActor, subject: str) -> str:
        return "sessions.revoke.self" if subject == actor.subject else "sessions.revoke.any"

    @staticmethod
    def _projection(
        session: ManagedSession,
        *,
        current: bool,
    ) -> dict[str, Any]:
        return {
            "id": session.id,
            "deviceLabel": session.device_label,
            "createdAt": _iso(session.created_at),
            "lastSeenAt": _iso(session.last_seen_at),
            "expiresAt": _iso(session.expires_at),
            "source": session.source,
            "current": current,
            "revoked": session.revoked,
            "revocable": session.revocable and not session.revoked and not current,
        }

    def read(self, actor: SettingsActor, subject: str | None = None) -> dict[str, Any]:
        if not isinstance(actor, SettingsActor):
            raise SettingsPermissionError("Authenticated native session actor is required.")
        target = actor.subject if subject is None else _visible(subject, 256, "session subject")
        permission = self._read_permission(actor, target)
        self._require(actor, permission)
        snapshot = self._snapshot()
        current_id = self._current_id(actor, snapshot)
        self._require(actor, permission)
        records = [item for item in snapshot.sessions if item.subject == target]
        records.sort(key=lambda item: (item.id != current_id, -item.last_seen_at, item.id))
        return {
            "revision": snapshot.revision,
            "subject": target,
            "complete": True,
            "sessions": [
                self._projection(
                    item,
                    current=(target == actor.subject and item.id == current_id),
                )
                for item in records
            ],
        }

    @staticmethod
    def _request(value: Mapping[str, Any]) -> dict[str, Any]:
        if (
            not isinstance(value, Mapping)
            or set(value) != {"subjectRef", "sessionId", "expectedRevision", "confirm"}
            or value["confirm"] is not True
        ):
            raise SettingsValidationError("Exact current session intent and explicit confirmation are required.")
        return {
            "subjectRef": _visible(value["subjectRef"], 256, "session subject"),
            "sessionId": _visible(value["sessionId"], 256, "session reference"),
            "expectedRevision": _visible(value["expectedRevision"], 256, "session revision"),
            "confirm": True,
        }

    @staticmethod
    def _target(
        snapshot: SessionDirectorySnapshot,
        subject: str,
        session_id: str,
    ) -> ManagedSession:
        target = next(
            (
                item
                for item in snapshot.sessions
                if item.id == session_id and item.subject == subject
            ),
            None,
        )
        if target is None:
            raise SettingsValidationError("Selected session is not current.")
        return target

    def _ready(
        self,
        actor: SettingsActor,
        subject: str,
        session_id: str,
    ) -> SessionManagementReadiness:
        value = self.driver.readiness(actor, subject, session_id)
        if not isinstance(value, SessionManagementReadiness):
            raise SettingsValidationError("Current native session revocation readiness is required.")
        return value

    def revoke(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        draft = self._request(request)
        permission = self._revoke_permission(actor, draft["subjectRef"])
        self._require(actor, permission)
        before = self._snapshot(draft["expectedRevision"])
        current_id = self._current_id(actor, before)
        target = self._target(before, draft["subjectRef"], draft["sessionId"])
        if target.revoked or not target.revocable:
            raise SettingsValidationError("Selected session is not revocable.")
        if target.subject == actor.subject and target.id == current_id:
            raise SettingsPermissionError("Use the product sign-out flow for the current session.")
        readiness = self._ready(actor, target.subject, target.id)
        if not readiness.safe:
            raise SettingsPermissionError("Session revocation requires current MFA, audit and native revoke readiness.")
        event = {
            "id": "session-audit-" + uuid4().hex,
            "actor": actor.subject,
            "subject": target.subject,
            "sessionRef": target.id,
            "action": "sessions.revoked",
            "timestamp": self._now(),
        }
        expected_sessions: tuple[ManagedSession, ...] = ()

        def build(current: SessionDirectorySnapshot) -> SessionMutation:
            nonlocal expected_sessions
            self._require(actor, permission)
            if current.revision != before.revision or current.sessions != before.sessions:
                raise SettingsRevisionConflict("Native session registry changed during revoke.")
            current_id_now = self._current_id(actor, current)
            current_target = self._target(current, target.subject, target.id)
            if current_target.revoked or not current_target.revocable:
                raise SettingsValidationError("Selected session is no longer revocable.")
            if current_target.subject == actor.subject and current_target.id == current_id_now:
                raise SettingsPermissionError("Current session cannot be revoked from session management.")
            if not self._ready(actor, current_target.subject, current_target.id).safe:
                raise SettingsPermissionError("Current native session revocation safety changed.")
            expected_sessions = tuple(
                replace(item, revoked=True)
                if item.id == current_target.id and item.subject == current_target.subject
                else item
                for item in current.sessions
            )
            return SessionMutation(expected_sessions, event)

        returned = self.store.transact(before.revision, build)
        observed = self._snapshot()
        proof = self.store.read_audit(event["id"])
        observed_target = self._target(observed, target.subject, target.id)
        if (
            not isinstance(returned, SessionDirectorySnapshot)
            or returned.revision == before.revision
            or returned.revision != observed.revision
            or returned.sessions != expected_sessions
            or observed.sessions != expected_sessions
            or not observed_target.revoked
            or proof != event
        ):
            raise RuntimeError("Native session revocation/audit was not independently verified.")
        current_after = self._current_id(actor, observed)
        records = [item for item in observed.sessions if item.subject == target.subject]
        records.sort(key=lambda item: (item.id != current_after, -item.last_seen_at, item.id))
        return {
            "revision": observed.revision,
            "subject": target.subject,
            "complete": True,
            "sessions": [
                self._projection(
                    item,
                    current=(target.subject == actor.subject and item.id == current_after),
                )
                for item in records
            ],
            "auditReference": event["id"],
        }
