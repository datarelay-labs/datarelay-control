import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button } from "@datarelay-labs/ui";
import { PasswordRevealField } from "./password-reveal-field.js";
import { AuthErrorNotice } from "./auth-error-notice.js";
export function PasswordChangeForm({ onSubmit, busy = false, requireCurrentPassword = true, errorCategory, errorMessage, guidance, allowPasswordReveal = false }) {
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [localError, setLocalError] = useState("");
    function submit(event) {
        event.preventDefault();
        if (requireCurrentPassword && !currentPassword) {
            setLocalError("Enter your current password.");
            return;
        }
        if (!newPassword || !confirmPassword) {
            setLocalError("Enter and confirm the new password.");
            return;
        }
        if (newPassword !== confirmPassword) {
            setLocalError("New password and confirmation do not match.");
            return;
        }
        setLocalError("");
        void onSubmit({
            ...(requireCurrentPassword ? { currentPassword } : {}),
            newPassword,
            confirmPassword
        });
    }
    return (_jsxs("form", { className: "dr-auth-form", onSubmit: submit, children: [guidance ? _jsx("p", { className: "dr-auth-form__guidance", children: guidance }) : null, requireCurrentPassword ? (_jsx(PasswordRevealField, { label: "Current password", autoComplete: "current-password", allowReveal: allowPasswordReveal, value: currentPassword, onChange: (event) => setCurrentPassword(event.target.value), disabled: busy })) : null, _jsx(PasswordRevealField, { label: "New password", autoComplete: "new-password", allowReveal: allowPasswordReveal, value: newPassword, onChange: (event) => setNewPassword(event.target.value), disabled: busy }), _jsx(PasswordRevealField, { label: "Confirm new password", autoComplete: "new-password", allowReveal: allowPasswordReveal, value: confirmPassword, onChange: (event) => setConfirmPassword(event.target.value), disabled: busy }), localError ? _jsx(AuthErrorNotice, { category: "validation", message: localError }) : null, errorCategory ? _jsx(AuthErrorNotice, { category: errorCategory, ...(errorMessage ? { message: errorMessage } : {}) }) : null, _jsx(Button, { type: "submit", disabled: busy, children: busy ? "Updating…" : "Update password" })] }));
}
