import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useState } from "react";
import { TextField } from "@datarelay-labs/ui";
/** Pure UI state. Authentication and password policy remain consumer-owned. */
export function PasswordRevealField({ label, autoComplete, value, onChange, disabled = false, allowReveal = false, placeholder }) {
    const [revealed, setRevealed] = useState(false);
    const fieldId = useId().replaceAll(":", "");
    useEffect(() => {
        // Never leave a plaintext input visible across a pending submission.
        if (disabled || !allowReveal)
            setRevealed(false);
    }, [disabled, allowReveal]);
    const visible = allowReveal && !disabled && revealed;
    return (_jsxs("div", { className: "dr-auth-form__password-field", children: [_jsx(TextField, { id: fieldId, label: label, type: visible ? "text" : "password", autoComplete: autoComplete, value: value, onChange: onChange, placeholder: placeholder, disabled: disabled }), allowReveal ? (_jsxs("button", { type: "button", className: "dr-auth-form__reveal-button", "aria-controls": fieldId, "aria-pressed": visible, disabled: disabled, onClick: () => setRevealed((current) => !current), children: [visible ? "Hide" : "Show", " ", label.toLowerCase()] })) : null] }));
}
