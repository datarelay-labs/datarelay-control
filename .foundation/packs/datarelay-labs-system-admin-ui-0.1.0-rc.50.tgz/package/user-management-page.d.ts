export type ManagedUser = {
    id: string;
    username: string;
    roleRef: string;
    status: "active" | "disabled";
    mfaRequired: boolean;
    credentialRevision?: string;
};
export type UserDirectory = {
    revision: string;
    currentUserId: string;
    complete: boolean;
    accounts: ManagedUser[];
    roles: {
        ref: string;
        label: string;
        administrator: boolean;
    }[];
    passwordPolicy: {
        minimumLength: number;
        maximumLength: number;
    };
};
/** Passwords are deliberately excluded from the previewable intent. */
export type UserChangeDraft = {
    operation: "create" | "update" | "delete";
    accountId: string | null;
    username: string;
    roleRef: string;
    status: "active" | "disabled";
    expectedRevision: string;
    passwordChange: boolean;
};
export type UserChangePreview = {
    allowed: boolean;
    blockers: readonly string[];
    expectedRevision: string;
    draft: UserChangeDraft;
    token: string;
    expiresAt: number;
};
export type UserChangeReceipt = {
    applied: boolean;
    revision: string;
    auditRef: string;
    accountId: string;
    credentialRevision?: string;
};
export type UserManagementAdapter = {
    read: () => Promise<UserDirectory>;
    preview: (draft: UserChangeDraft) => Promise<UserChangePreview>;
    /** Native service rechecks role/preview/revision and commits mutation + audit atomically. */
    apply: (request: {
        draft: UserChangeDraft;
        previewToken: string;
        password?: string;
    }) => Promise<UserChangeReceipt>;
};
export type UserManagementPageProps = {
    adapter: UserManagementAdapter;
    canRead?: boolean;
    canManage?: boolean;
};
export declare function validUserDirectory(value: unknown): value is UserDirectory;
export declare function validateManagedPassword(value: string, policy: UserDirectory["passwordPolicy"]): string | null;
export declare function UserManagementPage({ adapter, canRead, canManage }: UserManagementPageProps): import("react").JSX.Element;
