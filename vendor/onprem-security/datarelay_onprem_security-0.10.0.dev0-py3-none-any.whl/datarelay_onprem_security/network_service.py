"""Reusable network settings coordinator; native effects require injected ports.

This module runs no shell commands and starts no listener. Products bind their
current actor/readiness, existing atomic store, and bounded host driver. The
memory store and test driver are development references, not host enforcement.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import time
from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict


class NetworkApplyUnverified(RuntimeError):
    """Host outcome was not proven; inspect the operation before retrying."""


def _ports(value: object) -> dict[str, int]:
    if not isinstance(value, Mapping) or set(value) != {'httpPort', 'httpsPort'}:
        raise SettingsValidationError('Only HTTP and HTTPS port values are accepted.')
    if any(type(v) is not int or not 1 <= v <= 65535 for v in value.values()):
        raise SettingsValidationError('Ports must be integers between 1 and 65535.')
    if value['httpPort'] == value['httpsPort']:
        raise SettingsValidationError('HTTP and HTTPS ports cannot match.')
    return dict(value)


def _ref(value: object) -> str:
    if not isinstance(value, str) or not 0 < len(value) <= 256 or any(ord(c) < 33 or ord(c) == 127 for c in value):
        raise SettingsValidationError('A current native reference is required.')
    return value


def _seconds(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402300799:
        raise SettingsValidationError('Invalid native time evidence.')
    return float(value)


@dataclass(frozen=True)
class NetworkReadiness:
    ports_available: bool = False
    recovery_ready: bool = False
    rollback_ready: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        if any(type(v) is not bool for v in vars(self).values()):
            raise SettingsValidationError('Readiness must contain actual native Boolean evidence.')

    @property
    def safe(self) -> bool:
        return all(vars(self).values())


@dataclass(frozen=True)
class NetworkSnapshot:
    revision: str
    desired: dict[str, int]
    applying: bool = False


@dataclass(frozen=True)
class NetworkPreview:
    reference: str
    actor: str
    revision: str
    desired: dict[str, int]
    created_at: float
    expires_at: float
    safe: bool


@dataclass(frozen=True)
class NetworkApplyClaim:
    reference: str
    actor: str
    revision: str
    desired: dict[str, int]
    previous: dict[str, int]


class NetworkHostDriver(Protocol):
    """Native implementation enforces actor/MFA/host permissions on each call.

    arm_rollback MUST persist and verify a time-limited host rollback timer and
    independent recovery route before returning True. The exclusive claim spans
    arm/apply/read-back/confirm. Native driver operations must be time-bounded.
    confirm cancels that timer only after verified state has been audited; on
    uncertainty the service never silently releases the native apply claim.
    """
    def readiness(self, actor: SettingsActor, desired: Mapping[str, int]) -> NetworkReadiness: ...
    def read_active(self) -> dict[str, int]: ...
    def arm_rollback(self, operation_id: str, previous: Mapping[str, int]) -> bool: ...
    def apply(self, operation_id: str, desired: Mapping[str, int]) -> None: ...
    def rollback(self, operation_id: str) -> None: ...
    def confirm(self, operation_id: str) -> None: ...


class NetworkStore(Protocol):
    """Bind existing native storage, not a new shared DB.

    Save CAS + audit is atomic. claim is a durable exclusive native operation
    lease: it blocks competing save/apply until complete or verified rollback.
    mark_applied atomically writes verified state/audit while retaining the lease.
    release follows native rollback-timer confirmation. fail retains the lease
    when recovery is unverified. Native persistence must enforce current auth,
    preview expiry and conflicts, preserve failure evidence, and never auto-retry
    a crashed/unknown host operation; recovery is an explicit native runbook.
    """
    def read(self) -> NetworkSnapshot: ...
    def register_preview(self, preview: NetworkPreview) -> None: ...
    def preview_for(self, actor: str, revision: str, desired: Mapping[str, int], now: float) -> NetworkPreview: ...
    def save(self, preview: NetworkPreview, event: Mapping[str, Any], now: float) -> NetworkSnapshot: ...
    def claim(self, actor: str, revision: str, previous: Mapping[str, int]) -> NetworkApplyClaim: ...
    def mark_applied(self, claim: NetworkApplyClaim, active: Mapping[str, int], event: Mapping[str, Any]) -> NetworkSnapshot: ...
    def release(self, claim: NetworkApplyClaim) -> None: ...
    def fail(self, claim: NetworkApplyClaim, event: Mapping[str, Any], recovered: bool) -> None: ...


class MemoryNetworkStore:
    """Thread-safe reference store; only in-memory desired metadata is changed."""
    def __init__(self, desired: Mapping[str, int] | None = None) -> None:
        self._lock = RLock(); self._version = 1
        self._desired = _ports(desired if desired is not None else {'httpPort': 18080, 'httpsPort': 18443})
        self._previews: dict[str, NetworkPreview] = {}; self._claim: NetworkApplyClaim | None = None
        self._audit: list[dict[str, Any]] = []

    def _snapshot(self) -> NetworkSnapshot:
        return NetworkSnapshot('network-' + str(self._version), dict(self._desired), self._claim is not None)

    def read(self) -> NetworkSnapshot:
        with self._lock: return self._snapshot()

    def _available(self, revision: str) -> None:
        if self._snapshot().revision != revision or self._claim is not None:
            raise SettingsRevisionConflict('Network state changed or an apply operation owns the native lease.')

    def register_preview(self, preview: NetworkPreview) -> None:
        with self._lock:
            self._available(preview.revision)
            self._previews = {k: v for k, v in self._previews.items() if v.expires_at > preview.created_at}
            if len(self._previews) >= 1024: raise SettingsValidationError('Preview capacity exceeded.')
            self._previews[preview.reference] = deepcopy(preview)

    def preview_for(self, actor: str, revision: str, desired: Mapping[str, int], now: float) -> NetworkPreview:
        with self._lock:
            self._available(revision)
            for p in reversed(tuple(self._previews.values())):
                if p.actor == actor and p.revision == revision and p.desired == dict(desired) and p.created_at <= now < p.expires_at and p.safe:
                    return deepcopy(p)
            raise SettingsValidationError('A current matching native network preview is required.')

    def save(self, preview: NetworkPreview, event: Mapping[str, Any], now: float) -> NetworkSnapshot:
        copied = deepcopy(dict(event)); _ref(copied.get('id')); desired = _ports(preview.desired)
        with self._lock:
            p = self.preview_for(preview.actor, preview.revision, desired, now)
            if p.reference != preview.reference: raise SettingsRevisionConflict('Network preview was replaced.')
            self._desired = desired; self._version += 1; self._audit.append(copied); self._previews.clear()
            return self._snapshot()

    def claim(self, actor: str, revision: str, previous: Mapping[str, int]) -> NetworkApplyClaim:
        old = _ports(previous)
        with self._lock:
            self._available(revision)
            claim = NetworkApplyClaim('network-apply-' + uuid4().hex, actor, revision, dict(self._desired), old)
            self._claim = claim
            return deepcopy(claim)

    def _owned(self, claim: NetworkApplyClaim) -> None:
        if self._claim != claim: raise SettingsRevisionConflict('Native apply lease no longer belongs to this operation.')

    def mark_applied(self, claim: NetworkApplyClaim, active: Mapping[str, int], event: Mapping[str, Any]) -> NetworkSnapshot:
        observed = _ports(active); copied = deepcopy(dict(event)); _ref(copied.get('id'))
        with self._lock:
            self._owned(claim)
            if observed != claim.desired: raise NetworkApplyUnverified('Active ports differ from the desired ports.')
            self._version += 1; self._audit.append(copied)
            return self._snapshot()  # Keep exclusive ownership until timer confirmation.

    def release(self, claim: NetworkApplyClaim) -> None:
        with self._lock:
            self._owned(claim); self._claim = None

    def fail(self, claim: NetworkApplyClaim, event: Mapping[str, Any], recovered: bool) -> None:
        copied = deepcopy(dict(event)); _ref(copied.get('id'))
        if type(recovered) is not bool: raise SettingsValidationError('Recovery must be verified explicitly.')
        with self._lock:
            self._owned(claim); self._audit.append(copied); self._version += 1
            if recovered: self._claim = None

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock: return deepcopy(self._audit)


class NetworkSettingsService:
    """Common native-adapter orchestration, not a success-producing mock API."""
    def __init__(self, store: NetworkStore, driver: NetworkHostDriver, *, clock: Callable[[], float] = time.time) -> None:
        self.store = store; self.driver = driver; self.clock = clock

    @staticmethod
    def _require(actor: SettingsActor, permission: str) -> None:
        if not isinstance(actor, SettingsActor) or permission not in actor.capabilities:
            raise SettingsPermissionError('Native actor lacks the required network capability.')

    def _snapshot(self, actor: SettingsActor, expected: object | None = None) -> NetworkSnapshot:
        self._require(actor, 'network.service_ports.read')
        s = self.store.read()
        if not isinstance(s, NetworkSnapshot) or type(s.applying) is not bool:
            raise SettingsValidationError('Invalid native network snapshot.')
        _ref(s.revision); _ports(s.desired)
        if expected is not None and _ref(expected) != s.revision:
            raise SettingsRevisionConflict('Network configuration revision changed.')
        return s

    def _project(self, s: NetworkSnapshot, active: Mapping[str, int]) -> dict[str, Any]:
        a = _ports(active)
        return {'effective': {**s.desired, 'activeHttpPort': a['httpPort'], 'activeHttpsPort': a['httpsPort'],
                              'pendingApply': s.applying or a != s.desired}, 'revision': s.revision}

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        s = self._snapshot(actor)
        return self._project(s, self.driver.read_active())

    def _draft(self, request: Mapping[str, Any]) -> dict[str, int]:
        if not isinstance(request, Mapping) or set(request) != {'httpPort', 'httpsPort', 'expectedRevision'}:
            raise SettingsValidationError('Submit only ports and expectedRevision.')
        _ref(request['expectedRevision'])
        return _ports({k: request[k] for k in ('httpPort', 'httpsPort')})

    def _readiness(self, actor: SettingsActor, desired: Mapping[str, int], *, require_safe: bool = True) -> NetworkReadiness:
        r = self.driver.readiness(actor, desired)
        if not isinstance(r, NetworkReadiness): raise SettingsValidationError('Invalid native recovery evidence.')
        if require_safe and not r.safe: raise SettingsPermissionError('Native ports, recovery, rollback, MFA and audit must all be ready.')
        return r

    def _event(self, actor: SettingsActor, action: str, operation: str = '') -> dict[str, Any]:
        return dict(id='network-audit-' + uuid4().hex, actor=actor.subject, action=action, operation=operation,
                    timestamp=datetime.fromtimestamp(_seconds(self.clock()), timezone.utc).isoformat())

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'network.service_ports.configure'); desired = self._draft(request)
        s = self._snapshot(actor, request['expectedRevision'])
        if s.applying: raise SettingsRevisionConflict('Native network operation is already active.')
        r = self._readiness(actor, desired, require_safe=False); now = _seconds(self.clock())
        p = NetworkPreview('network-preview-' + uuid4().hex, actor.subject, s.revision, desired, now, now + 300, r.safe)
        self.store.register_preview(p)
        return {'supported': True, 'summary': 'Review saved ports and the native recovery plan before applying.',
                'effects': ['reconnect_required'], 'detail': {'safe': r.safe, 'expectedRevision': s.revision,
                  'rollbackAvailable': r.rollback_ready, 'blockers': [k for k, v in vars(r).items() if not v]}}

    def save_desired(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'network.service_ports.configure'); desired = self._draft(request)
        s = self._snapshot(actor, request['expectedRevision'])
        p = self.store.preview_for(actor.subject, s.revision, desired, _seconds(self.clock()))
        self._readiness(actor, desired)
        event = self._event(actor, 'network.desired.saved')
        after = self.store.save(p, event, _seconds(self.clock()))
        if not isinstance(after, NetworkSnapshot) or after.desired != desired or after.revision == s.revision:
            raise NetworkApplyUnverified('Desired configuration save could not be verified.')
        return self._project(after, self.driver.read_active())

    def apply(self, actor: SettingsActor, expected_revision: str) -> dict[str, Any]:
        self._require(actor, 'network.service_ports.configure')
        s = self._snapshot(actor, _ref(expected_revision))
        if s.applying: raise SettingsRevisionConflict('Another network operation owns the native lease.')
        previous = _ports(self.driver.read_active())
        if previous == s.desired: raise SettingsRevisionConflict('No pending network change remains at this revision.')
        self._readiness(actor, s.desired)
        claim = self.store.claim(actor.subject, s.revision, previous)
        if not isinstance(claim, NetworkApplyClaim) or claim.actor != actor.subject or claim.revision != s.revision or claim.desired != s.desired or claim.previous != previous:
            raise NetworkApplyUnverified('Native exclusive apply claim could not be verified.')
        armed = False; confirmed = False
        try:
            if self.driver.arm_rollback(claim.reference, previous) is not True:
                raise NetworkApplyUnverified('Native rollback timer was not proven armed.')
            armed = True
            self._readiness(actor, claim.desired)  # Recheck after potentially slow recovery setup.
            self.driver.apply(claim.reference, claim.desired)
            active = _ports(self.driver.read_active())
            if active != claim.desired: raise NetworkApplyUnverified('Active listener ports did not match the saved plan.')
            event = self._event(actor, 'network.apply.verified', claim.reference)
            audited = self.store.mark_applied(claim, active, event)
            if not isinstance(audited, NetworkSnapshot) or audited.revision == s.revision or audited.desired != claim.desired or not audited.applying:
                raise NetworkApplyUnverified('Native verified state/audit was not persisted under the exclusive claim.')
            self.driver.confirm(claim.reference)
            confirmed = True
            final = self._snapshot(actor)
            observed = _ports(self.driver.read_active())
            if not final.applying or final.desired != observed or final.revision != audited.revision:
                raise NetworkApplyUnverified('Network state changed before final verification.')
            self.store.release(claim)
            # Return the observation made while this operation still owned the
            # native lease. Never issue a late rollback after lease release.
            return {'effective': self._project(NetworkSnapshot(final.revision, final.desired), observed), 'audit': {'id': event['id']}}
        except Exception as reason:
            recovered = False
            try:
                if not confirmed:
                    if armed: self.driver.rollback(claim.reference)
                    recovered = _ports(self.driver.read_active()) == previous
                # After timer confirmation/release uncertainty, old recovery
                # authority cannot be reused against a potentially new owner.
            except Exception:
                recovered = False
            failure = self._event(actor, 'network.apply.rolled_back' if recovered else 'network.apply.unknown', claim.reference)
            try: self.store.fail(claim, failure, recovered)
            except Exception: recovered = False
            raise NetworkApplyUnverified('Network apply was not verified; ' + ('previous ports restored.' if recovered else 'native recovery and operation reconciliation are required.')) from None
