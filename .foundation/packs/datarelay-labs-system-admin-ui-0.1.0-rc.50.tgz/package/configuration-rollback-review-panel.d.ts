import { type CapabilityAvailability, type ConfigurationRollbackReviewProjection } from "@datarelay-labs/system-contracts";
export type ConfigurationRollbackReviewPanelProps = {
    /** Current immutable and product-authorized safe revision-only snapshot. */
    projection?: ConfigurationRollbackReviewProjection;
    reviewAvailability?: CapabilityAvailability | "unknown";
    /** Navigates product review/confirmation, NEVER restores configuration. */
    onReviewRollback?: (currentRevision: string, targetRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Strict preview of allowlisted field paths only. Real product applies under
 * actor authorization, CAS, backup and tested rollback. No secret values. */
export declare function ConfigurationRollbackReviewPanel({ projection, reviewAvailability, onReviewRollback, pending }: ConfigurationRollbackReviewPanelProps): import("react").JSX.Element;
