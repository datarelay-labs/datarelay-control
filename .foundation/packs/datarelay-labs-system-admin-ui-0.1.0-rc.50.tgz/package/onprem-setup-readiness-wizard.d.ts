import { type CapabilityAvailability, type OnPremSetupReadinessProjection } from "@datarelay-labs/system-contracts";
export type OnPremSetupReadinessWizardProps = {
    /** Product-authenticated, currently authorized setup evidence. */
    projection?: OnPremSetupReadinessProjection;
    /** Only the product, not this wizard, grants a review operation. */
    reviewAvailability?: CapabilityAvailability | "unknown";
    onReviewLaunch?: (currentRevision: string) => void | Promise<void>;
    pending?: boolean;
};
/** Six fixed first-run areas, stepper is local/navigation-only.
 * Product owns first administrator, source ACL, NTP/DNS/TLS, notifications,
 * backup/drill, audit, session and all real setup/migration effects. */
export declare function OnPremSetupReadinessWizard({ projection, reviewAvailability, onReviewLaunch, pending }: OnPremSetupReadinessWizardProps): import("react").JSX.Element;
