import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button, StatusBadge } from "@datarelay-labs/ui";
const record = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const ref = (v) => typeof v === "string" && /^[a-zA-Z0-9_.:-]{1,256}$/.test(v);
const kinds = ["webhook", "slack", "email"];
const integer = (v, lo, hi) => typeof v === "number" && Number.isSafeInteger(v) && v >= lo && v <= hi;
function validReceipt(v) {
    return record(v) && ref(v.id) && ref(v.ruleId) &&
        typeof v.channel === "string" && v.channel.length <= 80 && typeof v.status === "string" && v.status.length <= 80 &&
        typeof v.timestamp === "string" && Number.isFinite(Date.parse(v.timestamp)) && (v.detail === undefined || (typeof v.detail === "string" && v.detail.length <= 512));
}
function validState(v) {
    if (!record(v) || typeof v.monitorEnabled !== "boolean" || !integer(v.cooldownSeconds, 10, 86400) || !Array.isArray(v.rules) || v.rules.length > 128 ||
        !Array.isArray(v.channels) || v.channels.length > 3 || !Array.isArray(v.history) || v.history.length > 1000)
        return false;
    return v.rules.every(r => record(r) && ref(r.id) && typeof r.enabled === "boolean" && (r.severity === "WARNING" || r.severity === "CRITICAL") &&
        (r.lastTriggeredAt === null || (typeof r.lastTriggeredAt === "string" && Number.isFinite(Date.parse(r.lastTriggeredAt))))) &&
        new Set(v.rules.map(r => r.id)).size === v.rules.length && v.channels.every(c => record(c) && kinds.includes(c.kind) &&
        ref(c.revision) && typeof c.configured === "boolean" && typeof c.supported === "boolean" && typeof c.label === "string" && c.label.length <= 256) &&
        new Set(v.channels.map(c => c.kind)).size === v.channels.length && v.history.every(validReceipt) && new Set(v.history.map(r => r.id)).size === v.history.length;
}
const validRead = (v) => record(v) && validState(v.effective);
const makeDraft = (s, revision) => ({ expectedRevision: revision, monitorEnabled: s.monitorEnabled,
    cooldownSeconds: s.cooldownSeconds, rules: s.rules.map(r => ({ id: r.id, enabled: r.enabled, severity: r.severity })), destinations: {} });
function samePolicy(a, s) {
    return a.monitorEnabled === s.monitorEnabled && a.cooldownSeconds === s.cooldownSeconds &&
        a.rules.length === s.rules.length && a.rules.every(r => s.rules.some(v => v.id === r.id && v.enabled === r.enabled && v.severity === r.severity));
}
function draftError(d, s) {
    if (!integer(d.cooldownSeconds, 10, 86400))
        return "Cooldown must be 10–86400 seconds.";
    if (d.rules.length !== s.rules.length || new Set(d.rules.map(r => r.id)).size !== d.rules.length || d.rules.some(r => !s.rules.some(v => v.id === r.id) || typeof r.enabled !== "boolean" || !["WARNING", "CRITICAL"].includes(r.severity)))
        return "Unknown or invalid alert rule.";
    for (const [kind, value] of Object.entries(d.destinations)) {
        if (!s.channels.some(c => c.kind === kind))
            return "Unknown alert channel.";
        if (value === null)
            continue;
        if (typeof value !== "string" || !value.trim() || value.length > 2048)
            return "Enter a valid destination or choose Clear.";
        if (kind === "email") {
            if (!value.split(",").every(v => /^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(v.trim())))
                return "Enter valid comma-separated email addresses.";
        }
        else {
            try {
                const url = new URL(value);
                if (!["https:", "http:"].includes(url.protocol) || url.username || url.password || url.hash)
                    throw Error();
            }
            catch {
                return "Enter an HTTP or HTTPS destination without embedded credentials or fragment.";
            }
        }
    }
    return null;
}
function proofValid(p, revision) {
    return record(p) && p.expectedRevision === revision && ref(p.previewRef) &&
        ["allowed", "actorAuthorized", "recentMfaVerified", "auditReady", "destinationsVerified"].every(k => typeof p[k] === "boolean") && Array.isArray(p.blockers) && p.blockers.length <= 32 && p.blockers.every(b => typeof b === "string" && b.length <= 512);
}
const safe = (p) => p.allowed && p.actorAuthorized && p.recentMfaVerified && p.auditReady && p.destinationsVerified && p.blockers.length === 0;
/** Do not echo native exceptions containing write-only destination credentials. */
const safeError = (e) => e instanceof Error && /revision|stale|changed/i.test(e.message) ? "Alert settings changed. Refresh and review again." :
    e instanceof Error && /permission|forbidden|authoriz/i.test(e.message) ? "The product did not authorize this alert operation." : "Alert operation could not be verified. Refresh and inspect the product audit.";
export function OperationalAlerts({ adapter, canRead = false, canManage = false, canTest = false }) {
    const id = useId();
    const op = useRef(0);
    const live = useRef({ adapter, canRead, canManage, canTest });
    live.current = { adapter, canRead, canManage, canTest };
    const [loaded, setLoaded] = useState(null);
    const [draft, setDraft] = useState(null);
    const [editing, setEditing] = useState(false);
    const [plan, setPlan] = useState(null);
    const [ack, setAck] = useState(false);
    const [testRule, setTestRule] = useState(null);
    const [testAck, setTestAck] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const row = canRead && loaded?.adapter === adapter ? loaded.row : null;
    const state = row?.effective;
    const editor = canManage && ref(row?.revision) && typeof adapter.configure === "function" && typeof adapter.preview === "function";
    const tester = canTest && ref(row?.revision) && typeof adapter.test === "function" && state?.channels.some(c => c.supported && c.configured);
    const changed = Boolean(draft && state && (!samePolicy(draft, state) || Object.keys(draft.destinations).length));
    const signature = JSON.stringify(draft);
    const currentPlan = editor && plan?.signature === signature ? plan.proof : null;
    const alive = (n, right = "canRead") => op.current === n && live.current.adapter === adapter && live.current.canRead && live.current[right];
    function accept(r) { setLoaded({ adapter, row: r }); setDraft(makeDraft(r.effective, ref(r.revision) ? r.revision : "")); }
    function clearPlan() { setPlan(null); setAck(false); setError(""); setNotice(""); }
    useEffect(() => {
        const n = ++op.current;
        setLoaded(null);
        setDraft(null);
        setEditing(false);
        setTestRule(null);
        setTestAck(false);
        clearPlan();
        setBusy(canRead);
        if (canRead)
            void adapter.read().then(r => { if (!alive(n))
                return; if (!validRead(r))
                throw new Error("Invalid settings"); accept(r); })
                .catch(e => { if (alive(n))
                setError(safeError(e)); }).finally(() => { if (alive(n))
                setBusy(false); });
        return () => { op.current++; };
    }, [adapter, canRead, canManage, canTest]);
    async function refresh() {
        if (!canRead || busy)
            return;
        const n = ++op.current;
        clearPlan();
        setBusy(true);
        setEditing(false);
        setTestRule(null);
        setTestAck(false);
        try {
            const r = await adapter.read();
            if (!alive(n))
                return;
            if (!validRead(r))
                throw Error("Invalid settings");
            accept(r);
        }
        catch (e) {
            if (alive(n))
                setError(safeError(e));
        }
        finally {
            if (alive(n))
                setBusy(false);
        }
    }
    function edit(d) { clearPlan(); setDraft(d); }
    async function preview() {
        if (!editor || busy || !changed || !draft || !state)
            return;
        clearPlan();
        const err = draftError(draft, state);
        if (err) {
            setError(err);
            return;
        }
        const n = ++op.current;
        setBusy(true);
        try {
            const p = await adapter.preview(draft);
            if (!alive(n, "canManage"))
                return;
            if (!proofValid(p, draft.expectedRevision))
                throw Error("Invalid preview");
            setPlan({ signature, proof: p });
            if (!safe(p))
                setError("Alert change requires a valid authorization, MFA, destination and audit preview.");
        }
        catch (e) {
            if (alive(n, "canManage"))
                setError(safeError(e));
        }
        finally {
            if (alive(n))
                setBusy(false);
        }
    }
    async function save() {
        if (!editor || busy || !draft || !state || !currentPlan || !safe(currentPlan) || !ack)
            return;
        const n = ++op.current;
        const p = currentPlan;
        setBusy(true);
        clearPlan();
        try {
            const before = await adapter.read();
            if (!alive(n, "canManage"))
                return;
            if (!validRead(before) || before.revision !== draft.expectedRevision || draftError(draft, before.effective))
                throw Error("Stale revision");
            const receipt = await adapter.configure(draft, p.previewRef);
            if (!alive(n, "canManage"))
                return;
            const after = await adapter.read();
            if (!alive(n, "canManage"))
                return;
            if (!validRead(after))
                throw Error("Invalid result");
            if (!ref(receipt?.auditReference) || receipt.revision !== after.revision || after.revision === before.revision || !samePolicy(draft, after.effective))
                throw Error("Unverified policy");
            for (const [kind, value] of Object.entries(draft.destinations)) {
                const a = after.effective.channels.find(c => c.kind === kind);
                const b = before.effective.channels.find(c => c.kind === kind);
                if (!a || a.configured !== Boolean(value) || a.revision === b?.revision)
                    throw Error("Unverified channel change");
            }
            accept(after);
            setEditing(false);
            setNotice("Alert settings saved and verified.");
        }
        catch (e) {
            setDraft(d => d ? { ...d, destinations: {} } : null);
            if (alive(n, "canManage"))
                setError(safeError(e));
        }
        finally {
            if (alive(n))
                setBusy(false);
        }
    }
    async function sendTest() {
        if (!tester || busy || !testRule || !testAck || !row || !ref(row.revision))
            return;
        const n = ++op.current;
        setBusy(true);
        clearPlan();
        setTestAck(false);
        try {
            const before = await adapter.read();
            if (!alive(n, "canTest"))
                return;
            if (!validRead(before) || before.revision !== row.revision || !before.effective.rules.some(r => r.id === testRule) || !before.effective.channels.some(c => c.configured && c.supported))
                throw Error("Stale test scope");
            const result = await adapter.test({ ruleId: testRule, expectedRevision: row.revision });
            if (!alive(n, "canTest"))
                return;
            if (!validReceipt(result) || result.ruleId !== testRule)
                throw Error("Invalid test result");
            const after = await adapter.read();
            if (!alive(n, "canTest"))
                return;
            if (!validRead(after) || !after.effective.history.some(r => r.id === result.id && r.ruleId === result.ruleId && r.status === result.status && r.channel === result.channel))
                throw Error("Missing test record");
            accept(after);
            setTestRule(null);
            setNotice("Test delivery recorded: " + result.status + ". Inbox receipt is not verified.");
        }
        catch (e) {
            if (alive(n, "canTest"))
                setError(safeError(e));
        }
        finally {
            if (alive(n))
                setBusy(false);
        }
    }
    if (!canRead)
        return _jsx("p", { children: "Operational alert settings are unavailable for this session." });
    return _jsxs("section", { className: "dr-admin__alerts", "aria-label": "Operational alerts", children: [_jsxs("header", { children: [_jsx("h3", { children: "Operational alerts" }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void refresh(), children: "Refresh alerts" })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, !state && busy ? _jsx("p", { role: "status", children: "Loading alerts\u2026" }) : null, state ? _jsxs(_Fragment, { children: [_jsxs("p", { children: ["Monitor ", state.monitorEnabled ? "on" : "off", " \u00B7 Cooldown ", state.cooldownSeconds, "s"] }), _jsx("div", { className: "dr-admin__alerts-channels", children: state.channels.map(c => _jsxs("div", { children: [_jsx("strong", { children: c.label }), _jsxs("p", { children: [c.configured ? "Configured" : "Not configured", " \u00B7 ", c.supported ? "Delivery supported" : "Delivery not supported"] })] }, c.kind)) }), _jsx("div", { className: "dr-admin__alerts-table", role: "region", "aria-label": "Alert rule table", tabIndex: 0, children: _jsxs("table", { children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Alert" }), _jsx("th", { children: "Enabled" }), _jsx("th", { children: "Severity" }), _jsx("th", { children: "Last triggered" }), _jsx("th", { children: "Action" })] }) }), _jsx("tbody", { children: state.rules.map(r => _jsxs("tr", { children: [_jsx("th", { scope: "row", children: r.id.replaceAll("_", " ") }), _jsx("td", { children: r.enabled ? "Yes" : "No" }), _jsx("td", { children: r.severity }), _jsx("td", { children: r.lastTriggeredAt ?? "Never" }), _jsx("td", { children: tester ? _jsx(Button, { variant: "secondary", disabled: busy || editing, "aria-label": "Test " + r.id.replaceAll("_", " "), onClick: () => { setTestRule(r.id); setTestAck(false); clearPlan(); }, children: "Test" }) : "Read-only" })] }, r.id)) })] }) }), testRule && tester ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Confirm alert test", children: [_jsx("h4", { children: "Confirm alert test" }), _jsxs("p", { children: ["A test for ", testRule.replaceAll("_", " "), " will use existing supported configured channels."] }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: testAck, disabled: busy, onChange: e => setTestAck(e.target.checked) }), "I confirm sending a test through configured channels"] }), _jsx(Button, { disabled: busy || !testAck, onClick: () => void sendTest(), children: "Send alert test" })] }) : null, editor && !editing ? _jsx(Button, { disabled: busy, onClick: () => { clearPlan(); setDraft(makeDraft(state, row.revision)); setEditing(true); setTestRule(null); }, children: "Edit alert settings" }) : null, editing && editor && draft ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Edit operational alert settings", children: [_jsx("h4", { children: "Alert settings" }), draft.rules.map(r => _jsxs("div", { className: "dr-admin__alerts-rule", children: [_jsx("strong", { children: r.id.replaceAll("_", " ") }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: r.enabled, disabled: busy, onChange: e => edit({ ...draft, rules: draft.rules.map(v => v.id === r.id ? { ...v, enabled: e.target.checked } : v) }) }), r.id.replaceAll("_", " "), " enabled"] }), _jsxs("label", { children: ["Severity for ", r.id.replaceAll("_", " "), _jsxs("select", { value: r.severity, disabled: busy, onChange: e => edit({ ...draft, rules: draft.rules.map(v => v.id === r.id ? { ...v, severity: e.target.value === "CRITICAL" ? "CRITICAL" : "WARNING" } : v) }), children: [_jsx("option", { value: "WARNING", children: "Warning" }), _jsx("option", { value: "CRITICAL", children: "Critical" })] })] })] }, r.id)), _jsx("label", { htmlFor: id + "-cooldown", children: "Cooldown seconds" }), _jsx("input", { id: id + "-cooldown", type: "number", min: 10, max: 86400, value: draft.cooldownSeconds, disabled: busy, onChange: e => edit({ ...draft, cooldownSeconds: Number(e.target.value) }) }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: draft.monitorEnabled, disabled: busy, onChange: e => edit({ ...draft, monitorEnabled: e.target.checked }) }), "Monitor enabled"] }), state.channels.map(c => _jsxs("div", { className: "dr-admin__alerts-destination", children: [_jsxs("label", { htmlFor: id + "-" + c.kind, children: ["New ", c.kind, " destination"] }), _jsx("input", { id: id + "-" + c.kind, type: c.kind === "email" ? "text" : "password", autoComplete: "off", maxLength: 2048, placeholder: "Leave blank to keep " + c.label, value: draft.destinations[c.kind] ?? "", disabled: busy || draft.destinations[c.kind] === null, onChange: e => { const destinations = { ...draft.destinations }; if (e.target.value)
                                            destinations[c.kind] = e.target.value;
                                        else
                                            delete destinations[c.kind]; edit({ ...draft, destinations }); } }), c.configured ? _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: draft.destinations[c.kind] === null, disabled: busy, onChange: e => { const destinations = { ...draft.destinations }; if (e.target.checked)
                                                    destinations[c.kind] = null;
                                                else
                                                    delete destinations[c.kind]; edit({ ...draft, destinations }); } }), "Clear ", c.kind, " destination"] }) : null] }, c.kind)), _jsx(Button, { disabled: busy || !changed, onClick: () => void preview(), children: "Preview alert settings" }), _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => { setEditing(false); setDraft(makeDraft(state, row.revision)); clearPlan(); }, children: "Cancel alert changes" })] }) : null, currentPlan ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "Alert policy review", children: [_jsx("h4", { children: "Review alert settings" }), _jsx("p", { children: "Current product authorization, destination validation and audit are required. Secret destination values are not displayed in this review." }), currentPlan.blockers.length ? _jsx("ul", { children: currentPlan.blockers.map((b, i) => _jsx("li", { children: b }, i)) }) : null, safe(currentPlan) ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: ack, disabled: busy, onChange: e => setAck(e.target.checked) }), "I confirm these alert settings"] }), _jsx(Button, { disabled: busy || !ack, onClick: () => void save(), children: "Save alert settings" })] }) : null] }) : null, _jsxs("section", { "aria-label": "Recent alert deliveries", children: [_jsx("h4", { children: "Recent alert deliveries" }), state.history.length ? _jsx("div", { className: "dr-admin__alerts-table", role: "region", "aria-label": "Scrollable alert delivery history", tabIndex: 0, children: _jsxs("table", { children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Time" }), _jsx("th", { children: "Alert" }), _jsx("th", { children: "Channel" }), _jsx("th", { children: "Delivery status" })] }) }), _jsx("tbody", { children: state.history.map(r => _jsxs("tr", { children: [_jsx("td", { children: r.timestamp }), _jsx("td", { children: r.ruleId.replaceAll("_", " ") }), _jsx("td", { children: r.channel }), _jsx("td", { children: _jsx(StatusBadge, { tone: r.status === "delivered" ? "success" : r.status === "failed" ? "critical" : "neutral", children: r.status }) })] }, r.id)) })] }) }) : _jsx("p", { children: "No delivery attempts reported." })] })] }) : null] });
}
