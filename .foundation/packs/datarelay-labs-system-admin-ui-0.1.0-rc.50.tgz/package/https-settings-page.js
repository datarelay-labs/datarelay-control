import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState } from "react";
import { Button } from "@datarelay-labs/ui";
const VALID_DAYS = [30, 90, 180, 365, 730];
const record = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const revisionValid = (value) => typeof value === "string" && value.length > 0 && value.length <= 256 && !/[\x00-\x20\x7f]/.test(value);
const splitSans = (value) => [...new Set(value.split(",").map(v => v.trim()).filter(Boolean))];
function ipSan(value) {
    if (value.includes(":")) {
        if (!/^[0-9a-fA-F:.]+$/.test(value))
            return false;
        try {
            return new URL("http://[" + value + "]/").hostname.startsWith("[");
        }
        catch {
            return false;
        }
    }
    const parts = value.split(".");
    return parts.length === 4 && parts.every(v => /^(0|[1-9][0-9]{0,2})$/.test(v) && Number(v) <= 255);
}
function dnsSan(value) {
    const host = value.startsWith("*.") ? value.slice(2) : value;
    return host.length > 0 && value.length <= 253 && host.split(".").every(label => /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/.test(label));
}
/** Common SAN validation; certificate/key/chain/issuer policy remains enforced by Core. */
export function validateHttpsConfiguration(value) {
    if (!record(value) || typeof value.enabled !== "boolean" ||
        typeof value.redirectHttpToHttps !== "boolean" || !Array.isArray(value.certificateIpAddresses) ||
        !Array.isArray(value.certificateDnsNames))
        return "Invalid HTTPS configuration.";
    if (!Number.isSafeInteger(value.certificateValidDays) || Number(value.certificateValidDays) < 1 ||
        Number(value.certificateValidDays) > 3650)
        return "Certificate validity must be 1–3650 days.";
    if (value.certificateIpAddresses.length + value.certificateDnsNames.length > 128)
        return "Too many certificate SANs.";
    if (value.certificateIpAddresses.some(ip => typeof ip !== "string" || !ipSan(ip)))
        return "Invalid IP SAN.";
    if (value.certificateDnsNames.some(dns => typeof dns !== "string" || !dnsSan(dns)))
        return "Invalid DNS SAN.";
    if (value.enabled && !value.certificateIpAddresses.length && !value.certificateDnsNames.length)
        return "HTTPS requires at least one IP or DNS SAN.";
    if (!value.enabled && value.redirectHttpToHttps)
        return "HTTP redirect requires HTTPS to be enabled.";
    return null;
}
function validRead(value) {
    if (!record(value) || !record(value.effective) || validateHttpsConfiguration(value.effective))
        return false;
    const s = value.effective;
    return ["httpListenerActive", "httpsListenerActive", "redirectEffective", "restartRequired", "proxyFallbackToHttp"]
        .every(key => typeof s[key] === "boolean") &&
        ["ok", "degraded", "unknown", "not_configured"].includes(String(s.proxyStatus)) &&
        (s.proxyHealthOk === null || typeof s.proxyHealthOk === "boolean") &&
        ["currentAccessUrl", "browserHttpUrl"].every(k => typeof s[k] === "string" && s[k].length <= 2048) &&
        (s.browserHttpsUrl === null || typeof s.browserHttpsUrl === "string") &&
        (s.certificateNotAfter === null || (typeof s.certificateNotAfter === "string" &&
            Number.isFinite(Date.parse(s.certificateNotAfter))));
}
function previewValid(value, revision) {
    if (!record(value) || typeof value.supported !== "boolean" || !record(value.detail))
        return false;
    const d = value.detail;
    return d.expectedRevision === revision && typeof d.safe === "boolean" &&
        typeof d.rollbackAvailable === "boolean" && typeof d.recentMfaVerified === "boolean" &&
        Array.isArray(d.blockers) && d.blockers.length <= 32 &&
        d.blockers.every(b => typeof b === "string" && b.length > 0 && b.length <= 512) &&
        (d.recoveryUrl === undefined || (typeof d.recoveryUrl === "string" && d.recoveryUrl.length <= 2048)) &&
        (value.summary === undefined || typeof value.summary === "string");
}
const safe = (p) => p.supported === true &&
    p.detail?.safe === true && p.detail.rollbackAvailable === true &&
    p.detail.recentMfaVerified === true && p.detail.blockers.length === 0;
const sameSet = (a, b) => a.length === b.length && [...a].sort().every((v, i) => v === [...b].sort()[i]);
function sameConfiguration(a, b) {
    return a.enabled === b.enabled && a.redirectHttpToHttps === b.redirectHttpToHttps &&
        a.certificateValidDays === b.certificateValidDays &&
        sameSet(a.certificateIpAddresses, b.certificateIpAddresses) && sameSet(a.certificateDnsNames, b.certificateDnsNames);
}
const messageOf = (reason) => reason instanceof Error ? reason.message.slice(0, 512) : "HTTPS operation failed.";
/** Complete Control-reference form. Only the injected, authorized TLS adapter has host effects. */
export function HttpsSettingsPage({ adapter, canManage = false }) {
    const id = useId();
    const [loaded, setLoaded] = useState(null);
    const [config, setConfig] = useState(null);
    const [ips, setIps] = useState("");
    const [dns, setDns] = useState("");
    const [regenerate, setRegenerate] = useState(false);
    const [preview, setPreview] = useState(null);
    const [confirmed, setConfirmed] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const operation = useRef(0);
    const live = useRef({ adapter, canManage });
    live.current = { adapter, canManage };
    const row = loaded?.adapter === adapter ? loaded.row : null;
    const state = row?.effective;
    const editor = canManage && revisionValid(row?.revision) && typeof adapter.apply === "function" &&
        typeof adapter.preview === "function";
    const draft = config && row && revisionValid(row.revision) ? {
        enabled: config.enabled, redirectHttpToHttps: config.redirectHttpToHttps,
        certificateValidDays: config.certificateValidDays,
        certificateIpAddresses: splitSans(ips), certificateDnsNames: splitSans(dns),
        regenerateCertificate: regenerate, expectedRevision: row.revision
    } : null;
    const signature = JSON.stringify(draft);
    const dirty = Boolean(draft && state && (regenerate || !sameConfiguration(draft, state)));
    const activePreview = editor && preview?.signature === signature ? preview.value : null;
    const mayApply = activePreview && safe(activePreview) && confirmed && !busy;
    function accept(result) {
        setLoaded({ adapter, row: result });
        setConfig(result.effective);
        setIps(result.effective.certificateIpAddresses.join(", "));
        setDns(result.effective.certificateDnsNames.join(", "));
        setRegenerate(false);
    }
    useEffect(() => {
        const sequence = ++operation.current;
        setLoaded(null);
        setConfig(null);
        setPreview(null);
        setConfirmed(false);
        setBusy(true);
        setError("");
        setNotice("");
        void adapter.read().then(result => {
            if (operation.current !== sequence)
                return;
            if (!validRead(result))
                throw new Error("Invalid HTTPS state returned by product Core.");
            accept(result);
        }).catch(reason => { if (operation.current === sequence)
            setError(messageOf(reason)); })
            .finally(() => { if (operation.current === sequence)
            setBusy(false); });
        return () => { operation.current++; };
    }, [adapter]);
    useEffect(() => { if (!canManage) {
        setPreview(null);
        setConfirmed(false);
    } }, [canManage]);
    function invalidate() { setPreview(null); setConfirmed(false); setError(""); setNotice(""); }
    function alive(sequence, requireManage = true) {
        return operation.current === sequence && live.current.adapter === adapter && (!requireManage || live.current.canManage);
    }
    async function reload() {
        if (busy)
            return;
        const sequence = ++operation.current;
        invalidate();
        setBusy(true);
        try {
            const result = await adapter.read();
            if (!alive(sequence, false))
                return;
            if (!validRead(result))
                throw new Error("Invalid HTTPS state returned by product Core.");
            accept(result);
        }
        catch (reason) {
            if (alive(sequence, false))
                setError(messageOf(reason));
        }
        finally {
            if (alive(sequence, false))
                setBusy(false);
        }
    }
    async function prepare() {
        if (!editor || busy || !draft || !dirty)
            return;
        invalidate();
        const issue = validateHttpsConfiguration(draft);
        if (issue) {
            setError(issue);
            return;
        }
        const sequence = ++operation.current;
        setBusy(true);
        try {
            const result = await adapter.preview(draft);
            if (!alive(sequence))
                return;
            if (!previewValid(result, draft.expectedRevision))
                throw new Error("Invalid or stale product HTTPS preview.");
            setPreview({ signature, value: result });
            if (!safe(result))
                setError("HTTPS change requires safe rollback, current MFA verification and no blockers.");
        }
        catch (reason) {
            if (alive(sequence))
                setError(messageOf(reason));
        }
        finally {
            if (alive(sequence, false))
                setBusy(false);
        }
    }
    async function apply() {
        if (!editor || !mayApply || !draft || !state)
            return;
        const sequence = ++operation.current;
        setBusy(true);
        invalidate();
        try {
            const before = await adapter.read();
            if (!alive(sequence))
                return;
            if (!validRead(before) || before.revision !== draft.expectedRevision || !sameConfiguration(before.effective, state))
                throw new Error("HTTPS settings changed since you previewed. Refresh and review again.");
            await adapter.apply(draft);
            if (!alive(sequence))
                return;
            const after = await adapter.read();
            if (!alive(sequence))
                return;
            if (!validRead(after))
                throw new Error("Invalid HTTPS read-back after apply.");
            accept(after);
            if (!revisionValid(after.revision) || after.revision === draft.expectedRevision ||
                !sameConfiguration(after.effective, draft) || after.effective.restartRequired ||
                after.effective.httpsListenerActive !== draft.enabled ||
                after.effective.redirectEffective !== draft.redirectHttpToHttps ||
                after.effective.proxyFallbackToHttp || after.effective.proxyStatus !== "ok" || after.effective.proxyHealthOk !== true)
                throw new Error("HTTPS configuration not confirmed by authoritative read-back. Review listener status and recovery.");
            setNotice("HTTPS configuration applied and verified.");
        }
        catch (reason) {
            if (alive(sequence)) {
                const message = messageOf(reason);
                setError(/failed to fetch|networkerror|connection.*(reset|closed|aborted)/i.test(message)
                    ? "HTTPS apply status unknown after connection interruption. Reconnect and refresh; do not blindly retry."
                    : message);
            }
        }
        finally {
            if (alive(sequence, false))
                setBusy(false);
        }
    }
    return _jsxs("section", { className: "dr-admin__https", "aria-label": "HTTPS settings", children: [_jsxs("header", { children: [_jsx("h3", { children: "HTTPS / Certificate Settings" }), _jsx("p", { children: "Review listener state and certificates, preview your change, then confirm apply and verify connectivity." })] }), error ? _jsx("p", { role: "alert", children: error }) : null, notice ? _jsx("p", { role: "status", children: notice }) : null, !state && busy ? _jsx("p", { role: "status", children: "Loading HTTPS settings\u2026" }) : null, state && config ? _jsxs(_Fragment, { children: [_jsx("dl", { className: "dr-admin__timezone-facts", children: [["HTTP listener", state.httpListenerActive ? "Active" : "Inactive"], ["HTTPS listener", state.httpsListenerActive ? "Active" : "Inactive"],
                            ["Redirect effective", state.redirectEffective ? "Yes" : "No"], ["Proxy status", state.proxyStatus],
                            ["Proxy health", state.proxyHealthOk === null ? "Unknown" : state.proxyHealthOk ? "OK" : "Failed"],
                            ["Certificate valid to", state.certificateNotAfter ?? "Not reported"], ["Restart required", state.restartRequired ? "Yes" : "No"],
                            ["HTTP fallback", state.proxyFallbackToHttp ? "Yes" : "No"]].map(([label, value]) => _jsxs("div", { children: [_jsx("dt", { children: label }), _jsx("dd", { children: value })] }, label)) }), _jsx("div", { className: "dr-admin__https-urls", children: [["Current access URL", state.currentAccessUrl], ["Browser HTTP URL", state.browserHttpUrl],
                            ["Browser HTTPS URL", state.browserHttpsUrl ?? "Not available"]].map(([label, value]) => _jsxs("div", { children: [_jsx("strong", { children: label }), _jsx("code", { children: value })] }, label)) }), _jsxs("div", { className: "dr-admin__https-fields", children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: config.enabled, disabled: !editor || busy, onChange: e => { invalidate(); setConfig({ ...config, enabled: e.target.checked, redirectHttpToHttps: e.target.checked && config.redirectHttpToHttps }); } }), "Enable HTTPS"] }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: config.redirectHttpToHttps, disabled: !editor || busy || !config.enabled, onChange: e => { invalidate(); setConfig({ ...config, redirectHttpToHttps: e.target.checked }); } }), "Redirect HTTP to HTTPS"] }), _jsx("label", { htmlFor: id + "-ips", children: "Certificate IP addresses (SAN)" }), _jsx("input", { id: id + "-ips", value: ips, maxLength: 8192, disabled: !editor || busy, onChange: e => { invalidate(); setIps(e.target.value); }, placeholder: "192.0.2.10, 2001:db8::10" }), _jsx("label", { htmlFor: id + "-dns", children: "Certificate DNS names (SAN)" }), _jsx("input", { id: id + "-dns", value: dns, maxLength: 32768, disabled: !editor || busy, onChange: e => { invalidate(); setDns(e.target.value); }, placeholder: "console.example.com" }), _jsx("label", { htmlFor: id + "-days", children: "Certificate valid days" }), _jsx("select", { id: id + "-days", value: config.certificateValidDays, disabled: !editor || busy, onChange: e => { invalidate(); setConfig({ ...config, certificateValidDays: Number(e.target.value) }); }, children: [...new Set([...VALID_DAYS, config.certificateValidDays])].sort((a, b) => a - b).map(n => _jsx("option", { value: n, children: n }, n)) }), _jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: regenerate, disabled: !editor || busy, onChange: e => { invalidate(); setRegenerate(e.target.checked); } }), "Regenerate self-signed certificate on apply"] })] }), editor ? _jsx(Button, { disabled: !dirty || busy, onClick: () => void prepare(), children: "Preview HTTPS change" }) : _jsx("p", { className: "dr-admin__muted", children: "HTTPS configuration is read-only for this session." }), activePreview ? _jsxs("section", { className: "dr-admin__network-review", "aria-label": "HTTPS safety review", children: [_jsx("h4", { children: "Review HTTPS change" }), _jsx("p", { children: activePreview.summary }), activePreview.detail?.blockers.length ? _jsx("ul", { children: activePreview.detail.blockers.map((b, i) => _jsx("li", { children: b }, i)) }) : null, activePreview.detail?.recoveryUrl ? _jsxs("p", { children: ["Product recovery address: ", _jsx("code", { children: activePreview.detail.recoveryUrl })] }) : null, safe(activePreview) ? _jsxs(_Fragment, { children: [_jsxs("label", { children: [_jsx("input", { type: "checkbox", checked: confirmed, disabled: busy, onChange: e => setConfirmed(e.target.checked) }), "I confirm HTTPS connectivity and rollback risks"] }), _jsx(Button, { disabled: !mayApply, onClick: () => void apply(), children: "Apply HTTPS configuration" })] }) : null] }) : null] }) : null, _jsx(Button, { variant: "secondary", disabled: busy, onClick: () => void reload(), children: "Refresh HTTPS settings" })] });
}
