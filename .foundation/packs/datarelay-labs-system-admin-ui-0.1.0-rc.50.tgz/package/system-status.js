import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Card, StatusBadge } from "@datarelay-labs/ui";
export function SystemStatus({ health, info, triageLoadedHealthChecks = false }) {
    const [attentionOnly, setAttentionOnly] = useState(false);
    const suppliedChecks = health?.checks ?? [];
    // Unknown is not healthy; the product-supplied overall health is never recomputed.
    const displayedChecks = triageLoadedHealthChecks && attentionOnly
        ? suppliedChecks.filter((check) => check.status !== "healthy") : suppliedChecks;
    const healthTone = health?.status === "healthy"
        ? "success"
        : health?.status === "unhealthy"
            ? "critical"
            : health?.status === "degraded"
                ? "warning"
                : "neutral";
    return (_jsxs("div", { className: "dr-admin__status-grid", children: [health ? (_jsxs(Card, { title: "Health", actions: _jsx(StatusBadge, { tone: healthTone, children: health.status }), children: [triageLoadedHealthChecks && suppliedChecks.length ? (_jsxs("div", { className: "dr-admin__health-triage", children: [_jsxs("label", { className: "dr-admin__health-triage-label", children: [_jsx("input", { type: "checkbox", checked: attentionOnly, onChange: (event) => setAttentionOnly(event.target.checked) }), "Show only checks needing attention"] }), _jsxs("p", { className: "dr-admin__muted", role: "status", "aria-live": "polite", children: ["Showing ", displayedChecks.length, " of ", suppliedChecks.length, " loaded component checks. Unknown is included in attention."] })] })) : null, suppliedChecks.length ? (displayedChecks.length ? (_jsx("ul", { className: "dr-admin__check-list", "aria-label": triageLoadedHealthChecks ? "Component health checks" : undefined, children: displayedChecks.map((check) => (_jsxs("li", { children: [_jsx("span", { children: check.label }), _jsx("span", { children: check.status }), check.detail ? _jsx("small", { children: check.detail }) : null] }, check.id))) })) : _jsx("p", { className: "dr-admin__muted", children: "No loaded component checks need attention." })) : _jsx("p", { className: "dr-admin__muted", children: "No component checks were supplied." })] })) : null, info ? (_jsx(Card, { title: "System information", children: _jsx("dl", { className: "dr-admin__facts", children: info.facts.map((fact) => (_jsxs("div", { children: [_jsx("dt", { children: fact.label }), _jsx("dd", { children: fact.value })] }, fact.id))) }) })) : null] }));
}
